export async function runControls(){
const cases=[
 {name:'toronto-omitted-pisces',date:'1919-03-31',zone:'America/Toronto',witnesses:['1919-03-31T04:29:59.999Z','1919-03-31T04:30:00.000Z','1919-03-31T04:45:00.000Z','1919-04-01T03:59:59.999Z']},
 {name:'toronto-prior-date-extension',date:'1919-03-30',zone:'America/Toronto',witnesses:['1919-03-31T04:29:59.999Z','1919-03-31T04:30:00.000Z']},
 {name:'st-johns-return',date:'2009-10-31',zone:'America/St_Johns',witnesses:['2009-11-01T02:29:59.999Z','2009-11-01T02:30:00.000Z','2009-11-01T02:31:00.000Z','2009-11-01T03:29:59.999Z']},
 {name:'st-johns-disconnected',date:'2009-11-01',zone:'America/St_Johns',witnesses:['2009-11-01T02:30:00.000Z','2009-11-01T02:31:00.000Z','2009-11-01T03:30:00.000Z']},
 {name:'apia-repeated',date:'1892-07-04',zone:'Pacific/Apia',witnesses:['1892-07-03T11:26:56.000Z','1892-07-05T11:26:55.999Z']},
 {name:'juneau-repeat',date:'1867-10-18',zone:'America/Juneau',witnesses:['1867-10-19T00:31:12.000Z','1867-10-19T00:31:13.000Z','1867-10-19T08:57:40.999Z','1867-10-19T09:02:18.999Z']},
 {name:'ordinary',date:'1990-01-04',zone:'Asia/Bangkok',witnesses:['1990-01-03T17:00:00.000Z','1990-01-04T16:59:59.999Z']},
 {name:'new-york-short-date',date:'2024-03-10',zone:'America/New_York',witnesses:['2024-03-10T05:00:00.000Z','2024-03-11T03:59:59.999Z']},
 {name:'apia-skipped-rejected',date:'2011-12-30',zone:'Pacific/Apia',witnesses:['2011-12-30T10:00:00.000Z']},
];
const sign=(lon:number)=>signForLongitude(lon).slug;const rows:any[]=[];
for(const item of cases){
 const input={date:item.date,time:'',timeKnown:false,city:{tz:item.zone,lat:0,lon:0},houseSystem:'whole'};
 let chart:any;try{chart=captureChart(input);}catch(error){chart={error:String(error)};}
 const moon=await captureMoon(item.date,'',item.zone);
 const wall=(instant:string)=>new Intl.DateTimeFormat('en-US-u-ca-gregory-nu-latn',{timeZone:item.zone,year:'numeric',month:'2-digit',day:'2-digit',era:'short',hour:'2-digit',minute:'2-digit',second:'2-digit',hourCycle:'h23'}).format(new Date(instant));
 const observations=item.witnesses.map(instant=>{const utc=new Date(instant),lon=actualEngine.bodyLongitude('Moon',utc),sun=actualEngine.bodyLongitude('Sun',utc);return {instant,wall:wall(instant),member:localDateContainsUtc(item.date,utc,item.zone),moon:lon,moonSign:sign(lon),sun,sunSign:sign(sun),phase:moonPhaseName(utc)};});
 let presentation:any=null,referenceOnly:any=null;
 if(chart.result){
  const data=chart.result;const shape=(chart:any)=>({moonLabel:moonLabel(chart,'en'),uncertain:moonIsUncertain(chart),moonTrust:buildChartContext({...chart,timeKnown:chart.input.timeKnown}).placements.find(p=>p.body==='Moon'),approach:approachRead(chart),signature:chartSignature(chart,'en')});
  presentation=shape(data);referenceOnly=shape({...data,moonSignCandidates:[]});
  const receipt=JSON.parse(chart.receipt);chart={...chart,receipt:{reference:receipt.receipt.reference,instant:receipt.receipt.instant,context:receipt.receipt.localResolution},referenceMember:localDateContainsUtc(item.date,data.input.utc,item.zone),referenceMoonSign:sign(data.bodies.find(p=>p.body==='Moon').lon),candidates:data.moonSignCandidates,pointBodies:data.bodies};delete chart.result;
 }
 rows.push({...item,chart,moon:{...moon,displayedSigns:moon.result?[sign(moon.result.lon),...(moon.result.altLon===null?[]:[sign(moon.result.altLon)])]:[]},observations,presentation,referenceOnly});
}
const phases=[];for(const date of ['2024-01-01','2024-01-09','2024-01-16','2024-04-07']){const instants=['00:00:00.000','12:00:00.000','23:59:59.999'].map(time=>date+'T'+time+'Z');const calls=instants.map(instant=>({instant,phase:moonPhaseName(new Date(instant)),moon:actualEngine.bodyLongitude('Moon',new Date(instant)),sun:actualEngine.bodyLongitude('Sun',new Date(instant))}));phases.push({date,calls,lookup:await captureMoon(date,'',null)});}
const known=[];for(const input of [{date:'1919-03-31',zone:'America/Toronto',time:'00:30'},{date:'1990-01-04',zone:'Asia/Bangkok',time:'12:00'},{date:'2011-12-30',zone:'Pacific/Apia',time:'08:30'}]){const c=captureChart({date:input.date,time:input.time,timeKnown:true,city:{tz:input.zone,lat:0,lon:0},houseSystem:'whole'});known.push({...input,moon:await captureMoon(input.date,input.time,input.zone),chart:{instant:c?.result.input.utc.toISOString(),moon:c?.result.bodies.find(p=>p.body==='Moon'),uncertain:moonIsUncertain(c!.result),candidates:c?.result.moonSignCandidates??null}});}
return {temporalAvailable:typeof globalThis.Temporal!=='undefined',rows,phases,known,qualification:'Finite counterexamples and controls only; no interval enumeration, sample completeness or independent astronomical accuracy claim. Reference-only comparison changes an in-memory presentation metadata copy solely to evaluate policy; product source and numerical result are unchanged.'};
}
