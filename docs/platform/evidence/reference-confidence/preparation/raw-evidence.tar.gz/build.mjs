import {readFile,writeFile,mkdir} from 'node:fs/promises';import {createRequire} from 'node:module';import {createHash} from 'node:crypto';import {resolve,dirname} from 'node:path';import assert from 'node:assert/strict';
const root='/Users/chiburashka/.codex/worktrees/4806/site',out=import.meta.dirname,require=createRequire(root+'/package.json');const ts=require('typescript'),{build}=require('esbuild');const sha=b=>createHash('sha256').update(b).digest('hex');
const records=[];async function declaration(path,name){const source=await readFile(root+'/'+path,'utf8'),tree=ts.createSourceFile(path,source,ts.ScriptTarget.Latest,true,ts.ScriptKind.TSX);let found;const visit=node=>{if(ts.isFunctionDeclaration(node)&&node.name?.text===name)found=node;ts.forEachChild(node,visit)};visit(tree);assert.ok(found);return {source,tree,node:found};}
function record(path,name,node,tree,text=node.getText(tree)){records.push({path,name,start:tree.getLineAndCharacterOfPosition(node.getStart(tree)).line+1,end:tree.getLineAndCharacterOfPosition(node.end).line+1,sha256:sha(text)});return text;}
const moon=await declaration('src/islands/MoonPhaseTool.tsx','lookup'),illum=await declaration('src/islands/MoonPhaseTool.tsx','moonIlluminationFromAngle');const chart=await declaration('src/islands/ChartCalculator.tsx','runChart');const tryNode=chart.node.body.statements.find(ts.isTryStatement);assert.ok(tryNode);
const statements=[...tryNode.tryBlock.statements];const first=statements.findIndex(node=>node.getText(chart.tree).startsWith('const effectiveTime ='));
const last=statements.findIndex(node=>ts.isIfStatement(node)&&node.getText(chart.tree).includes('moonCandidatesFromEndpoints(startBodies, endBodies)'));
assert.ok(first>=0&&last>first);const block=statements.slice(first,last+1).map(node=>node.getText(chart.tree)).join('\n');records.push({path:'src/islands/ChartCalculator.tsx',name:'exact runChart calculation and certainty statements',start:chart.tree.getLineAndCharacterOfPosition(statements[first].getStart(chart.tree)).line+1,end:chart.tree.getLineAndCharacterOfPosition(statements[last].end).line+1,sha256:sha(block)});
const imports=`import * as actualEngine from '${root}/src/lib/engine/full';
import * as receiptModule from '${root}/src/lib/engine/calculator-receipt';
import {localDateContainsUtc,resolveLocalToUtc} from '${root}/src/lib/time/localToUtc';
import {localDateEndpointsUtc,stableBodySignSlug} from '${root}/src/lib/chart-date-certainty';
import {moonCandidatesFromEndpoints,moonIsUncertain,moonLabel} from '${root}/src/lib/moon-certainty';
import {signForLongitude} from '${root}/src/lib/signs';
import {moonPhaseName} from '${root}/src/lib/engine/lite';
import {buildChartContext} from '${root}/src/lib/chart-context';
import {approachRead} from '${root}/src/lib/approach';
import {chartSignature} from '${root}/src/lib/chart-signature';
import {t} from '${root}/src/lib/i18n';
`;
const helper=imports+`
export function captureChart(input:any){const mode='full';const calls:any[]=[];const engine={...actualEngine,computeBodies(utc:Date){calls.push({kind:'bodies',instant:utc.toISOString()});return actualEngine.computeBodies(utc);},computeChart(input:any){calls.push({kind:'legacyNatal',instant:input.utc.toISOString()});return actualEngine.computeChart(input);}};const runIsCurrent=()=>true;const localDateReferenceFailure=new Error('localDateReferenceError');
${block}
return {result,resolved,receipt:portable?.envelopeJson??null,nextMoonAmbiguous,nextRegistryRecordSlug,calls};}
export async function captureMoon(date:string,time:string,zone:string|null){const city=zone?{tz:zone}:null,locale='en',lookupRevisionRef={current:0},focusAfterComputeRef={current:false};const state:any={result:null,error:'',busy:false,calls:[],errors:[]};const loadEngine=async()=>({...actualEngine,bodyLongitude(body:any,utc:Date){const lon=actualEngine.bodyLongitude(body,utc);state.calls.push({body,instant:utc.toISOString(),lon});return lon;}});const setBusy=(v:any)=>state.busy=v,setError=(v:any)=>state.error=v,setResult=(v:any)=>state.result=v;const calculationError=(_err:any,_loc:any,fallback:any)=>fallback;const console={error:(error:any)=>state.errors.push(String(error))};
${record('src/islands/MoonPhaseTool.tsx','lookup',moon.node,moon.tree)}
${record('src/islands/MoonPhaseTool.tsx','moonIlluminationFromAngle',illum.node,illum.tree)}
await lookup({preventDefault(){}} as Event);return state;}
export {actualEngine,localDateContainsUtc,resolveLocalToUtc,localDateEndpointsUtc,stableBodySignSlug,moonLabel,moonIsUncertain,signForLongitude,moonPhaseName,buildChartContext,approachRead,chartSignature};
`;
await writeFile(out+'/caller-harness.ts',helper);const entry=helper+await readFile(out+'/controls.ts','utf8');await writeFile(out+'/entry.ts',entry);
const built=await build({absWorkingDir:root,stdin:{contents:entry,resolveDir:root,loader:'ts'},bundle:true,write:false,format:'esm',platform:'browser',define:{'import.meta.env.SSR':'true'},target:'es2022',metafile:true});const bytes=built.outputFiles[0].contents;await writeFile(out+'/subject.mjs',bytes);
const inputs=[];for(const path of Object.keys(built.metafile.inputs).filter(p=>p!=='<stdin>')){const file=resolve(root,path),b=await readFile(file);inputs.push({path,bytes:b.length,sha256:sha(b)});if(!path.startsWith('node_modules/')){const target=resolve(out,'source',path);await mkdir(dirname(target),{recursive:true});await writeFile(target,b);}}
for(const path of ['src/islands/ChartCalculator.tsx','src/islands/MoonPhaseTool.tsx','src/pages/moon-phase/index.astro']){const b=await readFile(root+'/'+path);const target=resolve(out,'source',path);await mkdir(dirname(target),{recursive:true});await writeFile(target,b);inputs.push({path,bytes:b.length,sha256:sha(b)});}
await writeFile(out+'/identity.json',JSON.stringify({records,inputs,bundleSha256:sha(bytes),qualification:'Exact AST-extracted Moon lookup and ChartCalculator numerical/receipt/certainty statement block. Observable state setters and synchronous current-run control replace only surrounding UI state. All time, receipt, engine, trust and sign methods are actual current source. No product code is modified.'},null,2)+'\n');console.log(JSON.stringify({sourceFiles:inputs.length,extractions:records.length,bundleBytes:bytes.length}));
