import * as actualEngine from '/Users/chiburashka/.codex/worktrees/4806/site/src/lib/engine/full';
import * as receiptModule from '/Users/chiburashka/.codex/worktrees/4806/site/src/lib/engine/calculator-receipt';
import {localDateContainsUtc,resolveLocalToUtc} from '/Users/chiburashka/.codex/worktrees/4806/site/src/lib/time/localToUtc';
import {localDateEndpointsUtc,stableBodySignSlug} from '/Users/chiburashka/.codex/worktrees/4806/site/src/lib/chart-date-certainty';
import {moonCandidatesFromEndpoints,moonIsUncertain,moonLabel} from '/Users/chiburashka/.codex/worktrees/4806/site/src/lib/moon-certainty';
import {signForLongitude} from '/Users/chiburashka/.codex/worktrees/4806/site/src/lib/signs';
import {moonPhaseName} from '/Users/chiburashka/.codex/worktrees/4806/site/src/lib/engine/lite';
import {buildChartContext} from '/Users/chiburashka/.codex/worktrees/4806/site/src/lib/chart-context';
import {approachRead} from '/Users/chiburashka/.codex/worktrees/4806/site/src/lib/approach';
import {chartSignature} from '/Users/chiburashka/.codex/worktrees/4806/site/src/lib/chart-signature';
import {t} from '/Users/chiburashka/.codex/worktrees/4806/site/src/lib/i18n';

export function captureChart(input:any){const mode='full';const calls:any[]=[];const engine={...actualEngine,computeBodies(utc:Date){calls.push({kind:'bodies',instant:utc.toISOString()});return actualEngine.computeBodies(utc);},computeChart(input:any){calls.push({kind:'legacyNatal',instant:input.utc.toISOString()});return actualEngine.computeChart(input);}};const runIsCurrent=()=>true;const localDateReferenceFailure=new Error('localDateReferenceError');
const effectiveTime = input.timeKnown ? input.time : '12:00';
const resolved = resolveLocalToUtc(input.date, effectiveTime, input.city.tz);
if (!input.timeKnown) {
        try {
          if (!localDateContainsUtc(input.date, resolved.utc, input.city.tz)) throw localDateReferenceFailure;
        } catch { throw localDateReferenceFailure; }
      }
const calculationInput = {
        utc: resolved.utc,
        latitude: input.city.lat,
        longitude: input.city.lon,
        houseSystem: input.houseSystem,
        timeKnown: input.timeKnown,
        flags: resolved.flags,
      };
const portable = receiptModule?.computeCalculatorReceipt(calculationInput, {
        date: input.date,
        time: effectiveTime,
        timeZone: input.city.tz,
        offsetMinutes: resolved.offsetMinutes,
        reference: input.timeKnown ? 'supplied-instant' : 'local-noon',
      });
const result = portable ? portable.chart : engine.computeChart(calculationInput);
if (!runIsCurrent()) return;
const computedSun = result.bodies.find((body) => body.body === 'Sun');
const computedSunSlug = computedSun ? signForLongitude(computedSun.lon).slug : null;
let nextMoonAmbiguous = false;
let nextRegistryRecordSlug = mode === 'full' && input.timeKnown ? computedSunSlug : null;
if (!input.timeKnown) {
        // Compute the local civil date's endpoints once. Moon uncertainty
        // reaches result/share notices; Sun uncertainty fails the singular
        // Registry bridge closed instead of trusting the noon reference.
        const endpoints = localDateEndpointsUtc(input.date, input.city.tz);
        const startBodies = engine.computeBodies(endpoints.start);
        const endBodies = engine.computeBodies(endpoints.end);
        result.moonSignCandidates = moonCandidatesFromEndpoints(startBodies, endBodies);
        nextMoonAmbiguous = moonIsUncertain(result);
        const stableSunSlug = stableBodySignSlug('Sun', startBodies, endBodies);
        nextRegistryRecordSlug = mode === 'full' && stableSunSlug === computedSunSlug
          ? stableSunSlug
          : null;
      }
return {result,resolved,receipt:portable?.envelopeJson??null,nextMoonAmbiguous,nextRegistryRecordSlug,calls};}
export async function captureMoon(date:string,time:string,zone:string|null){const city=zone?{tz:zone}:null,locale='en',lookupRevisionRef={current:0},focusAfterComputeRef={current:false};const state:any={result:null,error:'',busy:false,calls:[],errors:[]};const loadEngine=async()=>({...actualEngine,bodyLongitude(body:any,utc:Date){const lon=actualEngine.bodyLongitude(body,utc);state.calls.push({body,instant:utc.toISOString(),lon});return lon;}});const setBusy=(v:any)=>state.busy=v,setError=(v:any)=>state.error=v,setResult=(v:any)=>state.result=v;const calculationError=(_err:any,_loc:any,fallback:any)=>fallback;const console={error:(error:any)=>state.errors.push(String(error))};
async function lookup(e: Event) {
    e.preventDefault();
    if (!date) return;
    const revision = ++lookupRevisionRef.current;
    const localDateReferenceFailure = new Error('Could not establish a calculation time within the local date.');
    const isCurrent = () => revision === lookupRevisionRef.current;
    focusAfterComputeRef.current = true;
    setBusy(true);
    setError('');
    setResult(null);
    try {
      const engine = await loadEngine();
      if (!isCurrent()) return;
      const hasTime = time !== '';
      let utc: Date;
      let dayStart: Date;
      let dayEnd: Date;
      if (city) {
        utc = resolveLocalToUtc(date, hasTime ? time : '12:00', city.tz).utc;
        if (!hasTime) {
          try {
            if (!localDateContainsUtc(date, utc, city.tz)) throw localDateReferenceFailure;
          } catch { throw localDateReferenceFailure; }
        }
        dayStart = resolveLocalToUtc(date, '00:00', city.tz).utc;
        dayEnd = resolveLocalToUtc(date, '23:59', city.tz).utc;
      } else {
        utc = new Date(`${date}T${hasTime ? time : '12:00'}:00Z`);
        dayStart = new Date(`${date}T00:00:00Z`);
        dayEnd = new Date(`${date}T23:59:00Z`);
      }
      const lon = engine.bodyLongitude('Moon', utc);
      const sunLon = engine.bodyLongitude('Sun', utc);
      const angle = (((lon - sunLon) % 360) + 360) % 360;

      let altLon: number | null = null;
      if (!hasTime) {
        const early = engine.bodyLongitude('Moon', dayStart);
        const late = engine.bodyLongitude('Moon', dayEnd);
        if (signForLongitude(early).slug !== signForLongitude(late).slug) {
          altLon = signForLongitude(lon).slug === signForLongitude(early).slug ? late : early;
        }
      }

      const caption = city && hasTime
        ? ''
        : city
          ? t(locale, 'middayLocalCaption')
          : hasTime
            ? t(locale, 'utcTimeCaption')
            : t(locale, 'middayUtcCaption');

      if (!isCurrent()) return;
      setResult({
        phase: moonPhaseName(utc),
        angle,
        illum: moonIlluminationFromAngle(angle),
        lon,
        altLon,
        caption,
      });
    } catch (err) {
      if (!isCurrent()) return;
      setResult(null);
      setError(err === localDateReferenceFailure ? t(locale, 'localDateReferenceError')
        : calculationError(err, locale, t(locale, 'moonError')));
      console.error(err);
    } finally {
      if (isCurrent()) setBusy(false);
    }
  }
function moonIlluminationFromAngle(angle: number): number {
  return (1 - Math.cos((angle * Math.PI) / 180)) / 2;
}
await lookup({preventDefault(){}} as Event);return state;}
export {actualEngine,localDateContainsUtc,resolveLocalToUtc,localDateEndpointsUtc,stableBodySignSlug,moonLabel,moonIsUncertain,signForLongitude,moonPhaseName,buildChartContext,approachRead,chartSignature};
