import fs from 'node:fs';
import path from 'node:path';
import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
import ts from 'typescript';
const hash=s=>createHash('sha256').update(s).digest('hex');
const old=fs.readFileSync('source/src/islands/ChartCalculator.tsx','utf8');
const current=fs.readFileSync('candidate-source/src/islands/ChartCalculator.tsx','utf8');
const filename='src/islands/ChartCalculator.tsx';
const parse=(s,file=filename)=>ts.createSourceFile(file,s,ts.ScriptTarget.Latest,true,ts.ScriptKind.TSX);
const a=parse(old),b=parse(current);
function functions(ast){const result=new Map();const visit=n=>{if(ts.isFunctionDeclaration(n)&&n.name&&n.name.text!=='ChartCalculator')result.set(n.name.text,n);ts.forEachChild(n,visit);};visit(ast);return result;}
const fa=functions(a),fb=functions(b),functionsEqual=[];
for(const [name,node] of fa){assert.ok(fb.has(name));if(name==='runChart')continue;const before=node.getText(a),after=fb.get(name).getText(b);assert.equal(before,after,name);functionsEqual.push({name,sha256:hash(before),bytes:Buffer.byteLength(before)});}
assert.equal(fa.size,fb.size);
const starts=[['run start','    advanceInputRevision();','      let nextMoonAmbiguous = false;'],['run ownership/capture/share/context/catch','      const owner: ChartResultOwner = {','  function exportReceipt(): void {']];
const spans=starts.map(([name,start,end])=>{const before=old.slice(old.indexOf(start,old.indexOf('  async function runChart(')),old.indexOf(end,old.indexOf(start,old.indexOf('  async function runChart('))));const after=current.slice(current.indexOf(start,current.indexOf('  async function runChart(')),current.indexOf(end,current.indexOf(start,current.indexOf('  async function runChart('))));assert.equal(before,after,name);return{name,sha256:hash(before),bytes:Buffer.byteLength(before)};});

// Reconstruct the complete component using only the reviewed confidence edits.
let reconstructed=old;
function replace(from,to){assert.equal(reconstructed.split(from).length,2);reconstructed=reconstructed.replace(from,to);}
replace('moonCandidates, moonCandidatesFromEndpoints, moonIsUncertain, moonLabel','moonCandidates, moonIsUncertain, moonLabel');
replace("import { localDateEndpointsUtc, stableBodySignSlug } from '../lib/chart-date-certainty';\n",'');
const blockStart='      let nextRegistryRecordSlug =',blockEnd='      if (!runIsCurrent()) return;\n      const owner: ChartResultOwner =';
const beforeBlock=old.slice(old.indexOf(blockStart),old.indexOf(blockEnd,old.indexOf(blockStart)));
const candidateBlock=current.slice(current.indexOf('      const nextRegistryRecordSlug ='),current.indexOf(blockEnd,current.indexOf('      const nextRegistryRecordSlug =')));
assert.equal(candidateBlock,`      const nextRegistryRecordSlug = mode === 'full' && input.timeKnown ? computedSunSlug : null;
      if (!input.timeKnown) {
        // A reference instant does not verify the Moon's possible signs across
        // the birth date. Empty candidates use the existing unresolved state;
        // the numerical chart and portable receipt remain the reference result.
        result.moonSignCandidates = [];
        nextMoonAmbiguous = moonIsUncertain(result);
      }
`);
replace(beforeBlock,candidateBlock);
replace("{moonAmbiguous && ` ${t(locale, 'moonAmbiguousNotice')}`}","{moonAmbiguous && ` ${t(locale, 'moonUnverifiedNotice')}`}");
replace('              exact or stable across an unknown-time local birth date. */}','              from a known-time calculation. */}');
assert.equal(reconstructed,current,'The entire Chart component has only the reviewed confidence delta');
const helper='src/lib/chart-date-certainty.ts',helperOld=fs.readFileSync('source/'+helper,'utf8'),helperNew=fs.readFileSync('candidate-source/'+helper,'utf8');
const printer=ts.createPrinter({removeComments:true});
assert.equal(printer.printFile(parse(helperOld,helper)),printer.printFile(parse(helperNew,helper)),'Endpoint helper is comments only');
const catalogs=[];
for(const locale of ['en','es','fr','it','pt','ru']){const p=`src/lib/i18n/ui/${locale}.ts`,before=fs.readFileSync('source/'+p,'utf8'),after=fs.readFileSync('candidate-source/'+p,'utf8');const lines=after.split('\n'),addition=lines.filter(l=>l.includes('moonUnverifiedNotice:'));assert.equal(addition.length,1);assert.equal(lines.filter(l=>!l.includes('moonUnverifiedNotice:')).join('\n'),before);catalogs.push({locale,addedLine:addition[0],priorBytesRestored:true});}
const specifiers=ast=>{const out=[];const visit=n=>{if(ts.isImportDeclaration(n)&&ts.isStringLiteral(n.moduleSpecifier))out.push({kind:'static',value:n.moduleSpecifier.text});if(ts.isCallExpression(n)&&n.expression.kind===ts.SyntaxKind.ImportKeyword&&ts.isStringLiteral(n.arguments[0]))out.push({kind:'dynamic',value:n.arguments[0].text});ts.forEachChild(n,visit);};visit(ast);return out;};
assert.deepEqual(specifiers(b),specifiers(a).filter(x=>!(x.kind==='static'&&x.value==='../lib/chart-date-certainty')));
const identity=JSON.parse(fs.readFileSync('freeze.json','utf8')),files=Object.entries(identity.files).map(([p,x])=>{const bytes=fs.readFileSync('candidate-source/'+p);assert.equal(bytes.length,x.bytes);assert.equal(hash(bytes),x.sha256);return{path:p,...x};});
const preserved=['src/lib/engine/calculator-receipt.ts','src/lib/engine/portable.ts','src/lib/engine/full.ts','src/lib/time/localToUtc.ts','src/lib/profile/store.ts','src/lib/profile/post-chart-context.ts','src/lib/hooks/useProfileAccessGeneration.ts','src/lib/receipt-download.ts','src/islands/MoonPhaseTool.tsx','src/islands/PositionsShareSurface.tsx','src/lib/share-card.ts','src/lib/share-positions.ts','package.json','package-lock.json'].map(p=>{assert.ok(!identity.files[p]);return{path:p,sha256:hash(fs.readFileSync('source/'+p)),outsideFrozenChanges:true};});
const result={base:identity.baseCommit,freezeIdentitySha256:hash(fs.readFileSync('freeze.json')),files,entireComponentReconstructionMatches:true,unchangedNamedFunctions:functionsEqual,unchangedRunSpans:spans,helperExecutableAstUnchanged:true,catalogs,moduleSpecifiersBefore:specifiers(a),moduleSpecifiersAfter:specifiers(b),preserved,qualification:'Exact private base/frozen byte and AST review, not execution proof. Dynamic import graph strings are unchanged; one static endpoint helper import is removed. Production bundle/CI remains root-owned.'};
fs.writeFileSync('source-review.json',JSON.stringify(result,null,2)+'\n');console.log(JSON.stringify({files:files.length,unchangedNamedFunctions:functionsEqual.length,unchangedRunSpans:spans.length,entireComponentReconstructionMatches:true,helperExecutableAstUnchanged:true}));
