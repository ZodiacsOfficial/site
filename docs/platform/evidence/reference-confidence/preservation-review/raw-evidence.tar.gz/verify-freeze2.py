from pathlib import Path
import json, hashlib

p=Path(__file__).parent
read=lambda name:json.loads((p/name).read_text())
sha=lambda b:hashlib.sha256(b).hexdigest()
freeze=read('freeze.json')
assert sha((p/'freeze.json').read_bytes())=='54cd5acbc7f69c7b3935943a9380be10bb18e8ca2b5a90c1d1766625d8bca55c'
assert sha((p/'author-freeze2.patch').read_bytes())==freeze['patchSha256']=='b13527901ee962d462b0ddd2bdbc16f82763ffa8ad7486d797358b46f76fd0a4'
for f,x in freeze['files'].items():
    for source in [p/'candidate-source',Path('/private/tmp/zodiacs-platform-chart-reference-confidence-evidence/source-freeze2')]:
        b=(source/f).read_bytes();assert len(b)==x['bytes'] and sha(b)==x['sha256']
baseline={r['name']:r for r in read('baseline-result.json')['rows'] if r['passed']}
baseline.update({r['name']:r for r in read('baseline-save-corrected.json')['rows']})
baseline.update({r['name']:r for r in read('baseline-extra.json')['rows']})
candidate=read('candidate-result.json')['rows']+read('candidate-extra.json')['rows']
assert len(baseline)==len(candidate)==19 and len({r['name'] for r in candidate})==19
parity=[]
for row in candidate:
    assert row['passed']
    old=baseline[row['name']]
    assert old['passed']
    before=old['detail'];after=row['detail'];proof={'name':row['name']}
    if 'primary' in after:
        for key in ['beforeSha256','finalNumericalSha256','envelopeSha256','envelopeJson']:
            assert before['primary'][key]==after['primary'][key],(row['name'],key)
        proof.update(numericalBytesEqual=True,portableEnvelopePresent=after['primary']['envelopeJson'] is not None,priorCandidates=before['primary']['candidates'],candidates=after['primary']['candidates'])
    if 'savedSummary' in after:
        assert before['savedSummary']==after['savedSummary'] and before['savedBirth']==after['savedBirth']
        proof['savedBirthSummaryEqual']=True
    if row['name']=='receipt-native-download':assert before['sha256']==after['sha256'];proof['nativeBlobBytesEqual']=True
    if row['name'].startswith('extra-'):assert before==after;proof['extraOwnershipDetailsEqual']=True
    assert row['final']['error']==('We couldn’t establish a calculation time within this local date. Check the date and place.' if row['name']=='skipped-refusal-stays-before-primary' else '')
    parity.append(proof)
assert sum(r.get('numericalBytesEqual',False) for r in parity)==15
assert sum(r.get('portableEnvelopePresent',False) for r in parity)==12
identities=[]
for kind in ['baseline','candidate']:
    identity=read(kind+'-identity.json')
    assert sha((p/(kind+'.js')).read_bytes())==identity['bundleSha256']
    for r in identity['inputs']:
        f=Path(r['selected']);f=f if f.is_absolute() else p/f
        assert sha(f.read_bytes())==r['sha256']
    for r in identity['transformed']:
        assert sha((p/r['transformedFile']).read_bytes())==r['transformedSha256']
    identities.append({kind:r['sha256'] for r in []})
a={r['path']:r['sha256'] for r in read('baseline-identity.json')['inputs']}
b={r['path']:r['sha256'] for r in read('candidate-identity.json')['inputs']}
assert set(a)-set(b)=={'source/src/lib/chart-date-certainty.ts'} and not set(b)-set(a)
changed=[f for f in b if a.get(f)!=b[f]]
assert set(changed)=={'source/src/islands/ChartCalculator.tsx',*[f'source/src/lib/i18n/ui/{locale}.ts' for locale in ['en','es','fr','it','pt','ru']]}
source=read('source-review.json')
assert source['entireComponentReconstructionMatches'] and source['helperExecutableAstUnchanged']
assert len(source['unchangedNamedFunctions'])==42
result={'candidatePassed':19,'candidateFailed':0,'baselineAcceptedAcrossExecutions':19,'originalBaselineFixtureFailuresRetained':2,'numericalByteComparisons':15,'portableEnvelopeByteComparisons':12,'ordinaryLocalSaveComparisons':2,'extraOwnershipComparisons':2,'nativeBlobBytesEqual':True,'frozenFilesRehashed':16,'baselineInputs':len(a),'candidateInputs':len(b),'removedFixtureInput':'source/src/lib/chart-date-certainty.ts','addedFixtureInputs':[],'unchangedCommonInputHashes':len(b)-len(changed),'changedFixtureInputHashes':changed,'namedFunctionsUnchanged':42,'largeRunSpansUnchanged':2,'helperExecutableAstUnchanged':True,'parity':parity,'limits':['Actual native Preact fixture, not production graph/layout or remote preview.','Exact reference compatibility, not independent ephemeris accuracy or whole-date confidence.','Saved reference Sun remains unchanged and open; no observed false Sun claimed.','Conditional profile reader absence exercised, not real account authorization.','Root owns CI, full checks, captures, scope and release.']}
(p/'final-verification.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k not in ['parity','limits','changedFixtureInputHashes']}))
