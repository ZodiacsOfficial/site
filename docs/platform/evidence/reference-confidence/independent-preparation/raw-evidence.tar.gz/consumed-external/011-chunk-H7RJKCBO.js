import {
  normalizeLongitude
} from "./chunk-INI453VG.js";

// src/houses.ts
var DEG = Math.PI / 180;
var RAD = 180 / Math.PI;
var HOUSE_SYSTEMS = ["whole", "placidus"];
function meanObliquity(julianCenturies) {
  const t = julianCenturies;
  const arcseconds = 84381.406 - 46.836769 * t - 1831e-7 * t * t + 20034e-7 * t ** 3 - 576e-9 * t ** 4 - 434e-10 * t ** 5;
  return arcseconds / 3600;
}
function eclipticLongitudeOfRightAscension(ra, obliquity) {
  return normalizeLongitude(
    Math.atan2(Math.sin(ra * DEG), Math.cos(ra * DEG) * Math.cos(obliquity * DEG)) * RAD
  );
}
function declinationOfLongitude(lon, obliquity) {
  return Math.asin(Math.sin(obliquity * DEG) * Math.sin(lon * DEG)) * RAD;
}
function ramcOf(input) {
  return normalizeLongitude(input.gastHours * 15 + input.longitude);
}
function computeAngles(input) {
  const ramc = ramcOf(input);
  const mc = eclipticLongitudeOfRightAscension(ramc, input.obliquity);
  const ra = ramc * DEG;
  const eps = input.obliquity * DEG;
  const phi = input.latitude * DEG;
  let asc = normalizeLongitude(
    Math.atan2(Math.cos(ra), -(Math.sin(ra) * Math.cos(eps) + Math.tan(phi) * Math.sin(eps))) * RAD
  );
  if (normalizeLongitude(asc - mc) >= 180) asc = normalizeLongitude(asc + 180);
  return {
    asc,
    mc,
    dsc: normalizeLongitude(asc + 180),
    ic: normalizeLongitude(mc + 180)
  };
}
function wholeSignCusps(ascendant) {
  const first = Math.floor(normalizeLongitude(ascendant) / 30) * 30;
  return Array.from({ length: 12 }, (_, index) => normalizeLongitude(first + index * 30));
}
function placidusCusps(input, angles) {
  if (Math.abs(input.latitude) > 66) return null;
  const ramc = ramcOf(input);
  const phi = input.latitude * DEG;
  function iterate(offset, multiplier) {
    let ra = ramc + offset;
    let converged = false;
    for (let index = 0; index < 64; index += 1) {
      const lon = eclipticLongitudeOfRightAscension(normalizeLongitude(ra), input.obliquity);
      const declination = declinationOfLongitude(lon, input.obliquity);
      const argument = Math.tan(phi) * Math.tan(declination * DEG);
      if (Math.abs(argument) >= 1) return null;
      const ascensionalDifference = Math.asin(argument) * RAD;
      const next = ramc + offset + multiplier * ascensionalDifference;
      if (Math.abs(normalizeLongitude(next - ra + 180) - 180) < 1e-9) {
        ra = next;
        converged = true;
        break;
      }
      ra = next;
    }
    return converged ? eclipticLongitudeOfRightAscension(normalizeLongitude(ra), input.obliquity) : null;
  }
  const cusp11 = iterate(30, 1 / 3);
  const cusp12 = iterate(60, 2 / 3);
  const cusp2 = iterate(120, 2 / 3);
  const cusp3 = iterate(150, 1 / 3);
  if (cusp11 === null || cusp12 === null || cusp2 === null || cusp3 === null) {
    return null;
  }
  return [
    angles.asc,
    cusp2,
    cusp3,
    angles.ic,
    normalizeLongitude(cusp11 + 180),
    normalizeLongitude(cusp12 + 180),
    angles.dsc,
    normalizeLongitude(cusp2 + 180),
    normalizeLongitude(cusp3 + 180),
    angles.mc,
    cusp11,
    cusp12
  ];
}
function computeHouses(system, input, angles) {
  if (system === "placidus") {
    const cusps = placidusCusps(input, angles);
    if (cusps) {
      return { houses: { system: "placidus", cusps }, fellBack: false };
    }
    return {
      houses: { system: "whole", cusps: wholeSignCusps(angles.asc) },
      fellBack: true
    };
  }
  return {
    houses: { system: "whole", cusps: wholeSignCusps(angles.asc) },
    fellBack: false
  };
}
function houseOf(longitude, cusps) {
  if (cusps.length !== 12) throw new RangeError("House cusps must contain 12 longitudes.");
  for (let index = 0; index < 12; index += 1) {
    const start = cusps[index];
    const end = cusps[(index + 1) % 12];
    if (start === void 0 || end === void 0) continue;
    const span = normalizeLongitude(end - start);
    const offset = normalizeLongitude(longitude - start);
    if (offset < span || span === 0) return index + 1;
  }
  return 12;
}

// src/types.ts
var ENGINE_VERSION = "0.1.1-rc.6";

export {
  HOUSE_SYSTEMS,
  meanObliquity,
  ramcOf,
  computeAngles,
  wholeSignCusps,
  placidusCusps,
  computeHouses,
  houseOf,
  ENGINE_VERSION
};
