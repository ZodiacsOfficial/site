// src/aspects.ts
var ASPECT_TYPES = [
  "conjunction",
  "sextile",
  "square",
  "trine",
  "opposition"
];
var ASPECTS = [
  { type: "conjunction", angle: 0, orb: 8, luminaryOrb: 10 },
  { type: "sextile", angle: 60, orb: 4, luminaryOrb: 5 },
  { type: "square", angle: 90, orb: 7, luminaryOrb: 8 },
  { type: "trine", angle: 120, orb: 7, luminaryOrb: 8 },
  { type: "opposition", angle: 180, orb: 8, luminaryOrb: 10 }
];
var LUMINARIES = /* @__PURE__ */ new Set(["Sun", "Moon"]);
var ASPECT_BODIES = /* @__PURE__ */ new Set([
  "Sun",
  "Moon",
  "Mercury",
  "Venus",
  "Mars",
  "Jupiter",
  "Saturn",
  "Uranus",
  "Neptune",
  "Pluto"
]);
function separation(a, b) {
  const difference = Math.abs(((a - b) % 360 + 360) % 360);
  return difference > 180 ? 360 - difference : difference;
}
function matchAspect(aBody, aLongitude, bBody, bLongitude) {
  const distance = separation(aLongitude, bLongitude);
  const hasLuminary = LUMINARIES.has(aBody) || LUMINARIES.has(bBody);
  let best = null;
  for (const definition of ASPECTS) {
    const orb = Math.abs(distance - definition.angle);
    const maximum = hasLuminary ? definition.luminaryOrb : definition.orb;
    if (orb <= maximum && (!best || orb < best.orb)) {
      best = { definition, orb };
    }
  }
  return best;
}
function findAspects(bodies) {
  const candidates = bodies.filter((body) => ASPECT_BODIES.has(body.body));
  const aspects = [];
  for (let first = 0; first < candidates.length; first += 1) {
    for (let second = first + 1; second < candidates.length; second += 1) {
      const a = candidates[first];
      const b = candidates[second];
      if (!a || !b) continue;
      const match = matchAspect(a.body, a.lon, b.body, b.lon);
      if (!match) continue;
      const stepDays = 0.02;
      const nextSeparation = separation(a.lon + a.speed * stepDays, b.lon + b.speed * stepDays);
      aspects.push({
        a: a.body,
        b: b.body,
        type: match.definition.type,
        orb: match.orb,
        applying: Math.abs(nextSeparation - match.definition.angle) < match.orb
      });
    }
  }
  return aspects.sort((a, b) => a.orb - b.orb);
}

// src/signs.ts
var ELEMENTS = ["fire", "earth", "air", "water"];
var MODALITIES = ["cardinal", "fixed", "mutable"];
var SIGNS = [
  {
    slug: "aries",
    name: "Aries",
    element: "fire",
    modality: "cardinal",
    polarity: "day",
    naturalHouse: 1
  },
  {
    slug: "taurus",
    name: "Taurus",
    element: "earth",
    modality: "fixed",
    polarity: "night",
    naturalHouse: 2
  },
  {
    slug: "gemini",
    name: "Gemini",
    element: "air",
    modality: "mutable",
    polarity: "day",
    naturalHouse: 3
  },
  {
    slug: "cancer",
    name: "Cancer",
    element: "water",
    modality: "cardinal",
    polarity: "night",
    naturalHouse: 4
  },
  {
    slug: "leo",
    name: "Leo",
    element: "fire",
    modality: "fixed",
    polarity: "day",
    naturalHouse: 5
  },
  {
    slug: "virgo",
    name: "Virgo",
    element: "earth",
    modality: "mutable",
    polarity: "night",
    naturalHouse: 6
  },
  {
    slug: "libra",
    name: "Libra",
    element: "air",
    modality: "cardinal",
    polarity: "day",
    naturalHouse: 7
  },
  {
    slug: "scorpio",
    name: "Scorpio",
    element: "water",
    modality: "fixed",
    polarity: "night",
    naturalHouse: 8
  },
  {
    slug: "sagittarius",
    name: "Sagittarius",
    element: "fire",
    modality: "mutable",
    polarity: "day",
    naturalHouse: 9
  },
  {
    slug: "capricorn",
    name: "Capricorn",
    element: "earth",
    modality: "cardinal",
    polarity: "night",
    naturalHouse: 10
  },
  {
    slug: "aquarius",
    name: "Aquarius",
    element: "air",
    modality: "fixed",
    polarity: "day",
    naturalHouse: 11
  },
  {
    slug: "pisces",
    name: "Pisces",
    element: "water",
    modality: "mutable",
    polarity: "night",
    naturalHouse: 12
  }
];
var SIGN_NAMES = SIGNS.map((sign) => sign.slug);
function normalizeLongitude(lon) {
  if (!Number.isFinite(lon)) throw new RangeError("Longitude must be finite.");
  return (lon % 360 + 360) % 360;
}
function signIndexForLongitude(lon) {
  return Math.floor(normalizeLongitude(lon) / 30);
}
function signForLongitude(lon) {
  const sign = SIGNS[signIndexForLongitude(lon)];
  if (!sign) throw new RangeError("Could not resolve zodiac sign.");
  return sign;
}
function degreeInSign(lon) {
  return normalizeLongitude(lon) % 30;
}

export {
  ASPECT_TYPES,
  ASPECTS,
  ASPECT_BODIES,
  separation,
  matchAspect,
  findAspects,
  ELEMENTS,
  MODALITIES,
  SIGNS,
  SIGN_NAMES,
  normalizeLongitude,
  signIndexForLongitude,
  signForLongitude,
  degreeInSign
};
