import {
  dateFrom
} from "./chunk-CPALRSPC.js";
import {
  ASPECTS,
  ASPECT_BODIES,
  ASPECT_TYPES,
  SIGNS
} from "./chunk-INI453VG.js";

// src/receipt-json.ts
function parseReceiptJson(json, limits) {
  if (typeof json !== "string") return { ok: false, code: "invalid_json" };
  if (!Number.isSafeInteger(limits.depth) || limits.depth < 0 || !Number.isSafeInteger(limits.nodes) || limits.nodes < 1)
    return { ok: false, code: "complexity_limit" };
  let cursor = 0;
  let nodes = 0;
  let code = "invalid_json";
  const stack = [];
  const number2 = /-?(?:0|[1-9]\d*)(?:\.\d+)?(?:[eE][+-]?\d+)?/y;
  const reject = (reason = "invalid_json") => {
    code = reason;
    throw new Error();
  };
  const whitespace = () => {
    while (cursor < json.length && " 	\r\n".includes(json[cursor])) cursor += 1;
  };
  const string = (decode) => {
    const start = cursor;
    if (json[cursor++] !== '"') reject();
    while (cursor < json.length) {
      const character = json[cursor++];
      if (character === '"') {
        return decode ? JSON.parse(json.slice(start, cursor)) : void 0;
      }
      if (character.charCodeAt(0) < 32) reject();
      if (character !== "\\") continue;
      const escape = json[cursor++];
      if (escape === "u") {
        const digits = json.slice(cursor, cursor + 4);
        if (!/^[0-9a-fA-F]{4}$/.test(digits)) reject();
        cursor += 4;
      } else if (escape === void 0 || !'"\\/bfnrt'.includes(escape)) reject();
    }
    return reject();
  };
  const value = (depth) => {
    if (++nodes > limits.nodes || depth > limits.depth) reject("complexity_limit");
    whitespace();
    const token = json[cursor];
    if (token === "{" || token === "[") {
      cursor += 1;
      stack.push({
        kind: token === "{" ? "object" : "array",
        state: "first",
        ...token === "{" ? { keys: /* @__PURE__ */ new Set() } : {}
      });
    } else if (token === '"') string(false);
    else if (token === "-" || token !== void 0 && token >= "0" && token <= "9") {
      number2.lastIndex = cursor;
      if (!number2.exec(json)) reject();
      cursor = number2.lastIndex;
    } else {
      const literal = ["true", "false", "null"].find(
        (candidate) => json.startsWith(candidate, cursor)
      );
      if (!literal) return reject();
      cursor += literal.length;
    }
  };
  try {
    value(0);
    while (stack.length > 0) {
      const frame = stack[stack.length - 1];
      whitespace();
      const end = frame.kind === "object" ? "}" : "]";
      if (frame.state === "separator") {
        if (json[cursor] === end) {
          cursor += 1;
          stack.pop();
        } else if (json[cursor] === ",") {
          cursor += 1;
          frame.state = "next";
        } else reject();
        continue;
      }
      if (frame.state === "first" && json[cursor] === end) {
        cursor += 1;
        stack.pop();
        continue;
      }
      if (frame.kind === "object") {
        const key = string(true);
        if (frame.keys.has(key)) reject();
        frame.keys.add(key);
        whitespace();
        if (json[cursor++] !== ":") reject();
      }
      frame.state = "separator";
      value(stack.length);
    }
    whitespace();
    if (cursor !== json.length) reject();
    return { ok: true, value: JSON.parse(json) };
  } catch {
    return { ok: false, code };
  }
}

// src/receipt.ts
var NATAL_ENVELOPE_SCHEMA = "zodiacs.natal-envelope.draft-v1";
var NATAL_RECEIPT_SCHEMA = "zodiacs.calculation-receipt.draft-v1";
var NATAL_DIAGNOSTIC_SCHEMA = "zodiacs.natal-diagnostic.draft-v1";
var NATAL_ENVELOPE_LIMITS = Object.freeze({ bytes: 65536, depth: 12, nodes: 4096 });
var ERROR_CODES = /* @__PURE__ */ new Set([
  "invalid_json",
  "invalid_shape",
  "invalid_value",
  "inconsistent_result",
  "invalid_context",
  "size_limit",
  "complexity_limit",
  "unsupported_version",
  "unsupported_feature"
]);
var ERROR_BRAND = /* @__PURE__ */ new WeakMap();
var NatalEnvelopeError = class extends Error {
  code;
  constructor(code) {
    const fixed = ERROR_CODES.has(code) ? code : "invalid_shape";
    super(`Natal envelope rejected: ${fixed}.`);
    this.code = fixed;
    this.name = "NatalEnvelopeError";
    ERROR_BRAND.set(this, fixed);
  }
};
var CONVENTIONS = Object.freeze({
  calendar: "proleptic-gregorian",
  zodiac: "tropical",
  planetPositions: "apparent-geocentric-ecliptic-of-date",
  moonPosition: "astronomy-engine-ecliptic-geo-moon",
  moonNodes: "instantaneous-geocentric-moon-orbit-plane",
  angles: "gast-and-mean-obliquity",
  longitudeUnit: "degrees-[0,360)",
  speed: "degrees-per-day;central-difference-plus-minus-0.25-day",
  aspects: "major-aspects;sun-moon-eight-planets;no-nodes"
});
var COVERAGE = Object.freeze({
  assessment: "finite-reference-cases-only",
  broadDateRange: "not-certified",
  angleExclusions: "exact-geographic-poles-and-ecliptic-horizon-coincidence",
  inputSyntax: "not-an-astronomical-accuracy-guarantee"
});
var BODIES = [
  "Sun",
  "Moon",
  "Mercury",
  "Venus",
  "Mars",
  "Jupiter",
  "Saturn",
  "Uranus",
  "Neptune",
  "Pluto",
  "North Node",
  "South Node"
];
var FLAGS = ["dst-gap", "dst-fold", "lmt", "no-time", "polar-fallback"];
var TIME_FLAGS = ["dst-gap", "dst-fold", "lmt"];
var HOUSE_SYSTEMS = ["whole", "placidus"];
var HOSTILE_KEYS = /* @__PURE__ */ new Set(["__proto__", "prototype", "constructor"]);
function fail(code) {
  throw new NatalEnvelopeError(code);
}
function guarded(action) {
  try {
    return action();
  } catch (error) {
    return fail(errorCode(error));
  }
}
function errorCode(error) {
  return (error !== null && typeof error === "object" ? ERROR_BRAND.get(error) : void 0) ?? "invalid_shape";
}
function cloneData(value, allowDates = false) {
  const seen = /* @__PURE__ */ new Set();
  let nodes = 0;
  let stringBytes = 0;
  const countString = (text2) => {
    if (text2.length > NATAL_ENVELOPE_LIMITS.bytes) fail("size_limit");
    stringBytes += new TextEncoder().encode(text2).length;
    if (stringBytes > NATAL_ENVELOPE_LIMITS.bytes) fail("size_limit");
  };
  const visit = (item, depth) => {
    if (++nodes > NATAL_ENVELOPE_LIMITS.nodes || depth > NATAL_ENVELOPE_LIMITS.depth)
      fail("complexity_limit");
    if (item === null || typeof item === "boolean") return item;
    if (typeof item === "string") {
      countString(item);
      return item;
    }
    if (typeof item === "number") {
      if (!Number.isFinite(item)) fail("invalid_value");
      return Object.is(item, -0) ? 0 : item;
    }
    if (typeof item !== "object") fail("invalid_shape");
    if (seen.has(item)) fail("invalid_shape");
    const prototype = Object.getPrototypeOf(item);
    const keys = Reflect.ownKeys(item);
    if (keys.length > NATAL_ENVELOPE_LIMITS.nodes) fail("complexity_limit");
    if (allowDates && prototype === Date.prototype) {
      if (keys.length !== 0) fail("invalid_shape");
      const ms = Date.prototype.getTime.call(item);
      if (!Number.isFinite(ms)) fail("invalid_value");
      return new Date(ms);
    }
    const array = Array.isArray(item);
    if (prototype !== (array ? Array.prototype : Object.prototype) && !(prototype === null && !array))
      fail("invalid_shape");
    seen.add(item);
    const out = array ? [] : {};
    const length = array ? Object.getOwnPropertyDescriptor(item, "length")?.value : 0;
    if (array && (length > NATAL_ENVELOPE_LIMITS.nodes || keys.length !== length + 1))
      fail("invalid_shape");
    if (keys.some((key) => typeof key !== "string" || HOSTILE_KEYS.has(key))) fail("invalid_shape");
    for (const key of keys.sort()) {
      if (array && key === "length") continue;
      if (array && (!/^(0|[1-9]\d*)$/.test(key) || Number(key) >= length)) fail("invalid_shape");
      const descriptor = Object.getOwnPropertyDescriptor(item, key);
      if (!descriptor || !("value" in descriptor) || !descriptor.enumerable) fail("invalid_shape");
      countString(key);
      Object.defineProperty(out, key, {
        value: visit(descriptor.value, depth + 1),
        enumerable: true,
        writable: true,
        configurable: true
      });
    }
    seen.delete(item);
    return out;
  };
  return visit(value, 0);
}
function record(value) {
  if (!value || typeof value !== "object" || Array.isArray(value) || value instanceof Date)
    fail("invalid_shape");
  return value;
}
function fields(value, required, optional = []) {
  if (required.some((key) => !Object.hasOwn(value, key)) || Object.keys(value).some((key) => !required.includes(key) && !optional.includes(key)))
    fail("invalid_shape");
}
function choice(value, choices) {
  if (typeof value !== "string" || !choices.includes(value)) fail("invalid_value");
  return value;
}
function number(value, min, max, exclusiveMax = false) {
  if (typeof value !== "number" || !Number.isFinite(value) || value < min || (exclusiveMax ? value >= max : value > max))
    fail("invalid_value");
  return value;
}
function bool(value) {
  if (typeof value !== "boolean") fail("invalid_shape");
  return value;
}
function text(value, maximum = 128) {
  if (typeof value !== "string" || value.length === 0 || value.length > maximum || value.trim() !== value || /[\p{Cc}\p{Cf}]/u.test(value))
    fail("invalid_value");
  return value;
}
function version(value) {
  const parsed = text(value, 64);
  if (!/^\d+\.\d+\.\d+(?:-[A-Za-z0-9.-]+)?(?:\+[A-Za-z0-9.-]+)?$/.test(parsed))
    fail("invalid_value");
  return parsed;
}
function canonicalInstant(value) {
  if (typeof value !== "string" || value.length > 32) fail("invalid_value");
  try {
    if (dateFrom(value, "instant").toISOString() !== value) fail("invalid_value");
  } catch {
    fail("invalid_value");
  }
  return value;
}
function flagList(value, allowed) {
  if (!Array.isArray(value) || value.length > allowed.length) fail("invalid_value");
  const flags = value.map((flag) => choice(flag, allowed));
  if (new Set(flags).size !== flags.length || flags.includes("dst-gap") && flags.includes("dst-fold"))
    fail("inconsistent_result");
  return flags;
}
function sameFlags(a, b) {
  return a.length === b.length && a.every((flag) => b.includes(flag));
}
function fixedFields(value, expected) {
  const actual = record(value);
  fields(actual, Object.keys(expected));
  if (Object.keys(expected).some((key) => actual[key] !== expected[key]))
    fail("unsupported_feature");
}
function longitude(value) {
  return number(value, 0, 360, true);
}
function close(a, b) {
  return Math.abs(a - b) <= 1e-8;
}
function wrap(value) {
  return (value % 360 + 360) % 360;
}
function angularClose(a, b) {
  return Math.min(wrap(a - b), wrap(b - a)) <= 1e-8;
}
function validateResult(value) {
  const result = record(value);
  fields(result, ["bodies", "angles", "houses", "aspects"]);
  if (!Array.isArray(result.bodies) || result.bodies.length !== 12) fail("invalid_shape");
  const names = /* @__PURE__ */ new Set();
  const longitudes = /* @__PURE__ */ new Map();
  for (const item of result.bodies) {
    const body = record(item);
    fields(body, ["body", "lon", "lat", "speed", "retrograde", "sign", "degree"]);
    const name = choice(body.body, BODIES);
    if (names.has(name)) fail("invalid_value");
    names.add(name);
    const lon = longitude(body.lon);
    longitudes.set(name, lon);
    number(body.lat, -90, 90);
    const speed = number(body.speed, -Number.MAX_VALUE, Number.MAX_VALUE);
    const degree = number(body.degree, 0, 30, true);
    if (bool(body.retrograde) !== speed < 0 || body.sign !== SIGNS[Math.floor(lon / 30)]?.slug || !close(degree, lon % 30))
      fail("inconsistent_result");
  }
  if (result.angles === null !== (result.houses === null)) fail("inconsistent_result");
  if (result.angles !== null) {
    const angles = record(result.angles);
    fields(angles, ["asc", "mc", "dsc", "ic"]);
    for (const angle of Object.values(angles)) longitude(angle);
    if (!angularClose(angles.dsc, angles.asc + 180) || !angularClose(angles.ic, angles.mc + 180))
      fail("inconsistent_result");
    const houses = record(result.houses);
    fields(houses, ["system", "cusps"]);
    choice(houses.system, HOUSE_SYSTEMS);
    if (!Array.isArray(houses.cusps) || houses.cusps.length !== 12) fail("invalid_shape");
    const cusps = houses.cusps.map(longitude);
    if (new Set(cusps).size !== 12) fail("inconsistent_result");
    if (houses.system === "whole") {
      const first = Math.floor(angles.asc / 30) * 30;
      if (cusps.some((cusp, index) => !angularClose(cusp, first + index * 30)))
        fail("inconsistent_result");
    } else if (!angularClose(cusps[0], angles.asc) || !angularClose(cusps[9], angles.mc) || cusps.slice(0, 6).some((cusp, index) => !angularClose(cusps[index + 6], cusp + 180)))
      fail("inconsistent_result");
  }
  if (!Array.isArray(result.aspects) || result.aspects.length > 45) fail("invalid_shape");
  const pairs = /* @__PURE__ */ new Set();
  for (const item of result.aspects) {
    const aspect = record(item);
    fields(aspect, ["a", "b", "type", "orb", "applying"]);
    const a = choice(
      aspect.a,
      BODIES.filter((body) => ASPECT_BODIES.has(body))
    );
    const b = choice(
      aspect.b,
      BODIES.filter((body) => ASPECT_BODIES.has(body))
    );
    const key = [a, b].sort().join("/");
    if (a === b || pairs.has(key)) fail("inconsistent_result");
    pairs.add(key);
    const type = choice(aspect.type, ASPECT_TYPES);
    const definition = ASPECTS.find((aspect2) => aspect2.type === type);
    const luminary = a === "Sun" || a === "Moon" || b === "Sun" || b === "Moon";
    const orb = number(aspect.orb, 0, luminary ? definition.luminaryOrb : definition.orb);
    const distance = Math.abs(longitudes.get(a) - longitudes.get(b));
    if (!close(orb, Math.abs(Math.min(distance, 360 - distance) - definition.angle)))
      fail("inconsistent_result");
    bool(aspect.applying);
  }
  return result;
}
function validateLocal(value, receipt) {
  if (value === null) {
    if (receipt.reference === "local-noon") fail("invalid_context");
    return;
  }
  const local = record(value);
  fields(local, ["date", "time", "timeZone", "offsetMinutes", "gapShiftMinutes", "policy"]);
  const date = text(local.date, 10), time = text(local.time, 5);
  if (!/^\d{4}-\d{2}-\d{2}$/.test(date) || !/^(?:[01]\d|2[0-3]):[0-5]\d$/.test(time))
    fail("invalid_context");
  let wall;
  try {
    wall = dateFrom(`${date}T${time}:00Z`, "wall").getTime();
  } catch {
    fail("invalid_context");
  }
  const zone = text(local.timeZone, 128);
  if (!/^[A-Za-z][A-Za-z0-9._+-]*(?:\/[A-Za-z0-9._+-]+){0,3}$/.test(zone)) fail("invalid_context");
  const offset = number(local.offsetMinutes, -1440, 1440);
  const shift = number(local.gapShiftMinutes, 0, 2880);
  const offsetMs = offset * 6e4, shiftMs = shift * 6e4;
  if (Math.abs(offsetMs - Math.round(offsetMs)) > 1e-6 || Math.abs(shiftMs - Math.round(shiftMs)) > 1e-6)
    fail("invalid_context");
  if (wall + Math.round(shiftMs) - Math.round(offsetMs) !== dateFrom(receipt.instant, "instant").getTime())
    fail("invalid_context");
  fixedFields(local.policy, { fold: "earlier", gap: "shift-forward" });
  if (receipt.inputFlags.includes("dst-gap") !== shift > 0 || receipt.inputFlags.includes("lmt") !== Math.abs(offset % 1) > 1e-9)
    fail("invalid_context");
  if (receipt.reference === "local-noon" && time !== "12:00") fail("invalid_context");
}
function repository(value) {
  const input = text(value, 256);
  let url;
  try {
    url = new URL(input);
  } catch {
    return fail("invalid_value");
  }
  if (url.protocol !== "https:" || !url.hostname || url.username || url.password || url.search || url.hash)
    fail("invalid_value");
}
function commit(value) {
  if (typeof value !== "string" || !/^(?:[a-f0-9]{40}|[a-f0-9]{64})$/.test(value))
    fail("invalid_value");
}
function validateProvenance(value, engineVersion) {
  if (value === null) return;
  const facts = record(value);
  fields(facts, ["status"], ["source", "artifact", "runtime", "ephemeris"]);
  if (facts.status !== "claimed" || Object.keys(facts).length === 1) fail("invalid_shape");
  if (facts.source !== void 0) {
    const source = record(facts.source);
    fields(source, ["repository", "commit"]);
    repository(source.repository);
    commit(source.commit);
  }
  if (facts.artifact !== void 0) {
    const artifact = record(facts.artifact);
    fields(
      artifact,
      ["sha256", "packageVersion"],
      ["distributionRepository", "distributionCommit"]
    );
    if (typeof artifact.sha256 !== "string" || !/^[a-f0-9]{64}$/.test(artifact.sha256))
      fail("invalid_value");
    if (version(artifact.packageVersion) !== engineVersion) fail("invalid_context");
    if (artifact.distributionRepository === void 0 !== (artifact.distributionCommit === void 0))
      fail("invalid_context");
    if (artifact.distributionRepository !== void 0) {
      repository(artifact.distributionRepository);
      commit(artifact.distributionCommit);
    }
  }
  if (facts.runtime !== void 0) {
    const runtime = record(facts.runtime);
    fields(runtime, ["name"], ["version", "icuVersion", "tzdbVersion"]);
    for (const item of Object.values(runtime)) text(item, 64);
  }
  if (facts.ephemeris !== void 0) {
    const ephemeris = record(facts.ephemeris);
    fields(ephemeris, ["name", "version"]);
    if (ephemeris.name !== "astronomy-engine") fail("unsupported_feature");
    version(ephemeris.version);
  }
}
function validateEnvelope(input) {
  const envelope = record(input);
  if (envelope.schema !== NATAL_ENVELOPE_SCHEMA) fail("unsupported_version");
  fields(envelope, ["schema", "requiredFeatures", "receipt", "result"], ["extensions"]);
  if (!Array.isArray(envelope.requiredFeatures)) fail("invalid_shape");
  if (envelope.requiredFeatures.length !== 0) fail("unsupported_feature");
  const receipt = record(envelope.receipt);
  if (receipt.schema !== NATAL_RECEIPT_SCHEMA) fail("unsupported_version");
  fields(receipt, [
    "schema",
    "instant",
    "sourceInstant",
    "timeKnown",
    "reference",
    "localResolution",
    "coordinates",
    "houses",
    "inputFlags",
    "resultFlags",
    "engine",
    "provenance",
    "conventions",
    "coverage"
  ]);
  canonicalInstant(receipt.instant);
  if (receipt.sourceInstant !== null) {
    if (typeof receipt.sourceInstant !== "string" || receipt.sourceInstant.length > 40)
      fail("invalid_context");
    try {
      if (dateFrom(receipt.sourceInstant, "source").toISOString() !== receipt.instant)
        fail("invalid_context");
    } catch {
      fail("invalid_context");
    }
  }
  const timeKnown = bool(receipt.timeKnown);
  const reference = choice(receipt.reference, ["supplied-instant", "utc-noon", "local-noon"]);
  if (reference !== "supplied-instant" && timeKnown) fail("invalid_context");
  if (reference === "utc-noon" && !receipt.instant.endsWith("T12:00:00.000Z"))
    fail("invalid_context");
  if (receipt.coordinates !== null) {
    const coords = record(receipt.coordinates);
    fields(coords, ["latitude", "longitude"]);
    number(coords.latitude, -90, 90);
    number(coords.longitude, -180, 180);
    if (timeKnown && Math.abs(coords.latitude) === 90) fail("unsupported_feature");
  }
  const result = validateResult(envelope.result);
  const house = record(receipt.houses);
  fields(house, ["requested", "actual", "absenceReason"]);
  const requested = choice(house.requested, HOUSE_SYSTEMS);
  const reason = !timeKnown ? "unknown-time" : receipt.coordinates === null ? "missing-location" : null;
  if (house.absenceReason !== reason || result.houses === null !== (reason !== null) || house.actual !== (result.houses?.system ?? null))
    fail("inconsistent_result");
  if (requested === "whole" && result.houses?.system === "placidus") fail("inconsistent_result");
  const inputFlags = flagList(receipt.inputFlags, TIME_FLAGS);
  const resultFlags = flagList(receipt.resultFlags, FLAGS);
  const expected = [...inputFlags];
  if (!timeKnown) expected.push("no-time");
  if (requested === "placidus" && result.houses?.system === "whole")
    expected.push("polar-fallback");
  if (!sameFlags(expected, resultFlags)) fail("inconsistent_result");
  const engine = record(receipt.engine);
  fields(engine, ["name", "version"]);
  if (engine.name !== "@zodiacs/engine") fail("unsupported_feature");
  const engineVersion = version(engine.version);
  validateProvenance(receipt.provenance, engineVersion);
  validateLocal(receipt.localResolution, receipt);
  fixedFields(receipt.conventions, CONVENTIONS);
  fixedFields(receipt.coverage, COVERAGE);
  if (envelope.extensions !== void 0) record(envelope.extensions);
  return envelope;
}
function encoded(envelope) {
  const json = JSON.stringify(envelope);
  if (new TextEncoder().encode(json).length > NATAL_ENVELOPE_LIMITS.bytes) fail("size_limit");
  return json;
}
function checked(input) {
  const envelope = validateEnvelope(cloneData(input));
  encoded(envelope);
  return envelope;
}
function createNatalEnvelope(chart, context = {}) {
  return guarded(() => {
    const source = record(cloneData(chart, true));
    fields(source, ["input", "bodies", "angles", "houses", "aspects", "flags", "engineVersion"]);
    const input = record(source.input);
    fields(input, ["utc", "houseSystem", "timeKnown"], ["latitude", "longitude", "flags"]);
    if (!(input.utc instanceof Date)) fail("invalid_value");
    const supplied = record(cloneData(context));
    fields(
      supplied,
      [],
      ["reference", "sourceInstant", "localResolution", "provenance", "extensions"]
    );
    if (supplied.provenance !== void 0)
      fields(record(supplied.provenance), [], ["source", "artifact", "runtime", "ephemeris"]);
    if (input.latitude === void 0 !== (input.longitude === void 0)) fail("invalid_value");
    const houses = source.houses === null ? null : record(source.houses);
    const envelope = {
      schema: NATAL_ENVELOPE_SCHEMA,
      requiredFeatures: [],
      receipt: {
        schema: NATAL_RECEIPT_SCHEMA,
        instant: Date.prototype.toISOString.call(input.utc),
        sourceInstant: supplied.sourceInstant === void 0 ? null : supplied.sourceInstant,
        timeKnown: input.timeKnown,
        reference: supplied.reference === void 0 ? "supplied-instant" : supplied.reference,
        localResolution: supplied.localResolution ?? null,
        coordinates: input.latitude === void 0 ? null : { latitude: input.latitude, longitude: input.longitude },
        houses: {
          requested: input.houseSystem,
          actual: houses?.system ?? null,
          absenceReason: !input.timeKnown ? "unknown-time" : input.latitude === void 0 ? "missing-location" : null
        },
        inputFlags: input.flags ?? [],
        resultFlags: source.flags,
        engine: { name: "@zodiacs/engine", version: source.engineVersion },
        provenance: supplied.provenance === void 0 ? null : { ...record(supplied.provenance), status: "claimed" },
        conventions: { ...CONVENTIONS },
        coverage: { ...COVERAGE }
      },
      result: {
        bodies: source.bodies,
        angles: source.angles,
        houses: source.houses,
        aspects: source.aspects
      },
      ...supplied.extensions === void 0 ? {} : { extensions: supplied.extensions }
    };
    return checked(envelope);
  });
}
function parseNatalEnvelope(json) {
  try {
    if (typeof json !== "string") fail("invalid_shape");
    if (json.length > NATAL_ENVELOPE_LIMITS.bytes || new TextEncoder().encode(json).length > NATAL_ENVELOPE_LIMITS.bytes)
      fail("size_limit");
    const parsed = parseReceiptJson(json, {
      depth: NATAL_ENVELOPE_LIMITS.depth,
      nodes: NATAL_ENVELOPE_LIMITS.nodes
    });
    if (!parsed.ok) return parsed;
    return { ok: true, envelope: guarded(() => checked(parsed.value)) };
  } catch (error) {
    return { ok: false, code: errorCode(error) };
  }
}
function serializeNatalEnvelope(envelope) {
  return guarded(() => encoded(checked(envelope)));
}
function natalReplayInput(envelope) {
  return guarded(() => {
    const { receipt } = checked(envelope);
    return {
      utc: receipt.instant,
      houseSystem: receipt.houses.requested,
      timeKnown: receipt.timeKnown,
      flags: [...receipt.inputFlags],
      ...receipt.coordinates === null ? {} : { ...receipt.coordinates }
    };
  });
}
function redactNatalEnvelope(envelope) {
  return guarded(() => {
    const { receipt } = checked(envelope);
    return {
      schema: NATAL_DIAGNOSTIC_SCHEMA,
      status: "redacted-not-anonymous",
      timeKnown: receipt.timeKnown,
      houses: { ...receipt.houses },
      inputFlags: [...receipt.inputFlags],
      resultFlags: [...receipt.resultFlags]
    };
  });
}
export {
  NATAL_DIAGNOSTIC_SCHEMA,
  NATAL_ENVELOPE_LIMITS,
  NATAL_ENVELOPE_SCHEMA,
  NATAL_RECEIPT_SCHEMA,
  NatalEnvelopeError,
  createNatalEnvelope,
  natalReplayInput,
  parseNatalEnvelope,
  redactNatalEnvelope,
  serializeNatalEnvelope
};
