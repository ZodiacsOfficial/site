import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { resolveLocalToUtc, localDateContainsUtc } from './source/src/lib/time/localToUtc';
import { localDateEndpointsUtc, stableBodySignSlug } from './source/src/lib/chart-date-certainty';
import { computeBodies, bodyLongitude } from './source/src/lib/engine/full';
import { computeCalculatorReceipt } from './source/src/lib/engine/calculator-receipt';
import { moonCandidates, moonIsUncertain, moonCandidatesFromEndpoints } from './source/src/lib/moon-certainty';
import { buildChartContext } from './source/src/lib/chart-context';
import { approachRead } from './source/src/lib/approach';
import { communicationRead } from './source/src/lib/communication';
import { chartSignature } from './source/src/lib/chart-signature';
import { bigThreePlacements, signatureCardContent, communicationCardContent, approachCardContent } from './source/src/lib/share-card';
import { encodePositionsLink, decodePositionsLink } from './source/src/lib/share-positions';
import { positionsReading } from './source/src/lib/share-positions-reading';
import { encodeChartLink, decodeChartLink } from './source/src/lib/share';
import { signForLongitude } from './source/src/lib/signs';
const sha=(s:string)=>createHash('sha256').update(s).digest('hex');
const numerical=(chart:any)=>{const {moonSignCandidates,...rest}=chart;return JSON.stringify(rest)};
const fmt=(zone:string,instant:Date)=>new Intl.DateTimeFormat('en-GB-u-ca-gregory-nu-latn', {timeZone:zone,year:'numeric',month:'2-digit',day:'2-digit',hour:'2-digit',minute:'2-digit',second:'2-digit',fractionalSecondDigits:3,hourCycle:'h23'}).format(instant);
const controls=[
 {name:'Toronto',date:'1919-03-31',zone:'America/Toronto',lat:43.6532,lon:-79.3832,witness:'1919-03-31T04:30:00.000Z',previous:'1919-03-31T04:29:59.999Z',sign:'pisces',candidate:'aries'},
 {name:'Juneau',date:'1867-10-18',zone:'America/Juneau',lat:58.3019,lon:-134.4197,witness:'1867-10-19T00:31:13.000Z',previous:'1867-10-19T00:31:12.999Z',sign:'cancer',candidate:'gemini'},
 {name:'Bangkok ordinary',date:'2000-01-01',zone:'Asia/Bangkok',lat:13.7563,lon:100.5018},
];
function consumers(chart:any){
 const context=buildChartContext({bodies:chart.bodies,timeKnown:chart.input.timeKnown,moonSignCandidates:chart.moonSignCandidates,angles:chart.angles,houses:chart.houses});
 return {candidates:moonCandidates(chart),uncertain:moonIsUncertain(chart),moonContext:context.placements.find(p=>p.body==='Moon'),approach:approachRead(chart),communication:communicationRead(chart),signature:chartSignature(chart),bigThree:bigThreePlacements(chart),signatureCard:signatureCardContent(chart),communicationCard:communicationCardContent(chart),approachCard:approachCardContent(chart)};
}
const rows=[];
for(const input of controls){
 const resolved=resolveLocalToUtc(input.date,'12:00',input.zone);assert(localDateContainsUtc(input.date,resolved.utc,input.zone));
 const portable=computeCalculatorReceipt({utc:resolved.utc,latitude:input.lat,longitude:input.lon,houseSystem:'whole',timeKnown:false,flags:resolved.flags}, {date:input.date,time:'12:00',timeZone:input.zone,offsetMinutes:resolved.offsetMinutes,reference:'local-noon'});assert(portable);
 const chart=portable.chart, originalNumeric=numerical(chart), originalReceipt=portable.envelopeJson;
 const endpoints=localDateEndpointsUtc(input.date,input.zone),start=computeBodies(endpoints.start),end=computeBodies(endpoints.end);
 chart.moonSignCandidates=moonCandidatesFromEndpoints(start,end);
 const before=consumers(chart), policy={...chart,moonSignCandidates:[]},after=consumers(policy);
 assert.equal(numerical(policy),originalNumeric);assert.equal(portable.envelopeJson,originalReceipt);
 assert.deepEqual(after.candidates,[]);assert.equal(after.moonContext?.status,'unresolved');assert.equal(after.moonContext?.sign,null);
 assert.equal(after.approach.moon,null);assert.equal(after.communication.moonSign,null);assert(after.communication.aspects.every(x=>x.target!=='Moon'));
 assert.equal(after.bigThree.find(x=>x.kind==='moon')?.slug,'');
 assert.equal(after.communicationCard.rows.find(x=>x.body==='Moon')?.slug,'');
 assert.equal(after.approachCard.rows.find(x=>x.body==='Moon')?.slug,'');
 const pos=(c:any)=>encodePositionsLink({bodies:c.bodies,angles:c.angles,houseSystem:'whole',engineVersion:c.engineVersion});
 assert.equal(pos(chart),pos(policy));const decoded=decodePositionsLink(pos(policy)!);assert(decoded);assert(moonIsUncertain(decoded));
 assert(positionsReading(decoded).topAspects.every(a=>a.a!=='Moon'&&a.b!=='Moon'));
 const birth={date:input.date,time:null,timeKnown:false,lat:input.lat,lon:input.lon,tz:input.zone,houseSystem:'whole' as const};
 const birthToken=encodeChartLink(birth);assert.equal(decodeChartLink(birthToken)?.timeKnown,false);
 const savedProjection=(c:any)=>JSON.stringify({birth:{date:input.date,time:null,timeKnown:false,place:{lat:input.lat,lon:input.lon,tz:input.zone}},summary:{engineVersion:c.engineVersion,utcISO:c.input.utc.toISOString(),houseSystem:c.houses?.system??c.input.houseSystem,bodies:c.bodies.map((b:any)=>({body:b.body,lon:b.lon,retrograde:b.retrograde})),angles:c.angles?{asc:c.angles.asc,mc:c.angles.mc}:null,flags:c.flags}});
 assert.equal(savedProjection(chart),savedProjection(policy));
 let witness=null;
 if(input.witness){
  const utc=new Date(input.witness),previous=new Date(input.previous!);const longitude=bodyLongitude('Moon',utc);
  assert(localDateContainsUtc(input.date,utc,input.zone));assert(!localDateContainsUtc(input.date,previous,input.zone));
  assert.equal(signForLongitude(longitude).slug,input.sign);assert.deepEqual(before.candidates,[input.candidate]);assert(!before.candidates.includes(input.sign!));
  witness={utc:utc.toISOString(),local:fmt(input.zone,utc),member:true,moonLongitude:longitude,sign:signForLongitude(longitude).slug,previous:{utc:previous.toISOString(),local:fmt(input.zone,previous),member:false}};
 }
 rows.push({input,reference:{utc:resolved.utc.toISOString(),local:fmt(input.zone,resolved.utc),offsetMinutes:resolved.offsetMinutes,flags:resolved.flags},endpoints:{start:endpoints.start.toISOString(),end:endpoints.end.toISOString(),startLocal:fmt(input.zone,endpoints.start),endLocal:fmt(input.zone,endpoints.end)},witness,before,policy:after,unchanged:{numericalJsonSha256:sha(originalNumeric),receiptSha256:sha(originalReceipt),positionsTokenSha256:sha(pos(chart)!),birthTokenSha256:sha(birthToken),savedProjectionSha256:sha(savedProjection(policy))},currentRegistrySun:{endpointSlug:stableBodySignSlug('Sun',start,end),referenceSlug:signForLongitude(chart.bodies.find(b=>b.body==='Sun')!.lon).slug},policyRegistrySun:null});
}
const known=[];
for(const input of controls.slice(0,2)){
 const resolved=resolveLocalToUtc(input.date,'12:00',input.zone);const p=computeCalculatorReceipt({utc:resolved.utc,latitude:input.lat,longitude:input.lon,houseSystem:'whole',timeKnown:true,flags:resolved.flags},{date:input.date,time:'12:00',timeZone:input.zone,offsetMinutes:resolved.offsetMinutes,reference:'supplied-instant'});assert(p);const c=consumers(p.chart);assert(!c.uncertain);assert.equal(c.moonContext?.status,'established');known.push({input,candidates:c.candidates,moonStatus:c.moonContext?.status,moonAdvicePresent:!!c.approach.moon,numericalSha256:sha(numerical(p.chart)),receiptSha256:sha(p.envelopeJson)});
}
const skipped=resolveLocalToUtc('2011-12-30','12:00','Pacific/Apia');assert(!localDateContainsUtc('2011-12-30',skipped.utc,'Pacific/Apia'));
console.log(JSON.stringify({runtime:{node:process.version,versions:process.versions,temporalAvailable:typeof (globalThis as any).Temporal!=='undefined'},qualification:'Direct current source module calls and an in-memory policy copy; no product component/DOM execution, no candidate implementation acceptance, no independent ephemeris oracle, no full-date completeness, no persistence or network calls. Coordinates are explicit finite fixture coordinates, not a city-data lookup.',unknown:rows,known,skipped:{date:'2011-12-30',zone:'Pacific/Apia',reference:skipped.utc.toISOString(),member:false}},null,2));
