import {
  assertDerivedFlags,
  snapshotFlags,
  timeFlags,
  validateBirthSettings
} from "./chunk-K5MRTCWE.js";
import {
  bodyLongitude,
  computeBodies,
  computeChart
} from "./chunk-GBH7JIYF.js";
import {
  ENGINE_VERSION,
  HOUSE_SYSTEMS,
  computeAngles,
  computeHouses,
  houseOf,
  meanObliquity,
  placidusCusps,
  ramcOf,
  wholeSignCusps
} from "./chunk-H7RJKCBO.js";
import {
  dateFrom
} from "./chunk-CPALRSPC.js";
import {
  ASPECTS,
  ASPECT_BODIES,
  ASPECT_TYPES,
  ELEMENTS,
  MODALITIES,
  SIGNS,
  SIGN_NAMES,
  degreeInSign,
  findAspects,
  matchAspect,
  normalizeLongitude,
  separation,
  signForLongitude,
  signIndexForLongitude
} from "./chunk-INI453VG.js";

// src/returns.ts
var DAY = 864e5;
var MAX_CROSSING_SAMPLES = 1e4;
function validMilliseconds(date, label) {
  if (!(date instanceof Date)) throw new RangeError(`${label} must be a valid Date.`);
  const milliseconds = Date.prototype.getTime.call(date);
  if (!Number.isFinite(milliseconds)) throw new RangeError(`${label} must be a valid Date.`);
  return milliseconds;
}
function signedDelta(from, to) {
  const difference = ((to - from) % 360 + 360) % 360;
  return difference > 180 ? difference - 360 : difference;
}
function findLongitudeCrossings(body, targetLongitude, from, to, stepDays = 5) {
  const fromTime = validMilliseconds(from, "Crossing window start");
  const endTime = validMilliseconds(to, "Crossing window end");
  if (fromTime > endTime) {
    throw new RangeError("Crossing window must have from <= to.");
  }
  if (!Number.isFinite(targetLongitude)) {
    throw new RangeError("targetLongitude must be finite.");
  }
  if (!Number.isFinite(stepDays) || stepDays <= 0) {
    throw new RangeError("stepDays must be positive.");
  }
  const step = stepDays * DAY;
  if (!Number.isFinite(step) || step < 1) {
    throw new RangeError("stepDays must represent a finite step of at least one millisecond.");
  }
  const budgetError = () => new RangeError("Crossing search exceeds the 10,000-sample budget.");
  if (Math.ceil((endTime - fromTime) / step) + 1 > MAX_CROSSING_SAMPLES) {
    throw budgetError();
  }
  let samples = 0;
  function sample(time) {
    if (samples >= MAX_CROSSING_SAMPLES) throw budgetError();
    samples += 1;
    const longitude = bodyLongitude(body, new Date(time));
    if (!Number.isFinite(longitude)) {
      throw new RangeError("Ephemeris returned a non-finite longitude.");
    }
    return signedDelta(targetLongitude, longitude);
  }
  const crossings = [];
  let previousTime = fromTime;
  let previousDelta = sample(fromTime);
  let pendingExact = previousDelta === 0 ? { time: fromTime } : void 0;
  while (previousTime < endTime) {
    const time = Math.min(previousTime + step, endTime);
    if (!(time > previousTime)) {
      throw new RangeError("Crossing search step must advance time.");
    }
    const currentDelta = sample(time);
    if (currentDelta === 0) {
      pendingExact = previousDelta !== 0 && Math.abs(previousDelta) < 90 ? { time, before: previousDelta } : void 0;
    } else {
      if (pendingExact && Math.abs(currentDelta) < 90 && (pendingExact.before === void 0 || Math.sign(pendingExact.before) !== Math.sign(currentDelta))) {
        crossings.push({ at: new Date(pendingExact.time), retrograde: currentDelta < 0 });
      }
      pendingExact = void 0;
    }
    if (previousDelta !== 0 && currentDelta !== 0 && Math.sign(currentDelta) !== Math.sign(previousDelta) && Math.abs(currentDelta) < 90 && Math.abs(previousDelta) < 90) {
      let lower = previousTime;
      let upper = time;
      const increasing = currentDelta > previousDelta;
      for (let iteration = 0; iteration < 24; iteration += 1) {
        const middle = (lower + upper) / 2;
        const middleDelta = sample(middle);
        if (middleDelta > 0 === increasing) upper = middle;
        else lower = middle;
      }
      crossings.push({ at: new Date(upper), retrograde: !increasing });
    }
    previousTime = time;
    previousDelta = currentDelta;
  }
  if (pendingExact?.before !== void 0) {
    crossings.push({ at: new Date(pendingExact.time), retrograde: pendingExact.before > 0 });
  }
  return crossings;
}
function groupIntoSeasons(crossings, gapDays = 400) {
  if (!Number.isFinite(gapDays) || gapDays <= 0) {
    throw new RangeError("gapDays must be positive.");
  }
  const seasons = [];
  for (const crossing of crossings) {
    const current = seasons.at(-1);
    if (current && crossing.at.getTime() - current.last.getTime() <= gapDays * DAY) {
      current.crossings.push(crossing);
      current.last = crossing.at;
    } else {
      seasons.push({
        index: seasons.length + 1,
        crossings: [crossing],
        first: crossing.at,
        last: crossing.at
      });
    }
  }
  return seasons;
}
function computeSaturnReturns(birthUtc) {
  const birthTime = validMilliseconds(birthUtc, "Birth date");
  const before = new Date(birthTime - DAY);
  const after = new Date(birthTime + DAY);
  const from = new Date(birthTime + 26 * 365.25 * DAY);
  const to = new Date(birthTime + 92 * 365.25 * DAY);
  validMilliseconds(before, "Natal speed window start");
  validMilliseconds(after, "Natal speed window end");
  validMilliseconds(from, "Saturn return window start");
  validMilliseconds(to, "Saturn return window end");
  const natalLon = bodyLongitude("Saturn", birthUtc);
  const speed = signedDelta(bodyLongitude("Saturn", before), bodyLongitude("Saturn", after)) / 2;
  return {
    natalLon,
    natalRetrograde: speed < 0,
    seasons: groupIntoSeasons(findLongitudeCrossings("Saturn", natalLon, from, to))
  };
}

// src/synastry.ts
function findInterAspects(first, second) {
  const aBodies = first.filter((body) => ASPECT_BODIES.has(body.body));
  const bBodies = second.filter((body) => ASPECT_BODIES.has(body.body));
  const aspects = [];
  for (const a of aBodies) {
    for (const b of bBodies) {
      const match = matchAspect(a.body, a.lon, b.body, b.lon);
      if (!match) continue;
      aspects.push({
        a: a.body,
        aLon: a.lon,
        b: b.body,
        bLon: b.lon,
        type: match.definition.type,
        orb: match.orb
      });
    }
  }
  return aspects.sort((a, b) => a.orb - b.orb);
}
function elementBalance(bodies) {
  const balance = {
    fire: 0,
    earth: 0,
    air: 0,
    water: 0
  };
  for (const body of bodies) {
    if (!ASPECT_BODIES.has(body.body)) continue;
    balance[signForLongitude(body.lon).element] += 1;
  }
  return balance;
}
function modalityBalance(bodies) {
  const balance = {
    cardinal: 0,
    fixed: 0,
    mutable: 0
  };
  for (const body of bodies) {
    if (!ASPECT_BODIES.has(body.body)) continue;
    balance[signForLongitude(body.lon).modality] += 1;
  }
  return balance;
}
function summarizePair(first, second, topCount = 8) {
  if (!Number.isInteger(topCount) || topCount < 0) {
    throw new RangeError("topCount must be a non-negative integer.");
  }
  const aspects = findInterAspects(first, second);
  const counts = {
    conjunction: 0,
    sextile: 0,
    square: 0,
    trine: 0,
    opposition: 0
  };
  for (const aspect of aspects) counts[aspect.type] += 1;
  return {
    aspects,
    top: aspects.slice(0, topCount),
    counts,
    easeful: counts.trine + counts.sextile,
    charged: counts.square + counts.opposition,
    elements: {
      a: elementBalance(first),
      b: elementBalance(second)
    },
    modalities: {
      a: modalityBalance(first),
      b: modalityBalance(second)
    }
  };
}

// src/api.ts
function isChart(value) {
  if (!value || typeof value !== "object") return false;
  const candidate = value;
  return Array.isArray(candidate.bodies) && Array.isArray(candidate.aspects) && candidate.input?.utc instanceof Date;
}
function isBirth(value) {
  return Boolean(value && typeof value === "object" && "utc" in value);
}
function resolvedChart(source) {
  if (!isChart(source)) {
    const chart = natalChart(source);
    return { chart, utc: chart.input.utc };
  }
  const sourceInput = source.input;
  const { input, flags: inputFlags } = validateBirth(sourceInput);
  const resultFlags = snapshotFlags(source.flags);
  const expected = timeFlags(inputFlags?.values ?? []);
  const hasHouses = input.timeKnown && input.latitude !== void 0;
  const houses = source.houses;
  const angles = source.angles;
  const actualHouseSystem = houses?.system;
  if ((hasHouses ? !angles || typeof angles !== "object" || Array.isArray(angles) || !houses || typeof houses !== "object" || Array.isArray(houses) : angles !== null || houses !== null) || houses !== null && actualHouseSystem !== "whole" && actualHouseSystem !== "placidus" || input.houseSystem === "whole" && actualHouseSystem === "placidus") {
    throw new RangeError("chart flags must agree with its input and supplied house result.");
  }
  if (!input.timeKnown) expected.push("no-time");
  if (input.houseSystem === "placidus" && actualHouseSystem === "whole") {
    expected.push("polar-fallback");
  }
  assertDerivedFlags(inputFlags?.values ?? [], expected);
  if (resultFlags.values.length !== expected.length || !expected.every((flag) => resultFlags.values.includes(flag))) {
    throw new RangeError("chart flags must agree with its input and supplied house result.");
  }
  const canonicalInputFlags = input.flags ?? [];
  const inputChanged = inputFlags !== void 0 && (inputFlags.hasDuplicates || inputFlags.values.length !== canonicalInputFlags.length);
  const resultChanged = resultFlags.hasDuplicates || !expected.every((flag, index) => flag === resultFlags.values[index]);
  if (!inputChanged && !resultChanged) return { chart: source, utc: input.utc };
  return {
    chart: {
      ...source,
      input: inputChanged ? input : sourceInput,
      flags: expected
    },
    utc: input.utc
  };
}
function validateBirth(birth) {
  if (!birth || typeof birth !== "object" || Array.isArray(birth)) {
    throw new RangeError("birth must be an object containing a resolved utc instant.");
  }
  const settings = validateBirthSettings(birth);
  const supplied = birth.flags;
  const flags = supplied === void 0 ? void 0 : snapshotFlags(supplied);
  const possible = [];
  if (settings.timeKnown === false) possible.push("no-time");
  else if (settings.houseSystem === "placidus" && settings.latitude !== void 0) {
    possible.push("polar-fallback");
  }
  assertDerivedFlags(flags?.values ?? [], possible);
  const input = {
    utc: dateFrom(birth.utc, "birth.utc"),
    houseSystem: settings.houseSystem ?? "whole",
    timeKnown: settings.timeKnown ?? true,
    ...settings.latitude === void 0 ? {} : { latitude: settings.latitude, longitude: settings.longitude },
    ...flags === void 0 ? {} : { flags: timeFlags(flags.values) }
  };
  return { input, flags };
}
function computedBirth({ input, flags }) {
  const chart = computeChart(input);
  assertDerivedFlags(flags?.values ?? [], chart.flags);
  return chart;
}
function positions(date) {
  return computeBodies(dateFrom(date, "date"));
}
function natalChart(birth) {
  return computedBirth(validateBirth(birth));
}
function transits(natal, date) {
  const { chart } = resolvedChart(natal);
  const at = dateFrom(date, "date");
  const current = computeBodies(at);
  return {
    natal: chart,
    at,
    positions: current,
    aspects: findInterAspects(current, chart.bodies)
  };
}
function synastry(first, second) {
  const { chart: a } = resolvedChart(first);
  const { chart: b } = resolvedChart(second);
  return { a, b, ...summarizePair(a.bodies, b.bodies) };
}
function phaseName(angle) {
  if (angle < 22.5 || angle >= 337.5) return "New Moon";
  if (angle < 67.5) return "Waxing Crescent";
  if (angle < 112.5) return "First Quarter";
  if (angle < 157.5) return "Waxing Gibbous";
  if (angle < 202.5) return "Full Moon";
  if (angle < 247.5) return "Waning Gibbous";
  if (angle < 292.5) return "Last Quarter";
  return "Waning Crescent";
}
function moonPhase(date) {
  const at = dateFrom(date, "date");
  const angle = normalizeLongitude(bodyLongitude("Moon", at) - bodyLongitude("Sun", at));
  return {
    at,
    angle,
    illumination: (1 - Math.cos(angle * Math.PI / 180)) / 2,
    name: phaseName(angle),
    waxing: angle < 180
  };
}
function saturnReturn(birth) {
  let utc;
  if (isChart(birth)) {
    utc = resolvedChart(birth).utc;
  } else if (isBirth(birth)) {
    const validated = validateBirth(birth);
    utc = validated.flags?.values.includes("polar-fallback") ? computedBirth(validated).input.utc : validated.input.utc;
  } else utc = dateFrom(birth, "birth");
  return computeSaturnReturns(utc);
}
export {
  ASPECTS,
  ASPECT_BODIES,
  ASPECT_TYPES,
  ELEMENTS,
  ENGINE_VERSION,
  HOUSE_SYSTEMS,
  MODALITIES,
  SIGNS,
  SIGN_NAMES,
  computeAngles,
  computeHouses,
  degreeInSign,
  elementBalance,
  findAspects,
  findInterAspects,
  findLongitudeCrossings,
  groupIntoSeasons,
  houseOf,
  matchAspect,
  meanObliquity,
  modalityBalance,
  moonPhase,
  natalChart,
  normalizeLongitude,
  placidusCusps,
  positions,
  ramcOf,
  saturnReturn,
  separation,
  signForLongitude,
  signIndexForLongitude,
  summarizePair,
  synastry,
  transits,
  wholeSignCusps
};
