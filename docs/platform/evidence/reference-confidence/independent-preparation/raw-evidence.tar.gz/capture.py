from pathlib import Path
import subprocess,tarfile,io,hashlib,json
OUT=Path(__file__).parent;ROOT=Path('/Users/chiburashka/.codex/worktrees/4806/site');HEAD='f803d2543ad81343b22d49326b8b46d0e2ea03a0'
raw=subprocess.check_output(['git','archive',HEAD,'src/lib','src/data','src/islands','src/strings'],cwd=ROOT)
with tarfile.open(fileobj=io.BytesIO(raw)) as t:
 for member in t.getmembers():
  p=Path(member.name);assert not p.is_absolute() and '..' not in p.parts
  assert member.isdir() or member.isfile()
  dest=OUT/'source'/p
  if member.isdir():dest.mkdir(parents=True,exist_ok=True)
  else:dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(t.extractfile(member).read())
for name in ['REVIEW.md.log','manifest.json']:
 src=Path('/private/tmp/zodiacs-platform-reference-certainty-preparation/delivery')/name
 (OUT/('prior-'+name)).write_bytes(src.read_bytes())
(OUT/'capture-identity.json').write_text(json.dumps({'head':HEAD,'archiveSha256':hashlib.sha256(raw).hexdigest(),'method':'Read-only git archive of exact commit, validated regular-file/directory extraction into independent scratch','rootOrAuthorEdits':False},indent=2)+'\n')
print('Captured exact f803 source; no root or author edits.')
