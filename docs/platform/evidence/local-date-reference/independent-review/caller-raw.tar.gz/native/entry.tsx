import {h,render} from 'preact';
import ChartCalculator from './source/src/islands/ChartCalculator';
import MoonPhaseTool from './source/src/islands/MoonPhaseTool';
import * as actual from './source/src/lib/engine/full';
import {createModuleLoader} from './source/src/lib/module-load';
import en from './source/src/lib/i18n/ui/en';
import ru from './source/src/lib/i18n/ui/ru';
import {RUSSIAN_RUNTIME as ruRuntime} from './source/src/lib/i18n/ru-runtime/server';
const gates=new Map<string,any>(),pending:any[]=[],calls:any[]=[],outputs:any[]=[],events:any[]=[];
const defer=()=>{let resolve:any;const promise=new Promise(r=>resolve=r);return{promise,resolve};};
const engine={...actual,computeChart(input:any){calls.push({type:'legacy',utc:input.utc.toISOString()});const value=actual.computeChart(input);outputs.push({type:'chart',value});return value;},computeBodies(utc:any){calls.push({type:'bodies',utc:utc.toISOString()});return actual.computeBodies(utc);},bodyLongitude(body:any,utc:any){calls.push({type:'longitude',body,utc:utc.toISOString()});const value=actual.bodyLongitude(body,utc);outputs.push({type:'longitude',body,value});return value;}};
const loader=createModuleLoader(async()=>{events.push({type:'engine-load'});if(gates.has('engine'))await gates.get('engine').promise;return engine;});
const load=async(key:string,importer:()=>Promise<any>)=>{events.push({type:'import',key});if(gates.has(key))await gates.get(key).promise;const module=await importer();if(key==='../lib/engine/calculator-receipt')return{...module,computeCalculatorReceipt(...args:any[]){calls.push({type:'portable',utc:args[0].utc.toISOString()});const value=module.computeCalculatorReceipt(...args);if(value)outputs.push({type:'chart',value:value.chart});return value;}};if(key==='./PositionsShareSurface')return{...module,async preparePrimaryShareArtifact(){events.push({type:'share-prepared'});return{syntheticPreview:true};},async sharePrimaryArtifact(){events.push({type:'share'});return'copied';}};return module;};
const cityRows=[
 ['Apia','Pacific/Apia',-13.83,-171.76],['Kwajalein','Pacific/Kwajalein',8.72,167.73],['Kiritimati','Pacific/Kiritimati',1.87,-157.42],['Guam','Pacific/Guam',13.45,144.75],
 ['Bangkok','Asia/Bangkok',13.75,100.5],['Toronto','America/Toronto',43.65,-79.38],['St Johns','America/St_Johns',47.56,-52.71],['Fixed','+05:30',0,0],['Manaus','America/Manaus',-3.1,-60.03],
].map(([name,tz,lat,lon])=>({name:'Synthetic '+name,tz,lat,lon,admin1:'',country:'ZZ',pop:0}));
const review:any={calls,outputs,events,cityRows,load,engineLoad:loader,failMembership:false,
hold(key:string){const gate=defer();gates.set(key,gate);pending.push(gate);return pending.length-1;},release(id:number){pending[id].resolve();},reset(){calls.length=0;outputs.length=0;events.length=0;},
mount(kind='chart',locale='en',mode='full'){window.__ZDX_UI__={locale,messages:locale==='ru'?ru:en};if(locale==='ru')window.__ZDX_RU__={locale:'ru',data:ruRuntime};render(h(kind==='moon'?MoonPhaseTool:ChartCalculator,{locale,mode}),document.getElementById('mount')!);},unmount(){render(null,document.getElementById('mount')!);}};
window.review=review;
addEventListener('zodiacs:chart-computed',(e:any)=>events.push({type:'computed',detail:e.detail}));
addEventListener('zodiacs:chart-context',(e:any)=>events.push({type:'context',detail:e.detail}));
