# Prepared C-014 normal-build browser driver

Prepared only; no browser run has been executed. `normal-build-drive.mjs` passes Node 22 syntax checking. `normal-build-drive.original.mjs` preserves the exact original prepared driver for later comparison.

The 24 independent browser contexts cover six locales × birth chart / selected-city Moon × 1280 / 390 widths. Every group uses the actual built GeoNames index/shard and visible Apia option, verifies the selected chip, calculates unknown-time `2011-12-29`, edits to skipped `2011-12-30`, checks the exact catalog error and focused alert plus cleared prior result/actions/global chart context, then recovers with `2011-12-31`. Chart time text `08:30` remains typed while its unknown-time toggle is checked; Moon time remains blank. Both English desktop groups also verify the existing known-time `2011-12-30 08:30` success path. The driver does not click Save or submit any subscription.

The driver reads and verifies all twelve reviewed C-014 source hashes, records current Git HEAD/status and support source identities, then serves only actual files from the normal build. Each served path records its byte count and SHA-256, and changed bytes while serving fail. It substitutes no product modules, date methods, city responses, receipt/numerical results or loader behavior. It counts no numerical calls and makes no such claim. Positive chart controls require actual save/receipt action elements and an enabled receipt button before testing their removal.

All external and non-GET requests are blocked and recorded, so Plausible delivery remains excluded. Same-origin GET files are served directly. Uncaught page errors, console errors, failed/blocked requests, actual server requests, DOM snapshots and screenshots remain in the output. Expected refusal console errors and blocked external-resource messages are recorded; the driver does not falsely claim zero console errors. Known footer teardown aborts retain the existing repository qualification. Fresh browser contexts and explicit `zodiacs.profile.v1` checks establish that this flow saved no legacy profile; they do not certify every storage backend or account lifecycle. A separate signed-in combined control already covers that distinct scope.

Root should inspect the driver and run it only after the normal build finishes:

```
OUT_DIR=/private/tmp/zodiacs-platform-local-date-root-acceptance/run-1 /private/tmp/zodiacs-platform-runtime/node_modules/node/bin/node /private/tmp/zodiacs-platform-local-date-root-acceptance/normal-build-drive.mjs > /private/tmp/zodiacs-platform-local-date-root-acceptance/run-1.log 2>&1
```

`OUT_DIR` must not already exist: preserving each initial failure/run is deliberate. Optional `SOURCE_ROOT`, `DIST_DIR`, and `C014_FREEZE_JSON` select another verified local checkout/build and the reviewed twelve-file identity. No remote URL/auth/preview support is included. The driver owns its loopback server and Chrome contexts and closes them in `finally`. Root retains any execution, integration and evidence publication decisions.

Source inspection used existing Moon actual-page and receipt drivers, `BirthFields`, `PlaceSearch`, the actual city index/shard, and the two current callers. Several initial guessed source paths were absent; these preparation-only read errors are recorded in `preparation-read-errors.log`, with no source or browser conclusion drawn from them. No root source, test, workflow, locale or build output was edited.
