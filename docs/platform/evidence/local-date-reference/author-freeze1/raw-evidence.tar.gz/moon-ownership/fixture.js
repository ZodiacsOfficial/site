(() => {
  var __defProp = Object.defineProperty;
  var __getOwnPropNames = Object.getOwnPropertyNames;
  var __esm = (fn, res, err) => function __init() {
    if (err) throw err[0];
    try {
      return fn && (res = (0, fn[__getOwnPropNames(fn)[0]])(fn = 0)), res;
    } catch (e3) {
      throw err = [e3], e3;
    }
  };
  var __export = (target, all) => {
    for (var name in all)
      __defProp(target, name, { get: all[name], enumerable: true });
  };

  // <define:import.meta.env>
  var define_import_meta_env_default;
  var init_define_import_meta_env = __esm({
    "<define:import.meta.env>"() {
      define_import_meta_env_default = {};
    }
  });

  // owned:places
  var places_exports = {};
  __export(places_exports, {
    preloadIndex: () => preloadIndex,
    searchCities: () => searchCities
  });
  var city, preloadIndex, searchCities;
  var init_places = __esm({
    "owned:places"() {
      init_define_import_meta_env();
      city = { name: "Synthetic Bangkok", admin1: "", country: "TH", lat: 13.75, lon: 100.5, tz: "Asia/Bangkok", pop: 0 };
      preloadIndex = async () => {
      };
      searchCities = async (q2) => q2.toLowerCase().includes("bang") ? [city] : [];
    }
  });

  // <stdin>
  init_define_import_meta_env();

  // ../../../Users/chiburashka/.codex/worktrees/4806/site/node_modules/preact/dist/preact.module.js
  init_define_import_meta_env();
  var n;
  var l;
  var u;
  var t;
  var i;
  var r;
  var o;
  var e;
  var f;
  var c;
  var a;
  var s;
  var h;
  var p;
  var v;
  var y;
  var d = {};
  var w = [];
  var _ = /acit|ex(?:s|g|n|p|$)|rph|grid|ows|mnc|ntw|ine[ch]|zoo|^ord|itera/i;
  var g = Array.isArray;
  function m(n2, l3) {
    for (var u4 in l3) n2[u4] = l3[u4];
    return n2;
  }
  function b(n2) {
    n2 && n2.parentNode && n2.parentNode.removeChild(n2);
  }
  function k(l3, u4, t4) {
    var i3, r3, o3, e3 = {};
    for (o3 in u4) "key" == o3 ? i3 = u4[o3] : "ref" == o3 ? r3 = u4[o3] : e3[o3] = u4[o3];
    if (arguments.length > 2 && (e3.children = arguments.length > 3 ? n.call(arguments, 2) : t4), "function" == typeof l3 && null != l3.defaultProps) for (o3 in l3.defaultProps) void 0 === e3[o3] && (e3[o3] = l3.defaultProps[o3]);
    return x(l3, e3, i3, r3, null);
  }
  function x(n2, t4, i3, r3, o3) {
    var e3 = { type: n2, props: t4, key: i3, ref: r3, __k: null, __: null, __b: 0, __e: null, __c: null, constructor: void 0, __v: null == o3 ? ++u : o3, __i: -1, __u: 0 };
    return null == o3 && null != l.vnode && l.vnode(e3), e3;
  }
  function S(n2) {
    return n2.children;
  }
  function C(n2, l3) {
    this.props = n2, this.context = l3;
  }
  function $(n2, l3) {
    if (null == l3) return n2.__ ? $(n2.__, n2.__i + 1) : null;
    for (var u4; l3 < n2.__k.length; l3++) if (null != (u4 = n2.__k[l3]) && null != u4.__e) return u4.__e;
    return "function" == typeof n2.type ? $(n2) : null;
  }
  function I(n2) {
    if (n2.__P && n2.__d) {
      var u4 = n2.__v, t4 = u4.__e, i3 = [], r3 = [], o3 = m({}, u4);
      o3.__v = u4.__v + 1, l.vnode && l.vnode(o3), q(n2.__P, o3, u4, n2.__n, n2.__P.namespaceURI, 32 & u4.__u ? [t4] : null, i3, null == t4 ? $(u4) : t4, !!(32 & u4.__u), r3), o3.__v = u4.__v, o3.__.__k[o3.__i] = o3, D(i3, o3, r3), u4.__e = u4.__ = null, o3.__e != t4 && P(o3);
    }
  }
  function P(n2) {
    if (null != (n2 = n2.__) && null != n2.__c) return n2.__e = n2.__c.base = null, n2.__k.some(function(l3) {
      if (null != l3 && null != l3.__e) return n2.__e = n2.__c.base = l3.__e;
    }), P(n2);
  }
  function A(n2) {
    (!n2.__d && (n2.__d = true) && i.push(n2) && !H.__r++ || r != l.debounceRendering) && ((r = l.debounceRendering) || o)(H);
  }
  function H() {
    try {
      for (var n2, l3 = 1; i.length; ) i.length > l3 && i.sort(e), n2 = i.shift(), l3 = i.length, I(n2);
    } finally {
      i.length = H.__r = 0;
    }
  }
  function L(n2, l3, u4, t4, i3, r3, o3, e3, f4, c3, a3) {
    var s3, h3, p3, v3, y3, _2, g2, m3 = t4 && t4.__k || w, b2 = l3.length;
    for (f4 = T(u4, l3, m3, f4, b2), s3 = 0; s3 < b2; s3++) null != (p3 = u4.__k[s3]) && (h3 = -1 != p3.__i && m3[p3.__i] || d, p3.__i = s3, _2 = q(n2, p3, h3, i3, r3, o3, e3, f4, c3, a3), v3 = p3.__e, p3.ref && h3.ref != p3.ref && (h3.ref && J(h3.ref, null, p3), a3.push(p3.ref, p3.__c || v3, p3)), null == y3 && null != v3 && (y3 = v3), (g2 = !!(4 & p3.__u)) || h3.__k === p3.__k ? (f4 = j(p3, f4, n2, g2), g2 && h3.__e && (h3.__e = null)) : "function" == typeof p3.type && void 0 !== _2 ? f4 = _2 : v3 && (f4 = v3.nextSibling), p3.__u &= -7);
    return u4.__e = y3, f4;
  }
  function T(n2, l3, u4, t4, i3) {
    var r3, o3, e3, f4, c3, a3 = u4.length, s3 = a3, h3 = 0;
    for (n2.__k = new Array(i3), r3 = 0; r3 < i3; r3++) null != (o3 = l3[r3]) && "boolean" != typeof o3 && "function" != typeof o3 ? ("string" == typeof o3 || "number" == typeof o3 || "bigint" == typeof o3 || o3.constructor == String ? o3 = n2.__k[r3] = x(null, o3, null, null, null) : g(o3) ? o3 = n2.__k[r3] = x(S, { children: o3 }, null, null, null) : void 0 === o3.constructor && o3.__b > 0 ? o3 = n2.__k[r3] = x(o3.type, o3.props, o3.key, o3.ref ? o3.ref : null, o3.__v) : n2.__k[r3] = o3, f4 = r3 + h3, o3.__ = n2, o3.__b = n2.__b + 1, e3 = null, -1 != (c3 = o3.__i = O(o3, u4, f4, s3)) && (s3--, (e3 = u4[c3]) && (e3.__u |= 2)), null == e3 || null == e3.__v ? (-1 == c3 && (i3 > a3 ? h3-- : i3 < a3 && h3++), "function" != typeof o3.type && (o3.__u |= 4)) : c3 != f4 && (c3 == f4 - 1 ? h3-- : c3 == f4 + 1 ? h3++ : (c3 > f4 ? h3-- : h3++, o3.__u |= 4))) : n2.__k[r3] = null;
    if (s3) for (r3 = 0; r3 < a3; r3++) null != (e3 = u4[r3]) && 0 == (2 & e3.__u) && (e3.__e == t4 && (t4 = $(e3)), K(e3, e3));
    return t4;
  }
  function j(n2, l3, u4, t4) {
    var i3, r3;
    if ("function" == typeof n2.type) {
      for (i3 = n2.__k, r3 = 0; i3 && r3 < i3.length; r3++) i3[r3] && (i3[r3].__ = n2, l3 = j(i3[r3], l3, u4, t4));
      return l3;
    }
    n2.__e != l3 && (t4 && (l3 && n2.type && !l3.parentNode && (l3 = $(n2)), u4.insertBefore(n2.__e, l3 || null)), l3 = n2.__e);
    do {
      l3 = l3 && l3.nextSibling;
    } while (null != l3 && 8 == l3.nodeType);
    return l3;
  }
  function O(n2, l3, u4, t4) {
    var i3, r3, o3, e3 = n2.key, f4 = n2.type, c3 = l3[u4], a3 = null != c3 && 0 == (2 & c3.__u);
    if (null === c3 && null == e3 || a3 && e3 == c3.key && f4 == c3.type) return u4;
    if (t4 > (a3 ? 1 : 0)) {
      for (i3 = u4 - 1, r3 = u4 + 1; i3 >= 0 || r3 < l3.length; ) if (null != (c3 = l3[o3 = i3 >= 0 ? i3-- : r3++]) && 0 == (2 & c3.__u) && e3 == c3.key && f4 == c3.type) return o3;
    }
    return -1;
  }
  function z(n2, l3, u4) {
    "-" == l3[0] ? n2.setProperty(l3, null == u4 ? "" : u4) : n2[l3] = null == u4 ? "" : "number" != typeof u4 || _.test(l3) ? u4 : u4 + "px";
  }
  function N(n2, l3, u4, t4, i3) {
    var r3, o3;
    n: if ("style" == l3) if ("string" == typeof u4) n2.style.cssText = u4;
    else {
      if ("string" == typeof t4 && (n2.style.cssText = t4 = ""), t4) for (l3 in t4) u4 && l3 in u4 || z(n2.style, l3, "");
      if (u4) for (l3 in u4) t4 && u4[l3] == t4[l3] || z(n2.style, l3, u4[l3]);
    }
    else if ("o" == l3[0] && "n" == l3[1]) r3 = l3 != (l3 = l3.replace(s, "$1")), o3 = l3.toLowerCase(), l3 = o3 in n2 || "onFocusOut" == l3 || "onFocusIn" == l3 ? o3.slice(2) : l3.slice(2), n2.l || (n2.l = {}), n2.l[l3 + r3] = u4, u4 ? t4 ? u4[a] = t4[a] : (u4[a] = h, n2.addEventListener(l3, r3 ? v : p, r3)) : n2.removeEventListener(l3, r3 ? v : p, r3);
    else {
      if ("http://www.w3.org/2000/svg" == i3) l3 = l3.replace(/xlink(H|:h)/, "h").replace(/sName$/, "s");
      else if ("width" != l3 && "height" != l3 && "href" != l3 && "list" != l3 && "form" != l3 && "tabIndex" != l3 && "download" != l3 && "rowSpan" != l3 && "colSpan" != l3 && "role" != l3 && "popover" != l3 && l3 in n2) try {
        n2[l3] = null == u4 ? "" : u4;
        break n;
      } catch (n3) {
      }
      "function" == typeof u4 || (null == u4 || false === u4 && "-" != l3[4] ? n2.removeAttribute(l3) : n2.setAttribute(l3, "popover" == l3 && 1 == u4 ? "" : u4));
    }
  }
  function V(n2) {
    return function(u4) {
      if (this.l) {
        var t4 = this.l[u4.type + n2];
        if (null == u4[c]) u4[c] = h++;
        else if (u4[c] < t4[a]) return;
        return t4(l.event ? l.event(u4) : u4);
      }
    };
  }
  function q(n2, u4, t4, i3, r3, o3, e3, f4, c3, a3) {
    var s3, h3, p3, v3, y3, d3, _2, k3, x2, M, $2, I2, P2, A3, H2, T3, j3 = u4.type;
    if (void 0 !== u4.constructor) return null;
    128 & t4.__u && (c3 = !!(32 & t4.__u), o3 = [f4 = u4.__e = t4.__e]), (s3 = l.__b) && s3(u4);
    n: if ("function" == typeof j3) {
      h3 = e3.length;
      try {
        if (x2 = u4.props, M = j3.prototype && j3.prototype.render, $2 = (s3 = j3.contextType) && i3[s3.__c], I2 = s3 ? $2 ? $2.props.value : s3.__ : i3, t4.__c ? k3 = (p3 = u4.__c = t4.__c).__ = p3.__E : (M ? u4.__c = p3 = new j3(x2, I2) : (u4.__c = p3 = new C(x2, I2), p3.constructor = j3, p3.render = Q), $2 && $2.sub(p3), p3.state || (p3.state = {}), p3.__n = i3, v3 = p3.__d = true, p3.__h = [], p3._sb = []), M && null == p3.__s && (p3.__s = p3.state), M && null != j3.getDerivedStateFromProps && (p3.__s == p3.state && (p3.__s = m({}, p3.__s)), m(p3.__s, j3.getDerivedStateFromProps(x2, p3.__s))), y3 = p3.props, d3 = p3.state, p3.__v = u4, v3) M && null == j3.getDerivedStateFromProps && null != p3.componentWillMount && p3.componentWillMount(), M && null != p3.componentDidMount && p3.__h.push(p3.componentDidMount);
        else {
          if (M && null == j3.getDerivedStateFromProps && x2 !== y3 && null != p3.componentWillReceiveProps && p3.componentWillReceiveProps(x2, I2), u4.__v == t4.__v || !p3.__e && null != p3.shouldComponentUpdate && false === p3.shouldComponentUpdate(x2, p3.__s, I2)) {
            u4.__v != t4.__v && (p3.props = x2, p3.state = p3.__s, p3.__d = false), u4.__e = t4.__e, u4.__k = t4.__k, u4.__k.some(function(n3) {
              n3 && (n3.__ = u4);
            }), w.push.apply(p3.__h, p3._sb), p3._sb = [], p3.__h.length && e3.push(p3);
            break n;
          }
          null != p3.componentWillUpdate && p3.componentWillUpdate(x2, p3.__s, I2), M && null != p3.componentDidUpdate && p3.__h.push(function() {
            p3.componentDidUpdate(y3, d3, _2);
          });
        }
        if (p3.context = I2, p3.props = x2, p3.__P = n2, p3.__e = false, P2 = l.__r, A3 = 0, M) p3.state = p3.__s, p3.__d = false, P2 && P2(u4), s3 = p3.render(p3.props, p3.state, p3.context), w.push.apply(p3.__h, p3._sb), p3._sb = [];
        else do {
          p3.__d = false, P2 && P2(u4), s3 = p3.render(p3.props, p3.state, p3.context), p3.state = p3.__s;
        } while (p3.__d && ++A3 < 25);
        p3.state = p3.__s, null != p3.getChildContext && (i3 = m(m({}, i3), p3.getChildContext())), M && !v3 && null != p3.getSnapshotBeforeUpdate && (_2 = p3.getSnapshotBeforeUpdate(y3, d3)), H2 = null != s3 && s3.type === S && null == s3.key ? E(s3.props.children) : s3, f4 = L(n2, g(H2) ? H2 : [H2], u4, t4, i3, r3, o3, e3, f4, c3, a3), p3.base = u4.__e, u4.__u &= -161, p3.__h.length && e3.push(p3), k3 && (p3.__E = p3.__ = null);
      } catch (n3) {
        if (e3.length = h3, u4.__v = null, c3 || null != o3) {
          if (n3.then) {
            for (u4.__u |= c3 ? 160 : 128; f4 && 8 == f4.nodeType && f4.nextSibling; ) f4 = f4.nextSibling;
            null != o3 && (o3[o3.indexOf(f4)] = null), u4.__e = f4;
          } else if (null != o3) for (T3 = o3.length; T3--; ) b(o3[T3]);
        } else u4.__e = t4.__e;
        null == u4.__k && (u4.__k = t4.__k || []), n3.then || B(u4), l.__e(n3, u4, t4);
      }
    } else null == o3 && u4.__v == t4.__v ? (u4.__k = t4.__k, u4.__e = t4.__e) : f4 = u4.__e = G(t4.__e, u4, t4, i3, r3, o3, e3, c3, a3);
    return (s3 = l.diffed) && s3(u4), 128 & u4.__u ? void 0 : f4;
  }
  function B(n2) {
    n2 && (n2.__c && (n2.__c.__e = true), n2.__k && n2.__k.some(B));
  }
  function D(n2, u4, t4) {
    for (var i3 = 0; i3 < t4.length; i3++) J(t4[i3], t4[++i3], t4[++i3]);
    l.__c && l.__c(u4, n2), n2.some(function(u5) {
      try {
        n2 = u5.__h, u5.__h = [], n2.some(function(n3) {
          n3.call(u5);
        });
      } catch (n3) {
        l.__e(n3, u5.__v);
      }
    });
  }
  function E(n2) {
    return "object" != typeof n2 || null == n2 || n2.__b > 0 ? n2 : g(n2) ? n2.map(E) : void 0 !== n2.constructor ? null : m({}, n2);
  }
  function G(u4, t4, i3, r3, o3, e3, f4, c3, a3) {
    var s3, h3, p3, v3, y3, w3, _2, m3 = i3.props || d, k3 = t4.props, x2 = t4.type;
    if ("svg" == x2 ? o3 = "http://www.w3.org/2000/svg" : "math" == x2 ? o3 = "http://www.w3.org/1998/Math/MathML" : o3 || (o3 = "http://www.w3.org/1999/xhtml"), null != e3) {
      for (s3 = 0; s3 < e3.length; s3++) if ((y3 = e3[s3]) && "setAttribute" in y3 == !!x2 && (x2 ? y3.localName == x2 : 3 == y3.nodeType)) {
        u4 = y3, e3[s3] = null;
        break;
      }
    }
    if (null == u4) {
      if (null == x2) return document.createTextNode(k3);
      u4 = document.createElementNS(o3, x2, k3.is && k3), c3 && (l.__m && l.__m(t4, e3), c3 = false), e3 = null;
    }
    if (null == x2) m3 === k3 || c3 && u4.data == k3 || (u4.data = k3);
    else {
      if (e3 = "textarea" == x2 && null != k3.defaultValue ? null : e3 && n.call(u4.childNodes), !c3 && null != e3) for (m3 = {}, s3 = 0; s3 < u4.attributes.length; s3++) m3[(y3 = u4.attributes[s3]).name] = y3.value;
      for (s3 in m3) y3 = m3[s3], "dangerouslySetInnerHTML" == s3 ? p3 = y3 : "children" == s3 || s3 in k3 || "value" == s3 && "defaultValue" in k3 || "checked" == s3 && "defaultChecked" in k3 || N(u4, s3, null, y3, o3);
      for (s3 in k3) y3 = k3[s3], "children" == s3 ? v3 = y3 : "dangerouslySetInnerHTML" == s3 ? h3 = y3 : "value" == s3 ? w3 = y3 : "checked" == s3 ? _2 = y3 : c3 && "function" != typeof y3 || m3[s3] === y3 || N(u4, s3, y3, m3[s3], o3);
      if (h3) c3 || p3 && (h3.__html == p3.__html || h3.__html == u4.innerHTML) || (u4.innerHTML = h3.__html), t4.__k = [];
      else if (p3 && (u4.innerHTML = ""), L("template" == t4.type ? u4.content : u4, g(v3) ? v3 : [v3], t4, i3, r3, "foreignObject" == x2 ? "http://www.w3.org/1999/xhtml" : o3, e3, f4, e3 ? e3[0] : i3.__k && $(i3, 0), c3, a3), null != e3) for (s3 = e3.length; s3--; ) b(e3[s3]);
      c3 && "textarea" != x2 || (s3 = "value", "progress" == x2 && null == w3 ? u4.removeAttribute("value") : null != w3 && (w3 !== u4[s3] || "progress" == x2 && !w3 || "option" == x2 && w3 != m3[s3]) && N(u4, s3, w3, m3[s3], o3), s3 = "checked", null != _2 && _2 != u4[s3] && N(u4, s3, _2, m3[s3], o3));
    }
    return u4;
  }
  function J(n2, u4, t4) {
    try {
      if ("function" == typeof n2) {
        var i3 = "function" == typeof n2.__u;
        i3 && n2.__u(), i3 && null == u4 || (n2.__u = n2(u4));
      } else n2.current = u4;
    } catch (n3) {
      l.__e(n3, t4);
    }
  }
  function K(n2, u4, t4) {
    var i3, r3;
    if (l.unmount && l.unmount(n2), (i3 = n2.ref) && (i3.current && i3.current != n2.__e || J(i3, null, u4)), null != (i3 = n2.__c)) {
      if (i3.componentWillUnmount) try {
        i3.componentWillUnmount();
      } catch (n3) {
        l.__e(n3, u4);
      }
      i3.base = i3.__P = i3.__n = null;
    }
    if (i3 = n2.__k) for (r3 = 0; r3 < i3.length; r3++) i3[r3] && K(i3[r3], u4, t4 || "function" != typeof n2.type);
    t4 || b(n2.__e), n2.__c = n2.__ = n2.__e = void 0;
  }
  function Q(n2, l3, u4) {
    return this.constructor(n2, u4);
  }
  function R(u4, t4, i3) {
    var r3, o3, e3, f4;
    t4 == document && (t4 = document.documentElement), l.__ && l.__(u4, t4), o3 = (r3 = "function" == typeof i3) ? null : i3 && i3.__k || t4.__k, e3 = [], f4 = [], q(t4, u4 = (!r3 && i3 || t4).__k = k(S, null, [u4]), o3 || d, d, t4.namespaceURI, !r3 && i3 ? [i3] : o3 ? null : t4.firstChild ? n.call(t4.childNodes) : null, e3, !r3 && i3 ? i3 : o3 ? o3.__e : t4.firstChild, r3, f4), D(e3, u4, f4), u4.props.children = null;
  }
  n = w.slice, l = { __e: function(n2, l3, u4, t4) {
    for (var i3, r3, o3; l3 = l3.__; ) if ((i3 = l3.__c) && !i3.__) try {
      if ((r3 = i3.constructor) && null != r3.getDerivedStateFromError && (i3.setState(r3.getDerivedStateFromError(n2)), o3 = i3.__d), null != i3.componentDidCatch && (i3.componentDidCatch(n2, t4 || {}), o3 = i3.__d), o3) return i3.__E = i3;
    } catch (l4) {
      n2 = l4;
    }
    throw n2;
  } }, u = 0, t = function(n2) {
    return null != n2 && void 0 === n2.constructor;
  }, C.prototype.setState = function(n2, l3) {
    var u4;
    u4 = null != this.__s && this.__s != this.state ? this.__s : this.__s = m({}, this.state), "function" == typeof n2 && (n2 = n2(m({}, u4), this.props)), n2 && m(u4, n2), null != n2 && this.__v && (l3 && this._sb.push(l3), A(this));
  }, C.prototype.forceUpdate = function(n2) {
    this.__v && (this.__e = true, n2 && this.__h.push(n2), A(this));
  }, C.prototype.render = S, i = [], o = "function" == typeof Promise ? Promise.prototype.then.bind(Promise.resolve()) : setTimeout, e = function(n2, l3) {
    return n2.__v.__b - l3.__v.__b;
  }, H.__r = 0, f = Math.random().toString(8), c = "__d" + f, a = "__a" + f, s = /(PointerCapture)$|Capture$/i, h = 0, p = V(false), v = V(true), y = 0;

  // src/islands/MoonPhaseTool.tsx
  init_define_import_meta_env();

  // ../../../Users/chiburashka/.codex/worktrees/4806/site/node_modules/preact/hooks/dist/hooks.module.js
  init_define_import_meta_env();
  var t2;
  var r2;
  var u2;
  var i2;
  var o2 = 0;
  var f2 = [];
  var c2 = l;
  var e2 = c2.__b;
  var a2 = c2.__r;
  var v2 = c2.diffed;
  var l2 = c2.__c;
  var m2 = c2.unmount;
  var p2 = c2.__;
  function s2(n2, t4) {
    c2.__h && c2.__h(r2, n2, o2 || t4), o2 = 0;
    var u4 = r2.__H || (r2.__H = { __: [], __h: [] });
    return n2 >= u4.__.length && u4.__.push({}), u4.__[n2];
  }
  function d2(n2) {
    return o2 = 1, y2(D2, n2);
  }
  function y2(n2, u4, i3) {
    var o3 = s2(t2++, 2);
    if (o3.t = n2, !o3.__c && (o3.__ = [i3 ? i3(u4) : D2(void 0, u4), function(n3) {
      var t4 = o3.__N ? o3.__N[0] : o3.__[0], r3 = o3.t(t4, n3);
      t4 !== r3 && (o3.__N = [r3, o3.__[1]], o3.__c.setState({}));
    }], o3.__c = r2, !r2.__f)) {
      var f4 = function(n3, t4, r3) {
        if (!o3.__c.__H) return true;
        var u5 = false, i4 = o3.__c.props !== n3;
        if (o3.__c.__H.__.some(function(n4) {
          if (n4.__N) {
            u5 = true;
            var t5 = n4.__[0];
            n4.__ = n4.__N, n4.__N = void 0, t5 !== n4.__[0] && (i4 = true);
          }
        }), c3) {
          var f5 = c3.call(this, n3, t4, r3);
          return u5 ? f5 || i4 : f5;
        }
        return !u5 || i4;
      };
      r2.__f = true;
      var c3 = r2.shouldComponentUpdate, e3 = r2.componentWillUpdate;
      r2.componentWillUpdate = function(n3, t4, r3) {
        if (this.__e) {
          var u5 = c3;
          c3 = void 0, f4(n3, t4, r3), c3 = u5;
        }
        e3 && e3.call(this, n3, t4, r3);
      }, r2.shouldComponentUpdate = f4;
    }
    return o3.__N || o3.__;
  }
  function h2(n2, u4) {
    var i3 = s2(t2++, 3);
    !c2.__s && C2(i3.__H, u4) && (i3.__ = n2, i3.u = u4, r2.__H.__h.push(i3));
  }
  function A2(n2) {
    return o2 = 5, T2(function() {
      return { current: n2 };
    }, []);
  }
  function T2(n2, r3) {
    var u4 = s2(t2++, 7);
    return C2(u4.__H, r3) && (u4.__ = n2(), u4.__H = r3, u4.__h = n2), u4.__;
  }
  function j2() {
    for (var n2; n2 = f2.shift(); ) {
      var t4 = n2.__H;
      if (n2.__P && t4) try {
        t4.__h.some(z2), t4.__h.some(B2), t4.__h = [];
      } catch (r3) {
        t4.__h = [], c2.__e(r3, n2.__v);
      }
    }
  }
  c2.__b = function(n2) {
    r2 = null, e2 && e2(n2);
  }, c2.__ = function(n2, t4) {
    n2 && t4.__k && t4.__k.__m && (n2.__m = t4.__k.__m), p2 && p2(n2, t4);
  }, c2.__r = function(n2) {
    a2 && a2(n2), t2 = 0;
    var i3 = (r2 = n2.__c).__H;
    i3 && (u2 === r2 ? (i3.__h = [], r2.__h = [], i3.__.some(function(n3) {
      n3.__N && (n3.__ = n3.__N), n3.u = n3.__N = void 0;
    })) : (i3.__h.length && j2(), t2 = 0)), u2 = r2;
  }, c2.diffed = function(n2) {
    v2 && v2(n2);
    var t4 = n2.__c;
    t4 && t4.__H && (t4.__H.__h.length && (1 !== f2.push(t4) && i2 === c2.requestAnimationFrame || ((i2 = c2.requestAnimationFrame) || w2)(j2)), t4.__H.__.some(function(n3) {
      n3.u && (n3.__H = n3.u, n3.u = void 0);
    })), u2 = r2 = null;
  }, c2.__c = function(n2, t4) {
    t4.some(function(n3) {
      try {
        n3.__h.some(z2), n3.__h = n3.__h.filter(function(n4) {
          return !n4.__ || B2(n4);
        });
      } catch (r3) {
        t4.some(function(n4) {
          n4.__h && (n4.__h = []);
        }), t4 = [], c2.__e(r3, n3.__v);
      }
    }), l2 && l2(n2, t4);
  }, c2.unmount = function(n2) {
    m2 && m2(n2);
    var t4, r3 = n2.__c;
    r3 && r3.__H && (r3.__H.__.some(function(n3) {
      try {
        z2(n3);
      } catch (n4) {
        t4 = n4;
      }
    }), r3.__H = void 0, t4 && c2.__e(t4, r3.__v));
  };
  var k2 = "function" == typeof requestAnimationFrame;
  function w2(n2) {
    var t4, r3 = function() {
      clearTimeout(u4), k2 && cancelAnimationFrame(t4), setTimeout(n2);
    }, u4 = setTimeout(r3, 35);
    k2 && (t4 = requestAnimationFrame(r3));
  }
  function z2(n2) {
    var t4 = r2, u4 = n2.__c;
    "function" == typeof u4 && (n2.__c = void 0, u4()), r2 = t4;
  }
  function B2(n2) {
    var t4 = r2;
    n2.__c = n2.__(), r2 = t4;
  }
  function C2(n2, t4) {
    return !n2 || n2.length !== t4.length || t4.some(function(t5, r3) {
      return t5 !== n2[r3];
    });
  }
  function D2(n2, t4) {
    return "function" == typeof t4 ? t4(n2) : t4;
  }

  // src/islands/EvidenceDisclosure.tsx
  init_define_import_meta_env();

  // ../../../Users/chiburashka/.codex/worktrees/4806/site/node_modules/preact/jsx-runtime/dist/jsxRuntime.module.js
  init_define_import_meta_env();
  var f3 = 0;
  function u3(e3, t4, n2, o3, i3, u4) {
    t4 || (t4 = {});
    var a3, c3, p3 = t4;
    if ("ref" in p3) for (c3 in p3 = {}, t4) "ref" == c3 ? a3 = t4[c3] : p3[c3] = t4[c3];
    var l3 = { type: e3, props: p3, key: n2, ref: a3, __k: null, __: null, __b: 0, __e: null, __c: null, constructor: void 0, __v: --f3, __i: -1, __u: 0, __source: i3, __self: u4 };
    if ("function" == typeof e3 && (a3 = e3.defaultProps)) for (c3 in a3) void 0 === p3[c3] && (p3[c3] = a3[c3]);
    return l.vnode && l.vnode(l3), l3;
  }

  // src/islands/EvidenceDisclosure.tsx
  function EvidenceDisclosure({
    label,
    description,
    variant = "quiet",
    className,
    children
  }) {
    const classes = [
      "evidence-disclosure",
      `evidence-disclosure--${variant}`,
      className
    ].filter(Boolean).join(" ");
    return /* @__PURE__ */ u3("details", { class: classes, "data-evidence-disclosure": true, "data-evidence-variant": variant, children: [
      /* @__PURE__ */ u3("summary", { children: /* @__PURE__ */ u3("span", { class: "evidence-disclosure__summary", children: [
        /* @__PURE__ */ u3("strong", { children: label }),
        description && /* @__PURE__ */ u3("small", { children: description })
      ] }) }),
      /* @__PURE__ */ u3("div", { class: "evidence-disclosure__body", children })
    ] });
  }
  var EvidenceDisclosure_default = EvidenceDisclosure;

  // src/islands/PlaceSearch.tsx
  init_define_import_meta_env();

  // src/lib/i18n/index.ts
  init_define_import_meta_env();

  // src/lib/signs.ts
  init_define_import_meta_env();

  // src/lib/i18n/core.ts
  init_define_import_meta_env();
  var LOCALES = ["en", "es", "pt", "fr", "it", "ru", "ar"];
  var CATALOG_LOCALES = ["en", "es", "pt", "fr", "it", "ru"];
  var DEFAULT_LOCALE = "en";
  var LOCALE_META = {
    en: { pathPrefix: "", htmlLang: "en", dir: "ltr", hreflang: "en", intlLocale: "en-US", ogLocale: "en_US", languageName: "English" },
    es: { pathPrefix: "/es", htmlLang: "es", dir: "ltr", hreflang: "es", intlLocale: "es-419", ogLocale: "es_LA", languageName: "Espa\xF1ol" },
    pt: { pathPrefix: "/pt", htmlLang: "pt-BR", dir: "ltr", hreflang: "pt-BR", intlLocale: "pt-BR", ogLocale: "pt_BR", languageName: "Portugu\xEAs (Brasil)" },
    fr: { pathPrefix: "/fr", htmlLang: "fr", dir: "ltr", hreflang: "fr", intlLocale: "fr-FR", ogLocale: "fr_FR", languageName: "Fran\xE7ais" },
    it: { pathPrefix: "/it", htmlLang: "it", dir: "ltr", hreflang: "it", intlLocale: "it-IT", ogLocale: "it_IT", languageName: "Italiano" },
    ru: { pathPrefix: "/ru", htmlLang: "ru", dir: "ltr", hreflang: "ru", intlLocale: "ru-RU", ogLocale: "ru_RU", languageName: "\u0420\u0443\u0441\u0441\u043A\u0438\u0439" },
    ar: { pathPrefix: "/ar", htmlLang: "ar", dir: "rtl", hreflang: "ar", intlLocale: "ar-u-ca-gregory-nu-latn", ogLocale: "ar_AR", languageName: "\u0627\u0644\u0639\u0631\u0628\u064A\u0629" }
  };
  function isCatalogLocale(locale) {
    return CATALOG_LOCALES.includes(locale);
  }
  function normalizeKnownLocale(locale) {
    const value = locale?.trim().toLowerCase();
    if (!value) return DEFAULT_LOCALE;
    return LOCALES.find((candidate) => value === candidate || value.startsWith(`${candidate}-`)) ?? DEFAULT_LOCALE;
  }
  function normalizeCatalogLocale(locale) {
    const normalized = normalizeKnownLocale(locale);
    return isCatalogLocale(normalized) ? normalized : DEFAULT_LOCALE;
  }
  function requireCatalogLocale(locale) {
    if (!isCatalogLocale(locale)) {
      throw new Error(`Locale ${locale} has no complete production catalog`);
    }
    return locale;
  }

  // src/lib/i18n/ru-runtime/index.ts
  init_define_import_meta_env();

  // src/lib/i18n/ru-runtime/client.ts
  init_define_import_meta_env();
  function clientRussianRuntime() {
    const payload = globalThis.__ZDX_RU__;
    if (!payload || payload.locale !== "ru" || !payload.data) {
      throw new Error("Missing staged Russian runtime payload");
    }
    return payload.data;
  }

  // src/lib/i18n/ru-runtime/server.ts
  init_define_import_meta_env();

  // src/lib/i18n/ui/ru.ts
  init_define_import_meta_env();
  var RUSSIAN_UI_PLURALS = {
    charts: {
      one: "{n} \u043A\u0430\u0440\u0442\u0430",
      few: "{n} \u043A\u0430\u0440\u0442\u044B",
      many: "{n} \u043A\u0430\u0440\u0442",
      other: "{n} \u043A\u0430\u0440\u0442\u044B"
    },
    savedCharts: {
      one: "{n} \u0441\u043E\u0445\u0440\u0430\u043D\u0451\u043D\u043D\u0430\u044F \u043A\u0430\u0440\u0442\u0430",
      few: "{n} \u0441\u043E\u0445\u0440\u0430\u043D\u0451\u043D\u043D\u044B\u0435 \u043A\u0430\u0440\u0442\u044B",
      many: "{n} \u0441\u043E\u0445\u0440\u0430\u043D\u0451\u043D\u043D\u044B\u0445 \u043A\u0430\u0440\u0442",
      other: "{n} \u0441\u043E\u0445\u0440\u0430\u043D\u0451\u043D\u043D\u043E\u0439 \u043A\u0430\u0440\u0442\u044B"
    },
    aspects: {
      one: "{n} \u0430\u0441\u043F\u0435\u043A\u0442",
      few: "{n} \u0430\u0441\u043F\u0435\u043A\u0442\u0430",
      many: "{n} \u0430\u0441\u043F\u0435\u043A\u0442\u043E\u0432",
      other: "{n} \u0430\u0441\u043F\u0435\u043A\u0442\u0430"
    },
    activeTransits: {
      one: "{n} \u0430\u043A\u0442\u0438\u0432\u043D\u044B\u0439 \u0442\u0440\u0430\u043D\u0437\u0438\u0442",
      few: "{n} \u0430\u043A\u0442\u0438\u0432\u043D\u044B\u0445 \u0442\u0440\u0430\u043D\u0437\u0438\u0442\u0430",
      many: "{n} \u0430\u043A\u0442\u0438\u0432\u043D\u044B\u0445 \u0442\u0440\u0430\u043D\u0437\u0438\u0442\u043E\u0432",
      other: "{n} \u0430\u043A\u0442\u0438\u0432\u043D\u043E\u0433\u043E \u0442\u0440\u0430\u043D\u0437\u0438\u0442\u0430"
    },
    places: {
      one: "{n} \u043C\u0435\u0441\u0442\u043E",
      few: "{n} \u043C\u0435\u0441\u0442\u0430",
      many: "{n} \u043C\u0435\u0441\u0442",
      other: "{n} \u043C\u0435\u0441\u0442\u0430"
    },
    windows: {
      one: "{n} \u043E\u043A\u043D\u043E",
      few: "{n} \u043E\u043A\u043D\u0430",
      many: "{n} \u043E\u043A\u043E\u043D",
      other: "{n} \u043E\u043A\u043D\u0430"
    },
    years: {
      one: "{n} \u0433\u043E\u0434",
      few: "{n} \u0433\u043E\u0434\u0430",
      many: "{n} \u043B\u0435\u0442",
      other: "{n} \u0433\u043E\u0434\u0430"
    },
    days: {
      one: "{n} \u0434\u0435\u043D\u044C",
      few: "{n} \u0434\u043D\u044F",
      many: "{n} \u0434\u043D\u0435\u0439",
      other: "{n} \u0434\u043D\u044F"
    }
  };
  var ru = {
    chartDepthOpen: "See it in three dimensions \u2014 \u043F\u043E\u043A\u0430 \u043F\u043E-\u0430\u043D\u0433\u043B\u0438\u0439\u0441\u043A\u0438",
    chartDepthClose: "Hide the third dimension \u2014 \u043F\u043E\u043A\u0430 \u043F\u043E-\u0430\u043D\u0433\u043B\u0438\u0439\u0441\u043A\u0438",
    calculationLoadError: "\u041D\u0435 \u0443\u0434\u0430\u043B\u043E\u0441\u044C \u0437\u0430\u0433\u0440\u0443\u0437\u0438\u0442\u044C \u0444\u0430\u0439\u043B\u044B \u0440\u0430\u0441\u0447\u0451\u0442\u0430. \u041F\u0440\u043E\u0432\u0435\u0440\u044C\u0442\u0435 \u043F\u043E\u0434\u043A\u043B\u044E\u0447\u0435\u043D\u0438\u0435 \u0438 \u043F\u043E\u043F\u0440\u043E\u0431\u0443\u0439\u0442\u0435 \u0441\u043D\u043E\u0432\u0430.",
    calculationReload: "\u041F\u0435\u0440\u0435\u0437\u0430\u0433\u0440\u0443\u0437\u0438\u0442\u044C \u0441\u0442\u0440\u0430\u043D\u0438\u0446\u0443",
    calculationReloadWarning: "\u041F\u0440\u0438 \u043F\u0435\u0440\u0435\u0437\u0430\u0433\u0440\u0443\u0437\u043A\u0435 \u043D\u0435\u0441\u043E\u0445\u0440\u0430\u043D\u0451\u043D\u043D\u044B\u0435 \u0434\u0430\u043D\u043D\u044B\u0435 \u0431\u0443\u0434\u0443\u0442 \u0443\u0434\u0430\u043B\u0435\u043D\u044B.",
    calculationRetry: "\u041F\u043E\u043F\u0440\u043E\u0431\u043E\u0432\u0430\u0442\u044C \u0441\u043D\u043E\u0432\u0430",
    pfdYearError: "\u041D\u0435 \u0443\u0434\u0430\u043B\u043E\u0441\u044C \u0437\u0430\u0432\u0435\u0440\u0448\u0438\u0442\u044C \u0440\u0430\u0437\u0431\u043E\u0440 \u043D\u0430 \u0433\u043E\u0434 \u0432\u043F\u0435\u0440\u0451\u0434. \u041F\u043E\u043F\u0440\u043E\u0431\u0443\u0439\u0442\u0435 \u0441\u043D\u043E\u0432\u0430.",
    placeSearching: "\u041F\u043E\u0438\u0441\u043A \u043C\u0435\u0441\u0442\u2026",
    chartWheelActions: "\u0414\u0435\u0439\u0441\u0442\u0432\u0438\u044F \u0441 \u043A\u0430\u0440\u0442\u043E\u0439",
    chartWheelGuide: "\u041F\u0440\u043E\u0439\u0442\u0438 \u044D\u043A\u0441\u043A\u0443\u0440\u0441\u0438\u044E",
    chartWheelReplay: "\u041F\u043E\u0432\u0442\u043E\u0440\u0438\u0442\u044C \u044D\u043A\u0441\u043A\u0443\u0440\u0441\u0438\u044E",
    chartWheelAnother: "\u041F\u0440\u043E\u0447\u0438\u0442\u0430\u0442\u044C \u0434\u0440\u0443\u0433\u0443\u044E \u043A\u0430\u0440\u0442\u0443 \u2014 \u043F\u043E\u043A\u0430 \u043F\u043E-\u0430\u043D\u0433\u043B\u0438\u0439\u0441\u043A\u0438",
    chartWheelSignatureSelf: "\u0425\u0430\u0440\u0430\u043A\u0442\u0435\u0440\u043D\u044B\u0439 \u0440\u0438\u0441\u0443\u043D\u043E\u043A \u0432\u0430\u0448\u0435\u0439 \u043A\u0430\u0440\u0442\u044B",
    chartWheelSignatureOther: "\u0425\u0430\u0440\u0430\u043A\u0442\u0435\u0440\u043D\u044B\u0439 \u0440\u0438\u0441\u0443\u043D\u043E\u043A \u044D\u0442\u043E\u0439 \u043A\u0430\u0440\u0442\u044B",
    chartWheelCompareMine: "\u0421\u0440\u0430\u0432\u043D\u0438\u0442\u044C \u0441 \u043C\u043E\u0435\u0439 \u2014 \u043F\u043E\u043A\u0430 \u043F\u043E-\u0430\u043D\u0433\u043B\u0438\u0439\u0441\u043A\u0438",
    chartWheelCompareAdd: "\u0414\u043E\u0431\u0430\u0432\u0438\u0442\u044C \u043C\u043E\u044E \u043A\u0430\u0440\u0442\u0443 \u0434\u043B\u044F \u0441\u0440\u0430\u0432\u043D\u0435\u043D\u0438\u044F \u2014 \u043F\u043E\u043A\u0430 \u043F\u043E-\u0430\u043D\u0433\u043B\u0438\u0439\u0441\u043A\u0438",
    chartWheelShareOther: "\u041F\u043E\u0434\u0435\u043B\u0438\u0442\u044C\u0441\u044F \u044D\u0442\u043E\u0439 \u043A\u0430\u0440\u0442\u043E\u0439",
    navPrimary: "\u041E\u0441\u043D\u043E\u0432\u043D\u043E\u0435",
    navSigns: "\u0417\u043D\u0430\u043A\u0438",
    navTools: "\u0418\u043D\u0441\u0442\u0440\u0443\u043C\u0435\u043D\u0442\u044B",
    navLearn: "\u0420\u0430\u0437\u0431\u043E\u0440",
    navHoroscopes: "\u0413\u043E\u0440\u043E\u0441\u043A\u043E\u043F\u044B",
    navCollect: "Astrofolio",
    navSavedCharts: "\u0421\u043E\u0445\u0440\u0430\u043D\u0451\u043D\u043D\u044B\u0435 \u043A\u0430\u0440\u0442\u044B",
    navMenu: "\u041C\u0435\u043D\u044E",
    navSite: "\u041E \u0441\u0430\u0439\u0442\u0435",
    navTwelve: "\u0414\u0432\u0435\u043D\u0430\u0434\u0446\u0430\u0442\u044C \u0437\u043D\u0430\u043A\u043E\u0432",
    footerTag: "\u0411\u0435\u0441\u043F\u043B\u0430\u0442\u043D\u044B\u0435 \u0430\u0441\u0442\u0440\u043E\u043B\u043E\u0433\u0438\u0447\u0435\u0441\u043A\u0438\u0435 \u0438\u043D\u0441\u0442\u0440\u0443\u043C\u0435\u043D\u0442\u044B \u0438 \u0433\u0438\u0434\u044B \u043F\u043E \u0437\u043D\u0430\u043A\u0430\u043C. \u041A\u0430\u0440\u0442\u044B \u0441\u0447\u0438\u0442\u0430\u044E\u0442\u0441\u044F \u043F\u0440\u0438\u0432\u0430\u0442\u043D\u043E, \u043F\u0440\u044F\u043C\u043E \u0432 \u0432\u0430\u0448\u0435\u043C \u0431\u0440\u0430\u0443\u0437\u0435\u0440\u0435.",
    footerStartHere: "\u0421 \u0447\u0435\u0433\u043E \u043D\u0430\u0447\u0430\u0442\u044C",
    footerPlanets: "\u041F\u043B\u0430\u043D\u0435\u0442\u044B",
    footerHouses: "\u0414\u043E\u043C\u0430",
    footerZodiacDates: "\u0414\u0430\u0442\u044B \u0437\u043D\u0430\u043A\u043E\u0432",
    footerGlossary: "\u0413\u043B\u043E\u0441\u0441\u0430\u0440\u0438\u0439",
    footerCompute: "\u041A\u0430\u043A \u043C\u044B \u0441\u0447\u0438\u0442\u0430\u0435\u043C",
    footerRegistry: "Registry",
    footerThesis: "\u041C\u0430\u043D\u0438\u0444\u0435\u0441\u0442",
    footerArchive: "\u0410\u0440\u0445\u0438\u0432",
    footerSdk: "SDK",
    footerCollectNote: "\u0417\u0430\u043F\u0438\u0441\u0438, \u043F\u043E\u0438\u0441\u043A, \u0441\u0442\u0440\u0430\u043D\u0438\u0446\u044B \u043A\u0430\u0442\u0430\u043B\u043E\u0433\u0430 \u0438 SDK Registry \u0440\u0430\u0431\u043E\u0442\u0430\u044E\u0442 \u0442\u043E\u043B\u044C\u043A\u043E \u043D\u0430 \u0447\u0442\u0435\u043D\u0438\u0435. \u041D\u0435\u043E\u0431\u044F\u0437\u0430\u0442\u0435\u043B\u044C\u043D\u044B\u0439 \u0438\u043D\u0441\u0442\u0440\u0443\u043C\u0435\u043D\u0442 \u043F\u043E\u043A\u0443\u043F\u043A\u0438 Astrofolio \u0438\u0441\u043F\u043E\u043B\u044C\u0437\u0443\u0435\u0442 \u043D\u0435\u0437\u0430\u0432\u0438\u0441\u0438\u043C\u044B\u0439 \u0441\u0435\u0440\u0432\u0438\u0441 Jupiter \u0438 \u0432\u0430\u0448 \u043A\u043E\u0448\u0435\u043B\u0451\u043A; Zodiacs.org \u043D\u0435 \u0445\u0440\u0430\u043D\u0438\u0442 \u043A\u043B\u044E\u0447\u0438 \u0438\u043B\u0438 \u0441\u0440\u0435\u0434\u0441\u0442\u0432\u0430. \u041D\u0438\u0447\u0442\u043E \u0438\u0437 \u044D\u0442\u043E\u0433\u043E \u043D\u0435 \u044F\u0432\u043B\u044F\u0435\u0442\u0441\u044F \u0444\u0438\u043D\u0430\u043D\u0441\u043E\u0432\u043E\u0439 \u0440\u0435\u043A\u043E\u043C\u0435\u043D\u0434\u0430\u0446\u0438\u0435\u0439.",
    footerMethodology: "\u041C\u0435\u0442\u043E\u0434\u043E\u043B\u043E\u0433\u0438\u044F",
    footerAbout: "\u041E \u043F\u0440\u043E\u0435\u043A\u0442\u0435",
    footerPrivacy: "\u041A\u043E\u043D\u0444\u0438\u0434\u0435\u043D\u0446\u0438\u0430\u043B\u044C\u043D\u043E\u0441\u0442\u044C",
    footerTerms: "\u0423\u0441\u043B\u043E\u0432\u0438\u044F",
    footerPlaceData: "\u0414\u0430\u043D\u043D\u044B\u0435 \u043E \u043C\u0435\u0441\u0442\u0430\u0445",
    footerFonts: "\u0428\u0440\u0438\u0444\u0442\u044B \u043F\u043E\u0434 \u043B\u0438\u0446\u0435\u043D\u0437\u0438\u0435\u0439",
    skipContent: "\u041F\u0435\u0440\u0435\u0439\u0442\u0438 \u043A \u0441\u043E\u0434\u0435\u0440\u0436\u0438\u043C\u043E\u043C\u0443",
    open: "\u041E\u0442\u043A\u0440\u044B\u0442\u044C",
    birthChart: "\u041D\u0430\u0442\u0430\u043B\u044C\u043D\u0430\u044F \u043A\u0430\u0440\u0442\u0430",
    compatibility: "\u0421\u043E\u0432\u043C\u0435\u0441\u0442\u0438\u043C\u043E\u0441\u0442\u044C",
    moonSign: "\u041B\u0443\u043D\u043D\u044B\u0439 \u0437\u043D\u0430\u043A",
    risingSign: "\u0410\u0441\u0446\u0435\u043D\u0434\u0435\u043D\u0442",
    moonPhase: "\u0424\u0430\u0437\u0430 \u041B\u0443\u043D\u044B",
    saturnReturn: "\u0412\u043E\u0437\u0432\u0440\u0430\u0449\u0435\u043D\u0438\u0435 \u0421\u0430\u0442\u0443\u0440\u043D\u0430",
    transits: "\u0422\u0440\u0430\u043D\u0437\u0438\u0442\u044B",
    birthday: "\u0414\u0435\u043D\u044C \u0440\u043E\u0436\u0434\u0435\u043D\u0438\u044F",
    retrogrades: "\u0420\u0435\u0442\u0440\u043E\u0433\u0440\u0430\u0434\u043D\u043E\u0441\u0442\u0438",
    sun: "\u0421\u043E\u043B\u043D\u0446\u0435",
    moon: "\u041B\u0443\u043D\u0430",
    rising: "\u0410\u0441\u0446\u0435\u043D\u0434\u0435\u043D\u0442",
    body: "\u0422\u0435\u043B\u043E",
    position: "\u041F\u043E\u043B\u043E\u0436\u0435\u043D\u0438\u0435",
    sign: "\u0417\u043D\u0430\u043A",
    house: "\u0414\u043E\u043C",
    chart: "\u041A\u0430\u0440\u0442\u0430",
    date: "\u0414\u0430\u0442\u0430",
    time: "\u0412\u0440\u0435\u043C\u044F",
    place: "\u041C\u0435\u0441\u0442\u043E",
    motion: "\u0414\u0432\u0438\u0436\u0435\u043D\u0438\u0435",
    optional: "\u043D\u0435\u043E\u0431\u044F\u0437\u0430\u0442\u0435\u043B\u044C\u043D\u043E",
    birthDate: "\u0414\u0430\u0442\u0430 \u0440\u043E\u0436\u0434\u0435\u043D\u0438\u044F",
    birthTime: "\u0412\u0440\u0435\u043C\u044F \u0440\u043E\u0436\u0434\u0435\u043D\u0438\u044F",
    birthplace: "\u041C\u0435\u0441\u0442\u043E \u0440\u043E\u0436\u0434\u0435\u043D\u0438\u044F",
    birthDateRequired: "\u0423\u043A\u0430\u0436\u0438\u0442\u0435 \u0434\u0430\u0442\u0443 \u0440\u043E\u0436\u0434\u0435\u043D\u0438\u044F.",
    birthDateRange: "\u0412\u044B\u0431\u0435\u0440\u0438\u0442\u0435 \u0434\u0430\u0442\u0443 \u0440\u043E\u0436\u0434\u0435\u043D\u0438\u044F \u0441 1800 \u043F\u043E 2199 \u0433\u043E\u0434.",
    birthTimeRequired: "\u0423\u043A\u0430\u0436\u0438\u0442\u0435 \u0432\u0440\u0435\u043C\u044F \u0440\u043E\u0436\u0434\u0435\u043D\u0438\u044F.",
    houseSystem: "\u0421\u0438\u0441\u0442\u0435\u043C\u0430 \u0434\u043E\u043C\u043E\u0432",
    wholeSignDefault: "\u0426\u0435\u043B\u044B\u0435 \u0437\u043D\u0430\u043A\u0438 (\u043F\u043E \u0443\u043C\u043E\u043B\u0447\u0430\u043D\u0438\u044E)",
    placidus: "\u041F\u043B\u0430\u0446\u0438\u0434\u0443\u0441",
    houseSystemHelp: "\u041A\u0430\u043A \u043A\u0430\u0440\u0442\u0430 \u0434\u0435\u043B\u0438\u0442\u0441\u044F \u043D\u0430 \u0434\u0432\u0435\u043D\u0430\u0434\u0446\u0430\u0442\u044C \u0441\u0444\u0435\u0440 \u0436\u0438\u0437\u043D\u0438. \u0412 \u0441\u0438\u0441\u0442\u0435\u043C\u0435 \u0446\u0435\u043B\u044B\u0445 \u0437\u043D\u0430\u043A\u043E\u0432 \u043A\u0430\u0436\u0434\u044B\u0439 \u0437\u043D\u0430\u043A \u2014 \u043E\u0434\u0438\u043D \u0434\u043E\u043C; \u0432 \u0441\u0438\u0441\u0442\u0435\u043C\u0435 \u041F\u043B\u0430\u0446\u0438\u0434\u0443\u0441\u0430 \u0440\u0430\u0437\u043C\u0435\u0440 \u0434\u043E\u043C\u043E\u0432 \u0437\u0430\u0432\u0438\u0441\u0438\u0442 \u043E\u0442 \u0442\u043E\u0447\u043D\u043E\u0433\u043E \u0432\u0440\u0435\u043C\u0435\u043D\u0438 \u0438 \u043C\u0435\u0441\u0442\u0430. \u041F\u043B\u0430\u043D\u0435\u0442\u044B \u043E\u0441\u0442\u0430\u044E\u0442\u0441\u044F \u043D\u0430 \u043C\u0435\u0441\u0442\u0435: \u043C\u0435\u043D\u044F\u044E\u0442\u0441\u044F \u0442\u043E\u043B\u044C\u043A\u043E \u0433\u0440\u0430\u043D\u0438\u0446\u044B \u0434\u043E\u043C\u043E\u0432.",
    computing: "\u0421\u0447\u0438\u0442\u0430\u0435\u043C\u2026",
    checking: "\u041F\u0440\u043E\u0432\u0435\u0440\u044F\u0435\u043C\u2026",
    comparing: "\u0421\u0440\u0430\u0432\u043D\u0438\u0432\u0430\u0435\u043C\u2026",
    save: "\u0421\u043E\u0445\u0440\u0430\u043D\u0438\u0442\u044C",
    rename: "\u041F\u0435\u0440\u0435\u0438\u043C\u0435\u043D\u043E\u0432\u0430\u0442\u044C",
    remove: "\u0423\u0434\u0430\u043B\u0438\u0442\u044C",
    getBirthChart: "\u041F\u043E\u0441\u0442\u0440\u043E\u0439\u0442\u0435 \u0431\u0435\u0441\u043F\u043B\u0430\u0442\u043D\u0443\u044E \u043D\u0430\u0442\u0430\u043B\u044C\u043D\u0443\u044E \u043A\u0430\u0440\u0442\u0443",
    findMoonSign: "\u0423\u0437\u043D\u0430\u0439\u0442\u0435 \u0441\u0432\u043E\u0439 \u043B\u0443\u043D\u043D\u044B\u0439 \u0437\u043D\u0430\u043A",
    findRisingSign: "\u0423\u0437\u043D\u0430\u0439\u0442\u0435 \u0441\u0432\u043E\u0439 \u0430\u0441\u0446\u0435\u043D\u0434\u0435\u043D\u0442",
    savedCharts: "\u0421\u043E\u0445\u0440\u0430\u043D\u0451\u043D\u043D\u044B\u0435 \u043A\u0430\u0440\u0442\u044B",
    profile: "\u0412\u0430\u0448 \u043F\u0440\u043E\u0444\u0438\u043B\u044C",
    read: "\u0427\u0438\u0442\u0430\u0442\u044C",
    rightNow: "\u041F\u0440\u044F\u043C\u043E \u0441\u0435\u0439\u0447\u0430\u0441",
    enterBirthDetails: "\u0412\u0432\u0435\u0434\u0438\u0442\u0435 \u0434\u0430\u043D\u043D\u044B\u0435 \u0440\u043E\u0436\u0434\u0435\u043D\u0438\u044F\u2026",
    privacyDevice: "\u041F\u0440\u0438\u0432\u0430\u0442\u043D\u043E \u043F\u043E \u0443\u043C\u043E\u043B\u0447\u0430\u043D\u0438\u044E. \u0414\u0430\u043D\u043D\u044B\u0435 \u0440\u043E\u0436\u0434\u0435\u043D\u0438\u044F \u043E\u0441\u0442\u0430\u044E\u0442\u0441\u044F \u0432 \u044D\u0442\u043E\u043C \u0431\u0440\u0430\u0443\u0437\u0435\u0440\u0435.",
    placePlaceholder: "\u041D\u0430\u0447\u043D\u0438\u0442\u0435 \u0432\u0432\u043E\u0434\u0438\u0442\u044C \u0433\u043E\u0440\u043E\u0434\u2026",
    placeChange: "\u0418\u0437\u043C\u0435\u043D\u0438\u0442\u044C \u043C\u0435\u0441\u0442\u043E \u0440\u043E\u0436\u0434\u0435\u043D\u0438\u044F",
    placePickHint: "\u0412\u044B\u0431\u0435\u0440\u0438\u0442\u0435 \u043C\u0435\u0441\u0442\u043E \u0440\u043E\u0436\u0434\u0435\u043D\u0438\u044F \u0438\u0437 \u0441\u043F\u0438\u0441\u043A\u0430.",
    placeNoResults: "\u041D\u0435\u0442 \u0432 \u0441\u043F\u0438\u0441\u043A\u0435? \u0412\u044B\u0431\u0435\u0440\u0438\u0442\u0435 \u0431\u043B\u0438\u0436\u0430\u0439\u0448\u0438\u0439 \u0433\u043E\u0440\u043E\u0434 \u2014 \u043D\u0435\u0441\u043A\u043E\u043B\u044C\u043A\u043E \u043A\u0438\u043B\u043E\u043C\u0435\u0442\u0440\u043E\u0432 \u0440\u0435\u0434\u043A\u043E \u043C\u0435\u043D\u044F\u044E\u0442 \u043A\u0430\u0440\u0442\u0443.",
    placeError: "\u041D\u0435 \u0443\u0434\u0430\u043B\u043E\u0441\u044C \u0437\u0430\u0433\u0440\u0443\u0437\u0438\u0442\u044C \u0441\u043F\u0440\u0430\u0432\u043E\u0447\u043D\u0438\u043A \u043C\u0435\u0441\u0442 \u2014 \u043F\u0440\u043E\u0432\u0435\u0440\u044C\u0442\u0435 \u0441\u043E\u0435\u0434\u0438\u043D\u0435\u043D\u0438\u0435 \u0438 \u043F\u043E\u043F\u0440\u043E\u0431\u0443\u0439\u0442\u0435 \u0435\u0449\u0451 \u0440\u0430\u0437.",
    searchGeo: "\u041F\u043E\u0438\u0441\u043A \u043F\u043E ~34 000 \u043C\u0435\u0441\u0442 \xB7 GeoNames (CC BY 4.0)",
    chartError: "\u041D\u0435 \u043F\u043E\u043B\u0443\u0447\u0438\u043B\u043E\u0441\u044C \u0440\u0430\u0441\u0441\u0447\u0438\u0442\u0430\u0442\u044C \u043A\u0430\u0440\u0442\u0443. \u041F\u043E\u043F\u0440\u043E\u0431\u0443\u0439\u0442\u0435 \u0435\u0449\u0451 \u0440\u0430\u0437.",
    moonError: "\u041D\u0435 \u043F\u043E\u043B\u0443\u0447\u0438\u043B\u043E\u0441\u044C \u0440\u0430\u0441\u0441\u0447\u0438\u0442\u0430\u0442\u044C \u044D\u0442\u0443 \u041B\u0443\u043D\u0443. \u041F\u043E\u043F\u0440\u043E\u0431\u0443\u0439\u0442\u0435 \u0435\u0449\u0451 \u0440\u0430\u0437.",
    localDateReferenceError: "\u041D\u0435 \u0443\u0434\u0430\u043B\u043E\u0441\u044C \u043E\u043F\u0440\u0435\u0434\u0435\u043B\u0438\u0442\u044C \u0432\u0440\u0435\u043C\u044F \u0434\u043B\u044F \u0440\u0430\u0441\u0447\u0451\u0442\u0430 \u0432 \u043F\u0440\u0435\u0434\u0435\u043B\u0430\u0445 \u044D\u0442\u043E\u0439 \u043C\u0435\u0441\u0442\u043D\u043E\u0439 \u0434\u0430\u0442\u044B. \u041F\u0440\u043E\u0432\u0435\u0440\u044C\u0442\u0435 \u0434\u0430\u0442\u0443 \u0438 \u043C\u0435\u0441\u0442\u043E.",
    returnError: "\u041D\u0435 \u043F\u043E\u043B\u0443\u0447\u0438\u043B\u043E\u0441\u044C \u0440\u0430\u0441\u0441\u0447\u0438\u0442\u0430\u0442\u044C \u0432\u043E\u0437\u0432\u0440\u0430\u0449\u0435\u043D\u0438\u0435. \u041F\u043E\u043F\u0440\u043E\u0431\u0443\u0439\u0442\u0435 \u0435\u0449\u0451 \u0440\u0430\u0437.",
    transitError: "\u041D\u0435 \u043F\u043E\u043B\u0443\u0447\u0438\u043B\u043E\u0441\u044C \u0440\u0430\u0441\u0441\u0447\u0438\u0442\u0430\u0442\u044C \u0442\u0440\u0430\u043D\u0437\u0438\u0442\u044B. \u041F\u043E\u043F\u0440\u043E\u0431\u0443\u0439\u0442\u0435 \u0435\u0449\u0451 \u0440\u0430\u0437.",
    compareError: "\u041D\u0435 \u043F\u043E\u043B\u0443\u0447\u0438\u043B\u043E\u0441\u044C \u0441\u0440\u0430\u0432\u043D\u0438\u0442\u044C \u043A\u0430\u0440\u0442\u044B. \u041F\u043E\u043F\u0440\u043E\u0431\u0443\u0439\u0442\u0435 \u0435\u0449\u0451 \u0440\u0430\u0437.",
    noBirthTime: "\u041D\u0435 \u0437\u043D\u0430\u044E \u0432\u0440\u0435\u043C\u044F",
    risingTimeHelp: "\u0410\u0441\u0446\u0435\u043D\u0434\u0435\u043D\u0442 \u043C\u0435\u043D\u044F\u0435\u0442\u0441\u044F \u043A\u0430\u0436\u0434\u044B\u0435 \u0434\u0432\u0430 \u0447\u0430\u0441\u0430 \u2014 \u0437\u0434\u0435\u0441\u044C \u0432\u0430\u0436\u043D\u044B \u0438\u043C\u0435\u043D\u043D\u043E \u0447\u0430\u0441\u044B.",
    chartTimeHelp: "\u041D\u0435\u0442 \u0432\u0440\u0435\u043C\u0435\u043D\u0438 \u0440\u043E\u0436\u0434\u0435\u043D\u0438\u044F? \u041F\u043E\u043A\u0430\u0436\u0435\u043C \u043E\u0440\u0438\u0435\u043D\u0442\u0438\u0440 \u043D\u0430 \u043C\u0435\u0441\u0442\u043D\u044B\u0439 \u043F\u043E\u043B\u0434\u0435\u043D\u044C \u0431\u0435\u0437 \u0430\u0441\u0446\u0435\u043D\u0434\u0435\u043D\u0442\u0430 \u0438 \u0434\u043E\u043C\u043E\u0432; \u043F\u043E\u043B\u043E\u0436\u0435\u043D\u0438\u0435 \u041B\u0443\u043D\u044B \u043C\u043E\u0436\u0435\u0442 \u0431\u044B\u0442\u044C \u043D\u0435\u043E\u043F\u0440\u0435\u0434\u0435\u043B\u0451\u043D\u043D\u044B\u043C.",
    chartSavedDevice: "\u0421\u043E\u0445\u0440\u0430\u043D\u0435\u043D\u043E \xB7 \u043D\u0430 \u044D\u0442\u043E\u043C \u0443\u0441\u0442\u0440\u043E\u0439\u0441\u0442\u0432\u0435",
    saveThisChart: "\u0421\u043E\u0445\u0440\u0430\u043D\u0438\u0442\u044C \u044D\u0442\u0443 \u043A\u0430\u0440\u0442\u0443",
    chartSavedStatus: "\u041A\u0430\u0440\u0442\u0430 \u0441\u043E\u0445\u0440\u0430\u043D\u0435\u043D\u0430 \u043D\u0430 \u044D\u0442\u043E\u043C \u0443\u0441\u0442\u0440\u043E\u0439\u0441\u0442\u0432\u0435.",
    chartSaveFull: "\u041C\u043E\u0436\u043D\u043E \u0445\u0440\u0430\u043D\u0438\u0442\u044C \u0434\u043E 40 \u043A\u0430\u0440\u0442 \u2014 \u0441\u043D\u0430\u0447\u0430\u043B\u0430 \u0443\u0434\u0430\u043B\u0438\u0442\u0435 \u043E\u0434\u043D\u0443.",
    chartSaveError: "\u041D\u0435 \u0443\u0434\u0430\u043B\u043E\u0441\u044C \u0441\u043E\u0445\u0440\u0430\u043D\u0438\u0442\u044C \u2014 \u0432\u043E\u0437\u043C\u043E\u0436\u043D\u043E, \u0431\u0440\u0430\u0443\u0437\u0435\u0440 \u0431\u043B\u043E\u043A\u0438\u0440\u0443\u0435\u0442 \u043B\u043E\u043A\u0430\u043B\u044C\u043D\u043E\u0435 \u0445\u0440\u0430\u043D\u0438\u043B\u0438\u0449\u0435.",
    chartSavedMessage: "\u0421\u043E\u0445\u0440\u0430\u043D\u0435\u043D\u043E \u0432 \u0432\u0430\u0448\u0438 \u043A\u0430\u0440\u0442\u044B. \u0412\u043E\u0439\u0434\u0438\u0442\u0435 \u0437\u0434\u0435\u0441\u044C, \u0435\u0441\u043B\u0438 \u0445\u043E\u0442\u0438\u0442\u0435 \u0432\u0438\u0434\u0435\u0442\u044C \u0438\u0445 \u043D\u0430 \u0432\u0441\u0435\u0445 \u0443\u0441\u0442\u0440\u043E\u0439\u0441\u0442\u0432\u0430\u0445.",
    linkCopied: "\u0421\u0441\u044B\u043B\u043A\u0430 \u0441\u043A\u043E\u043F\u0438\u0440\u043E\u0432\u0430\u043D\u0430",
    copyChartLink: "\u0421\u043A\u043E\u043F\u0438\u0440\u043E\u0432\u0430\u0442\u044C \u0441\u0441\u044B\u043B\u043A\u0443 \u043D\u0430 \u044D\u0442\u0443 \u043A\u0430\u0440\u0442\u0443",
    rendering: "\u0420\u0438\u0441\u0443\u0435\u043C\u2026",
    cardSaved: "\u041A\u0430\u0440\u0442\u043E\u0447\u043A\u0430 \u0441\u043E\u0445\u0440\u0430\u043D\u0435\u043D\u0430",
    saveChartCard: "\u0421\u043E\u0445\u0440\u0430\u043D\u0438\u0442\u044C \u043A\u0430\u0440\u0442\u043E\u0447\u043A\u0443 \u043A\u0430\u0440\u0442\u044B",
    shareChart: "\u041F\u043E\u0434\u0435\u043B\u0438\u0442\u044C\u0441\u044F \u043A\u0430\u0440\u0442\u043E\u0439",
    linkToChart: "\u0421\u0441\u044B\u043B\u043A\u0430 \u043D\u0430 \u044D\u0442\u0443 \u043A\u0430\u0440\u0442\u0443",
    chartLinkCopied: "\u0421\u0441\u044B\u043B\u043A\u0430 \u043D\u0430 \u043A\u0430\u0440\u0442\u0443 \u0441\u043A\u043E\u043F\u0438\u0440\u043E\u0432\u0430\u043D\u0430 \u0432 \u0431\u0443\u0444\u0435\u0440 \u043E\u0431\u043C\u0435\u043D\u0430.",
    chartCardSaved: "\u041A\u0430\u0440\u0442\u043E\u0447\u043A\u0430 \u043A\u0430\u0440\u0442\u044B \u0441\u043E\u0445\u0440\u0430\u043D\u0435\u043D\u0430.",
    cardError: "\u041D\u0435 \u0443\u0434\u0430\u043B\u043E\u0441\u044C \u043D\u0430\u0440\u0438\u0441\u043E\u0432\u0430\u0442\u044C \u043A\u0430\u0440\u0442\u043E\u0447\u043A\u0443 \u0432 \u044D\u0442\u043E\u043C \u0431\u0440\u0430\u0443\u0437\u0435\u0440\u0435 \u2014 \u043A\u043E\u043B\u0435\u0441\u043E \u0432\u044B\u0448\u0435 \u043E\u0442\u043B\u0438\u0447\u043D\u043E \u0441\u043D\u0438\u043C\u0430\u0435\u0442\u0441\u044F \u0438 \u0441\u043A\u0440\u0438\u043D\u0448\u043E\u0442\u043E\u043C.",
    shareNote: "\u0421\u0441\u044B\u043B\u043A\u0430 \u0441\u043E\u0434\u0435\u0440\u0436\u0438\u0442 \u0432\u0432\u0435\u0434\u0451\u043D\u043D\u044B\u0435 \u0434\u0430\u043D\u043D\u044B\u0435 \u0440\u043E\u0436\u0434\u0435\u043D\u0438\u044F \u2014 \u043D\u0430\u043C \u043D\u0438\u0447\u0435\u0433\u043E \u043D\u0435 \u043E\u0442\u043F\u0440\u0430\u0432\u043B\u044F\u0435\u0442\u0441\u044F, \u043E\u0442\u043A\u0440\u044B\u0442\u044C \u0435\u0451 \u0441\u043C\u043E\u0433\u0443\u0442 \u0442\u043E\u043B\u044C\u043A\u043E \u0442\u0435, \u043A\u043E\u043C\u0443 \u0432\u044B \u0435\u0451 \u043F\u0435\u0440\u0435\u0434\u0430\u0434\u0438\u0442\u0435. \u041A\u0430\u0440\u0442\u043E\u0447\u043A\u0430 \u2014 \u0438\u0437\u043E\u0431\u0440\u0430\u0436\u0435\u043D\u0438\u0435 1080\xD71350, \u0441\u043E\u0437\u0434\u0430\u0451\u0442\u0441\u044F \u043D\u0430 \u0432\u0430\u0448\u0435\u043C \u0443\u0441\u0442\u0440\u043E\u0439\u0441\u0442\u0432\u0435.",
    needsBirthTime: "\u041D\u0443\u0436\u043D\u043E \u0432\u0440\u0435\u043C\u044F \u0440\u043E\u0436\u0434\u0435\u043D\u0438\u044F",
    yourMoonSign: "\u0412\u0430\u0448 \u043B\u0443\u043D\u043D\u044B\u0439 \u0437\u043D\u0430\u043A",
    yourRisingSign: "\u0412\u0430\u0448 \u0430\u0441\u0446\u0435\u043D\u0434\u0435\u043D\u0442",
    moonPhaseAtBirth: "\u0424\u0430\u0437\u0430 \u041B\u0443\u043D\u044B \u043F\u0440\u0438 \u0440\u043E\u0436\u0434\u0435\u043D\u0438\u0438",
    chartRuler: "\u0423\u043F\u0440\u0430\u0432\u0438\u0442\u0435\u043B\u044C \u043A\u0430\u0440\u0442\u044B",
    planetSteering: "\u043F\u043B\u0430\u043D\u0435\u0442\u0430, \u0432\u0435\u0434\u0443\u0449\u0430\u044F \u0432\u0430\u0448 \u0430\u0441\u0446\u0435\u043D\u0434\u0435\u043D\u0442.",
    aspectsFound: "\u0410\u0441\u043F\u0435\u043A\u0442\u044B",
    found: "\u043D\u0430\u0439\u0434\u0435\u043D\u043E",
    applying: "\u0441\u0445\u043E\u0434\u044F\u0449\u0438\u0439\u0441\u044F",
    wholeSignHouses: "\u0414\u043E\u043C\u0430 \u0446\u0435\u043B\u044B\u0445 \u0437\u043D\u0430\u043A\u043E\u0432",
    placidusHouses: "\u0414\u043E\u043C\u0430 \u041F\u043B\u0430\u0446\u0438\u0434\u0443\u0441\u0430",
    engine: "\u0434\u0432\u0438\u0436\u043E\u043A v",
    readInOrder: "\u0427\u0438\u0442\u0430\u0435\u043C \u043F\u043E \u043F\u043E\u0440\u044F\u0434\u043A\u0443",
    readIntro: "\u0421\u0432\u0435\u0440\u0445\u0443 \u0432\u043D\u0438\u0437 \u2014 \u0442\u0430\u043A \u043A\u0430\u0440\u0442\u0443 \u0447\u0438\u0442\u0430\u043B \u0431\u044B \u0430\u0441\u0442\u0440\u043E\u043B\u043E\u0433. \u0422\u0430\u0431\u043B\u0438\u0446\u044B \u0432\u044B\u0448\u0435 \u2014 \u0434\u0430\u043D\u043D\u044B\u0435; \u0437\u0434\u0435\u0441\u044C \u2014 \u0447\u0442\u043E \u043E\u043D\u0438 \u0437\u043D\u0430\u0447\u0430\u0442.",
    readBigThree: "\u041D\u0430\u0447\u043D\u0438\u0442\u0435 \u0441 \u0431\u043E\u043B\u044C\u0448\u043E\u0439 \u0442\u0440\u043E\u0439\u043A\u0438",
    readBigThreeBody: "\u0421\u043E\u043B\u043D\u0446\u0435, \u041B\u0443\u043D\u0430, \u0430\u0441\u0446\u0435\u043D\u0434\u0435\u043D\u0442 \u2014 \u0442\u0440\u0438 \u043A\u0430\u0440\u0442\u043E\u0447\u043A\u0438 \u043D\u0430\u0432\u0435\u0440\u0445\u0443. \u041B\u0438\u0447\u043D\u043E\u0441\u0442\u044C, \u0438\u043D\u0441\u0442\u0438\u043D\u043A\u0442, \u0432\u0445\u043E\u0434. \u0412\u0441\u0451, \u0447\u0442\u043E \u043D\u0438\u0436\u0435, \u0443\u0442\u043E\u0447\u043D\u044F\u0435\u0442 \u0438\u0445; \u043D\u0438\u0447\u0442\u043E \u0438\u0445 \u043D\u0435 \u0437\u0430\u043C\u0435\u043D\u044F\u0435\u0442.",
    readRooms: "\u041F\u043B\u0430\u043D\u0435\u0442\u044B, \u043A\u043E\u043C\u043D\u0430\u0442\u0430 \u0437\u0430 \u043A\u043E\u043C\u043D\u0430\u0442\u043E\u0439",
    readNoHouses: "\u0411\u0435\u0437 \u0432\u0440\u0435\u043C\u0435\u043D\u0438 \u0440\u043E\u0436\u0434\u0435\u043D\u0438\u044F \u043D\u0435\u0442 \u0434\u043E\u043C\u043E\u0432, \u043F\u043E\u044D\u0442\u043E\u043C\u0443 \u043A\u0430\u0436\u0434\u0430\u044F \u043F\u043B\u0430\u043D\u0435\u0442\u0430 \u0447\u0438\u0442\u0430\u0435\u0442\u0441\u044F \u0442\u043E\u043B\u044C\u043A\u043E \u043F\u043E \u0437\u043D\u0430\u043A\u0443. \u0414\u043E\u0431\u0430\u0432\u044C\u0442\u0435 \u0432\u0440\u0435\u043C\u044F \u2014 \u0438 \u0440\u0430\u0437\u0434\u0435\u043B \u043E\u0431\u0440\u0435\u0442\u0451\u0442 \u0441\u0432\u043E\u0438 \u043A\u043E\u043C\u043D\u0430\u0442\u044B.",
    readAspects: "\u0410\u0441\u043F\u0435\u043A\u0442\u044B, \u043A\u043E\u0442\u043E\u0440\u044B\u0435 \u0440\u0430\u0431\u043E\u0442\u0430\u044E\u0442 \u0431\u043E\u043B\u044C\u0448\u0435 \u0432\u0441\u0435\u0433\u043E",
    readWeather: "\u041F\u043E\u0433\u043E\u0434\u0430 \u043A\u0430\u0440\u0442\u044B",
    readIn: "\u0432",
    today: "\u0441\u0435\u0433\u043E\u0434\u043D\u044F",
    todayBySignTitle: "\u041D\u0435\u0431\u043E \u0441\u0435\u0433\u043E\u0434\u043D\u044F \u2014 \u0434\u043B\u044F \u043A\u0430\u0436\u0434\u043E\u0433\u043E \u0437\u043D\u0430\u043A\u0430",
    todayBySignPrompt: "\u0412\u044B\u0431\u0435\u0440\u0438\u0442\u0435 \u0441\u0432\u043E\u0439 \u0441\u043E\u043B\u043D\u0435\u0447\u043D\u044B\u0439 \u0437\u043D\u0430\u043A, \u0447\u0442\u043E\u0431\u044B \u043F\u0440\u043E\u0447\u0438\u0442\u0430\u0442\u044C \u044F\u0441\u043D\u044B\u0439 \u043F\u0440\u043E\u0433\u043D\u043E\u0437 \u043D\u0430 \u0441\u0435\u0433\u043E\u0434\u043D\u044F \u2014 \u0432\u0440\u0435\u043C\u044F \u0440\u043E\u0436\u0434\u0435\u043D\u0438\u044F \u043D\u0435 \u043D\u0443\u0436\u043D\u043E.",
    todaySolarNote: "\u0447\u0438\u0442\u0430\u0435\u0442\u0441\u044F \u043F\u043E \u0441\u043E\u043B\u043D\u0435\u0447\u043D\u044B\u043C \u0434\u043E\u043C\u0430\u043C \u0432\u0430\u0448\u0435\u0433\u043E \u0437\u043D\u0430\u043A\u0430",
    whyThisReading: "\u041F\u043E\u0447\u0435\u043C\u0443 \u0442\u0430\u043A\u043E\u0435 \u0447\u0442\u0435\u043D\u0438\u0435",
    todayHoroscopeLink: "\u0433\u043E\u0440\u043E\u0441\u043A\u043E\u043F",
    or: "\u0438\u043B\u0438",
    chartSavedBeforeLink: "\u0421\u043E\u0445\u0440\u0430\u043D\u0435\u043D\u043E \u0432 \u0432\u0430\u0448\u0438 \u043A\u0430\u0440\u0442\u044B. \u0412\u043E\u0439\u0434\u0438\u0442\u0435",
    chartSavedLink: "\u0437\u0434\u0435\u0441\u044C",
    chartSavedAfterLink: "\u043A\u043E\u0433\u0434\u0430 \u0437\u0430\u0445\u043E\u0442\u0438\u0442\u0435 \u0432\u0438\u0434\u0435\u0442\u044C \u0438\u0445 \u043D\u0430 \u0432\u0441\u0435\u0445 \u0443\u0441\u0442\u0440\u043E\u0439\u0441\u0442\u0432\u0430\u0445.",
    signedInAs: "\u0412\u044B \u0432\u043E\u0448\u043B\u0438 \u043A\u0430\u043A {email}",
    removeChartConfirm: "\u0423\u0434\u0430\u043B\u0438\u0442\u044C \xAB{name}\xBB \u0441 \u044D\u0442\u043E\u0433\u043E \u0443\u0441\u0442\u0440\u043E\u0439\u0441\u0442\u0432\u0430?",
    compareSavedHeading: "\u0421\u0440\u0430\u0432\u043D\u0438\u0442\u044C: {a} \u0438 {b}",
    compareSavedPitch: "\u0414\u0432\u0435 \u0441\u043E\u0445\u0440\u0430\u043D\u0451\u043D\u043D\u044B\u0435 \u043A\u0430\u0440\u0442\u044B \u2014 \u044D\u0442\u043E \u0433\u043E\u0442\u043E\u0432\u043E\u0435 \u0441\u0440\u0430\u0432\u043D\u0435\u043D\u0438\u0435: \u043A\u0430\u0436\u0434\u044B\u0439 \u043C\u0435\u0436\u043A\u0430\u0440\u0442\u043D\u044B\u0439 \u0430\u0441\u043F\u0435\u043A\u0442, \u0447\u0435\u0441\u0442\u043D\u043E \u0440\u0430\u0441\u0441\u0447\u0438\u0442\u0430\u043D\u043D\u044B\u0439 \u043D\u0430 \u044D\u0442\u043E\u043C \u0443\u0441\u0442\u0440\u043E\u0439\u0441\u0442\u0432\u0435.",
    saturnDateHelp: "\u041E\u0434\u043D\u0430 \u0434\u0430\u0442\u0430 \u0443\u0436\u0435 \u0437\u0430\u043A\u0440\u0435\u043F\u043B\u044F\u0435\u0442 \u0433\u043E\u0434\u044B \u0432\u043E\u0437\u0432\u0440\u0430\u0449\u0435\u043D\u0438\u044F. \u0412\u0440\u0435\u043C\u044F \u0438 \u043C\u0435\u0441\u0442\u043E \u0443\u0442\u043E\u0447\u043D\u044F\u044E\u0442 \u0434\u0430\u0442\u044B \u043D\u0430 \u043D\u0435\u0441\u043A\u043E\u043B\u044C\u043A\u043E \u0434\u043D\u0435\u0439 \u2014 \u043D\u043E \u043D\u0435 \u0433\u043E\u0434.",
    saturnReturnHeading: "{ordinal} \u0432\u043E\u0437\u0432\u0440\u0430\u0449\u0435\u043D\u0438\u0435",
    skyMercuryRetrograde: "\u0420\u0435\u0442\u0440\u043E\u0433\u0440\u0430\u0434\u043D\u044B\u0439 \u041C\u0435\u0440\u043A\u0443\u0440\u0438\u0439",
    skyMercuryDirect: "\u041C\u0435\u0440\u043A\u0443\u0440\u0438\u0439 \u0434\u0438\u0440\u0435\u043A\u0442\u043D\u044B\u0439",
    skyPlanetRetrograde: "\u0420\u0435\u0442\u0440\u043E\u0433\u0440\u0430\u0434\u043D\u044B\u0439 {planet}",
    skyFullMoon: "\u041F\u043E\u043B\u043D\u043E\u043B\u0443\u043D\u0438\u0435",
    skyNewMoon: "\u041D\u043E\u0432\u043E\u043B\u0443\u043D\u0438\u0435",
    skyMoonOn: "{event} \xB7 {date}",
    skyAsOf: "{date} \xB7 12 UTC",
    skyTickerAria: "\u041F\u043E\u043B\u043E\u0436\u0435\u043D\u0438\u044F \u043D\u0435\u0431\u0430 \u043D\u0430 {date}, 12:00 UTC",
    moonDiscAria: "\u041B\u0443\u043D\u0430, \u043E\u0441\u0432\u0435\u0449\u0435\u043D\u043E {percent}%",
    pairingCta: "\u0427\u0438\u0442\u0430\u0442\u044C \u043F\u0430\u0440\u0443 {a} \u0438 {b}",
    inviteWith: "\u041F\u0440\u0438\u0433\u043B\u0430\u0441\u0438\u0442\u044C \u043A\u043E\u0433\u043E-\u0442\u043E \u0441\u0440\u0430\u0432\u043D\u0438\u0442\u044C\u0441\u044F \u0441 {name}",
    inviteNamedNote: "\u0421\u0441\u044B\u043B\u043A\u0430 \u0441\u043E\u0434\u0435\u0440\u0436\u0438\u0442 \u0434\u0430\u043D\u043D\u044B\u0435 \u0440\u043E\u0436\u0434\u0435\u043D\u0438\u044F {name} \u0438 \u043E\u0442\u043A\u0440\u044B\u0432\u0430\u0435\u0442 \u044D\u0442\u0443 \u0441\u0442\u0440\u0430\u043D\u0438\u0446\u0443 \u0441 \u0437\u0430\u043F\u043E\u043B\u043D\u0435\u043D\u043D\u043E\u0439 \u0441\u0442\u043E\u0440\u043E\u043D\u043E\u0439 \u2014 \u043D\u0430\u043C \u043D\u0438\u0447\u0435\u0433\u043E \u043D\u0435 \u043E\u0442\u043F\u0440\u0430\u0432\u043B\u044F\u0435\u0442\u0441\u044F. \u0415\u0441\u043B\u0438 \u044D\u0442\u043E \u043D\u0435 \u0432\u044B, \u0441\u0442\u043E\u0438\u0442 \u0441\u043F\u0440\u043E\u0441\u0438\u0442\u044C \u0441\u043E\u0433\u043B\u0430\u0441\u0438\u044F.",
    transitMiddayUtc: "{date} \xB7 \u043F\u043E\u043B\u0434\u0435\u043D\u044C UTC",
    planetReturn: "\u0412\u043E\u0437\u0432\u0440\u0430\u0449\u0435\u043D\u0438\u0435: {planet}",
    natalPlanet: "\u041D\u0430\u0442\u0430\u043B\u044C\u043D\u044B\u0439 {planet}",
    pfdToday: "\u0421\u0435\u0433\u043E\u0434\u043D\u044F \u0434\u043B\u044F \u044D\u0442\u043E\u0439 \u043A\u0430\u0440\u0442\u044B",
    pfdComing: "\u0427\u0442\u043E \u0432\u043F\u0435\u0440\u0435\u0434\u0438 \u0443 \u044D\u0442\u043E\u0439 \u043A\u0430\u0440\u0442\u044B",
    pfdYearAhead: "\u0413\u043E\u0434 \u0432\u043F\u0435\u0440\u0451\u0434 \u0434\u043B\u044F \u044D\u0442\u043E\u0439 \u043A\u0430\u0440\u0442\u044B",
    pfdYearBusy: "\u0421\u0447\u0438\u0442\u0430\u0435\u043C \u0433\u043E\u0434 \u043D\u0430 \u0432\u0430\u0448\u0435\u043C \u0443\u0441\u0442\u0440\u043E\u0439\u0441\u0442\u0432\u0435 \u2014 \u043D\u0435\u0441\u043A\u043E\u043B\u044C\u043A\u043E \u0441\u0435\u043A\u0443\u043D\u0434\u2026",
    pfdYearNote: "\u0420\u0430\u0441\u0441\u0447\u0438\u0442\u0430\u043D\u043E \u043F\u043E \u0432\u0430\u0448\u0435\u0439 \u0441\u043E\u0445\u0440\u0430\u043D\u0451\u043D\u043D\u043E\u0439 \u043A\u0430\u0440\u0442\u0435: \u0442\u043E\u0447\u043D\u044B\u0435 \u0434\u0430\u0442\u044B \u043D\u0430 \u0431\u043B\u0438\u0436\u0430\u0439\u0448\u0438\u0435 \u0434\u0432\u0435\u043D\u0430\u0434\u0446\u0430\u0442\u044C \u043C\u0435\u0441\u044F\u0446\u0435\u0432.",
    saveYearAheadNote: "\u0414\u043B\u044F \u0441\u043E\u0445\u0440\u0430\u043D\u0451\u043D\u043D\u044B\u0445 \u043A\u0430\u0440\u0442 \u043F\u0440\u043E\u0444\u0438\u043B\u044C \u0441\u0447\u0438\u0442\u0430\u0435\u0442 \u0433\u043E\u0434 \u0432\u043F\u0435\u0440\u0451\u0434 \u2014 \u0441\u043E\u043B\u043D\u0435\u0447\u043D\u043E\u0435 \u0432\u043E\u0437\u0432\u0440\u0430\u0449\u0435\u043D\u0438\u0435, \u0434\u0430\u0442\u044B \u042E\u043F\u0438\u0442\u0435\u0440\u0430 \u0438 \u0421\u0430\u0442\u0443\u0440\u043D\u0430, \u043F\u043E\u043F\u0430\u0434\u0430\u043D\u0438\u044F \u0437\u0430\u0442\u043C\u0435\u043D\u0438\u0439.",
    recordLabel: "\u041A\u043E\u043B\u043B\u0435\u043A\u0446\u0438\u043E\u043D\u043D\u043E\u0435 \u043A\u0440\u044B\u043B\u043E",
    recordOneOfTwelve: "\u0442\u0430\u043A\u0436\u0435 \u0435\u0441\u0442\u044C \u0441\u0440\u0435\u0434\u0438 \u0414\u0432\u0435\u043D\u0430\u0434\u0446\u0430\u0442\u0438 \u2014 \u044D\u0442\u043E \u043A\u0430\u043D\u043E\u043D\u0438\u0447\u0435\u0441\u043A\u0430\u044F \u0437\u0430\u043F\u0438\u0441\u044C \u0432 \u0420\u0435\u0435\u0441\u0442\u0440\u0435, \u043F\u043E\u043A\u0430 \u043F\u043E-\u0430\u043D\u0433\u043B\u0438\u0439\u0441\u043A\u0438.",
    recordViewLink: "\u041F\u043E\u0441\u043C\u043E\u0442\u0440\u0435\u0442\u044C \u0437\u0430\u043F\u0438\u0441\u044C \u2014 \u043F\u043E\u043A\u0430 \u043F\u043E-\u0430\u043D\u0433\u043B\u0438\u0439\u0441\u043A\u0438 \u2192",
    recordChartSun: "\u0412\u0430\u0448 \u0441\u043E\u043B\u043D\u0435\u0447\u043D\u044B\u0439 \u0437\u043D\u0430\u043A \u2014 {sign}.",
    recordChartBody: "{sign} \u0432\u0445\u043E\u0434\u0438\u0442 \u0432 \u0447\u0438\u0441\u043B\u043E \u0414\u0432\u0435\u043D\u0430\u0434\u0446\u0430\u0442\u0438 \u2014 \u0441\u043E \u0441\u0432\u043E\u0438\u043C \u043E\u0431\u0440\u0430\u0437\u043E\u043C, \u0438\u0441\u0442\u043E\u0440\u0438\u0435\u0439 \u0438 \u043E\u0444\u0438\u0446\u0438\u0430\u043B\u044C\u043D\u043E\u0439 \u0437\u0430\u043F\u0438\u0441\u044C\u044E \u0432 \u0420\u0435\u0435\u0441\u0442\u0440\u0435, \u043F\u043E\u043A\u0430 \u043F\u043E-\u0430\u043D\u0433\u043B\u0438\u0439\u0441\u043A\u0438.",
    recordChartLink: "\u041E\u0442\u043A\u0440\u044B\u0442\u044C \u0420\u0435\u0435\u0441\u0442\u0440: {sign} \u2014 \u043F\u043E\u043A\u0430 \u043F\u043E-\u0430\u043D\u0433\u043B\u0438\u0439\u0441\u043A\u0438 \u2192",
    babyDueDate: "\u041F\u0440\u0435\u0434\u043F\u043E\u043B\u0430\u0433\u0430\u0435\u043C\u0430\u044F \u0434\u0430\u0442\u0430 \u0440\u043E\u0434\u043E\u0432",
    babyCompute: "\u041F\u0440\u043E\u0447\u0438\u0442\u0430\u0442\u044C \u043D\u0435\u0431\u043E \u043D\u0430 \u044D\u0442\u0443 \u0434\u0430\u0442\u0443",
    babyNeedDate: "\u0421\u043D\u0430\u0447\u0430\u043B\u0430 \u0432\u0432\u0435\u0434\u0438\u0442\u0435 \u0434\u0430\u0442\u0443.",
    babyError: "\u041D\u0435 \u043F\u043E\u043B\u0443\u0447\u0438\u043B\u043E\u0441\u044C \u0440\u0430\u0441\u0441\u0447\u0438\u0442\u0430\u0442\u044C \u043D\u0435\u0431\u043E. \u041F\u043E\u043F\u0440\u043E\u0431\u0443\u0439\u0442\u0435 \u0435\u0449\u0451 \u0440\u0430\u0437.",
    babySunHead: "\u0421\u043E\u043B\u043D\u0435\u0447\u043D\u044B\u0439 \u0437\u043D\u0430\u043A \u2014 \u043F\u043E\u0447\u0442\u0438 \u043D\u0430\u0432\u0435\u0440\u043D\u044F\u043A\u0430",
    babySunSingle: "\u0420\u043E\u0436\u0434\u0435\u043D\u0438\u0435 \u0432 \u044D\u0442\u043E\u0442 \u0434\u0435\u043D\u044C \u0434\u0430\u0451\u0442 \u0421\u043E\u043B\u043D\u0446\u0435 \u0432",
    babySunNearEdge: "\u0414\u0430\u0442\u0430 \u0441\u0442\u043E\u0438\u0442 \u0443 \u0441\u0430\u043C\u043E\u0439 \u0433\u0440\u0430\u043D\u0438\u0446\u044B \u0437\u043D\u0430\u043A\u0430, \u0442\u0430\u043A \u0447\u0442\u043E \u043F\u0440\u0438\u0445\u043E\u0434 \u043D\u0430 \u0434\u0435\u043D\u044C \u0441 \u043B\u0438\u0448\u043D\u0438\u043C \u0440\u0430\u043D\u044C\u0448\u0435 \u0438\u043B\u0438 \u043F\u043E\u0437\u0436\u0435 \u043C\u043E\u0436\u0435\u0442 \u0441\u043C\u0435\u0441\u0442\u0438\u0442\u044C \u0432",
    babySunNearEdgeTail: "\u2014 \u0440\u0435\u0448\u0430\u0435\u0442 \u0434\u0430\u0442\u0430 \u0440\u043E\u0436\u0434\u0435\u043D\u0438\u044F.",
    babySunSplitA: "\u0412 \u044D\u0442\u043E\u0442 \u0434\u0435\u043D\u044C \u0421\u043E\u043B\u043D\u0446\u0435 \u043C\u0435\u043D\u044F\u0435\u0442 \u0437\u043D\u0430\u043A: \u0440\u043E\u0436\u0434\u0435\u043D\u0438\u0435 \u0432\u044B\u0445\u043E\u0434\u0438\u0442",
    babySunSplitOr: "\u0438\u043B\u0438",
    babySunSplitTail: "\u0432 \u0437\u0430\u0432\u0438\u0441\u0438\u043C\u043E\u0441\u0442\u0438 \u043E\u0442 \u0447\u0430\u0441\u0430. \u0420\u0435\u0448\u0430\u0435\u0442 \u0442\u043E\u0447\u043D\u044B\u0439 \u043C\u043E\u043C\u0435\u043D\u0442 \u0440\u043E\u0436\u0434\u0435\u043D\u0438\u044F.",
    babyNoonNote: "\u0437\u043D\u0430\u043A\u0438 \u0447\u0438\u0442\u0430\u044E\u0442\u0441\u044F \u043D\u0430 \u043F\u043E\u043B\u0434\u0435\u043D\u044C \u0432\u0441\u0435\u043C\u0438\u0440\u043D\u043E\u0433\u043E \u0432\u0440\u0435\u043C\u0435\u043D\u0438",
    babyMoonHead: "\u041B\u0443\u043D\u043D\u044B\u0439 \u0437\u043D\u0430\u043A \u2014 \u043E\u0434\u0438\u043D \u0438\u0437 \u043D\u0435\u0441\u043A\u043E\u043B\u044C\u043A\u0438\u0445",
    babyMoonBody: "\u041B\u0443\u043D\u0430 \u043C\u0435\u043D\u044F\u0435\u0442 \u0437\u043D\u0430\u043A \u043A\u0430\u0436\u0434\u044B\u0435 \u0434\u0432\u0430-\u0442\u0440\u0438 \u0434\u043D\u044F, \u0442\u0430\u043A \u0447\u0442\u043E \u043D\u0435\u0434\u0435\u043B\u044F \u0440\u043E\u0434\u043E\u0432 \u043E\u0431\u044B\u0447\u043D\u043E \u043E\u0445\u0432\u0430\u0442\u044B\u0432\u0430\u0435\u0442 \u0434\u0432\u0430-\u0442\u0440\u0438 \u043B\u0443\u043D\u043D\u044B\u0445 \u0437\u043D\u0430\u043A\u0430. \u0414\u0435\u0442\u0438, \u0440\u043E\u0436\u0434\u0451\u043D\u043D\u044B\u0435 \u0432 \u043E\u0434\u043D\u0443 \u043D\u0435\u0434\u0435\u043B\u044E, \u043C\u043E\u0433\u0443\u0442 \u043D\u0435\u0441\u0442\u0438 \u0440\u0430\u0437\u043D\u044B\u0435 \u2014 \u0440\u0435\u0448\u0430\u044E\u0442 \u0434\u0435\u043D\u044C \u0438 \u0447\u0430\u0441 \u0440\u043E\u0436\u0434\u0435\u043D\u0438\u044F.",
    babyRetroHead: "\u0420\u0435\u0442\u0440\u043E\u0433\u0440\u0430\u0434\u043D\u044B\u0435 \u043F\u0440\u0438 \u0440\u043E\u0436\u0434\u0435\u043D\u0438\u0438",
    babyRetroBody: "\u044D\u0442\u0438 \u043F\u043B\u0430\u043D\u0435\u0442\u044B \u0432 \u0441\u0432\u043E\u0451\u043C \u0440\u0435\u0442\u0440\u043E\u0433\u0440\u0430\u0434\u043D\u043E\u043C \u043E\u0442\u0440\u0435\u0437\u043A\u0435 \u043E\u043A\u043E\u043B\u043E \u0434\u0430\u0442\u044B \u0440\u043E\u0434\u043E\u0432. \u0412 \u043D\u0430\u0442\u0430\u043B\u044C\u043D\u043E\u0439 \u043A\u0430\u0440\u0442\u0435 \u0440\u0435\u0442\u0440\u043E\u0433\u0440\u0430\u0434\u043D\u0430\u044F \u043F\u043B\u0430\u043D\u0435\u0442\u0430 \u0447\u0438\u0442\u0430\u0435\u0442\u0441\u044F \u043A\u0430\u043A \u0431\u043E\u043B\u0435\u0435 \u043E\u0431\u0440\u0430\u0449\u0451\u043D\u043D\u0430\u044F \u0432\u043D\u0443\u0442\u0440\u044C \u2014 \u044D\u0442\u043E \u043E\u0431\u044B\u0447\u043D\u043E\u0435 \u0434\u0435\u043B\u043E, \u0447\u0438\u043D\u0438\u0442\u044C \u043D\u0435\u0447\u0435\u0433\u043E.",
    babyRisingHead: "\u0410\u0441\u0446\u0435\u043D\u0434\u0435\u043D\u0442 \u2014 \u043D\u0435 \u0443\u0437\u043D\u0430\u0442\u044C \u0434\u043E \u043C\u0438\u043D\u0443\u0442\u044B",
    babyRisingBody: "\u0410\u0441\u0446\u0435\u043D\u0434\u0435\u043D\u0442 \u043C\u0435\u043D\u044F\u0435\u0442\u0441\u044F \u043F\u0440\u0438\u043C\u0435\u0440\u043D\u043E \u043A\u0430\u0436\u0434\u044B\u0435 \u0434\u0432\u0430 \u0447\u0430\u0441\u0430, \u0438 \u043D\u0438\u043A\u0430\u043A\u0430\u044F \u0434\u0430\u0442\u0430 \u0440\u043E\u0434\u043E\u0432 \u0435\u0433\u043E \u043D\u0435 \u043F\u0440\u0435\u0434\u0441\u043A\u0430\u0436\u0435\u0442. \u042D\u0442\u043E \u0435\u0434\u0438\u043D\u0441\u0442\u0432\u0435\u043D\u043D\u0430\u044F \u043F\u043E\u0437\u0438\u0446\u0438\u044F, \u043A\u043E\u0442\u043E\u0440\u0430\u044F \u0436\u0434\u0451\u0442 \u0441\u0432\u0438\u0434\u0435\u0442\u0435\u043B\u044C\u0441\u0442\u0432\u0430 \u043E \u0440\u043E\u0436\u0434\u0435\u043D\u0438\u0438.",
    babyDateLink: "\u0420\u0430\u0437\u043E\u0431\u0440\u0430\u0442\u044C \u044D\u0442\u043E\u0442 \u0434\u0435\u043D\u044C \u0440\u043E\u0436\u0434\u0435\u043D\u0438\u044F \u043F\u043E\u0434\u0440\u043E\u0431\u043D\u043E",
    babyChartLink: "\u041F\u043E\u0441\u043B\u0435 \u0440\u043E\u0436\u0434\u0435\u043D\u0438\u044F: \u043F\u043E\u043B\u043D\u0430\u044F \u043A\u0430\u0440\u0442\u0430",
    pfdChartPick: "\u041A\u0430\u0440\u0442\u0430",
    pfdQuietSky: "\u0422\u0438\u0445\u043E\u0435 \u043D\u0435\u0431\u043E \u0434\u043B\u044F \u044D\u0442\u043E\u0439 \u043A\u0430\u0440\u0442\u044B \u0441\u0435\u0433\u043E\u0434\u043D\u044F \u2014 \u043D\u0438\u0447\u0435\u0433\u043E \u0432 \u043F\u0440\u0435\u0434\u0435\u043B\u0430\u0445 3\xB0 \u043E\u0442 \u043D\u0430\u0442\u0430\u043B\u044C\u043D\u044B\u0445 \u0442\u043E\u0447\u0435\u043A.",
    pfdQuietAhead: "\u041D\u0430 \u0433\u043E\u0440\u0438\u0437\u043E\u043D\u0442\u0435 \u044D\u0442\u043E\u0439 \u043A\u0430\u0440\u0442\u044B \u0432 \u0440\u0430\u0441\u0441\u0447\u0438\u0442\u0430\u043D\u043D\u043E\u043C \u043E\u043A\u043D\u0435 \u043D\u0435\u0442 \u043A\u0440\u0443\u043F\u043D\u043E\u0433\u043E.",
    pfdSaturnBusy: "\u0421\u0447\u0438\u0442\u0430\u0435\u043C \u043E\u043A\u043D\u0430 \u0421\u0430\u0442\u0443\u0440\u043D\u0430 \u043D\u0430 \u0432\u0430\u0448\u0435\u043C \u0443\u0441\u0442\u0440\u043E\u0439\u0441\u0442\u0432\u0435\u2026",
    pfdEmptyTitle: "\u0412\u0430\u0448\u0435 \u043D\u0435\u0431\u043E \u2014 \u043F\u043E\u0441\u043B\u0435 \u043F\u0435\u0440\u0432\u043E\u0439 \u0441\u043E\u0445\u0440\u0430\u043D\u0451\u043D\u043D\u043E\u0439 \u043A\u0430\u0440\u0442\u044B",
    pfdEmptyBody: "\u0421\u043E\u0445\u0440\u0430\u043D\u0438\u0442\u0435 \u043D\u0430\u0442\u0430\u043B\u044C\u043D\u0443\u044E \u043A\u0430\u0440\u0442\u0443, \u0438 \u044D\u0442\u0430 \u0441\u0442\u0440\u0430\u043D\u0438\u0446\u0430 \u0431\u0443\u0434\u0435\u0442 \u043A\u0430\u0436\u0434\u044B\u0439 \u0434\u0435\u043D\u044C \u043E\u0442\u043A\u0440\u044B\u0432\u0430\u0442\u044C\u0441\u044F \u0435\u0451 \u0442\u0440\u0430\u043D\u0437\u0438\u0442\u0430\u043C\u0438, \u0434\u043E\u043C\u0430\u043C\u0438 \u0438 \u0442\u0435\u043C, \u0447\u0442\u043E \u0434\u043B\u044F \u043D\u0435\u0451 \u0432\u043F\u0435\u0440\u0435\u0434\u0438.",
    pfdWindows: "\u043E\u043A\u043D\u0430",
    openChart: "\u041E\u0442\u043A\u0440\u044B\u0442\u044C",
    dignityDomicile: "\u043E\u0431\u0438\u0442\u0435\u043B\u044C",
    dignityExaltation: "\u044D\u043A\u0437\u0430\u043B\u044C\u0442\u0430\u0446\u0438\u044F",
    dignityDetriment: "\u0438\u0437\u0433\u043D\u0430\u043D\u0438\u0435",
    dignityFall: "\u043F\u0430\u0434\u0435\u043D\u0438\u0435",
    explorerHint: "\u041A\u043E\u0441\u043D\u0438\u0442\u0435\u0441\u044C \u043B\u044E\u0431\u043E\u0439 \u043F\u043B\u0430\u043D\u0435\u0442\u044B, \u0437\u043D\u0430\u043A\u0430, \u0434\u043E\u043C\u0430 \u0438\u043B\u0438 \u043B\u0438\u043D\u0438\u0438 \u0430\u0441\u043F\u0435\u043A\u0442\u0430 \u2014 \u0438\u043B\u0438 \u0441\u0444\u043E\u043A\u0443\u0441\u0438\u0440\u0443\u0439\u0442\u0435 \u043A\u043E\u043B\u0435\u0441\u043E \u0438 \u043B\u0438\u0441\u0442\u0430\u0439\u0442\u0435 \u0441\u0442\u0440\u0435\u043B\u043A\u0430\u043C\u0438.",
    explorerLabel: "\u0418\u043D\u0442\u0435\u0440\u0430\u043A\u0442\u0438\u0432\u043D\u0430\u044F \u043D\u0430\u0442\u0430\u043B\u044C\u043D\u0430\u044F \u043A\u0430\u0440\u0442\u0430",
    explorerSelectPart: "\u0412\u044B\u0431\u0435\u0440\u0438\u0442\u0435 \u0447\u0430\u0441\u0442\u044C \u043A\u0430\u0440\u0442\u044B",
    explorerNoSelection: "\u041D\u0438\u0447\u0435\u0433\u043E \u043D\u0435 \u0432\u044B\u0431\u0440\u0430\u043D\u043E",
    explorerAngles: "\u0423\u0433\u043B\u044B",
    explorerControlsLoading: "\u0417\u0430\u0433\u0440\u0443\u0437\u043A\u0430 \u0438\u043D\u0442\u0435\u0440\u043F\u0440\u0435\u0442\u0430\u0446\u0438\u0439 \u0438 \u044D\u043B\u0435\u043C\u0435\u043D\u0442\u043E\u0432 \u0443\u043F\u0440\u0430\u0432\u043B\u0435\u043D\u0438\u044F \u043A\u0430\u0440\u0442\u043E\u0439\u2026",
    explorerControlsError: "\u041A\u0430\u0440\u0442\u0430 \u0433\u043E\u0442\u043E\u0432\u0430, \u043D\u043E \u0435\u0451 \u0438\u043D\u0442\u0435\u0440\u043F\u0440\u0435\u0442\u0430\u0446\u0438\u0438 \u0438 \u044D\u043B\u0435\u043C\u0435\u043D\u0442\u044B \u0443\u043F\u0440\u0430\u0432\u043B\u0435\u043D\u0438\u044F \u043D\u0435 \u0437\u0430\u0433\u0440\u0443\u0437\u0438\u043B\u0438\u0441\u044C. \u041F\u0440\u043E\u0432\u0435\u0440\u044C\u0442\u0435 \u043F\u043E\u0434\u043A\u043B\u044E\u0447\u0435\u043D\u0438\u0435 \u0438 \u043F\u043E\u043F\u0440\u043E\u0431\u0443\u0439\u0442\u0435 \u0441\u043D\u043E\u0432\u0430.",
    explorerKeyHint: "\u0421\u0442\u0440\u0435\u043B\u043A\u0438 \u0432\u043B\u0435\u0432\u043E \u0438 \u0432\u043F\u0440\u0430\u0432\u043E \u043F\u0435\u0440\u0435\u043A\u043B\u044E\u0447\u0430\u044E\u0442 \u043F\u043E\u043B\u043E\u0436\u0435\u043D\u0438\u044F; Enter \u043E\u0442\u043A\u0440\u044B\u0432\u0430\u0435\u0442 \u043F\u0430\u043D\u0435\u043B\u044C \u043F\u043E\u0434\u0440\u043E\u0431\u043D\u043E\u0441\u0442\u0435\u0439.",
    selectionCleared: "\u0412\u044B\u0431\u043E\u0440 \u0441\u043D\u044F\u0442.",
    inspectorClose: "\u0417\u0430\u043A\u0440\u044B\u0442\u044C \u0434\u0435\u0442\u0430\u043B\u0438",
    speed: "\u0421\u043A\u043E\u0440\u043E\u0441\u0442\u044C",
    day: "\u0441\u0443\u0442\u043A\u0438",
    dignity: "\u0414\u043E\u0441\u0442\u043E\u0438\u043D\u0441\u0442\u0432\u043E",
    separating: "\u0440\u0430\u0441\u0445\u043E\u0434\u044F\u0449\u0438\u0439\u0441\u044F",
    dates: "\u0414\u0430\u0442\u044B",
    element: "\u0421\u0442\u0438\u0445\u0438\u044F",
    ruler: "\u0423\u043F\u0440\u0430\u0432\u0438\u0442\u0435\u043B\u044C",
    inThisSign: "\u0412 \u044D\u0442\u043E\u043C \u0437\u043D\u0430\u043A\u0435",
    inThisHouse: "\u0412 \u044D\u0442\u043E\u043C \u0434\u043E\u043C\u0435",
    cusp: "\u041A\u0443\u0441\u043F\u0438\u0434",
    span: "\u041F\u0440\u043E\u0442\u044F\u0436\u0451\u043D\u043D\u043E\u0441\u0442\u044C",
    emptyHouseNote: "\u041F\u043B\u0430\u043D\u0435\u0442 \u0437\u0434\u0435\u0441\u044C \u043D\u0435\u0442. \u041F\u0443\u0441\u0442\u043E\u0439 \u0434\u043E\u043C \u2014 \u043D\u0435 \u043F\u0440\u043E\u0431\u0435\u043B: \u0435\u0433\u043E \u0442\u0435\u043C\u044B \u0438\u0434\u0443\u0442 \u0447\u0435\u0440\u0435\u0437 \u043F\u043B\u0430\u043D\u0435\u0442\u0443, \u043A\u043E\u0442\u043E\u0440\u0430\u044F \u0438\u043C \u0443\u043F\u0440\u0430\u0432\u043B\u044F\u0435\u0442.",
    angleAscNote: "\u0410\u0441\u0446\u0435\u043D\u0434\u0435\u043D\u0442 \u2014 \u0433\u0440\u0430\u0434\u0443\u0441, \u0432\u043E\u0441\u0445\u043E\u0434\u044F\u0449\u0438\u0439 \u043D\u0430\u0434 \u0432\u043E\u0441\u0442\u043E\u0447\u043D\u044B\u043C \u0433\u043E\u0440\u0438\u0437\u043E\u043D\u0442\u043E\u043C \u0432 \u043C\u043E\u043C\u0435\u043D\u0442 \u0440\u043E\u0436\u0434\u0435\u043D\u0438\u044F. \u041E\u043D \u0434\u0435\u0440\u0436\u0438\u0442 \u0432\u0441\u0451 \u043A\u043E\u043B\u0435\u0441\u043E.",
    angleDscNote: "\u0414\u0435\u0441\u0446\u0435\u043D\u0434\u0435\u043D\u0442 \u2014 \u0433\u0440\u0430\u0434\u0443\u0441, \u0437\u0430\u0445\u043E\u0434\u044F\u0449\u0438\u0439 \u043D\u0430 \u0437\u0430\u043F\u0430\u0434\u0435, \u043D\u0430\u043F\u0440\u043E\u0442\u0438\u0432 \u0430\u0441\u0446\u0435\u043D\u0434\u0435\u043D\u0442\u0430. \u0422\u0440\u0430\u0434\u0438\u0446\u0438\u043E\u043D\u043D\u0430\u044F \u0434\u0432\u0435\u0440\u044C \u043A \u043F\u0430\u0440\u0442\u043D\u0451\u0440\u0430\u043C.",
    angleMcNote: "\u0421\u0435\u0440\u0435\u0434\u0438\u043D\u0430 \u043D\u0435\u0431\u0430 \u2014 \u0433\u0440\u0430\u0434\u0443\u0441, \u043A\u0443\u043B\u044C\u043C\u0438\u043D\u0438\u0440\u0443\u044E\u0449\u0438\u0439 \u043D\u0430\u0434 \u0433\u043E\u043B\u043E\u0432\u043E\u0439 \u043F\u0440\u0438 \u0440\u043E\u0436\u0434\u0435\u043D\u0438\u0438. \u041A\u0430\u0440\u044C\u0435\u0440\u0430, \u0440\u0435\u043F\u0443\u0442\u0430\u0446\u0438\u044F, \u0432\u0438\u0434\u0438\u043C\u0430\u044F \u0436\u0438\u0437\u043D\u044C.",
    angleIcNote: "IC \u2014 \u043D\u0438\u0436\u043D\u044F\u044F \u0442\u043E\u0447\u043A\u0430 \u043A\u043E\u043B\u0435\u0441\u0430, \u043D\u0430\u043F\u0440\u043E\u0442\u0438\u0432 \u0421\u0435\u0440\u0435\u0434\u0438\u043D\u044B \u043D\u0435\u0431\u0430. \u0414\u043E\u043C, \u043A\u043E\u0440\u043D\u0438, \u0447\u0430\u0441\u0442\u043D\u0430\u044F \u0436\u0438\u0437\u043D\u044C.",
    layersLabel: "\u0421\u043B\u043E\u0438 \u043A\u0430\u0440\u0442\u044B",
    layerHouses: "\u0414\u043E\u043C\u0430",
    editedBy: "\u041F\u0443\u0431\u043B\u0438\u043A\u0443\u0435\u0442",
    tourStart: "\u041F\u0440\u043E\u0439\u0442\u0438 \u044D\u043A\u0441\u043A\u0443\u0440\u0441\u0438\u044E",
    firstReadingLabel: "\u0412\u0430\u0448\u0435 \u0447\u0442\u0435\u043D\u0438\u0435 \u0437\u0430 2 \u043C\u0438\u043D\u0443\u0442\u044B",
    firstReadingTitle: "\u0427\u0442\u043E \u0432\u0430\u0448\u0430 \u043A\u0430\u0440\u0442\u0430 \u0433\u043E\u0432\u043E\u0440\u0438\u0442 \u043E \u0432\u0430\u0441 \u2014 \u0438 \u0447\u0442\u043E \u0434\u0430\u043B\u044C\u0448\u0435?",
    firstReadingBody: "\u041F\u043E\u0441\u043C\u043E\u0442\u0440\u0438\u0442\u0435 \u0441\u0432\u043E\u0439 \u0445\u0430\u0440\u0430\u043A\u0442\u0435\u0440\u043D\u044B\u0439 \u0440\u0430\u0441\u043A\u043B\u0430\u0434, \u0433\u0434\u0435 \u043E\u043D \u0440\u0430\u0437\u0432\u043E\u0440\u0430\u0447\u0438\u0432\u0430\u0435\u0442\u0441\u044F, \u043E\u0434\u0438\u043D \u0443\u0437\u043D\u0430\u0432\u0430\u0435\u043C\u044B\u0439 \u043F\u0430\u0442\u0442\u0435\u0440\u043D \u2014 \u0438 \u043A\u0430\u043A \u0430\u0441\u0442\u0440\u043E\u043B\u043E\u0433\u0438\u044F \u043F\u0440\u0435\u0432\u0440\u0430\u0449\u0430\u0435\u0442 \u043A\u0430\u0440\u0442\u0443 \u0432 \u043F\u0440\u043E\u0433\u043D\u043E\u0437.",
    firstReadingResumeTitle: "\u0412\u0430\u0448\u0435 \u0447\u0442\u0435\u043D\u0438\u0435 \u0436\u0434\u0451\u0442",
    firstReadingResumeBody: "\u041F\u0440\u043E\u0434\u043E\u043B\u0436\u0438\u0442\u0435 \u0441 \u0442\u043E\u0433\u043E \u043C\u0435\u0441\u0442\u0430, \u0433\u0434\u0435 \u043E\u0441\u0442\u0430\u043D\u043E\u0432\u0438\u043B\u0438\u0441\u044C \u043D\u0430 \u044D\u0442\u043E\u043C \u0443\u0441\u0442\u0440\u043E\u0439\u0441\u0442\u0432\u0435.",
    firstReadingStart: "\u041F\u0440\u043E\u0447\u0438\u0442\u0430\u0442\u044C \u043C\u043E\u044E \u043A\u0430\u0440\u0442\u0443",
    firstReadingExplore: "\u0420\u0430\u0437\u0431\u0435\u0440\u0443\u0441\u044C \u0441\u0430\u043C(\u0430)",
    firstReadingResume: "\u041F\u0440\u043E\u0434\u043E\u043B\u0436\u0438\u0442\u044C \u0447\u0442\u0435\u043D\u0438\u0435",
    firstReadingStep: "\u0428\u0430\u0433",
    firstReadingFullTour: "\u041A\u0430\u043A \u0443\u0441\u0442\u0440\u043E\u0435\u043D\u0430 \u043A\u0430\u0440\u0442\u0430 \u2014 \u0440\u0430\u0441\u0448\u0438\u0440\u0435\u043D\u043D\u0430\u044F \u044D\u043A\u0441\u043A\u0443\u0440\u0441\u0438\u044F",
    firstReadingReplay: "\u041F\u0440\u043E\u0438\u0433\u0440\u0430\u0442\u044C \u0438\u0441\u0442\u043E\u0440\u0438\u044E \u043A\u0430\u0440\u0442\u044B \u0437\u0430\u043D\u043E\u0432\u043E",
    chartActionsMore: "\u0415\u0449\u0451 \u0441\u043F\u043E\u0441\u043E\u0431\u044B \u0438\u0441\u043F\u043E\u043B\u044C\u0437\u043E\u0432\u0430\u0442\u044C \u044D\u0442\u0443 \u043A\u0430\u0440\u0442\u0443",
    chartReceiptDownload: "\u0421\u043A\u0430\u0447\u0430\u0442\u044C \u0437\u0430\u043F\u0438\u0441\u044C \u0440\u0430\u0441\u0447\u0451\u0442\u0430 (.json)",
    chartReceiptPrivacy: "\u0424\u0430\u0439\u043B \u0441\u043E\u0434\u0435\u0440\u0436\u0438\u0442 \u043B\u0438\u0447\u043D\u044B\u0435 \u0434\u0430\u043D\u043D\u044B\u0435 \u043E \u0440\u043E\u0436\u0434\u0435\u043D\u0438\u0438 \u0438 \u0434\u0430\u043D\u043D\u044B\u0435 \u043A\u0430\u0440\u0442\u044B. \u0425\u0440\u0430\u043D\u0438\u0442\u0435 \u0435\u0433\u043E \u0432 \u0431\u0435\u0437\u043E\u043F\u0430\u0441\u043D\u043E\u043C \u043C\u0435\u0441\u0442\u0435.",
    chartReceiptError: "\u041D\u0435 \u0443\u0434\u0430\u043B\u043E\u0441\u044C \u0441\u043A\u0430\u0447\u0430\u0442\u044C \u0444\u0430\u0439\u043B. \u041F\u043E\u043F\u0440\u043E\u0431\u0443\u0439\u0442\u0435 \u0435\u0449\u0451 \u0440\u0430\u0437.",
    chartReceiptUnavailable: "\u0417\u0430\u043F\u0438\u0441\u044C \u0440\u0430\u0441\u0447\u0451\u0442\u0430 \u0434\u043B\u044F \u044D\u0442\u043E\u0439 \u043A\u0430\u0440\u0442\u044B \u043D\u0435\u0434\u043E\u0441\u0442\u0443\u043F\u043D\u0430.",
    seeTodaySky: "\u041D\u0435\u0431\u043E \u0441\u0435\u0433\u043E\u0434\u043D\u044F",
    contextHelpCue: "\u0422\u0435\u0440\u043C\u0438\u043D\u044B \u0441 \u0442\u043E\u0447\u0435\u0447\u043D\u044B\u043C \u043F\u043E\u0434\u0447\u0451\u0440\u043A\u0438\u0432\u0430\u043D\u0438\u0435\u043C \u043E\u0442\u043A\u0440\u044B\u0432\u0430\u044E\u0442 \u043F\u043E\u044F\u0441\u043D\u0435\u043D\u0438\u0435 \u043F\u0440\u043E\u0441\u0442\u044B\u043C \u044F\u0437\u044B\u043A\u043E\u043C.",
    editorialHow: "\u0440\u0435\u0434\u0430\u043A\u0446\u0438\u043E\u043D\u043D\u044B\u0435 \u0441\u0442\u0430\u043D\u0434\u0430\u0440\u0442\u044B",
    dstGapNotice: "\u042D\u0442\u043E \u0432\u0440\u0435\u043C\u044F \u043F\u043E\u043F\u0430\u043B\u043E \u0432 \xAB\u043F\u0440\u044B\u0436\u043E\u043A\xBB \u043F\u0435\u0440\u0435\u0432\u043E\u0434\u0430 \u0447\u0430\u0441\u043E\u0432 \u0438 \u0444\u043E\u0440\u043C\u0430\u043B\u044C\u043D\u043E \u043D\u0435 \u0441\u0443\u0449\u0435\u0441\u0442\u0432\u043E\u0432\u0430\u043B\u043E \u2014 \u043C\u044B \u0441\u0434\u0432\u0438\u043D\u0443\u043B\u0438 \u0435\u0433\u043E \u0432\u043F\u0435\u0440\u0451\u0434 \u0447\u0435\u0440\u0435\u0437 \u0440\u0430\u0437\u0440\u044B\u0432, \u043A\u0430\u043A \u043F\u0440\u0438\u043D\u044F\u0442\u043E.",
    dstFoldNotice: "\u0412 \u043C\u0435\u0441\u0442\u0435 \u0440\u043E\u0436\u0434\u0435\u043D\u0438\u044F \u044D\u0442\u043E\u0442 \u0447\u0430\u0441 \u043F\u0440\u043E\u0448\u0451\u043B \u0434\u0432\u0430\u0436\u0434\u044B; \u043C\u044B \u0432\u0437\u044F\u043B\u0438 \u043F\u0435\u0440\u0432\u044B\u0439 \u043F\u0440\u043E\u0445\u043E\u0434. \u0415\u0441\u043B\u0438 \u0432\u044B \u0437\u043D\u0430\u0435\u0442\u0435, \u0447\u0442\u043E \u0431\u044B\u043B \u0432\u0442\u043E\u0440\u043E\u0439, \u043A\u0430\u0440\u0442\u0430 \u043F\u043E\u0447\u0442\u0438 \u043D\u0435 \u0438\u0437\u043C\u0435\u043D\u0438\u0442\u0441\u044F \u2014 \u041B\u0443\u043D\u0430 \u043F\u0440\u043E\u0445\u043E\u0434\u0438\u0442 \u043E\u043A\u043E\u043B\u043E \u043F\u043E\u043B\u0443\u0433\u0440\u0430\u0434\u0443\u0441\u0430 \u0432 \u0447\u0430\u0441.",
    lmtNotice: "\u0420\u043E\u0436\u0434\u0435\u043D\u0438\u0435 \u0434\u043E \u0432\u0432\u0435\u0434\u0435\u043D\u0438\u044F \u0447\u0430\u0441\u043E\u0432\u044B\u0445 \u043F\u043E\u044F\u0441\u043E\u0432 \u2014 \u043C\u044B \u0438\u0441\u043F\u043E\u043B\u044C\u0437\u043E\u0432\u0430\u043B\u0438 \u043C\u0435\u0441\u0442\u043D\u043E\u0435 \u0441\u0440\u0435\u0434\u043D\u0435\u0435 \u0432\u0440\u0435\u043C\u044F \u0442\u043E\u0439 \u044D\u043F\u043E\u0445\u0438, \u0442\u0443 \u0436\u0435 \u043A\u043E\u043D\u0432\u0435\u043D\u0446\u0438\u044E, \u0447\u0442\u043E \u0438 \u043F\u0440\u043E\u0444\u0435\u0441\u0441\u0438\u043E\u043D\u0430\u043B\u044C\u043D\u044B\u0435 \u043F\u0440\u043E\u0433\u0440\u0430\u043C\u043C\u044B.",
    polarNotice: "\u0422\u0430\u043A \u0431\u043B\u0438\u0437\u043A\u043E \u043A \u043F\u043E\u043B\u044E\u0441\u0443 \u0434\u043E\u043C\u0430 \u041F\u043B\u0430\u0446\u0438\u0434\u0443\u0441\u0430 \u043D\u0435 \u043E\u043F\u0440\u0435\u0434\u0435\u043B\u0435\u043D\u044B, \u043F\u043E\u044D\u0442\u043E\u043C\u0443 \u043A\u0430\u0440\u0442\u0430 \u0438\u0441\u043F\u043E\u043B\u044C\u0437\u0443\u0435\u0442 \u0434\u043E\u043C\u0430 \u0446\u0435\u043B\u044B\u0445 \u0437\u043D\u0430\u043A\u043E\u0432.",
    noTimeNotice: "\u0411\u0435\u0437 \u0432\u0440\u0435\u043C\u0435\u043D\u0438 \u0440\u043E\u0436\u0434\u0435\u043D\u0438\u044F \u0438\u0441\u043F\u043E\u043B\u044C\u0437\u0443\u0435\u043C 12:00 \u043C\u0435\u0441\u0442\u043D\u043E\u0433\u043E \u0433\u0440\u0430\u0436\u0434\u0430\u043D\u0441\u043A\u043E\u0433\u043E \u0432\u0440\u0435\u043C\u0435\u043D\u0438 \u043A\u0430\u043A \u043E\u0440\u0438\u0435\u043D\u0442\u0438\u0440 \u0438 \u043D\u0435 \u043F\u043E\u043A\u0430\u0437\u044B\u0432\u0430\u0435\u043C \u0430\u0441\u0446\u0435\u043D\u0434\u0435\u043D\u0442, \u0443\u0433\u043B\u044B \u0438 \u0434\u043E\u043C\u0430.",
    moonAmbiguousNotice: "\u0412 \u044D\u0442\u043E\u0442 \u0434\u0435\u043D\u044C \u041B\u0443\u043D\u0430 \u0441\u043C\u0435\u043D\u0438\u043B\u0430 \u0437\u043D\u0430\u043A \u2014 \u043F\u043E\u043A\u0430 \u0432\u0440\u0435\u043C\u044F \u043D\u0435 \u043D\u0430\u0439\u0434\u0435\u043D\u043E, \u0447\u0435\u0441\u0442\u043D\u043E \u0447\u0438\u0442\u0430\u0442\u044C \u043E\u0431\u043E\u0438\u0445 \u0441\u043E\u0441\u0435\u0434\u0435\u0439.",
    fromLinkNotice: "\u041E\u0442\u043A\u0440\u044B\u0442\u043E \u043F\u043E \u0441\u0441\u044B\u043B\u043A\u0435 \u2014 \u0434\u0430\u043D\u043D\u044B\u0435 \u0440\u043E\u0436\u0434\u0435\u043D\u0438\u044F \u043F\u0440\u0438\u0448\u043B\u0438 \u0432 \u0441\u0430\u043C\u043E\u0439 \u0441\u0441\u044B\u043B\u043A\u0435, \u0438 \u043A\u0430\u0440\u0442\u0430 \u0442\u043E\u043B\u044C\u043A\u043E \u0447\u0442\u043E \u0440\u0430\u0441\u0441\u0447\u0438\u0442\u0430\u043D\u0430 \u043D\u0430 \u0432\u0430\u0448\u0435\u043C \u0443\u0441\u0442\u0440\u043E\u0439\u0441\u0442\u0432\u0435.",
    howWeCompute: "\u041A\u0430\u043A \u043C\u044B \u0441\u0447\u0438\u0442\u0430\u0435\u043C",
    welcomeBack: "\u0421 \u0432\u043E\u0437\u0432\u0440\u0430\u0449\u0435\u043D\u0438\u0435\u043C.",
    savedChartAria: "\u0412\u0430\u0448\u0430 \u0441\u043E\u0445\u0440\u0430\u043D\u0451\u043D\u043D\u0430\u044F \u043A\u0430\u0440\u0442\u0430",
    todayAgainstChart: "\u0421\u0435\u0433\u043E\u0434\u043D\u044F \u043D\u0430 \u0444\u043E\u043D\u0435 \u0432\u0430\u0448\u0435\u0439 \u043A\u0430\u0440\u0442\u044B",
    yourCharts: "\u0412\u0430\u0448\u0438 \u043A\u0430\u0440\u0442\u044B",
    recommendedNext: "\u0427\u0442\u043E \u0434\u0430\u043B\u044C\u0448\u0435",
    todayForName: "\u0427\u0442\u043E \u0441\u0435\u0433\u043E\u0434\u043D\u044F \u0437\u043D\u0430\u0447\u0438\u0442 \u0434\u043B\u044F {name}",
    savedChartTodayBody: "\u0412\u0430\u0448\u0430 \u043A\u0430\u0440\u0442\u0430 \u043D\u0435 \u043C\u0435\u043D\u044F\u0435\u0442\u0441\u044F. \u0421\u0435\u0433\u043E\u0434\u043D\u044F\u0448\u043D\u0435\u0435 \u043D\u0435\u0431\u043E \u2014 \u043C\u0435\u043D\u044F\u0435\u0442\u0441\u044F: \u043D\u0430\u0447\u043D\u0438\u0442\u0435 \u0441 \u0442\u043E\u0433\u043E, \u0447\u0442\u043E \u0434\u0432\u0438\u0436\u0435\u0442\u0441\u044F \u0434\u043B\u044F \u0432\u0430\u0441 \u0441\u0435\u0439\u0447\u0430\u0441.",
    openSavedChart: "\u041E\u0442\u043A\u0440\u044B\u0442\u044C \u0441\u043E\u0445\u0440\u0430\u043D\u0451\u043D\u043D\u0443\u044E \u043A\u0430\u0440\u0442\u0443",
    moonReadingSky: "\u0427\u0438\u0442\u0430\u0435\u043C \u043D\u0435\u0431\u043E\u2026",
    illuminated: "\u043E\u0441\u0432\u0435\u0449\u0435\u043D\u043E",
    moonIn: "\u041B\u0443\u043D\u0430 \u0432:",
    findThatMoon: "\u041D\u0430\u0439\u0442\u0438 \u044D\u0442\u0443 \u041B\u0443\u043D\u0443",
    dateHelp: "\u0414\u0435\u043D\u044C \u0440\u043E\u0436\u0434\u0435\u043D\u0438\u044F, \u0433\u043E\u0434\u043E\u0432\u0449\u0438\u043D\u0430 \u2014 \u043B\u044E\u0431\u0430\u044F \u0434\u0430\u0442\u0430.",
    placeHelpMoon: "\u0423\u0442\u043E\u0447\u043D\u044F\u0435\u0442 \u043F\u0435\u0440\u0435\u0441\u0447\u0451\u0442 \u0447\u0430\u0441\u043E\u0432; \u0444\u0430\u0437\u0435 \u044D\u0442\u043E \u043F\u043E\u0447\u0442\u0438 \u043D\u0435 \u043D\u0443\u0436\u043D\u043E.",
    middayLocalCaption: "\u0421\u0447\u0438\u0442\u0430\u043D\u043E \u043D\u0430 \u043F\u043E\u043B\u0434\u0435\u043D\u044C \u043C\u0435\u0441\u0442\u043D\u043E\u0433\u043E \u0432\u0440\u0435\u043C\u0435\u043D\u0438 \u2014 \u0442\u043E\u0447\u043D\u043E\u0435 \u0432\u0440\u0435\u043C\u044F \u0441\u0443\u0442\u043E\u043A \u0437\u0430\u043A\u0440\u0435\u043F\u0438\u0442 \u0433\u0440\u0430\u0434\u0443\u0441.",
    utcTimeCaption: "\u0412\u0440\u0435\u043C\u044F \u0447\u0438\u0442\u0430\u0435\u0442\u0441\u044F \u043A\u0430\u043A \u0432\u0441\u0435\u043C\u0438\u0440\u043D\u043E\u0435 \u2014 \u0434\u043E\u0431\u0430\u0432\u044C\u0442\u0435 \u043C\u0435\u0441\u0442\u043E \u0440\u043E\u0436\u0434\u0435\u043D\u0438\u044F, \u0447\u0442\u043E\u0431\u044B \u043F\u0435\u0440\u0435\u0441\u0447\u0438\u0442\u0430\u0442\u044C \u0432\u0430\u0448\u0438 \u0447\u0430\u0441\u044B.",
    middayUtcCaption: "\u0421\u0447\u0438\u0442\u0430\u043D\u043E \u043D\u0430 \u043F\u043E\u043B\u0434\u0435\u043D\u044C \u0432\u0441\u0435\u043C\u0438\u0440\u043D\u043E\u0433\u043E \u0432\u0440\u0435\u043C\u0435\u043D\u0438 \u2014 \u0432\u0440\u0435\u043C\u044F \u0438 \u043C\u0435\u0441\u0442\u043E \u0437\u0430\u043A\u0440\u0435\u043F\u044F\u0442 \u0433\u0440\u0430\u0434\u0443\u0441 \u0442\u043E\u0447\u043D\u043E.",
    moonChangedNotice: "\u0412 \u044D\u0442\u043E\u0442 \u0434\u0435\u043D\u044C \u041B\u0443\u043D\u0430 \u0441\u043C\u0435\u043D\u0438\u043B\u0430 \u0437\u043D\u0430\u043A, \u0438 \u0431\u0435\u0437 \u0432\u0440\u0435\u043C\u0435\u043D\u0438 \u043D\u0435\u043B\u044C\u0437\u044F \u0441\u043A\u0430\u0437\u0430\u0442\u044C, \u043F\u043E \u043A\u0430\u043A\u0443\u044E \u0441\u0442\u043E\u0440\u043E\u043D\u0443 \u0433\u0440\u0430\u043D\u0438\u0446\u044B \u0432\u044B \u0440\u043E\u0434\u0438\u043B\u0438\u0441\u044C. \u0424\u0430\u0437\u0430 \u043D\u0435 \u0441\u0442\u0440\u0430\u0434\u0430\u0435\u0442 \u2014 \u043E\u043D\u0430 \u0434\u0432\u0438\u0436\u0435\u0442\u0441\u044F \u0441\u043B\u0438\u0448\u043A\u043E\u043C \u043C\u0435\u0434\u043B\u0435\u043D\u043D\u043E, \u0447\u0442\u043E\u0431\u044B \u0447\u0430\u0441\u044B \u0438\u043C\u0435\u043B\u0438 \u0437\u043D\u0430\u0447\u0435\u043D\u0438\u0435.",
    birthChartForDate: "\u041F\u043E\u0441\u0442\u0440\u043E\u0438\u0442\u044C \u043D\u0430\u0442\u0430\u043B\u044C\u043D\u0443\u044E \u043A\u0430\u0440\u0442\u0443 \u043D\u0430 \u044D\u0442\u0443 \u0434\u0430\u0442\u0443",
    natalSaturn: "\u0412\u0430\u0448 \u043D\u0430\u0442\u0430\u043B\u044C\u043D\u044B\u0439 \u0421\u0430\u0442\u0443\u0440\u043D",
    addBirthDetails: "\u0414\u043E\u0431\u0430\u0432\u0438\u0442\u044C \u0432\u0440\u0435\u043C\u044F \u0438 \u043C\u0435\u0441\u0442\u043E \u0440\u043E\u0436\u0434\u0435\u043D\u0438\u044F (\u043D\u0435\u043E\u0431\u044F\u0437\u0430\u0442\u0435\u043B\u044C\u043D\u043E)",
    findSaturnReturn: "\u041D\u0430\u0439\u0442\u0438 \u0441\u0432\u043E\u0451 \u0432\u043E\u0437\u0432\u0440\u0430\u0449\u0435\u043D\u0438\u0435 \u0421\u0430\u0442\u0443\u0440\u043D\u0430",
    returnApprox: "\u0414\u0430\u0442\u044B \u0440\u0430\u0441\u0441\u0447\u0438\u0442\u0430\u043D\u044B \u043F\u043E \u043F\u043E\u043B\u0443\u0434\u0435\u043D\u043D\u043E\u043C\u0443 \u0447\u0442\u0435\u043D\u0438\u044E \u2014 \u0441\u043E \u0432\u0440\u0435\u043C\u0435\u043D\u0435\u043C \u0438 \u043C\u0435\u0441\u0442\u043E\u043C \u0440\u043E\u0436\u0434\u0435\u043D\u0438\u044F \u043E\u043D\u0438 \u043C\u043E\u0433\u0443\u0442 \u0441\u0434\u0432\u0438\u043D\u0443\u0442\u044C\u0441\u044F \u043D\u0430 \u043D\u0435\u0441\u043A\u043E\u043B\u044C\u043A\u043E \u0434\u043D\u0435\u0439 \u0432 \u043B\u044E\u0431\u0443\u044E \u0441\u0442\u043E\u0440\u043E\u043D\u0443.",
    complete: "\u041F\u043E\u0437\u0430\u0434\u0438",
    underwayNow: "\u0418\u0434\u0451\u0442 \u0441\u0435\u0439\u0447\u0430\u0441",
    aheadOfYou: "\u0412\u043F\u0435\u0440\u0435\u0434\u0438",
    first: "\u041F\u0435\u0440\u0432\u043E\u0435",
    second: "\u0412\u0442\u043E\u0440\u043E\u0435",
    third: "\u0422\u0440\u0435\u0442\u044C\u0435",
    fourth: "\u0427\u0435\u0442\u0432\u0451\u0440\u0442\u043E\u0435",
    aroundAge29: "\u043E\u043A\u043E\u043B\u043E 29 \u043B\u0435\u0442",
    aroundAge58: "\u043E\u043A\u043E\u043B\u043E 58 \u043B\u0435\u0442",
    aroundAge88: "\u043E\u043A\u043E\u043B\u043E 88 \u043B\u0435\u0442",
    retrogradePass: "\u0440\u0435\u0442\u0440\u043E\u0433\u0440\u0430\u0434\u043D\u044B\u0439 \u043F\u0440\u043E\u0445\u043E\u0434",
    threePasses: "\u0422\u0440\u0438 \u0442\u043E\u0447\u043D\u044B\u0445 \u043F\u0440\u043E\u0445\u043E\u0434\u0430: \u0421\u0430\u0442\u0443\u0440\u043D \u043F\u0435\u0440\u0435\u0441\u0435\u043A\u0430\u0435\u0442 \u0432\u0430\u0448 \u0433\u0440\u0430\u0434\u0443\u0441, \u0432\u043E\u0437\u0432\u0440\u0430\u0449\u0430\u0435\u0442\u0441\u044F \u043F\u043E \u043D\u0435\u043C\u0443 \u0440\u0435\u0442\u0440\u043E\u0433\u0440\u0430\u0434\u043D\u043E \u0438 \u0437\u0430\u043A\u0440\u0435\u043F\u043B\u044F\u0435\u0442 \u043D\u0430 \u0432\u044B\u0445\u043E\u0434\u0435. \u0412\u043E\u0437\u0432\u0440\u0430\u0449\u0435\u043D\u0438\u0435 \u2014 \u0432\u0435\u0441\u044C \u044D\u0442\u043E\u0442 \u043E\u0442\u0440\u0435\u0437\u043E\u043A.",
    seeSaturnChart: "\u0421\u0430\u0442\u0443\u0440\u043D \u0432 \u0432\u0430\u0448\u0435\u0439 \u043D\u0430\u0442\u0430\u043B\u044C\u043D\u043E\u0439 \u043A\u0430\u0440\u0442\u0435",
    whatSaturnMeans: "\u0427\u0442\u043E \u0437\u043D\u0430\u0447\u0438\u0442 \u0421\u0430\u0442\u0443\u0440\u043D",
    yourChart: "\u0412\u0430\u0448\u0430 \u043A\u0430\u0440\u0442\u0430",
    theSky: "\u041D\u0435\u0431\u043E",
    transitRingLede: "\u041F\u043E\u0441\u0442\u0440\u043E\u0439\u0442\u0435 \u043A\u0430\u0440\u0442\u0443, \u0437\u0430\u0442\u0435\u043C \u0434\u0432\u0438\u0433\u0430\u0439\u0442\u0435 \u043F\u043E\u043B\u0437\u0443\u043D\u043E\u043A \u0438 \u0441\u043C\u043E\u0442\u0440\u0438\u0442\u0435, \u043A\u0430\u043A \u043F\u043B\u0430\u043D\u0435\u0442\u044B \u0438\u0434\u0443\u0442 \u043F\u043E \u043D\u0435\u0439 \u2014 \u0432\u043F\u0435\u0440\u0451\u0434 \u0438\u043B\u0438 \u043D\u0430\u0437\u0430\u0434, \u0434\u043E \u0433\u043E\u0434\u0430.",
    checkTransits: "\u041F\u0440\u043E\u0432\u0435\u0440\u0438\u0442\u044C \u0441\u0432\u043E\u0438 \u0442\u0440\u0430\u043D\u0437\u0438\u0442\u044B",
    savedChartHelp: "\u0420\u0430\u0441\u0441\u0447\u0438\u0442\u0430\u043D\u043D\u044B\u0435 \u0438 \u0441\u043E\u0445\u0440\u0430\u043D\u0451\u043D\u043D\u044B\u0435 \u043A\u0430\u0440\u0442\u044B \u043F\u043E\u044F\u0432\u043B\u044F\u044E\u0442\u0441\u044F \u0437\u0434\u0435\u0441\u044C \u0432 \u043E\u0434\u0438\u043D \u0442\u0430\u043F \u2014 \u0441\u043B\u0435\u0434\u0443\u044E\u0449\u0430\u044F \u043F\u0440\u043E\u0432\u0435\u0440\u043A\u0430 \u043E\u0431\u043E\u0439\u0434\u0451\u0442\u0441\u044F \u0431\u0435\u0437 \u0432\u0432\u043E\u0434\u0430.",
    noTransitTimeNotice: "\u0423 \u044D\u0442\u043E\u0439 \u043A\u0430\u0440\u0442\u044B \u043D\u0435\u0442 \u0432\u0440\u0435\u043C\u0435\u043D\u0438 \u0440\u043E\u0436\u0434\u0435\u043D\u0438\u044F, \u0442\u0430\u043A \u0447\u0442\u043E \u0435\u0451 \u041B\u0443\u043D\u0430 \u2014 \u043F\u043E\u043B\u0443\u0434\u0435\u043D\u043D\u0430\u044F \u043E\u0446\u0435\u043D\u043A\u0430: \u043E\u043D\u0430 \u043C\u043E\u0436\u0435\u0442 \u043E\u0442\u0441\u0442\u043E\u044F\u0442\u044C \u0434\u043E \u0448\u0435\u0441\u0442\u0438 \u0433\u0440\u0430\u0434\u0443\u0441\u043E\u0432, \u0438 \u0442\u0440\u0430\u043D\u0437\u0438\u0442 \u043A \u041B\u0443\u043D\u0435 \u0443 \u043A\u0440\u0430\u044F \u043E\u0440\u0431\u0438\u0441\u0430 \u043C\u043E\u0436\u0435\u0442 \u043F\u043E\u044F\u0432\u0438\u0442\u044C\u0441\u044F \u0438\u043B\u0438 \u0438\u0441\u0447\u0435\u0437\u043D\u0443\u0442\u044C \u0441 \u043D\u0430\u0441\u0442\u043E\u044F\u0449\u0438\u043C \u0432\u0440\u0435\u043C\u0435\u043D\u0435\u043C.",
    skyAt: "\u041D\u0435\u0431\u043E \u043D\u0430",
    noTransitsWithin: "\u041D\u0435\u0442 \u0442\u0440\u0430\u043D\u0437\u0438\u0442\u043E\u0432 \u0432 \u043F\u0440\u0435\u0434\u0435\u043B\u0430\u0445",
    activeTransitsWithin: "\u0430\u043A\u0442\u0438\u0432\u043D\u044B\u0445 \u0442\u0440\u0430\u043D\u0437\u0438\u0442\u043E\u0432 \u0432 \u043F\u0440\u0435\u0434\u0435\u043B\u0430\u0445",
    activeTransitWithin: "\u0430\u043A\u0442\u0438\u0432\u043D\u044B\u0439 \u0442\u0440\u0430\u043D\u0437\u0438\u0442 \u0432 \u043F\u0440\u0435\u0434\u0435\u043B\u0430\u0445",
    ofExact: "\u043E\u0442 \u0442\u043E\u0447\u043D\u043E\u0433\u043E",
    transitMoonOmitted: "\u0442\u0440\u0430\u043D\u0437\u0438\u0442\u043D\u0430\u044F \u041B\u0443\u043D\u0430 \u043D\u0435 \u043F\u043E\u043A\u0430\u0437\u0430\u043D\u0430 \u2014 \u043E\u043D\u0430 \u043F\u0440\u043E\u0445\u043E\u0434\u0438\u0442 \u0432\u0441\u044E \u043A\u0430\u0440\u0442\u0443 \u0437\u0430 \u043C\u0435\u0441\u044F\u0446",
    quietSky: "\u0422\u0438\u0445\u043E\u0435 \u043D\u0435\u0431\u043E \u043F\u043E \u0441\u0442\u0440\u043E\u0433\u043E\u043C\u0443 \u043E\u0440\u0431\u0438\u0441\u0443 \u044D\u0442\u043E\u0439 \u0441\u0442\u0440\u0430\u043D\u0438\u0446\u044B. \u041D\u0438\u0447\u0435\u0433\u043E \u0441\u0440\u043E\u0447\u043D\u043E\u0433\u043E \u2014 \u0437\u0430\u0433\u043B\u044F\u043D\u0438\u0442\u0435 \u0447\u0435\u0440\u0435\u0437 \u043F\u0430\u0440\u0443 \u0434\u043D\u0435\u0439 \u0438\u043B\u0438 \u0440\u0430\u0441\u0448\u0438\u0440\u044C\u0442\u0435 \u0447\u0442\u0435\u043D\u0438\u0435 \u0434\u043E \u0441\u043E\u0431\u044B\u0442\u0438\u0439 \u043C\u0435\u0441\u044F\u0446\u0430 \u043D\u0438\u0436\u0435.",
    natal: "\u041D\u0430\u0442\u0430\u043B\u044C\u043D\u044B\u0439",
    forYourChart: "\u0414\u043B\u044F \u0432\u0430\u0448\u0435\u0439 \u043A\u0430\u0440\u0442\u044B",
    orb: "\u043E\u0440\u0431\u0438\u0441",
    openDailyBrief: "\u041E\u0442\u043A\u0440\u044B\u0442\u044C \u043F\u043E\u043B\u043D\u044B\u0439 \u0432\u044B\u043F\u0443\u0441\u043A \u043D\u0430 \u0441\u0435\u0433\u043E\u0434\u043D\u044F \u2014 \u043F\u043E\u043A\u0430 \u043F\u043E-\u0430\u043D\u0433\u043B\u0438\u0439\u0441\u043A\u0438",
    allTransits: "\u0412\u0441\u0435 \u0432\u0430\u0448\u0438 \u0442\u0440\u0430\u043D\u0437\u0438\u0442\u044B",
    personA: "\u0427\u0435\u043B\u043E\u0432\u0435\u043A A",
    personB: "\u0427\u0435\u043B\u043E\u0432\u0435\u043A B",
    sharedChart: "\u041F\u0440\u0438\u0441\u043B\u0430\u043D\u043D\u0430\u044F \u043A\u0430\u0440\u0442\u0430",
    sharedWithYou: "\u0432\u0430\u043C \u043F\u043E\u0434\u0435\u043B\u0438\u043B\u0438\u0441\u044C",
    removeSharedChart: "\u0423\u0431\u0440\u0430\u0442\u044C \u043F\u0440\u0438\u0441\u043B\u0430\u043D\u043D\u0443\u044E \u043A\u0430\u0440\u0442\u0443",
    sharedSideHelp: "\u042D\u0442\u0430 \u0441\u0442\u043E\u0440\u043E\u043D\u0430 \u043F\u0440\u0438\u0448\u043B\u0430 \u0432 \u0441\u0441\u044B\u043B\u043A\u0435 \u2014 \u043E\u0447\u0438\u0441\u0442\u0438\u0442\u0435 \u0435\u0451, \u0447\u0442\u043E\u0431\u044B \u0432\u0432\u0435\u0441\u0442\u0438 \u0434\u0440\u0443\u0433\u043E\u0433\u043E \u0447\u0435\u043B\u043E\u0432\u0435\u043A\u0430.",
    name: "\u0418\u043C\u044F",
    compareCharts: "\u0421\u0440\u0430\u0432\u043D\u0438\u0442\u044C \u043A\u0430\u0440\u0442\u044B",
    sameChart: "\u042D\u0442\u043E \u043E\u0434\u043D\u0430 \u0438 \u0442\u0430 \u0436\u0435 \u043A\u0430\u0440\u0442\u0430 \u0434\u0432\u0430\u0436\u0434\u044B \u2014 \u0432\u044B\u0431\u0435\u0440\u0438\u0442\u0435 \u0434\u0432\u0435 \u0440\u0430\u0437\u043D\u044B\u0435.",
    compareSavedHelp: "\u0420\u0430\u0441\u0441\u0447\u0438\u0442\u0430\u043D\u043D\u044B\u0435 \u0438 \u0441\u043E\u0445\u0440\u0430\u043D\u0451\u043D\u043D\u044B\u0435 \u043A\u0430\u0440\u0442\u044B \u043F\u043E\u044F\u0432\u043B\u044F\u044E\u0442\u0441\u044F \u0437\u0434\u0435\u0441\u044C \u0432 \u043E\u0434\u0438\u043D \u0442\u0430\u043F \u2014 \u0432\u0442\u043E\u0440\u043E\u0435 \u0441\u0440\u0430\u0432\u043D\u0435\u043D\u0438\u0435 \u0431\u044B\u0441\u0442\u0440\u0435\u0435 \u043F\u0435\u0440\u0432\u043E\u0433\u043E.",
    compareNoTimeNotice: "\u041D\u0435\u0442 \u0432\u0440\u0435\u043C\u0435\u043D\u0438 \u0440\u043E\u0436\u0434\u0435\u043D\u0438\u044F \u0443",
    moonMiddayEstimate: "\u043F\u043E\u044D\u0442\u043E\u043C\u0443 \u044D\u0442\u0430 \u041B\u0443\u043D\u0430 \u2014 \u043F\u043E\u043B\u0443\u0434\u0435\u043D\u043D\u0430\u044F \u043E\u0446\u0435\u043D\u043A\u0430: \u043E\u043D\u0430 \u043C\u043E\u0436\u0435\u0442 \u043E\u0442\u0441\u0442\u043E\u044F\u0442\u044C \u0434\u043E \u0448\u0435\u0441\u0442\u0438 \u0433\u0440\u0430\u0434\u0443\u0441\u043E\u0432, \u0438 \u043B\u0443\u043D\u043D\u044B\u0439 \u0430\u0441\u043F\u0435\u043A\u0442 \u0443 \u043A\u0440\u0430\u044F \u043E\u0440\u0431\u0438\u0441\u0430 \u043C\u043E\u0436\u0435\u0442 \u043F\u043E\u044F\u0432\u0438\u0442\u044C\u0441\u044F \u0438\u043B\u0438 \u0438\u0441\u0447\u0435\u0437\u043D\u0443\u0442\u044C \u0441 \u043D\u0430\u0441\u0442\u043E\u044F\u0449\u0438\u043C \u0432\u0440\u0435\u043C\u0435\u043D\u0435\u043C.",
    crossChartAspects: "\u043C\u0435\u0436\u043A\u0430\u0440\u0442\u043D\u044B\u0445 \u0430\u0441\u043F\u0435\u043A\u0442\u043E\u0432",
    easeful: "\u043B\u0451\u0433\u043A\u0438\u0435",
    charged: "\u043D\u0430\u043F\u0440\u044F\u0436\u0451\u043D\u043D\u044B\u0435",
    readPairing: "\u0427\u0438\u0442\u0430\u0442\u044C \u043F\u0430\u0440\u0443",
    inviteCompare: "\u041F\u0440\u0438\u0433\u043B\u0430\u0441\u0438\u0442\u044C \u043D\u0430 \u0441\u0440\u0430\u0432\u043D\u0435\u043D\u0438\u0435",
    inviteLink: "\u0421\u0441\u044B\u043B\u043A\u0430-\u043F\u0440\u0438\u0433\u043B\u0430\u0448\u0435\u043D\u0438\u0435",
    inviteNote: "\u0421\u0441\u044B\u043B\u043A\u0430 \u0441\u043E\u0434\u0435\u0440\u0436\u0438\u0442 \u0434\u0430\u043D\u043D\u044B\u0435 \u0440\u043E\u0436\u0434\u0435\u043D\u0438\u044F \u044D\u0442\u043E\u0433\u043E \u0447\u0435\u043B\u043E\u0432\u0435\u043A\u0430 \u0438 \u043E\u0442\u043A\u0440\u044B\u0432\u0430\u0435\u0442 \u0441\u0442\u0440\u0430\u043D\u0438\u0446\u0443 \u0441 \u0437\u0430\u043F\u043E\u043B\u043D\u0435\u043D\u043D\u043E\u0439 \u0441\u0442\u043E\u0440\u043E\u043D\u043E\u0439 \u2014 \u043D\u0430\u043C \u043D\u0438\u0447\u0435\u0433\u043E \u043D\u0435 \u043E\u0442\u043F\u0440\u0430\u0432\u043B\u044F\u0435\u0442\u0441\u044F. \u0415\u0441\u043B\u0438 \u044D\u0442\u043E \u043D\u0435 \u0432\u044B, \u0441\u0442\u043E\u0438\u0442 \u0441\u043F\u0440\u043E\u0441\u0438\u0442\u044C \u0435\u0433\u043E \u0441\u043E\u0433\u043B\u0430\u0441\u0438\u044F.",
    inviteCopied: "\u0421\u0441\u044B\u043B\u043A\u0430-\u043F\u0440\u0438\u0433\u043B\u0430\u0448\u0435\u043D\u0438\u0435 \u0441\u043A\u043E\u043F\u0438\u0440\u043E\u0432\u0430\u043D\u0430 \u0432 \u0431\u0443\u0444\u0435\u0440 \u043E\u0431\u043C\u0435\u043D\u0430.",
    syncOn: "\u0421\u0438\u043D\u0445\u0440\u043E\u043D\u0438\u0437\u0430\u0446\u0438\u044F \u0432\u043A\u043B\u044E\u0447\u0435\u043D\u0430",
    keepEveryDevice: "\u041A\u0430\u0440\u0442\u044B \u043D\u0430 \u0432\u0441\u0435\u0445 \u0443\u0441\u0442\u0440\u043E\u0439\u0441\u0442\u0432\u0430\u0445",
    signedIn: "\u0412\u0445\u043E\u0434 \u0432\u044B\u043F\u043E\u043B\u043D\u0435\u043D",
    syncCopyOn: "\u0421\u043E\u0445\u0440\u0430\u043D\u0451\u043D\u043D\u044B\u0435 \u043A\u0430\u0440\u0442\u044B \u0438 \u0443\u0434\u0430\u043B\u0435\u043D\u0438\u044F \u0441\u0438\u043D\u0445\u0440\u043E\u043D\u0438\u0437\u0438\u0440\u0443\u044E\u0442\u0441\u044F \u043C\u0435\u0436\u0434\u0443 \u0443\u0441\u0442\u0440\u043E\u0439\u0441\u0442\u0432\u0430\u043C\u0438.",
    syncCopyOff: "\u0421\u043E\u0445\u0440\u0430\u043D\u044F\u0439\u0442\u0435 \u043A\u0430\u0440\u0442\u044B \u043D\u0430 \u044D\u0442\u043E\u043C \u0443\u0441\u0442\u0440\u043E\u0439\u0441\u0442\u0432\u0435. \u0412\u043E\u0439\u0434\u0438\u0442\u0435, \u043A\u043E\u0433\u0434\u0430 \u0437\u0430\u0445\u043E\u0442\u0438\u0442\u0435 \u0432\u0438\u0434\u0435\u0442\u044C \u0438\u0445 \u0432\u0435\u0437\u0434\u0435.",
    weeklyDigestTitle: "\u0415\u0436\u0435\u043D\u0435\u0434\u0435\u043B\u044C\u043D\u043E\u0435 \u043F\u0438\u0441\u044C\u043C\u043E \u043E \u043D\u0435\u0431\u0435",
    weeklyDigestCopy: "\u041E\u0434\u043D\u043E \u043F\u0438\u0441\u044C\u043C\u043E \u0432 \u043D\u0435\u0434\u0435\u043B\u044E: \u043D\u0435\u0431\u043E \u043D\u0430 \u0444\u043E\u043D\u0435 \u0432\u0430\u0448\u0438\u0445 \u0441\u043E\u0445\u0440\u0430\u043D\u0451\u043D\u043D\u044B\u0445 \u043A\u0430\u0440\u0442. \u041E\u0442\u043F\u0438\u0441\u0430\u0442\u044C\u0441\u044F \u043C\u043E\u0436\u043D\u043E \u0432 \u043B\u044E\u0431\u043E\u0439 \u043C\u043E\u043C\u0435\u043D\u0442.",
    weeklyDigestAria: "\u041F\u043E\u0434\u043F\u0438\u0441\u043A\u0430 \u043D\u0430 \u0435\u0436\u0435\u043D\u0435\u0434\u0435\u043B\u044C\u043D\u044B\u0439 \u0434\u0430\u0439\u0434\u0436\u0435\u0441\u0442",
    digestSaved: "\u041D\u0430\u0441\u0442\u0440\u043E\u0439\u043A\u0430 \u0434\u0430\u0439\u0434\u0436\u0435\u0441\u0442\u0430 \u0441\u043E\u0445\u0440\u0430\u043D\u0435\u043D\u0430.",
    digestFailed: "\u041D\u0435 \u0443\u0434\u0430\u043B\u043E\u0441\u044C \u043E\u0431\u043D\u043E\u0432\u0438\u0442\u044C \u043D\u0430\u0441\u0442\u0440\u043E\u0439\u043A\u0443 \u0434\u0430\u0439\u0434\u0436\u0435\u0441\u0442\u0430. \u041F\u043E\u043F\u0440\u043E\u0431\u0443\u0439\u0442\u0435 \u0435\u0449\u0451 \u0440\u0430\u0437.",
    checkEmail: "\u041F\u0440\u043E\u0432\u0435\u0440\u044C\u0442\u0435 \u043F\u043E\u0447\u0442\u0443 \u2014 \u0442\u0430\u043C \u0441\u0441\u044B\u043B\u043A\u0430 \u0434\u043B\u044F \u0432\u0445\u043E\u0434\u0430. \u0421\u0442\u0440\u0430\u043D\u0438\u0446\u0430 \u0441\u0438\u043D\u0445\u0440\u043E\u043D\u0438\u0437\u0438\u0440\u0443\u0435\u0442\u0441\u044F \u043F\u043E\u0441\u043B\u0435 \u0432\u043E\u0437\u0432\u0440\u0430\u0449\u0435\u043D\u0438\u044F.",
    syncFailed: "\u0421\u0438\u043D\u0445\u0440\u043E\u043D\u0438\u0437\u0430\u0446\u0438\u044F \u043D\u0435 \u0443\u0434\u0430\u043B\u0430\u0441\u044C. \u041F\u043E\u043F\u0440\u043E\u0431\u0443\u0439\u0442\u0435 \u0435\u0449\u0451 \u0440\u0430\u0437.",
    syncing: "\u0421\u0438\u043D\u0445\u0440\u043E\u043D\u0438\u0437\u0438\u0440\u0443\u0435\u043C\u2026",
    synced: "\u0421\u0438\u043D\u0445\u0440\u043E\u043D\u0438\u0437\u0438\u0440\u043E\u0432\u0430\u043D\u043E",
    syncNow: "\u0421\u0438\u043D\u0445\u0440\u043E\u043D\u0438\u0437\u0438\u0440\u043E\u0432\u0430\u0442\u044C",
    signOut: "\u0412\u044B\u0439\u0442\u0438",
    emailSyncAria: "\u041F\u043E\u0447\u0442\u0430 \u0434\u043B\u044F \u0441\u0438\u043D\u0445\u0440\u043E\u043D\u0438\u0437\u0430\u0446\u0438\u0438 \u043F\u0440\u043E\u0444\u0438\u043B\u044F",
    sending: "\u041E\u0442\u043F\u0440\u0430\u0432\u043B\u044F\u0435\u043C\u2026",
    sendSignIn: "\u041E\u0442\u043F\u0440\u0430\u0432\u0438\u0442\u044C \u0441\u0441\u044B\u043B\u043A\u0443 \u0434\u043B\u044F \u0432\u0445\u043E\u0434\u0430",
    nothingSaved: "\u041F\u043E\u043A\u0430 \u043D\u0438\u0447\u0435\u0433\u043E \u043D\u0435 \u0441\u043E\u0445\u0440\u0430\u043D\u0435\u043D\u043E.",
    emptyProfile: "\u0421\u043E\u0445\u0440\u0430\u043D\u0451\u043D\u043D\u044B\u0435 \u043A\u0430\u0440\u0442\u044B \u0431\u0443\u0434\u0443\u0442 \u0436\u0438\u0442\u044C \u0437\u0434\u0435\u0441\u044C, \u0441\u043D\u0430\u0447\u0430\u043B\u0430 \u043D\u0430 \u0432\u0430\u0448\u0435\u043C \u0443\u0441\u0442\u0440\u043E\u0439\u0441\u0442\u0432\u0435. \u0420\u0430\u0441\u0441\u0447\u0438\u0442\u0430\u0439\u0442\u0435 \u043A\u0430\u0440\u0442\u0443 \u0438 \u043D\u0430\u0436\u043C\u0438\u0442\u0435 \xAB\u0421\u043E\u0445\u0440\u0430\u043D\u0438\u0442\u044C \u044D\u0442\u0443 \u043A\u0430\u0440\u0442\u0443\xBB.",
    saved: "\u0441\u043E\u0445\u0440\u0430\u043D\u0435\u043D\u043E",
    chartSingular: "\u043A\u0430\u0440\u0442\u0430",
    chartPlural: "\u043A\u0430\u0440\u0442\u044B",
    savedChartSingular: "\u0441\u043E\u0445\u0440\u0430\u043D\u0451\u043D\u043D\u0430\u044F \u043A\u0430\u0440\u0442\u0430",
    savedChartPlural: "\u0441\u043E\u0445\u0440\u0430\u043D\u0451\u043D\u043D\u044B\u0435 \u043A\u0430\u0440\u0442\u044B",
    syncedWhenSignedIn: "\u0441\u0438\u043D\u0445\u0440\u043E\u043D\u0438\u0437\u0438\u0440\u0443\u044E\u0442\u0441\u044F \u043F\u043E\u0441\u043B\u0435 \u0432\u0445\u043E\u0434\u0430",
    storedBrowser: "\u0445\u0440\u0430\u043D\u044F\u0442\u0441\u044F \u0432 \u044D\u0442\u043E\u043C \u0431\u0440\u0430\u0443\u0437\u0435\u0440\u0435",
    chartName: "\u041D\u0430\u0437\u0432\u0430\u043D\u0438\u0435 \u043A\u0430\u0440\u0442\u044B",
    timeUnknown: "\u0432\u0440\u0435\u043C\u044F \u043D\u0435\u0438\u0437\u0432\u0435\u0441\u0442\u043D\u043E",
    needsTime: "\u043D\u0443\u0436\u043D\u043E \u0432\u0440\u0435\u043C\u044F",
    compareThese: "\u0421\u0440\u0430\u0432\u043D\u0438\u0442\u044C \u044D\u0442\u0438 \u0434\u0432\u0435 \u043A\u0430\u0440\u0442\u044B",
    addAnotherChart: "\u0414\u043E\u0431\u0430\u0432\u0438\u0442\u044C \u0435\u0449\u0451 \u043A\u0430\u0440\u0442\u0443",
    footerWidgets: "\u0412\u0438\u0434\u0436\u0435\u0442\u044B",
    footerDisclosure: "\u0420\u0430\u0441\u043A\u0440\u044B\u0442\u0438\u0435 \u0438\u043D\u0444\u043E\u0440\u043C\u0430\u0446\u0438\u0438",
    emailCaptureKicker: "\u0411\u0435\u0441\u043F\u043B\u0430\u0442\u043D\u044B\u0439 \u0435\u0436\u0435\u043D\u0435\u0434\u0435\u043B\u044C\u043D\u044B\u0439 \u043F\u0440\u043E\u0433\u043D\u043E\u0437",
    emailCaptureTitle: "\u0412\u0430\u0448\u0430 \u043D\u0435\u0434\u0435\u043B\u044F \u0432\u043F\u0435\u0440\u0435\u0434\u0438.",
    emailCapturePersonalTitle: "\u0412\u0430\u0448\u0430 \u043D\u0435\u0434\u0435\u043B\u044F {sign} \u0432\u043F\u0435\u0440\u0435\u0434\u0438.",
    emailCaptureCopy: "\u0415\u0436\u0435\u043D\u0435\u0434\u0435\u043B\u044C\u043D\u044B\u0439 \u043F\u0440\u043E\u0433\u043D\u043E\u0437 \u0434\u043B\u044F \u0432\u0430\u0448\u0435\u0433\u043E \u0437\u043D\u0430\u043A\u0430. \u0411\u0435\u0441\u043F\u043B\u0430\u0442\u043D\u043E, \u043E\u0442\u043F\u0438\u0441\u043A\u0430 \u0432 \u043B\u044E\u0431\u043E\u0439 \u043C\u043E\u043C\u0435\u043D\u0442.",
    emailCaptureEmailLabel: "\u0410\u0434\u0440\u0435\u0441 \u043F\u043E\u0447\u0442\u044B",
    emailCaptureEmailPlaceholder: "you@example.com",
    emailCaptureSignLegend: "\u0412\u0430\u0448 \u0441\u043E\u043B\u043D\u0435\u0447\u043D\u044B\u0439 \u0437\u043D\u0430\u043A (\u043D\u0435\u043E\u0431\u044F\u0437\u0430\u0442\u0435\u043B\u044C\u043D\u043E)",
    emailCaptureNoSign: "\u0411\u0435\u0437 \u0437\u043D\u0430\u043A\u0430",
    emailCaptureUsingSign: "\u0412\u0430\u0448 \u0441\u043E\u043B\u043D\u0435\u0447\u043D\u044B\u0439 \u0437\u043D\u0430\u043A: {sign}",
    emailCaptureChangeSign: "\u0418\u0437\u043C\u0435\u043D\u0438\u0442\u044C",
    emailCaptureSubmit: "\u041F\u0440\u0438\u0441\u043B\u0430\u0442\u044C \u043C\u043E\u044E \u043D\u0435\u0434\u0435\u043B\u044E",
    emailCaptureSubmitting: "\u041F\u043E\u0434\u043A\u043B\u044E\u0447\u0430\u0435\u043C\u2026",
    emailCaptureSuccess: "\u041F\u0440\u043E\u0432\u0435\u0440\u044C\u0442\u0435 \u043F\u043E\u0447\u0442\u0443, \u0447\u0442\u043E\u0431\u044B \u043F\u043E\u0434\u0442\u0432\u0435\u0440\u0434\u0438\u0442\u044C \u043F\u043E\u0434\u043F\u0438\u0441\u043A\u0443.",
    emailCaptureErrorTitle: "\u041F\u043E\u0434\u043F\u0438\u0441\u043A\u0430 \u043D\u0435\u0434\u043E\u0441\u0442\u0443\u043F\u043D\u0430",
    emailCaptureError: "\u041D\u0435 \u0443\u0434\u0430\u043B\u043E\u0441\u044C \u043E\u0444\u043E\u0440\u043C\u0438\u0442\u044C \u043F\u043E\u0434\u043F\u0438\u0441\u043A\u0443. \u041F\u043E\u043F\u0440\u043E\u0431\u0443\u0439\u0442\u0435 \u0435\u0449\u0451 \u0440\u0430\u0437.",
    emailCapturePrivacy: "\u041C\u044B \u0445\u0440\u0430\u043D\u0438\u043C \u0432\u0430\u0448\u0443 \u043F\u043E\u0447\u0442\u0443 \u0442\u043E\u043B\u044C\u043A\u043E \u0441 \u0432\u044B\u0431\u0440\u0430\u043D\u043D\u044B\u043C \u0437\u043D\u0430\u043A\u043E\u043C \u2014 \u0438 \u043D\u0438\u043A\u043E\u0433\u0434\u0430 \u0434\u0430\u043D\u043D\u044B\u0435 \u0440\u043E\u0436\u0434\u0435\u043D\u0438\u044F.",
    emailCaptureHoneypot: "\u041E\u0441\u0442\u0430\u0432\u044C\u0442\u0435 \u044D\u0442\u043E \u043F\u043E\u043B\u0435 \u043F\u0443\u0441\u0442\u044B\u043C",
    emailPendingTitle: "\u041F\u0440\u043E\u0432\u0435\u0440\u044C\u0442\u0435 \u043F\u043E\u0447\u0442\u0443.",
    emailPendingBody: "\u041F\u0435\u0440\u0435\u0439\u0434\u0438\u0442\u0435 \u043F\u043E \u0441\u0441\u044B\u043B\u043A\u0435 \u043F\u043E\u0434\u0442\u0432\u0435\u0440\u0436\u0434\u0435\u043D\u0438\u044F \u0438\u0437 \u043F\u0438\u0441\u044C\u043C\u0430 \u2014 \u043F\u043E\u0434\u043F\u0438\u0441\u043A\u0430 \u043D\u0430\u0447\u043D\u0451\u0442\u0441\u044F \u043F\u043E\u0441\u043B\u0435 \u044D\u0442\u043E\u0433\u043E.",
    emailConfirmSubject: "\u041F\u043E\u0434\u0442\u0432\u0435\u0440\u0434\u0438\u0442\u0435 \u043F\u043E\u0434\u043F\u0438\u0441\u043A\u0443 \u043D\u0430 Zodiacs.org",
    emailConfirmMessage: "\u041F\u043E\u0434\u0442\u0432\u0435\u0440\u0434\u0438\u0442\u0435, \u0447\u0442\u043E \u0445\u043E\u0442\u0438\u0442\u0435 \u043F\u043E\u043B\u0443\u0447\u0430\u0442\u044C \u043F\u0438\u0441\u044C\u043C\u0430 Zodiacs.org:",
    emailConfirmIgnore: "\u0421\u0441\u044B\u043B\u043A\u0430 \u0434\u0435\u0439\u0441\u0442\u0432\u0443\u0435\u0442 48 \u0447\u0430\u0441\u043E\u0432. \u0415\u0441\u043B\u0438 \u0432\u044B \u043D\u0438\u0447\u0435\u0433\u043E \u043D\u0435 \u0437\u0430\u043F\u0440\u0430\u0448\u0438\u0432\u0430\u043B\u0438, \u043F\u0440\u043E\u0441\u0442\u043E \u043F\u0440\u043E\u0438\u0433\u043D\u043E\u0440\u0438\u0440\u0443\u0439\u0442\u0435 \u043F\u0438\u0441\u044C\u043C\u043E \u2014 \u043D\u0438\u0447\u0435\u0433\u043E \u043F\u043E\u0434\u043F\u0438\u0441\u0430\u043D\u043E \u043D\u0435 \u0431\u0443\u0434\u0435\u0442.",
    emailConfirmTitle: "\u041F\u043E\u0441\u043B\u0435\u0434\u043D\u044F\u044F \u043F\u0440\u043E\u0432\u0435\u0440\u043A\u0430.",
    emailConfirmBody: "\u041F\u043E\u0434\u0442\u0432\u0435\u0440\u0434\u0438\u0442\u0435 \u043F\u043E\u0434\u043F\u0438\u0441\u043A\u0443, \u0447\u0442\u043E\u0431\u044B \u043E\u043D\u0430 \u043D\u0430\u0447\u0430\u043B\u0430\u0441\u044C. \u0414\u043E \u044D\u0442\u043E\u0433\u043E \u043D\u0438\u0447\u0435\u0433\u043E \u043D\u0435 \u0430\u043A\u0442\u0438\u0432\u043D\u043E.",
    emailConfirmAction: "\u041F\u043E\u0434\u0442\u0432\u0435\u0440\u0434\u0438\u0442\u044C \u043F\u043E\u0434\u043F\u0438\u0441\u043A\u0443",
    emailConfirmedTitle: "\u041F\u043E\u0434\u043F\u0438\u0441\u043A\u0430 \u043F\u043E\u0434\u0442\u0432\u0435\u0440\u0436\u0434\u0435\u043D\u0430.",
    emailConfirmedBody: "\u041A\u0430\u0436\u0434\u043E\u0435 \u043F\u0438\u0441\u044C\u043C\u043E \u0441\u043E\u0434\u0435\u0440\u0436\u0438\u0442 \u0441\u0441\u044B\u043B\u043A\u0443 \u0434\u043B\u044F \u043E\u0442\u043F\u0438\u0441\u043A\u0438.",
    emailConfirmInvalidTitle: "\u0421\u0441\u044B\u043B\u043A\u0430 \u043D\u0435\u0434\u0435\u0439\u0441\u0442\u0432\u0438\u0442\u0435\u043B\u044C\u043D\u0430.",
    emailConfirmInvalidBody: "\u041E\u043D\u0430 \u043C\u043E\u0433\u043B\u0430 \u0438\u0441\u0442\u0435\u0447\u044C \u2014 \u0441\u0441\u044B\u043B\u043A\u0438 \u0434\u0435\u0439\u0441\u0442\u0432\u0443\u044E\u0442 48 \u0447\u0430\u0441\u043E\u0432 \u2014 \u0438\u043B\u0438 \u0443\u0436\u0435 \u0431\u044B\u0442\u044C \u0438\u0441\u043F\u043E\u043B\u044C\u0437\u043E\u0432\u0430\u043D\u043D\u043E\u0439. \u0417\u0430\u043F\u0440\u043E\u0441\u0438\u0442\u0435 \u043D\u043E\u0432\u0443\u044E \u0432 \u043B\u044E\u0431\u043E\u0439 \u0444\u043E\u0440\u043C\u0435 \u043F\u043E\u0434\u043F\u0438\u0441\u043A\u0438 \u043D\u0430 \u0441\u0430\u0439\u0442\u0435.",
    emailReturnHome: "\u0412\u0435\u0440\u043D\u0443\u0442\u044C\u0441\u044F \u043D\u0430 Zodiacs.org"
  };
  var ru_default = ru;

  // src/lib/i18n/ru-runtime/server.ts
  var RUSSIAN_RUNTIME = {
    signs: {
      names: {
        aries: "\u041E\u0432\u0435\u043D",
        taurus: "\u0422\u0435\u043B\u0435\u0446",
        gemini: "\u0411\u043B\u0438\u0437\u043D\u0435\u0446\u044B",
        cancer: "\u0420\u0430\u043A",
        leo: "\u041B\u0435\u0432",
        virgo: "\u0414\u0435\u0432\u0430",
        libra: "\u0412\u0435\u0441\u044B",
        scorpio: "\u0421\u043A\u043E\u0440\u043F\u0438\u043E\u043D",
        sagittarius: "\u0421\u0442\u0440\u0435\u043B\u0435\u0446",
        capricorn: "\u041A\u043E\u0437\u0435\u0440\u043E\u0433",
        aquarius: "\u0412\u043E\u0434\u043E\u043B\u0435\u0439",
        pisces: "\u0420\u044B\u0431\u044B"
      },
      dates: {
        aries: "21 \u043C\u0430\u0440 \u2013 19 \u0430\u043F\u0440",
        taurus: "20 \u0430\u043F\u0440 \u2013 20 \u043C\u0430\u044F",
        gemini: "21 \u043C\u0430\u044F \u2013 20 \u0438\u044E\u043D",
        cancer: "21 \u0438\u044E\u043D \u2013 22 \u0438\u044E\u043B",
        leo: "23 \u0438\u044E\u043B \u2013 22 \u0430\u0432\u0433",
        virgo: "23 \u0430\u0432\u0433 \u2013 22 \u0441\u0435\u043D",
        libra: "23 \u0441\u0435\u043D \u2013 22 \u043E\u043A\u0442",
        scorpio: "23 \u043E\u043A\u0442 \u2013 21 \u043D\u043E\u044F",
        sagittarius: "22 \u043D\u043E\u044F \u2013 21 \u0434\u0435\u043A",
        capricorn: "22 \u0434\u0435\u043A \u2013 19 \u044F\u043D\u0432",
        aquarius: "20 \u044F\u043D\u0432 \u2013 18 \u0444\u0435\u0432",
        pisces: "19 \u0444\u0435\u0432 \u2013 20 \u043C\u0430\u0440"
      },
      essences: {
        aries: "\u041F\u0435\u0440\u0432\u044B\u0439 \u0441\u043E \u0441\u0442\u0430\u0440\u0442\u0430 \u2014 \u043F\u0440\u044F\u043C\u043E\u0439, \u0431\u044B\u0441\u0442\u0440\u044B\u0439, \u043D\u0435 \u0431\u043E\u0438\u0442\u0441\u044F \u043D\u0430\u0447\u0438\u043D\u0430\u0442\u044C.",
        taurus: "\u0422\u0432\u0451\u0440\u0434\u044B\u0435 \u0440\u0443\u043A\u0438, \u0445\u043E\u0440\u043E\u0448\u0438\u0439 \u0432\u043A\u0443\u0441 \u0438 \u0434\u043E\u043B\u0433\u0430\u044F \u043F\u0430\u043C\u044F\u0442\u044C \u043D\u0430 \u0443\u044E\u0442.",
        gemini: "\u0411\u044B\u0441\u0442\u0440\u044B\u0435, \u043B\u044E\u0431\u043E\u043F\u044B\u0442\u043D\u044B\u0435, \u0441\u043E\u0437\u0434\u0430\u043D\u044B \u0434\u043B\u044F \u0440\u0430\u0437\u0433\u043E\u0432\u043E\u0440\u0430.",
        cancer: "\u0421\u043D\u0430\u0447\u0430\u043B\u0430 \u0447\u0443\u0432\u0441\u0442\u0432\u0443\u0435\u0442, \u0432\u0441\u0451 \u043F\u043E\u043C\u043D\u0438\u0442, \u0431\u0435\u0440\u0435\u0436\u0451\u0442 \u0442\u043E, \u0447\u0442\u043E \u043B\u044E\u0431\u0438\u0442.",
        leo: "\u0422\u0451\u043F\u043B\u043E\u0435 \u0441\u0435\u0440\u0434\u0446\u0435, \u0432\u044B\u0440\u0430\u0437\u0438\u0442\u0435\u043B\u044C\u043D\u043E\u0441\u0442\u044C, \u0440\u043E\u0436\u0434\u0451\u043D \u0434\u043B\u044F \u0441\u0432\u0435\u0442\u0430.",
        virgo: "\u0422\u043E\u0447\u043D\u0430\u044F, \u043F\u043E\u043B\u0435\u0437\u043D\u0430\u044F, \u0442\u0438\u0445\u043E \u0432\u0435\u0434\u0451\u0442 \u0432\u0441\u0451 \u0445\u043E\u0437\u044F\u0439\u0441\u0442\u0432\u043E.",
        libra: "\u0412\u0437\u0432\u0435\u0448\u0438\u0432\u0430\u044E\u0442 \u0432\u0441\u0451 \u2014 \u0440\u0430\u0434\u0438 \u043A\u0440\u0430\u0441\u043E\u0442\u044B \u0438 \u0440\u0430\u0434\u0438 \u0441\u043F\u0440\u0430\u0432\u0435\u0434\u043B\u0438\u0432\u043E\u0441\u0442\u0438.",
        scorpio: "\u0413\u043B\u0443\u0431\u0438\u043D\u0430, \u0432\u044B\u0434\u0435\u0440\u0436\u043A\u0430 \u0438 \u0432\u0437\u0433\u043B\u044F\u0434, \u043A\u043E\u0442\u043E\u0440\u044B\u0439 \u043D\u0435 \u043E\u0442\u0432\u0435\u0441\u0442\u0438.",
        sagittarius: "\u0414\u0430\u043B\u044C\u043D\u044F\u044F \u0434\u043E\u0440\u043E\u0433\u0430, \u0448\u0438\u0440\u043E\u043A\u0430\u044F \u043C\u044B\u0441\u043B\u044C, \u0447\u0435\u0441\u0442\u043D\u044B\u0439 \u0441\u043C\u0435\u0445.",
        capricorn: "\u0414\u043E\u043B\u0433\u0438\u0439 \u043F\u043E\u0434\u044A\u0451\u043C, \u0441\u0443\u0445\u043E\u0439 \u044E\u043C\u043E\u0440, \u0440\u0435\u0437\u0443\u043B\u044C\u0442\u0430\u0442 \u043F\u043E \u0440\u0430\u0441\u043F\u0438\u0441\u0430\u043D\u0438\u044E.",
        aquarius: "\u0421\u0432\u043E\u0439 \u0443\u0433\u043E\u043B \u0437\u0440\u0435\u043D\u0438\u044F \u2014 \u0438 \u0434\u0432\u0435\u0440\u044C, \u043E\u0442\u043A\u0440\u044B\u0442\u0430\u044F \u0431\u0443\u0434\u0443\u0449\u0435\u043C\u0443.",
        pisces: "\u041C\u044F\u0433\u043A\u0430\u044F \u043D\u0430\u0441\u0442\u0440\u043E\u0439\u043A\u0430 \u043D\u0430 \u0432\u0441\u0435\u0445, \u043C\u043E\u0440\u0435 \u0432\u043D\u0443\u0442\u0440\u0438."
      },
      prepositional: {
        aries: "\u041E\u0432\u043D\u0435",
        taurus: "\u0422\u0435\u043B\u044C\u0446\u0435",
        gemini: "\u0411\u043B\u0438\u0437\u043D\u0435\u0446\u0430\u0445",
        cancer: "\u0420\u0430\u043A\u0435",
        leo: "\u041B\u044C\u0432\u0435",
        virgo: "\u0414\u0435\u0432\u0435",
        libra: "\u0412\u0435\u0441\u0430\u0445",
        scorpio: "\u0421\u043A\u043E\u0440\u043F\u0438\u043E\u043D\u0435",
        sagittarius: "\u0421\u0442\u0440\u0435\u043B\u044C\u0446\u0435",
        capricorn: "\u041A\u043E\u0437\u0435\u0440\u043E\u0433\u0435",
        aquarius: "\u0412\u043E\u0434\u043E\u043B\u0435\u0435",
        pisces: "\u0420\u044B\u0431\u0430\u0445"
      },
      elements: { fire: "\u043E\u0433\u043E\u043D\u044C", earth: "\u0437\u0435\u043C\u043B\u044F", air: "\u0432\u043E\u0437\u0434\u0443\u0445", water: "\u0432\u043E\u0434\u0430" },
      modalities: { cardinal: "\u043A\u0430\u0440\u0434\u0438\u043D\u0430\u043B\u044C\u043D\u044B\u0439", fixed: "\u0444\u0438\u043A\u0441\u0438\u0440\u043E\u0432\u0430\u043D\u043D\u044B\u0439", mutable: "\u043C\u0443\u0442\u0430\u0431\u0435\u043B\u044C\u043D\u044B\u0439" }
    },
    astrology: {
      planets: {
        Sun: "\u0421\u043E\u043B\u043D\u0446\u0435",
        Moon: "\u041B\u0443\u043D\u0430",
        Mercury: "\u041C\u0435\u0440\u043A\u0443\u0440\u0438\u0439",
        Venus: "\u0412\u0435\u043D\u0435\u0440\u0430",
        Mars: "\u041C\u0430\u0440\u0441",
        Jupiter: "\u042E\u043F\u0438\u0442\u0435\u0440",
        Saturn: "\u0421\u0430\u0442\u0443\u0440\u043D",
        Uranus: "\u0423\u0440\u0430\u043D",
        Neptune: "\u041D\u0435\u043F\u0442\u0443\u043D",
        Pluto: "\u041F\u043B\u0443\u0442\u043E\u043D",
        "North Node": "\u0421\u0435\u0432\u0435\u0440\u043D\u044B\u0439 \u0443\u0437\u0435\u043B",
        "South Node": "\u042E\u0436\u043D\u044B\u0439 \u0443\u0437\u0435\u043B"
      },
      aspects: {
        conjunction: "\u0441\u043E\u0435\u0434\u0438\u043D\u0435\u043D\u0438\u0435",
        sextile: "\u0441\u0435\u043A\u0441\u0442\u0438\u043B\u044C",
        square: "\u043A\u0432\u0430\u0434\u0440\u0430\u0442\u0443\u0440\u0430",
        trine: "\u0442\u0440\u0438\u043D",
        opposition: "\u043E\u043F\u043F\u043E\u0437\u0438\u0446\u0438\u044F"
      },
      moonPhases: {
        "New Moon": "\u041D\u043E\u0432\u043E\u043B\u0443\u043D\u0438\u0435",
        "Waxing Crescent": "\u0420\u0430\u0441\u0442\u0443\u0449\u0438\u0439 \u0441\u0435\u0440\u043F",
        "First Quarter": "\u041F\u0435\u0440\u0432\u0430\u044F \u0447\u0435\u0442\u0432\u0435\u0440\u0442\u044C",
        "Waxing Gibbous": "\u0420\u0430\u0441\u0442\u0443\u0449\u0430\u044F \u041B\u0443\u043D\u0430",
        "Full Moon": "\u041F\u043E\u043B\u043D\u043E\u043B\u0443\u043D\u0438\u0435",
        "Waning Gibbous": "\u0423\u0431\u044B\u0432\u0430\u044E\u0449\u0430\u044F \u041B\u0443\u043D\u0430",
        "Last Quarter": "\u041F\u043E\u0441\u043B\u0435\u0434\u043D\u044F\u044F \u0447\u0435\u0442\u0432\u0435\u0440\u0442\u044C",
        "Waning Crescent": "\u0423\u0431\u044B\u0432\u0430\u044E\u0449\u0438\u0439 \u0441\u0435\u0440\u043F"
      }
    },
    chart: {
      lens: {
        rail: "\u041A\u0430\u0440\u0442\u0430 \u0432\u043E \u0432\u0440\u0435\u043C\u0435\u043D\u0438",
        natal: "\u041D\u0430\u0442\u0430\u043B\u044C\u043D\u0430\u044F",
        sky: "\u041D\u0435\u0431\u043E \u0441\u0435\u0439\u0447\u0430\u0441",
        progressed: "\u041F\u0440\u043E\u0433\u0440\u0435\u0441\u0441\u0438\u0438",
        return: "\u0421\u043E\u043B\u043D\u0435\u0447\u043D\u043E\u0435 \u0432\u043E\u0437\u0432\u0440\u0430\u0449\u0435\u043D\u0438\u0435"
      },
      detail: { lead: "\u0422\u043E\u0447\u043D\u044B\u0435 \u0434\u0430\u043D\u043D\u044B\u0435 \u043A\u0430\u0440\u0442\u044B \u2014 ", placements: " \u043F\u043E\u043B\u043E\u0436\u0435\u043D\u0438\u0439 \xB7 ", aspects: " \u0430\u0441\u043F\u0435\u043A\u0442\u043E\u0432" },
      wheelActions: {
        actions: "\u0414\u0435\u0439\u0441\u0442\u0432\u0438\u044F \u0441 \u043A\u0430\u0440\u0442\u043E\u0439",
        guide: "\u041F\u0440\u043E\u0439\u0442\u0438 \u044D\u043A\u0441\u043A\u0443\u0440\u0441\u0438\u044E",
        replay: "\u041F\u043E\u0432\u0442\u043E\u0440\u0438\u0442\u044C \u044D\u043A\u0441\u043A\u0443\u0440\u0441\u0438\u044E",
        another: "\u041F\u0440\u043E\u0447\u0438\u0442\u0430\u0442\u044C \u0434\u0440\u0443\u0433\u0443\u044E \u043A\u0430\u0440\u0442\u0443 \u2014 \u043F\u043E\u043A\u0430 \u043F\u043E-\u0430\u043D\u0433\u043B\u0438\u0439\u0441\u043A\u0438",
        signatureSelf: "\u0425\u0430\u0440\u0430\u043A\u0442\u0435\u0440\u043D\u044B\u0439 \u0440\u0438\u0441\u0443\u043D\u043E\u043A \u0432\u0430\u0448\u0435\u0439 \u043A\u0430\u0440\u0442\u044B",
        signatureOther: "\u0425\u0430\u0440\u0430\u043A\u0442\u0435\u0440\u043D\u044B\u0439 \u0440\u0438\u0441\u0443\u043D\u043E\u043A \u044D\u0442\u043E\u0439 \u043A\u0430\u0440\u0442\u044B",
        compareMine: "\u0421\u0440\u0430\u0432\u043D\u0438\u0442\u044C \u0441 \u043C\u043E\u0435\u0439 \u2014 \u043F\u043E\u043A\u0430 \u043F\u043E-\u0430\u043D\u0433\u043B\u0438\u0439\u0441\u043A\u0438",
        compareAdd: "\u0414\u043E\u0431\u0430\u0432\u0438\u0442\u044C \u043C\u043E\u044E \u043A\u0430\u0440\u0442\u0443 \u0434\u043B\u044F \u0441\u0440\u0430\u0432\u043D\u0435\u043D\u0438\u044F \u2014 \u043F\u043E\u043A\u0430 \u043F\u043E-\u0430\u043D\u0433\u043B\u0438\u0439\u0441\u043A\u0438",
        shareOther: "\u041F\u043E\u0434\u0435\u043B\u0438\u0442\u044C\u0441\u044F \u044D\u0442\u043E\u0439 \u043A\u0430\u0440\u0442\u043E\u0439",
        spotlight: "\u0412\u044B\u0434\u0435\u043B\u0435\u043D\u043E \u043D\u0430 \u044D\u0442\u043E\u0439 \u043A\u0430\u0440\u0442\u0435"
      },
      chartBook: { label: "\u0427\u044C\u044F \u044D\u0442\u043E \u043A\u0430\u0440\u0442\u0430?", save: "\u0421\u043E\u0445\u0440\u0430\u043D\u0438\u0442\u044C", skip: "\u041F\u0440\u043E\u043F\u0443\u0441\u0442\u0438\u0442\u044C" },
      registryAura: {
        discover: "\u0421\u043E\u0445\u0440\u0430\u043D\u0451\u043D\u043D\u0443\u044E \u043A\u0430\u0440\u0442\u0443 \u043C\u043E\u0436\u043D\u043E \u0441\u043E\u043F\u043E\u0441\u0442\u0430\u0432\u0438\u0442\u044C \u0441 \u0437\u0430\u043F\u0438\u0441\u044F\u043C\u0438 \u0420\u0435\u0435\u0441\u0442\u0440\u0430 \u043F\u043E \u043F\u0443\u0431\u043B\u0438\u0447\u043D\u043E\u043C\u0443 \u0430\u0434\u0440\u0435\u0441\u0443.",
        discoverLink: "\u041E\u0442\u043A\u0440\u044B\u0442\u044C \u043A\u0430\u0440\u0442\u0443 \u0440\u044F\u0434\u043E\u043C \u0441 \u043F\u0443\u0431\u043B\u0438\u0447\u043D\u044B\u043C \u0430\u0434\u0440\u0435\u0441\u043E\u043C \u2014 \u043F\u043E\u043A\u0430 \u043F\u043E-\u0430\u043D\u0433\u043B\u0438\u0439\u0441\u043A\u0438 \u2192",
        return: "\u041A\u0430\u0440\u0442\u0430 \u0441\u043E\u0445\u0440\u0430\u043D\u0435\u043D\u0430.",
        returnLink: "\u0412\u0435\u0440\u043D\u0443\u0442\u044C\u0441\u044F \u0432 Registry Collection \u2014 \u043F\u043E\u043A\u0430 \u043F\u043E-\u0430\u043D\u0433\u043B\u0438\u0439\u0441\u043A\u0438 \u2192"
      },
      personChartTemplate: "\u041A\u0430\u0440\u0442\u0430 {name}: \u043D\u0438\u0436\u0435 \xAB\u0432\u044B\xBB \u043E\u0437\u043D\u0430\u0447\u0430\u0435\u0442 {name}.",
      otherSubject: {
        unnamed: "\u0412\u044B \u0447\u0438\u0442\u0430\u0435\u0442\u0435 \u043A\u0430\u0440\u0442\u0443 \u0434\u0440\u0443\u0433\u043E\u0433\u043E \u0447\u0435\u043B\u043E\u0432\u0435\u043A\u0430. \u041D\u0438\u0436\u0435 \xAB\u0432\u044B\xBB \u043E\u0437\u043D\u0430\u0447\u0430\u0435\u0442 \u0447\u0435\u043B\u043E\u0432\u0435\u043A\u0430, \u0447\u044C\u0438 \u0434\u0430\u043D\u043D\u044B\u0435 \u0440\u043E\u0436\u0434\u0435\u043D\u0438\u044F \u0432\u044B \u0432\u0432\u0435\u043B\u0438.",
        namedTemplate: "\u0412\u044B \u0447\u0438\u0442\u0430\u0435\u0442\u0435 \u043A\u0430\u0440\u0442\u0443 {name}. \u041D\u0438\u0436\u0435 \xAB\u0432\u044B\xBB \u043E\u0437\u043D\u0430\u0447\u0430\u0435\u0442 {name}.",
        headingTemplate: "\u041D\u0430\u0442\u0430\u043B\u044C\u043D\u0430\u044F \u043A\u0430\u0440\u0442\u0430: {name}",
        headingUnnamed: "\u041D\u0430\u0442\u0430\u043B\u044C\u043D\u0430\u044F \u043A\u0430\u0440\u0442\u0430 \u0434\u0440\u0443\u0433\u043E\u0433\u043E \u0447\u0435\u043B\u043E\u0432\u0435\u043A\u0430",
        submit: "\u041E\u0431\u043D\u043E\u0432\u0438\u0442\u044C \u044D\u0442\u0443 \u043A\u0430\u0440\u0442\u0443",
        privacy: "\u041F\u0440\u0438\u0432\u0430\u0442\u043D\u043E \u043F\u043E \u0443\u043C\u043E\u043B\u0447\u0430\u043D\u0438\u044E. \u0414\u0430\u043D\u043D\u044B\u0435 \u0440\u043E\u0436\u0434\u0435\u043D\u0438\u044F \u044D\u0442\u043E\u0433\u043E \u0447\u0435\u043B\u043E\u0432\u0435\u043A\u0430 \u043E\u0441\u0442\u0430\u044E\u0442\u0441\u044F \u0432 \u0431\u0440\u0430\u0443\u0437\u0435\u0440\u0435."
      },
      autoNameSun: "\u0421\u043E\u043B\u043D\u0446\u0435",
      sharedBirthplace: "\u041E\u0431\u0449\u0435\u0435 \u043C\u0435\u0441\u0442\u043E \u0440\u043E\u0436\u0434\u0435\u043D\u0438\u044F",
      englishOnlyTitle: "\u041C\u0430\u0442\u0435\u0440\u0438\u0430\u043B \u043F\u043E\u043A\u0430 \u0434\u043E\u0441\u0442\u0443\u043F\u0435\u043D \u043F\u043E-\u0430\u043D\u0433\u043B\u0438\u0439\u0441\u043A\u0438",
      englishOnlySuffix: " \u2014 \u043F\u043E\u043A\u0430 \u043F\u043E-\u0430\u043D\u0433\u043B\u0438\u0439\u0441\u043A\u0438"
    },
    plurals: RUSSIAN_UI_PLURALS
  };
  function serverRussianRuntime() {
    return RUSSIAN_RUNTIME;
  }

  // src/lib/i18n/ru-runtime/index.ts
  function russianRuntime() {
    return define_import_meta_env_default.SSR ? serverRussianRuntime() : clientRussianRuntime();
  }

  // src/lib/signs.ts
  var SIGNS = [
    { slug: "aries", name: "Aries", glyph: "\u2648", dates: "Mar 21 \u2013 Apr 19", start: [3, 21], end: [4, 19], element: "fire", modality: "cardinal", ruler: "Mars", polarity: "day", house: 1, hue: "#DE8E79", essence: "First out of the gate \u2014 direct, fast, unafraid to start." },
    { slug: "taurus", name: "Taurus", glyph: "\u2649", dates: "Apr 20 \u2013 May 20", start: [4, 20], end: [5, 20], element: "earth", modality: "fixed", ruler: "Venus", polarity: "night", house: 2, hue: "#B9D4BE", essence: "Steady hands, good taste, and a long memory for comfort." },
    { slug: "gemini", name: "Gemini", glyph: "\u264A", dates: "May 21 \u2013 Jun 20", start: [5, 21], end: [6, 20], element: "air", modality: "mutable", ruler: "Mercury", polarity: "day", house: 3, hue: "#B29DD0", essence: "Quick, curious, wired for conversation." },
    { slug: "cancer", name: "Cancer", glyph: "\u264B", dates: "Jun 21 \u2013 Jul 22", start: [6, 21], end: [7, 22], element: "water", modality: "cardinal", ruler: "Moon", polarity: "night", house: 4, hue: "#B6D4E4", essence: "Feels first, remembers everything, protects what it loves." },
    { slug: "leo", name: "Leo", glyph: "\u264C", dates: "Jul 23 \u2013 Aug 22", start: [7, 23], end: [8, 22], element: "fire", modality: "fixed", ruler: "Sun", polarity: "day", house: 5, hue: "#E0A9B4", essence: "Warm-hearted, expressive, born for the spotlight." },
    { slug: "virgo", name: "Virgo", glyph: "\u264D", dates: "Aug 23 \u2013 Sep 22", start: [8, 23], end: [9, 22], element: "earth", modality: "mutable", ruler: "Mercury", polarity: "night", house: 6, hue: "#B7D9B0", essence: "Precise, useful, quietly running the whole operation." },
    { slug: "libra", name: "Libra", glyph: "\u264E", dates: "Sep 23 \u2013 Oct 22", start: [9, 23], end: [10, 22], element: "air", modality: "cardinal", ruler: "Venus", polarity: "day", house: 7, hue: "#D3A9DE", essence: "Balance-seeking, charming, allergic to unfairness." },
    { slug: "scorpio", name: "Scorpio", glyph: "\u264F", dates: "Oct 23 \u2013 Nov 21", start: [10, 23], end: [11, 21], element: "water", modality: "fixed", ruler: "Pluto", classicRuler: "Mars", polarity: "night", house: 8, hue: "#B9DCE8", essence: "Intense, private, all-or-nothing." },
    { slug: "sagittarius", name: "Sagittarius", glyph: "\u2650", dates: "Nov 22 \u2013 Dec 21", start: [11, 22], end: [12, 21], element: "fire", modality: "mutable", ruler: "Jupiter", polarity: "day", house: 9, hue: "#E0B080", essence: "Restless, honest, aimed at the horizon." },
    { slug: "capricorn", name: "Capricorn", glyph: "\u2651", dates: "Dec 22 \u2013 Jan 19", start: [12, 22], end: [1, 19], element: "earth", modality: "cardinal", ruler: "Saturn", polarity: "night", house: 10, hue: "#C0DEA8", essence: "Patient, ambitious, building something that lasts." },
    { slug: "aquarius", name: "Aquarius", glyph: "\u2652", dates: "Jan 20 \u2013 Feb 18", start: [1, 20], end: [2, 18], element: "air", modality: "fixed", ruler: "Uranus", classicRuler: "Saturn", polarity: "day", house: 11, hue: "#AE8FC9", essence: "Independent, inventive, loyal to the future." },
    { slug: "pisces", name: "Pisces", glyph: "\u2653", dates: "Feb 19 \u2013 Mar 20", start: [2, 19], end: [3, 20], element: "water", modality: "mutable", ruler: "Neptune", classicRuler: "Jupiter", polarity: "night", house: 12, hue: "#A9D4C4", essence: "Porous, imaginative, tuned to what goes unspoken." }
  ];
  var SIGN_SLUGS = SIGNS.map((s3) => s3.slug);
  function signPrepositional(sign) {
    const resolved = typeof sign === "string" ? signBySlug(sign) : sign;
    return russianRuntime().signs.prepositional[resolved.slug];
  }
  var SIGN_NAME_ES = {
    aries: "Aries",
    taurus: "Tauro",
    gemini: "G\xE9minis",
    cancer: "C\xE1ncer",
    leo: "Leo",
    virgo: "Virgo",
    libra: "Libra",
    scorpio: "Escorpio",
    sagittarius: "Sagitario",
    capricorn: "Capricornio",
    aquarius: "Acuario",
    pisces: "Piscis"
  };
  var SIGN_NAME_PT = {
    aries: "\xC1ries",
    taurus: "Touro",
    gemini: "G\xEAmeos",
    cancer: "C\xE2ncer",
    leo: "Le\xE3o",
    virgo: "Virgem",
    libra: "Libra",
    scorpio: "Escorpi\xE3o",
    sagittarius: "Sagit\xE1rio",
    capricorn: "Capric\xF3rnio",
    aquarius: "Aqu\xE1rio",
    pisces: "Peixes"
  };
  var SIGN_NAME_FR = {
    aries: "B\xE9lier",
    taurus: "Taureau",
    gemini: "G\xE9meaux",
    cancer: "Cancer",
    leo: "Lion",
    virgo: "Vierge",
    libra: "Balance",
    scorpio: "Scorpion",
    sagittarius: "Sagittaire",
    capricorn: "Capricorne",
    aquarius: "Verseau",
    pisces: "Poissons"
  };
  var SIGN_NAME_IT = {
    aries: "Ariete",
    taurus: "Toro",
    gemini: "Gemelli",
    cancer: "Cancro",
    leo: "Leone",
    virgo: "Vergine",
    libra: "Bilancia",
    scorpio: "Scorpione",
    sagittarius: "Sagittario",
    capricorn: "Capricorno",
    aquarius: "Acquario",
    pisces: "Pesci"
  };
  var SIGN_NAME_OVERRIDES = {
    en: null,
    es: SIGN_NAME_ES,
    pt: SIGN_NAME_PT,
    fr: SIGN_NAME_FR,
    it: SIGN_NAME_IT
  };
  function signBySlug(slug) {
    const sign = SIGNS.find((s3) => s3.slug === slug);
    if (!sign) throw new Error(`Unknown sign: ${slug}`);
    return sign;
  }
  function signIndexForLongitude(lon) {
    return Math.floor((lon % 360 + 360) % 360 / 30);
  }
  function signForLongitude(lon) {
    return SIGNS[signIndexForLongitude(lon)];
  }
  function signName(sign, locale = "en") {
    const resolved = typeof sign === "string" ? signBySlug(sign) : sign;
    const catalogLocale = requireCatalogLocale(locale);
    if (catalogLocale === "ru") return russianRuntime().signs.names[resolved.slug] ?? resolved.name;
    return SIGN_NAME_OVERRIDES[catalogLocale]?.[resolved.slug] ?? resolved.name;
  }
  function degreeInSign(lon) {
    return (lon % 360 + 360) % 360 % 30;
  }
  function formatLongitude(lon, locale = "en") {
    const sign = signForLongitude(lon);
    const deg = degreeInSign(lon);
    const d3 = Math.floor(deg);
    const m3 = Math.floor((deg - d3) * 60);
    return `${d3}\xB0${String(m3).padStart(2, "0")}\u2032 ${signName(sign, locale)}`;
  }

  // src/lib/i18n/ui/client.ts
  init_define_import_meta_env();
  function clientUi(locale) {
    const catalogLocale = requireCatalogLocale(locale);
    const payload = globalThis.__ZDX_UI__;
    if (!payload || payload.locale !== catalogLocale || !payload.messages) {
      throw new Error(`Missing client UI catalog for ${catalogLocale}`);
    }
    return payload.messages;
  }
  function clientUiMessage(locale, key) {
    const message = clientUi(locale)[key];
    if (typeof message !== "string") {
      throw new Error(`Missing client UI message ${locale}.${String(key)}`);
    }
    return message;
  }

  // src/lib/i18n/ui/server.ts
  init_define_import_meta_env();

  // src/lib/i18n/ui/en.ts
  init_define_import_meta_env();

  // src/lib/i18n/ui/growth.ts
  init_define_import_meta_env();
  var GROWTH_UI_EN = {
    footerWidgets: "Widgets",
    footerDisclosure: "Disclosure",
    emailCaptureKicker: "Free weekly forecast",
    emailCaptureTitle: "Your week ahead.",
    emailCapturePersonalTitle: "Your {sign} week ahead.",
    emailCaptureCopy: "A weekly forecast for your sign. Free, unsubscribe anytime.",
    emailCaptureEmailLabel: "Email address",
    emailCaptureEmailPlaceholder: "you@example.com",
    emailCaptureSignLegend: "Your sun sign (optional)",
    emailCaptureNoSign: "Skip the sign",
    emailCaptureUsingSign: "Using your Sun sign: {sign}",
    emailCaptureChangeSign: "Change",
    emailCaptureSubmit: "Send my week",
    emailCaptureSubmitting: "Joining\u2026",
    emailCaptureSuccess: "Check your email to confirm your subscription.",
    emailCaptureErrorTitle: "Subscription unavailable",
    emailCaptureError: "Couldn't start the subscription. Please try again.",
    emailCapturePrivacy: "We store your email with your chosen sign only \u2014 never your birth data.",
    emailCaptureHoneypot: "Leave this field blank",
    emailPendingTitle: "Check your email.",
    emailPendingBody: "Use the confirmation link we sent before your weekly forecast begins.",
    emailConfirmSubject: "Confirm your Zodiacs.org weekly forecast",
    emailConfirmMessage: "Confirm that you want the free Zodiacs.org weekly forecast:",
    emailConfirmIgnore: "If you did not request this, ignore this email. Nothing will be subscribed.",
    emailConfirmTitle: "One last check.",
    emailConfirmBody: "Confirm this subscription to begin the free weekly forecast. Until then, no weekly subscription is active.",
    emailConfirmAction: "Confirm subscription",
    emailConfirmedTitle: "Subscription confirmed.",
    emailConfirmedBody: "Your free weekly forecast is on. Every message includes an unsubscribe link.",
    emailConfirmInvalidTitle: "This link is not valid.",
    emailConfirmInvalidBody: "The confirmation link is invalid or has expired. Return to Zodiacs.org to request another.",
    emailReturnHome: "Return to Zodiacs.org"
  };
  var GROWTH_UI_ES = {
    ...GROWTH_UI_EN,
    footerWidgets: "Widgets",
    footerDisclosure: "Declaraciones",
    emailCaptureKicker: "Pron\xF3stico semanal gratuito",
    emailCaptureTitle: "Tu semana por delante.",
    emailCapturePersonalTitle: "Tu semana de {sign} por delante.",
    emailCaptureCopy: "Un pron\xF3stico semanal para tu signo. Gratis y con baja en cualquier momento.",
    emailCaptureEmailLabel: "Direcci\xF3n de email",
    emailCaptureEmailPlaceholder: "tu@email.com",
    emailCaptureSignLegend: "Tu signo solar (opcional)",
    emailCaptureNoSign: "Omitir el signo",
    emailCaptureUsingSign: "Usando tu signo solar: {sign}",
    emailCaptureChangeSign: "Cambiar",
    emailCaptureSubmit: "Env\xEDame mi semana",
    emailCaptureSubmitting: "Uni\xE9ndote\u2026",
    emailCaptureSuccess: "Revisa tu email para confirmar la suscripci\xF3n.",
    emailCaptureErrorTitle: "Suscripci\xF3n no disponible",
    emailCaptureError: "No se pudo iniciar la suscripci\xF3n. Int\xE9ntalo otra vez.",
    emailCapturePrivacy: "Guardamos tu email solo con el signo que elijas, nunca tus datos de nacimiento.",
    emailCaptureHoneypot: "Deja este campo en blanco",
    emailPendingTitle: "Revisa tu email.",
    emailPendingBody: "Usa el enlace de confirmaci\xF3n que te enviamos antes de que comience tu pron\xF3stico semanal.",
    emailConfirmSubject: "Confirma tu pron\xF3stico semanal de Zodiacs.org",
    emailConfirmMessage: "Confirma que quieres recibir el pron\xF3stico semanal gratuito de Zodiacs.org:",
    emailConfirmIgnore: "Si no lo solicitaste, ignora este email. No se activar\xE1 ninguna suscripci\xF3n.",
    emailConfirmTitle: "Una \xFAltima comprobaci\xF3n.",
    emailConfirmBody: "Confirma la suscripci\xF3n para empezar a recibir el pron\xF3stico semanal gratuito. Hasta entonces, no hay ninguna suscripci\xF3n semanal activa.",
    emailConfirmAction: "Confirmar suscripci\xF3n",
    emailConfirmedTitle: "Suscripci\xF3n confirmada.",
    emailConfirmedBody: "Tu pron\xF3stico semanal gratuito est\xE1 activo. Cada mensaje incluye un enlace para darte de baja.",
    emailConfirmInvalidTitle: "Este enlace no es v\xE1lido.",
    emailConfirmInvalidBody: "El enlace de confirmaci\xF3n no es v\xE1lido o ha caducado. Vuelve a Zodiacs.org para solicitar otro.",
    emailReturnHome: "Volver a Zodiacs.org"
  };

  // src/lib/i18n/ui/en.ts
  var en = {
    chartDepthOpen: "See it in three dimensions",
    chartDepthClose: "Hide the third dimension",
    calculationLoadError: "The calculation files could not load. Check your connection and try again.",
    calculationReload: "Reload page",
    calculationReloadWarning: "Reloading clears unsaved entries.",
    calculationRetry: "Try again",
    pfdYearError: "We couldn\u2019t finish your year-ahead reading. Try again.",
    placeSearching: "Searching places\u2026",
    chartWheelActions: "Chart actions",
    chartWheelGuide: "Take the guided tour",
    chartWheelReplay: "Replay the tour",
    chartWheelAnother: "Read another chart",
    chartWheelSignatureSelf: "Your chart signature",
    chartWheelSignatureOther: "Their chart signature",
    chartWheelCompareMine: "Compare with mine",
    chartWheelCompareAdd: "Add my chart to compare",
    chartWheelShareOther: "Share this chart",
    navPrimary: "Primary",
    navSigns: "Signs",
    navTools: "Tools",
    navLearn: "Learn",
    navHoroscopes: "Horoscopes",
    navCollect: "Astrofolio",
    navSavedCharts: "Saved charts",
    navMenu: "Menu",
    navSite: "The site",
    navTwelve: "The twelve",
    footerTag: "Free astrology tools and sign guides, with charts calculated privately in your browser.",
    footerStartHere: "Start here",
    footerPlanets: "The planets",
    footerHouses: "The houses",
    footerZodiacDates: "Zodiac dates",
    footerGlossary: "Glossary",
    footerCompute: "How we compute",
    footerRegistry: "Registry",
    footerThesis: "Thesis",
    footerArchive: "Archive",
    footerSdk: "SDK",
    footerCollectNote: "Registry records, lookups, catalogue profiles, and the SDK are read-only. Astrofolio\u2019s optional buying tool uses independent Jupiter and your own wallet; Zodiacs.org holds no keys or funds. Nothing here is financial advice.",
    footerMethodology: "Methodology",
    footerAbout: "About",
    footerPrivacy: "Privacy",
    footerTerms: "Terms",
    footerPlaceData: "Place data",
    footerFonts: "Fonts under",
    skipContent: "Skip to content",
    open: "Open",
    birthChart: "Birth chart",
    compatibility: "Compatibility",
    moonSign: "Moon sign",
    risingSign: "Rising sign",
    moonPhase: "Moon phase",
    saturnReturn: "Saturn return",
    transits: "Transits",
    birthday: "Birthday",
    retrogrades: "Retrogrades",
    sun: "Sun",
    moon: "Moon",
    rising: "Rising",
    body: "Body",
    position: "Position",
    sign: "Sign",
    house: "House",
    chart: "Chart",
    date: "Date",
    time: "Time",
    place: "Place",
    motion: "Motion",
    optional: "optional",
    birthDate: "Birth date",
    birthTime: "Birth time",
    birthplace: "Birthplace",
    birthDateRequired: "Enter your birth date.",
    birthDateRange: "Choose a birth date from 1800 through 2199.",
    birthTimeRequired: "Enter your birth time.",
    houseSystem: "House system",
    wholeSignDefault: "Whole sign (default)",
    placidus: "Placidus",
    // The EN calculator renders this sentence as JSX with tap-to-explain terms — keep both in sync.
    houseSystemHelp: "How the chart divides into twelve areas of life. Whole sign gives each sign one house; Placidus varies house sizes by exact birth time and place. Planets stay put \u2014 only house boundaries move.",
    computing: "Computing\u2026",
    checking: "Checking\u2026",
    comparing: "Comparing\u2026",
    save: "Save",
    rename: "Rename",
    remove: "Remove",
    getBirthChart: "Get your free birth chart",
    findMoonSign: "Find your moon sign",
    findRisingSign: "Find your rising sign",
    savedCharts: "Saved charts",
    profile: "Your profile",
    read: "Read",
    rightNow: "Right now",
    enterBirthDetails: "Enter birth details\u2026",
    privacyDevice: "Private by default. Your birth details stay in this browser.",
    placePlaceholder: "Start typing a city\u2026",
    placeChange: "Change birthplace",
    placePickHint: "Pick your birthplace from the list.",
    placeNoResults: "Not listed? Choose the nearest town \u2014 a few km rarely changes the chart.",
    placeError: "Couldn't load the place index \u2014 check your connection and try again.",
    searchGeo: "Search covers ~34,000 places \xB7 GeoNames (CC BY 4.0)",
    chartError: "Something went wrong computing the chart. Please try again.",
    moonError: "Something went wrong computing that moon. Please try again.",
    localDateReferenceError: "We couldn\u2019t establish a calculation time within this local date. Check the date and place.",
    returnError: "Something went wrong computing the return. Please try again.",
    transitError: "Something went wrong computing the transits. Please try again.",
    compareError: "Something went wrong comparing the charts. Please try again.",
    noBirthTime: "I don't know it",
    risingTimeHelp: "Rising signs change every two hours \u2014 the clock matters here.",
    chartTimeHelp: "No birth time? You'll get a local-noon reference without rising or houses; the Moon may be uncertain.",
    chartSavedDevice: "Saved \xB7 on this device",
    saveThisChart: "Save this chart",
    chartSavedStatus: "Chart saved on this device.",
    chartSaveFull: "You can save up to 40 charts \u2014 remove one first.",
    chartSaveError: "Couldn't save \u2014 your browser may be blocking local storage.",
    chartSavedMessage: "Saved to your charts. Sign in here when you want them on every device.",
    linkCopied: "Link copied",
    copyChartLink: "Copy a link to this chart",
    rendering: "Rendering\u2026",
    cardSaved: "Card saved",
    saveChartCard: "Save a chart card",
    shareChart: "Share your chart",
    linkToChart: "Link to this chart",
    chartLinkCopied: "Chart link copied to your clipboard.",
    chartCardSaved: "Chart card saved.",
    cardError: "Couldn't draw the card in this browser \u2014 the wheel above will screenshot just as well.",
    shareNote: "The link carries the birth details you entered \u2014 nothing is sent to us, so only people you hand it to can open it. The card is a 1080\xD71350 image drawn on your device.",
    needsBirthTime: "Needs a birth time",
    yourMoonSign: "Your Moon sign",
    yourRisingSign: "Your Rising sign",
    moonPhaseAtBirth: "Moon phase at birth",
    chartRuler: "Chart ruler",
    planetSteering: "the planet steering your rising sign.",
    aspectsFound: "Aspects",
    found: "found",
    applying: "applying",
    wholeSignHouses: "Whole sign houses",
    placidusHouses: "Placidus houses",
    engine: "engine v",
    readInOrder: "Reading it in order",
    readIntro: "Top to bottom, the way an astrologer would take it in. The tables above are the data; this is what they say.",
    readBigThree: "Start with the big three",
    readBigThreeBody: "Sun, Moon, rising \u2014 the three cards at the top. Identity, instinct, entrance. Everything below refines them; nothing replaces them.",
    readRooms: "Planets, room by room",
    readNoHouses: "Without a birth time there are no houses, so each planet reads by sign alone. Add a time and this section gains its rooms.",
    readAspects: "The aspects doing the most work",
    readWeather: "The chart\u2019s weather",
    readIn: "in",
    today: "today",
    todayBySignTitle: "The sky today, by sign",
    todayBySignPrompt: "Tap your Sun sign for a clear reading for today \u2014 no birth time needed.",
    todaySolarNote: "read from your sign\u2019s solar houses",
    whyThisReading: "Why this reading",
    todayHoroscopeLink: "horoscope",
    or: "or",
    chartSavedBeforeLink: "Saved to your charts. Sign in",
    chartSavedLink: "here",
    chartSavedAfterLink: "when you want them on every device.",
    signedInAs: "Signed in as {email}",
    removeChartConfirm: 'Remove "{name}" from this device?',
    compareSavedHeading: "Compare {a} & {b}",
    compareSavedPitch: "Two charts saved is a comparison waiting to happen: every cross-chart aspect, read honestly, computed on this device.",
    saturnDateHelp: "The date alone pins your return years. Time and place sharpen the dates by a few days, never the year.",
    saturnReturnHeading: "{ordinal} return",
    skyMercuryRetrograde: "Mercury retrograde",
    skyMercuryDirect: "Mercury direct",
    skyPlanetRetrograde: "{planet} retrograde",
    skyFullMoon: "Full moon",
    skyNewMoon: "New moon",
    skyMoonOn: "{event} \xB7 {date}",
    skyAsOf: "{date} \xB7 12 UTC",
    skyTickerAria: "Sky positions for {date} at 12:00 UTC",
    moonDiscAria: "Moon, {percent}% illuminated",
    pairingCta: "Read the {a} and {b} pairing",
    inviteWith: "Invite someone to compare with {name}",
    inviteNamedNote: "The link carries {name}'s birth details and opens this page with that side filled in \u2014 nothing is sent to us. Worth their okay if that isn't you.",
    transitMiddayUtc: "{date} \xB7 midday UTC",
    planetReturn: "{planet} return",
    natalPlanet: "Natal {planet}",
    pfdToday: "Today for this chart",
    pfdComing: "Coming up for this chart",
    pfdYearAhead: "The year ahead for this chart",
    pfdYearBusy: "Computing the year on your device \u2014 a few seconds\u2026",
    pfdYearNote: "Computed from your saved chart: exact dates for the next twelve months.",
    saveYearAheadNote: "Saved charts get a computed year ahead on the profile page \u2014 solar return, Jupiter and Saturn dates, eclipse hits.",
    recordLabel: "Collector\u2019s wing",
    recordOneOfTwelve: "also exists as one of the Twelve \u2014 a canonical record in the registry.",
    recordViewLink: "View the record \u2192",
    recordChartSun: "Your Sun is in {sign}.",
    recordChartBody: "{sign} is one of the Twelve\u2014with its own artwork, history, and official Registry record.",
    recordChartLink: "Explore the {sign} Registry \u2192",
    babyDueDate: "Due date",
    babyCompute: "Read the due-date sky",
    babyNeedDate: "Enter a due date first.",
    babyError: "Something went wrong computing the sky. Please try again.",
    babySunHead: "Sun sign \u2014 near certain",
    babySunSingle: "A birth on this date gets the Sun in",
    babySunNearEdge: "The date sits close to the edge of the sign, so arriving more than a day early or late can tip into",
    babySunNearEdgeTail: "\u2014 the birth date decides.",
    babySunSplitA: "The Sun changes signs on this date: a birth comes out",
    babySunSplitOr: "or",
    babySunSplitTail: "depending on the hour. The exact birth moment decides.",
    babyNoonNote: "signs read at midday universal time",
    babyMoonHead: "Moon sign \u2014 one of a few",
    babyMoonBody: "The Moon changes signs every two or three days, so a due week usually spans two or three moon signs. Babies born the same week can carry different ones \u2014 the birth day and hour decide.",
    babyRetroHead: "Retrograde at birth",
    babyRetroBody: "these planets are in their retrograde stretch around the due date. In a birth chart a retrograde planet reads as more inward than usual \u2014 common and nothing to fix.",
    babyRisingHead: "Rising sign \u2014 unknowable until the minute",
    babyRisingBody: "The rising sign changes roughly every two hours, so no due date can predict it. It is the one placement that has to wait for the birth certificate.",
    babyDateLink: "Read this birthday in depth",
    babyChartLink: "After the birth: the full chart",
    pfdChartPick: "Chart",
    pfdQuietSky: "A quiet sky for this chart today \u2014 nothing within 3\xB0 of a natal point.",
    pfdQuietAhead: "Nothing major on this chart\u2019s horizon in the computed window.",
    pfdSaturnBusy: "Computing Saturn windows on your device\u2026",
    pfdEmptyTitle: "Your sky, once you save a chart",
    pfdEmptyBody: "Save a birth chart and this page opens each day with its transits, its houses, and what\u2019s coming for it.",
    pfdWindows: "windows",
    openChart: "Open",
    dignityDomicile: "domicile",
    dignityExaltation: "exaltation",
    dignityDetriment: "detriment",
    dignityFall: "fall",
    explorerHint: "Tap any planet, sign, house, or aspect line to inspect it \u2014 or focus the wheel and use the arrow keys.",
    explorerLabel: "Interactive birth chart",
    explorerSelectPart: "Choose a chart part",
    explorerNoSelection: "No selection",
    explorerAngles: "Angles",
    explorerControlsLoading: "Loading chart readings and controls\u2026",
    explorerControlsError: "Your chart is ready, but its readings and controls could not load. Check your connection and try again.",
    explorerKeyHint: "Left and right arrow keys move between placements; Enter opens the details panel.",
    selectionCleared: "Selection cleared.",
    inspectorClose: "Close details",
    speed: "Speed",
    day: "day",
    dignity: "Standing",
    separating: "separating",
    dates: "Dates",
    element: "Element",
    ruler: "Ruler",
    inThisSign: "In this sign",
    inThisHouse: "In this house",
    cusp: "Cusp",
    span: "Span",
    emptyHouseNote: "No planets here. An empty house isn't a blank \u2014 its themes run through the planet that rules it.",
    angleAscNote: "The Ascendant \u2014 the degree rising on the eastern horizon at the birth moment. It anchors the whole wheel.",
    angleDscNote: "The Descendant \u2014 the degree setting in the west, opposite the Ascendant. The traditional doorway to partners.",
    angleMcNote: "The Midheaven \u2014 the degree culminating overhead at birth. Career, reputation, the visible life.",
    angleIcNote: "The IC \u2014 the lowest point of the wheel, opposite the Midheaven. Home, roots, the private life.",
    layersLabel: "Chart layers",
    layerHouses: "Houses",
    editedBy: "Published by",
    tourStart: "Take the tour",
    firstReadingLabel: "Your 2-minute reading",
    firstReadingTitle: "What does your chart say about you \u2014 and what comes next?",
    firstReadingBody: "See your personality mix, where it plays out, one pattern you may recognize, and how astrology turns a birth chart into a forecast.",
    firstReadingResumeTitle: "Your reading is waiting",
    firstReadingResumeBody: "Continue where you left off on this device.",
    firstReadingStart: "Read my chart",
    firstReadingExplore: "Explore on my own",
    firstReadingResume: "Continue my reading",
    firstReadingStep: "Step",
    firstReadingFullTour: "See how the chart works \u2014 advanced tour",
    firstReadingReplay: "Replay my chart story",
    chartActionsMore: "More ways to use this chart",
    chartReceiptDownload: "Download calculation receipt (.json)",
    chartReceiptPrivacy: "This file contains sensitive birth details and chart data. Keep it private.",
    chartReceiptError: "The file could not be downloaded. Please try again.",
    chartReceiptUnavailable: "A calculation receipt is not available for this chart.",
    seeTodaySky: "See today's sky",
    contextHelpCue: "Dotted terms can be tapped for a plain-English explanation.",
    editorialHow: "editorial standards",
    dstGapNotice: "That clock time fell inside a daylight-saving jump, so it never quite existed \u2014 we shifted forward across the gap, the standard convention.",
    dstFoldNotice: "Clocks repeated that hour where you were born; we used the earlier pass. If you know it was the later one, your chart barely changes \u2014 the Moon moves about half a degree an hour.",
    lmtNotice: "Born before standardized time zones \u2014 we used local mean time for that era, the same convention professional software uses.",
    polarNotice: "Placidus houses aren't defined that close to the pole, so this chart uses whole sign houses instead.",
    noTimeNotice: "Without a birth time we use 12:00 local civil time as a reference and omit the rising sign, angles, and houses.",
    moonAmbiguousNotice: "The Moon also changed signs that day \u2014 reading both neighbors is fair until you find the time.",
    fromLinkNotice: "Opened from a shared link \u2014 the birth details came in the link itself, and the chart was computed on your device just now.",
    howWeCompute: "How we compute",
    welcomeBack: "Welcome back.",
    savedChartAria: "Your saved chart",
    todayAgainstChart: "Today against your chart",
    yourCharts: "Your charts",
    recommendedNext: "Recommended next",
    todayForName: "See what today means for {name}",
    savedChartTodayBody: "Your chart stays the same. Today\u2019s sky does not \u2014 start with what is changing for you now.",
    openSavedChart: "Open saved chart",
    moonReadingSky: "Reading the sky\u2026",
    illuminated: "illuminated",
    moonIn: "Moon in",
    findThatMoon: "Find that moon",
    dateHelp: "A birthday, an anniversary, any date at all.",
    placeHelpMoon: "Sharpens the clock conversion; the phase barely needs it.",
    middayLocalCaption: "Read at midday local time \u2014 adding the clock time pins the degree exactly.",
    utcTimeCaption: "The time is read as universal time \u2014 add a birthplace to convert your local clock.",
    middayUtcCaption: "Read at midday universal time \u2014 a time and place pin the degree exactly.",
    moonChangedNotice: "The Moon changed signs that day, and without a time we can't say which side of the line you were born on. The phase is unaffected \u2014 it moves too slowly for hours to matter.",
    birthChartForDate: "Get the birth chart for this date",
    natalSaturn: "Your natal Saturn",
    addBirthDetails: "Add birth time and place (optional)",
    findSaturnReturn: "Find your Saturn return",
    returnApprox: "Dates computed from a noon reading \u2014 with a birth time and place they can shift by a few days either way.",
    complete: "Complete",
    underwayNow: "Underway now",
    aheadOfYou: "Ahead of you",
    first: "First",
    second: "Second",
    third: "Third",
    fourth: "Fourth",
    aroundAge29: "around age 29",
    aroundAge58: "around age 58",
    aroundAge88: "around age 88",
    retrogradePass: "retrograde pass",
    threePasses: "Three exact passes: Saturn crosses your degree, backs over it in retrograde, then seals it on the way out. The whole span is the return.",
    seeSaturnChart: "See Saturn in your birth chart",
    whatSaturnMeans: "What Saturn means",
    yourChart: "Your chart",
    theSky: "The sky",
    transitRingLede: "Draw your chart, then move a slider to watch the planets travel over it \u2014 forward or back, up to a year.",
    checkTransits: "Check your transits",
    savedChartHelp: "Charts you calculate and save appear here as one-tap choices, so the next check skips the typing.",
    noTransitTimeNotice: "No birth time on this chart, so its Moon is a midday estimate \u2014 it can sit up to six degrees off, and a transit to the Moon near the edge of its orb may come or go with the real time.",
    skyAt: "Sky at",
    noTransitsWithin: "No transits within",
    activeTransitsWithin: "active transits within",
    activeTransitWithin: "active transit within",
    ofExact: "of exact",
    transitMoonOmitted: "transiting Moon left out \u2014 it crosses the whole chart every month",
    quietSky: "A quiet sky by the tight orb this page uses. Nothing pressing \u2014 check back in a few days, or widen your reading to the month's events below.",
    natal: "Natal",
    forYourChart: "For your chart",
    orb: "orb",
    openDailyBrief: "Open my full daily brief",
    allTransits: "All your transits",
    personA: "Person A",
    personB: "Person B",
    sharedChart: "Shared chart",
    sharedWithYou: "shared with you",
    removeSharedChart: "Remove the shared chart",
    sharedSideHelp: "This side arrived in the link \u2014 clear it to enter someone else.",
    name: "Name",
    compareCharts: "Compare the charts",
    sameChart: "That's the same chart twice \u2014 pick two different ones to compare.",
    compareSavedHelp: "Charts you calculate and save appear here as one-tap choices, so the second comparison is faster than the first.",
    compareNoTimeNotice: "No birth time for",
    moonMiddayEstimate: "so that Moon is a midday estimate \u2014 it can sit up to six degrees off, and a Moon aspect near the edge of its orb may come or go with the real time.",
    crossChartAspects: "cross-chart aspects",
    easeful: "easeful",
    charged: "charged",
    readPairing: "Read the pairing",
    inviteCompare: "Invite someone to compare",
    inviteLink: "Invite link",
    inviteNote: "The link carries this person's birth details and opens this page with that side filled in \u2014 nothing is sent to us. Worth their okay if that isn't you.",
    inviteCopied: "Invite link copied to your clipboard.",
    syncOn: "Sync is on",
    keepEveryDevice: "Keep charts on every device",
    signedIn: "Signed in",
    syncCopyOn: "Saved charts and removals sync across devices.",
    syncCopyOff: "Save charts on this device. Sign in when you want them on every device.",
    weeklyDigestTitle: "Weekly sky email",
    weeklyDigestCopy: "One email a week: the sky against your saved charts. Unsubscribe any time.",
    weeklyDigestAria: "Weekly digest opt-in",
    digestSaved: "Digest preference saved.",
    digestFailed: "Couldn't update digest preference. Please try again.",
    checkEmail: "Check your email for a sign-in link. This page will sync after you return.",
    syncFailed: "Sync failed. Please try again.",
    syncing: "Syncing\u2026",
    synced: "Synced",
    syncNow: "Sync now",
    signOut: "Sign out",
    emailSyncAria: "Email for profile sync",
    sending: "Sending\u2026",
    sendSignIn: "Send sign-in link",
    nothingSaved: "Nothing saved yet.",
    emptyProfile: "Charts you save will live here, on your device first. Run a chart and tap Save this chart to start your saved charts.",
    saved: "saved",
    chartSingular: "chart",
    chartPlural: "charts",
    savedChartSingular: "saved chart",
    savedChartPlural: "saved charts",
    syncedWhenSignedIn: "synced when signed in",
    storedBrowser: "stored in this browser",
    chartName: "Chart name",
    timeUnknown: "time unknown",
    needsTime: "needs a time",
    compareThese: "Compare these two charts",
    addAnotherChart: "Add another chart",
    ...GROWTH_UI_EN
  };
  var en_default = en;

  // src/lib/i18n/ui/es.ts
  init_define_import_meta_env();
  var es = {
    chartDepthOpen: "Verla en tres dimensiones",
    chartDepthClose: "Ocultar la tercera dimensi\xF3n",
    calculationLoadError: "No se pudieron cargar los archivos de c\xE1lculo. Comprueba tu conexi\xF3n e int\xE9ntalo de nuevo.",
    calculationReload: "Recargar p\xE1gina",
    calculationReloadWarning: "Al recargar se borran los datos que no hayas guardado.",
    calculationRetry: "Intentar de nuevo",
    pfdYearError: "No pudimos completar la lectura del a\xF1o que viene. Int\xE9ntalo de nuevo.",
    placeSearching: "Buscando lugares\u2026",
    chartWheelActions: "Acciones de la carta",
    chartWheelGuide: "Hacer el recorrido guiado",
    chartWheelReplay: "Repetir el recorrido",
    chartWheelAnother: "Leer otra carta",
    chartWheelSignatureSelf: "La firma de tu carta",
    chartWheelSignatureOther: "La firma de su carta",
    chartWheelCompareMine: "Comparar con la m\xEDa",
    chartWheelCompareAdd: "A\xF1adir mi carta para comparar",
    chartWheelShareOther: "Compartir esta carta",
    navPrimary: "Principal",
    navSigns: "Signos",
    navTools: "Herramientas",
    navLearn: "Aprende",
    navHoroscopes: "Hor\xF3scopos",
    navCollect: "Astrofolio",
    navSavedCharts: "Cartas guardadas",
    navMenu: "Men\xFA",
    navSite: "El sitio",
    navTwelve: "Los doce",
    footerTag: "Herramientas gratuitas de astrolog\xEDa y gu\xEDas de signos, con cartas calculadas de forma privada en tu navegador.",
    footerStartHere: "Empieza aqu\xED",
    footerPlanets: "Los planetas",
    footerHouses: "Las casas",
    footerZodiacDates: "Fechas del zodiaco",
    footerGlossary: "Glosario",
    footerCompute: "C\xF3mo calculamos",
    footerRegistry: "Registry",
    footerThesis: "Tesis",
    footerArchive: "Archivo",
    footerSdk: "SDK",
    footerCollectNote: "Los registros, las consultas, los perfiles del cat\xE1logo y el SDK del Registry son de solo lectura. La herramienta opcional de compra de Astrofolio usa Jupiter independiente y tu propia cartera; Zodiacs.org no custodia claves ni fondos. Nada de esto es asesoramiento financiero.",
    footerMethodology: "Metodolog\xEDa",
    footerAbout: "Acerca de",
    footerPrivacy: "Privacidad",
    footerTerms: "T\xE9rminos",
    footerPlaceData: "Datos de lugares",
    footerFonts: "Fuentes bajo la licencia",
    skipContent: "Saltar al contenido",
    open: "Abrir",
    birthChart: "Carta natal",
    compatibility: "Compatibilidad",
    moonSign: "Signo lunar",
    risingSign: "Ascendente",
    moonPhase: "Fase lunar",
    saturnReturn: "Retorno de Saturno",
    transits: "Tr\xE1nsitos",
    birthday: "Cumplea\xF1os (en ingl\xE9s)",
    retrogrades: "Retr\xF3grados",
    sun: "Sol",
    moon: "Luna",
    rising: "Ascendente",
    body: "Cuerpo",
    position: "Posici\xF3n",
    sign: "Signo",
    house: "Casa",
    chart: "Carta",
    date: "Fecha",
    time: "Hora",
    place: "Lugar",
    motion: "Movimiento",
    optional: "opcional",
    birthDate: "Fecha de nacimiento",
    birthTime: "Hora de nacimiento",
    birthplace: "Lugar de nacimiento",
    birthDateRequired: "Ingresa tu fecha de nacimiento.",
    birthDateRange: "Elige una fecha de nacimiento entre 1800 y 2199.",
    birthTimeRequired: "Ingresa tu hora de nacimiento.",
    houseSystem: "Sistema de casas",
    wholeSignDefault: "Signos completos (predeterminado)",
    placidus: "Placidus",
    houseSystemHelp: "C\xF3mo se divide la carta en doce \xE1reas de la vida. Signos completos da a cada signo una casa entera; Placidus var\xEDa el tama\xF1o de las casas seg\xFAn la hora y el lugar exactos. Los planetas no se mueven: solo cambian los l\xEDmites de las casas.",
    computing: "Calculando\u2026",
    checking: "Revisando\u2026",
    comparing: "Comparando\u2026",
    save: "Guardar",
    rename: "Renombrar",
    remove: "Eliminar",
    getBirthChart: "Obt\xE9n tu carta natal gratis",
    findMoonSign: "Encuentra tu signo lunar",
    findRisingSign: "Encuentra tu ascendente",
    savedCharts: "Cartas guardadas",
    profile: "Tu perfil",
    read: "Leer",
    rightNow: "Ahora mismo",
    enterBirthDetails: "Ingresa los datos de nacimiento\u2026",
    privacyDevice: "Privado de forma predeterminada. Tus datos de nacimiento permanecen en este navegador.",
    placePlaceholder: "Empieza a escribir una ciudad\u2026",
    placeChange: "Cambiar lugar de nacimiento",
    placePickHint: "Elige tu lugar de nacimiento de la lista.",
    placeNoResults: "\xBFNo aparece? Elige la localidad m\xE1s cercana \u2014 unos pocos km rara vez cambian la carta.",
    placeError: "No se pudo cargar el \xEDndice de lugares \u2014 revisa tu conexi\xF3n e intenta otra vez.",
    searchGeo: "La b\xFAsqueda cubre ~34,000 lugares \xB7 GeoNames (CC BY 4.0)",
    chartError: "Algo sali\xF3 mal al calcular la carta. Int\xE9ntalo otra vez.",
    moonError: "Algo sali\xF3 mal al calcular esa Luna. Int\xE9ntalo otra vez.",
    localDateReferenceError: "No pudimos establecer una hora de c\xE1lculo dentro de esta fecha local. Comprueba la fecha y el lugar.",
    returnError: "Algo sali\xF3 mal al calcular el retorno. Int\xE9ntalo otra vez.",
    transitError: "Algo sali\xF3 mal al calcular los tr\xE1nsitos. Int\xE9ntalo otra vez.",
    compareError: "Algo sali\xF3 mal al comparar las cartas. Int\xE9ntalo otra vez.",
    noBirthTime: "No la s\xE9",
    risingTimeHelp: "El ascendente cambia cada dos horas \u2014 aqu\xED la hora importa.",
    chartTimeHelp: "\xBFNo sabes la hora? Ver\xE1s una referencia al mediod\xEDa local sin ascendente ni casas; la Luna puede ser incierta.",
    chartSavedDevice: "Guardada \xB7 en este dispositivo",
    saveThisChart: "Guardar esta carta",
    chartSavedStatus: "Carta guardada en este dispositivo.",
    chartSaveFull: "Puedes guardar hasta 40 cartas \u2014 elimina una primero.",
    chartSaveError: "No se pudo guardar \u2014 tu navegador puede estar bloqueando el almacenamiento local.",
    chartSavedMessage: "Guardada en tus cartas. Inicia sesi\xF3n aqu\xED cuando quieras tenerlas en todos tus dispositivos.",
    linkCopied: "Enlace copiado",
    copyChartLink: "Copiar enlace a esta carta",
    rendering: "Creando\u2026",
    cardSaved: "Imagen guardada",
    saveChartCard: "Guardar imagen de la carta",
    shareChart: "Comparte tu carta",
    linkToChart: "Enlace a esta carta",
    chartLinkCopied: "Enlace de la carta copiado al portapapeles.",
    chartCardSaved: "Imagen de la carta guardada.",
    cardError: "No se pudo dibujar la imagen en este navegador \u2014 la rueda de arriba tambi\xE9n sirve para una captura.",
    shareNote: "El enlace incluye los datos de nacimiento que ingresaste \u2014 no se nos env\xEDa nada, as\xED que solo las personas a quienes se lo des podr\xE1n abrirlo. La imagen es de 1080\xD71350 y se dibuja en tu dispositivo.",
    needsBirthTime: "Necesita hora de nacimiento",
    yourMoonSign: "Tu signo lunar",
    yourRisingSign: "Tu ascendente",
    moonPhaseAtBirth: "Fase lunar al nacer",
    chartRuler: "Regente de la carta",
    planetSteering: "el planeta que gu\xEDa tu ascendente.",
    aspectsFound: "Aspectos",
    found: "encontrados",
    applying: "aplicativo",
    wholeSignHouses: "casas de signos completos",
    placidusHouses: "casas Placidus",
    engine: "motor v",
    readInOrder: "La lectura, en orden",
    readIntro: "De arriba abajo, como la asimilar\xEDa un astr\xF3logo. Las tablas de arriba son los datos; esto es lo que dicen.",
    readBigThree: "Empieza por los tres grandes",
    readBigThreeBody: "Sol, Luna, ascendente: las tres tarjetas de arriba. Identidad, instinto, presencia. Todo lo que sigue los matiza; nada los sustituye.",
    readRooms: "Planetas, casa por casa",
    readNoHouses: "Sin hora de nacimiento no hay casas, as\xED que cada planeta se lee solo por signo. A\xF1ade la hora y esta secci\xF3n gana sus casas.",
    readAspects: "Los aspectos con m\xE1s peso",
    readWeather: "El clima de la carta",
    readIn: "en",
    today: "hoy",
    todayBySignTitle: "El cielo de hoy, por signo",
    todayBySignPrompt: "Toca tu signo solar para una lectura clara de hoy \u2014 no necesitas la hora de nacimiento.",
    todaySolarNote: "le\xEDdo desde las casas solares de tu signo",
    whyThisReading: "Por qu\xE9 esta lectura",
    todayHoroscopeLink: "hor\xF3scopo en ingl\xE9s",
    or: "o",
    chartSavedBeforeLink: "Guardada en tus cartas. Inicia sesi\xF3n",
    chartSavedLink: "aqu\xED",
    chartSavedAfterLink: "cuando quieras tenerlas en todos tus dispositivos.",
    signedInAs: "Sesi\xF3n iniciada como {email}",
    removeChartConfirm: '\xBFEliminar "{name}" de este dispositivo?',
    compareSavedHeading: "Comparar {a} y {b}",
    compareSavedPitch: "Dos cartas guardadas ya pueden compararse: cada aspecto entre cartas, le\xEDdo con claridad y calculado en este dispositivo.",
    saturnDateHelp: "Solo con la fecha se ubican los a\xF1os de tu retorno. La hora y el lugar afinan las fechas por unos d\xEDas, pero nunca cambian el a\xF1o.",
    saturnReturnHeading: "{ordinal} retorno",
    skyMercuryRetrograde: "Mercurio retr\xF3grado",
    skyMercuryDirect: "Mercurio directo",
    skyPlanetRetrograde: "{planet} retr\xF3grado",
    skyFullMoon: "Luna llena",
    skyNewMoon: "Luna nueva",
    skyMoonOn: "{event} \xB7 {date}",
    skyAsOf: "{date} \xB7 12 UTC",
    skyTickerAria: "Posiciones del cielo para el {date} a las 12:00 UTC",
    moonDiscAria: "Luna, {percent}% iluminada",
    pairingCta: "Leer la combinaci\xF3n de {a} y {b}",
    inviteWith: "Invitar a alguien a comparar con {name}",
    inviteNamedNote: "El enlace incluye los datos de nacimiento de {name} y abre esta p\xE1gina con ese lado completado; no se nos env\xEDa nada. Conviene tener su permiso si no eres t\xFA.",
    transitMiddayUtc: "{date} \xB7 mediod\xEDa UTC",
    planetReturn: "retorno de {planet}",
    natalPlanet: "{planet} natal",
    pfdToday: "Hoy para esta carta",
    pfdComing: "Lo pr\xF3ximo para esta carta",
    pfdYearAhead: "Los pr\xF3ximos doce meses para esta carta",
    pfdYearBusy: "Calculando los pr\xF3ximos doce meses en tu dispositivo \u2014 unos segundos\u2026",
    pfdYearNote: "Calculado a partir de tu carta guardada: fechas exactas para los pr\xF3ximos doce meses.",
    saveYearAheadNote: "En la p\xE1gina de perfil, las cartas guardadas reciben un c\xE1lculo de los pr\xF3ximos doce meses: retorno solar, fechas de J\xFApiter y Saturno, eclipses.",
    recordLabel: "Zona de colecci\xF3n",
    recordOneOfTwelve: "forma parte de las Doce piezas del Registro.",
    recordViewLink: "Ver el registro \u2014 por ahora en ingl\xE9s \u2192",
    recordChartSun: "Tu Sol est\xE1 en {sign}.",
    recordChartBody: "{sign} es una de las Doce, con su propio arte, historia y registro oficial en el Registro.",
    recordChartLink: "Explora el Registro de {sign} \u2192",
    babyDueDate: "Fecha probable de parto",
    babyCompute: "Leer el cielo de la fecha",
    babyNeedDate: "Primero ingresa una fecha probable de parto.",
    babyError: "Algo sali\xF3 mal al calcular el cielo. Int\xE9ntalo de nuevo.",
    babySunHead: "Signo solar \u2014 casi seguro",
    babySunSingle: "Un nacimiento en esta fecha tiene el Sol en",
    babySunNearEdge: "La fecha est\xE1 cerca del borde del signo: si el beb\xE9 nace m\xE1s de un d\xEDa antes o despu\xE9s, puede tener el Sol en",
    babySunNearEdgeTail: "\u2014 la fecha de nacimiento decide.",
    babySunSplitA: "El Sol cambia de signo ese d\xEDa: el beb\xE9 nace con el Sol en",
    babySunSplitOr: "o en",
    babySunSplitTail: "seg\xFAn la hora. El momento exacto del nacimiento decide.",
    babyNoonNote: "signos le\xEDdos al mediod\xEDa en tiempo universal",
    babyMoonHead: "Signo lunar \u2014 uno de varios",
    babyMoonBody: "La Luna cambia de signo cada dos o tres d\xEDas, as\xED que una semana de parto suele abarcar dos o tres signos lunares. Los beb\xE9s nacidos la misma semana pueden tener signos distintos: el d\xEDa y la hora deciden.",
    babyRetroHead: "Retr\xF3grados al nacer",
    babyRetroBody: "estos planetas est\xE1n en su tramo retr\xF3grado alrededor de la fecha. En una carta natal, un planeta retr\xF3grado se lee como m\xE1s interior de lo habitual \u2014 es com\xFAn y no hay nada que corregir.",
    babyRisingHead: "Ascendente \u2014 imposible de saber hasta el minuto",
    babyRisingBody: "El ascendente cambia aproximadamente cada dos horas, as\xED que ninguna fecha probable puede predecirlo. Es la \xFAnica posici\xF3n que tiene que esperar al acta de nacimiento.",
    babyDateLink: "Leer este cumplea\xF1os a fondo",
    babyChartLink: "Despu\xE9s del nacimiento: la carta completa",
    pfdChartPick: "Carta",
    pfdQuietSky: "Un cielo tranquilo para esta carta hoy: nada a menos de 3\xB0 de un punto natal.",
    pfdQuietAhead: "Nada importante en el horizonte de esta carta dentro de la ventana calculada.",
    pfdSaturnBusy: "Calculando las ventanas de Saturno en tu dispositivo\u2026",
    pfdEmptyTitle: "Tu cielo, cuando guardes una carta",
    pfdEmptyBody: "Guarda una carta natal y esta p\xE1gina se abrir\xE1 cada d\xEDa con sus tr\xE1nsitos, sus casas y lo que viene.",
    pfdWindows: "ventanas",
    openChart: "Abrir",
    dignityDomicile: "domicilio",
    dignityExaltation: "exaltaci\xF3n",
    dignityDetriment: "detrimento",
    dignityFall: "ca\xEDda",
    explorerHint: "Toca cualquier planeta, signo, casa o l\xEDnea de aspecto para inspeccionarlo \u2014 o enfoca la rueda y usa las flechas.",
    explorerLabel: "Carta natal interactiva",
    explorerSelectPart: "Elige una parte de la carta",
    explorerNoSelection: "Sin selecci\xF3n",
    explorerAngles: "\xC1ngulos",
    explorerControlsLoading: "Cargando las interpretaciones y los controles de la carta\u2026",
    explorerControlsError: "Tu carta est\xE1 lista, pero sus interpretaciones y controles no se pudieron cargar. Comprueba tu conexi\xF3n e int\xE9ntalo de nuevo.",
    explorerKeyHint: "Las flechas izquierda y derecha recorren las posiciones; Intro abre el panel de detalles.",
    selectionCleared: "Selecci\xF3n borrada.",
    inspectorClose: "Cerrar detalles",
    speed: "Velocidad",
    day: "d\xEDa",
    dignity: "Dignidad",
    separating: "separativo",
    dates: "Fechas",
    element: "Elemento",
    ruler: "Regente",
    inThisSign: "En este signo",
    inThisHouse: "En esta casa",
    cusp: "C\xFAspide",
    span: "Extensi\xF3n",
    emptyHouseNote: "No hay planetas aqu\xED. Una casa vac\xEDa no est\xE1 en blanco \u2014 sus temas se expresan a trav\xE9s del planeta que la rige.",
    angleAscNote: "El Ascendente \u2014 el grado que sub\xEDa por el horizonte oriental al momento de nacer. Ancla toda la rueda.",
    angleDscNote: "El Descendente \u2014 el grado que se pon\xEDa por el oeste, opuesto al Ascendente. La puerta tradicional hacia los v\xEDnculos.",
    angleMcNote: "El Medio Cielo \u2014 el grado que culminaba en lo alto al nacer. Carrera, reputaci\xF3n, la vida visible.",
    angleIcNote: "El IC \u2014 el punto m\xE1s bajo de la rueda, opuesto al Medio Cielo. Hogar, ra\xEDces, la vida privada.",
    layersLabel: "Capas de la carta",
    layerHouses: "Casas",
    editedBy: "Publicado por",
    tourStart: "Hacer el recorrido",
    firstReadingLabel: "Tu lectura de 2 minutos",
    firstReadingTitle: "\xBFQu\xE9 dice tu carta sobre ti \u2014 y qu\xE9 viene despu\xE9s?",
    firstReadingBody: "Descubre tu mezcla de personalidad, d\xF3nde se manifiesta, un patr\xF3n que quiz\xE1 reconozcas y c\xF3mo la astrolog\xEDa convierte una carta natal en un pron\xF3stico.",
    firstReadingResumeTitle: "Tu lectura te est\xE1 esperando",
    firstReadingResumeBody: "Contin\xFAa donde la dejaste en este dispositivo.",
    firstReadingStart: "Leer mi carta",
    firstReadingExplore: "Explorar por mi cuenta",
    firstReadingResume: "Continuar mi lectura",
    firstReadingStep: "Paso",
    firstReadingFullTour: "Ver c\xF3mo funciona la carta \u2014 recorrido avanzado",
    firstReadingReplay: "Volver a leer la historia de mi carta",
    chartActionsMore: "M\xE1s formas de usar esta carta",
    chartReceiptDownload: "Descargar el registro del c\xE1lculo (.json)",
    chartReceiptPrivacy: "Este archivo contiene datos de nacimiento sensibles y datos de la carta. Mantenlo privado.",
    chartReceiptError: "No se pudo descargar el archivo. Int\xE9ntalo de nuevo.",
    chartReceiptUnavailable: "No hay un registro del c\xE1lculo disponible para esta carta.",
    seeTodaySky: "Ver el cielo de hoy",
    contextHelpCue: "Toca los t\xE9rminos subrayados con puntos para ver una explicaci\xF3n sencilla.",
    editorialHow: "normas editoriales",
    dstGapNotice: "Esa hora cay\xF3 dentro de un salto por horario de verano, as\xED que no existi\xF3 exactamente \u2014 la movimos hacia adelante, la convenci\xF3n est\xE1ndar.",
    dstFoldNotice: "Los relojes repitieron esa hora donde naciste; usamos la primera pasada. Si sabes que fue la segunda, tu carta casi no cambia \u2014 la Luna avanza cerca de medio grado por hora.",
    lmtNotice: "Naciste antes de las zonas horarias estandarizadas \u2014 usamos hora media local para esa \xE9poca, la misma convenci\xF3n que usa el software profesional.",
    polarNotice: "Las casas Placidus no est\xE1n definidas tan cerca del polo, as\xED que esta carta usa signos completos.",
    noTimeNotice: "Sin hora de nacimiento usamos las 12:00 del tiempo civil local como referencia y omitimos ascendente, \xE1ngulos y casas.",
    moonAmbiguousNotice: "La Luna tambi\xE9n cambi\xF3 de signo ese d\xEDa \u2014 leer los dos signos vecinos es razonable hasta encontrar la hora.",
    fromLinkNotice: "Abierta desde un enlace compartido \u2014 los datos ven\xEDan en el enlace y la carta se calcul\xF3 ahora en tu dispositivo.",
    howWeCompute: "C\xF3mo calculamos",
    welcomeBack: "Hola de nuevo.",
    savedChartAria: "Tu carta guardada",
    todayAgainstChart: "El cielo de hoy sobre tu carta",
    yourCharts: "Tus cartas",
    recommendedNext: "Siguiente paso recomendado",
    todayForName: "Descubre qu\xE9 significa hoy para {name}",
    savedChartTodayBody: "Tu carta no cambia. El cielo de hoy s\xED: empieza por lo que est\xE1 cambiando para ti ahora.",
    openSavedChart: "Abrir carta guardada",
    moonReadingSky: "Leyendo el cielo\u2026",
    illuminated: "iluminada",
    moonIn: "Luna en",
    findThatMoon: "Encontrar esa Luna",
    dateHelp: "Un cumplea\xF1os, un aniversario, cualquier fecha.",
    placeHelpMoon: "Afina la conversi\xF3n de hora; la fase casi no lo necesita.",
    middayLocalCaption: "Lectura al mediod\xEDa local \u2014 agregar la hora exacta fija el grado.",
    utcTimeCaption: "La hora se lee como tiempo universal \u2014 agrega un lugar para convertir tu hora local.",
    middayUtcCaption: "Lectura al mediod\xEDa universal \u2014 una hora y un lugar fijan el grado.",
    moonChangedNotice: "La Luna cambi\xF3 de signo ese d\xEDa, y sin hora no podemos saber de qu\xE9 lado naciste. La fase no cambia: se mueve demasiado lento para que unas horas importen.",
    birthChartForDate: "Obtener la carta natal de esta fecha",
    natalSaturn: "Tu Saturno natal",
    addBirthDetails: "Agregar hora y lugar de nacimiento (opcional)",
    findSaturnReturn: "Encuentra tu retorno de Saturno",
    returnApprox: "Fechas calculadas desde una lectura al mediod\xEDa \u2014 con hora y lugar de nacimiento pueden moverse unos d\xEDas.",
    complete: "Completo",
    underwayNow: "En curso",
    aheadOfYou: "Por delante",
    first: "Primer",
    second: "Segundo",
    third: "Tercer",
    fourth: "Cuarto",
    aroundAge29: "cerca de los 29",
    aroundAge58: "cerca de los 58",
    aroundAge88: "cerca de los 88",
    retrogradePass: "pasada retr\xF3grada",
    threePasses: "Tres pasadas exactas: Saturno cruza tu grado, vuelve a cruzarlo durante la retrogradaci\xF3n y luego lo sella al salir. Todo ese per\xEDodo es el retorno.",
    seeSaturnChart: "Ver Saturno en tu carta natal",
    whatSaturnMeans: "Qu\xE9 significa Saturno",
    yourChart: "Tu carta",
    theSky: "El cielo",
    transitRingLede: "Dibuja tu carta y mueve el control de la fecha para ver los planetas viajar sobre ella \u2014 hacia adelante o atr\xE1s, hasta un a\xF1o.",
    checkTransits: "Revisa tus tr\xE1nsitos",
    savedChartHelp: "Las cartas que calcules y guardes aparecer\xE1n aqu\xED como opciones de un toque, para que la pr\xF3xima revisi\xF3n sea m\xE1s r\xE1pida.",
    noTransitTimeNotice: "Esta carta no tiene hora de nacimiento, as\xED que su Luna es una estimaci\xF3n al mediod\xEDa \u2014 puede variar hasta seis grados, y un tr\xE1nsito a la Luna cerca del borde del orbe puede aparecer o desaparecer con la hora real.",
    skyAt: "Cielo en",
    noTransitsWithin: "No hay tr\xE1nsitos dentro de",
    activeTransitsWithin: "tr\xE1nsitos activos a menos de",
    activeTransitWithin: "tr\xE1nsito activo a menos de",
    ofExact: "de exactitud",
    transitMoonOmitted: "Luna en tr\xE1nsito omitida \u2014 cruza toda la carta cada mes",
    quietSky: "Cielo tranquilo con el orbe estrecho de esta p\xE1gina. Nada urgente \u2014 vuelve en unos d\xEDas o ampl\xEDa la lectura con los eventos del mes abajo.",
    natal: "natal",
    forYourChart: "Para tu carta",
    orb: "orbe",
    openDailyBrief: "Abrir mi resumen diario completo",
    allTransits: "Todos tus tr\xE1nsitos",
    personA: "Persona A",
    personB: "Persona B",
    sharedChart: "Carta compartida",
    sharedWithYou: "compartida contigo",
    removeSharedChart: "Eliminar la carta compartida",
    sharedSideHelp: "Este lado lleg\xF3 en el enlace \u2014 b\xF3rralo para ingresar los datos de otra persona.",
    name: "Nombre",
    compareCharts: "Comparar las cartas",
    sameChart: "Es la misma carta dos veces \u2014 elige dos distintas.",
    compareSavedHelp: "Las cartas que calcules y guardes aparecer\xE1n aqu\xED como opciones de un toque, as\xED la segunda comparaci\xF3n ser\xE1 m\xE1s r\xE1pida que la primera.",
    compareNoTimeNotice: "Sin hora de nacimiento para",
    moonMiddayEstimate: "as\xED que esa Luna es una estimaci\xF3n al mediod\xEDa \u2014 puede variar hasta seis grados, y un aspecto lunar cerca del borde del orbe puede aparecer o desaparecer con la hora real.",
    crossChartAspects: "aspectos entre cartas",
    easeful: "fluidos",
    charged: "tensos",
    readPairing: "Leer la combinaci\xF3n",
    inviteCompare: "Invitar a alguien a comparar",
    inviteLink: "Enlace de invitaci\xF3n",
    inviteNote: "El enlace incluye los datos de nacimiento de esta persona y abre esta p\xE1gina con ese lado lleno \u2014 no se nos env\xEDa nada. Conviene tener su permiso si no eres t\xFA.",
    inviteCopied: "Enlace de invitaci\xF3n copiado al portapapeles.",
    syncOn: "Sincronizaci\xF3n activa",
    keepEveryDevice: "Lleva tus cartas a todos tus dispositivos",
    signedIn: "Sesi\xF3n iniciada",
    syncCopyOn: "Las cartas guardadas y las eliminaciones se sincronizan entre dispositivos.",
    syncCopyOff: "Guarda cartas en este dispositivo. Inicia sesi\xF3n cuando quieras tenerlas en todos tus dispositivos.",
    weeklyDigestTitle: "Email semanal del cielo",
    weeklyDigestCopy: "Un email por semana: el cielo sobre tus cartas guardadas. Puedes darte de baja cuando quieras.",
    weeklyDigestAria: "Activar email semanal",
    digestSaved: "Preferencia del resumen guardada.",
    digestFailed: "No se pudo actualizar la preferencia del resumen. Int\xE9ntalo otra vez.",
    checkEmail: "Revisa tu email para entrar. Esta p\xE1gina se sincronizar\xE1 cuando vuelvas.",
    syncFailed: "La sincronizaci\xF3n fall\xF3. Int\xE9ntalo otra vez.",
    syncing: "Sincronizando\u2026",
    synced: "Sincronizado",
    syncNow: "Sincronizar ahora",
    signOut: "Cerrar sesi\xF3n",
    emailSyncAria: "Email para sincronizar perfil",
    sending: "Enviando\u2026",
    sendSignIn: "Enviar enlace de acceso",
    nothingSaved: "A\xFAn no hay nada guardado.",
    emptyProfile: "Las cartas que guardes vivir\xE1n aqu\xED, primero en este dispositivo. Calcula una carta y toca Guardar esta carta para empezar.",
    saved: "guardadas",
    chartSingular: "carta",
    chartPlural: "cartas",
    savedChartSingular: "carta guardada",
    savedChartPlural: "cartas guardadas",
    syncedWhenSignedIn: "con sincronizaci\xF3n activa",
    storedBrowser: "en este navegador",
    chartName: "Nombre de la carta",
    timeUnknown: "hora desconocida",
    needsTime: "necesita hora",
    compareThese: "Comparar estas dos cartas",
    addAnotherChart: "Agregar otra carta",
    ...GROWTH_UI_ES
  };
  var es_default = es;

  // src/lib/i18n/ui/pt.ts
  init_define_import_meta_env();
  var pt = {
    chartDepthOpen: "Ver em tr\xEAs dimens\xF5es",
    chartDepthClose: "Ocultar a terceira dimens\xE3o",
    calculationLoadError: "N\xE3o foi poss\xEDvel carregar os arquivos de c\xE1lculo. Verifique sua conex\xE3o e tente novamente.",
    calculationReload: "Recarregar p\xE1gina",
    calculationReloadWarning: "Recarregar apaga os dados que voc\xEA n\xE3o salvou.",
    calculationRetry: "Tentar novamente",
    pfdYearError: "N\xE3o foi poss\xEDvel concluir a leitura do pr\xF3ximo ano. Tente novamente.",
    placeSearching: "Buscando lugares\u2026",
    chartWheelActions: "A\xE7\xF5es do mapa",
    chartWheelGuide: "Fazer o tour guiado",
    chartWheelReplay: "Repetir o tour",
    chartWheelAnother: "Ler outro mapa",
    chartWheelSignatureSelf: "A assinatura do seu mapa",
    chartWheelSignatureOther: "A assinatura deste mapa",
    chartWheelCompareMine: "Comparar com o meu",
    chartWheelCompareAdd: "Adicionar meu mapa para comparar",
    chartWheelShareOther: "Compartilhar este mapa",
    navPrimary: "Principal",
    navSigns: "Signos",
    navTools: "Ferramentas",
    navLearn: "Aprenda",
    navHoroscopes: "Hor\xF3scopos",
    navCollect: "Astrofolio",
    navSavedCharts: "Mapas salvos",
    navMenu: "Menu",
    navSite: "O site",
    navTwelve: "Os Doze",
    footerTag: "Ferramentas gratuitas de astrologia e guias dos signos, com mapas calculados de forma privada no seu navegador.",
    footerStartHere: "Comece aqui",
    footerPlanets: "Os planetas",
    footerHouses: "As casas",
    footerZodiacDates: "Datas dos signos",
    footerGlossary: "Gloss\xE1rio",
    footerCompute: "Como calculamos",
    footerRegistry: "Registry",
    footerThesis: "Tese",
    footerArchive: "Acervo",
    footerSdk: "SDK",
    footerCollectNote: "Os registros, as consultas, os perfis do cat\xE1logo e o SDK do Registry s\xE3o somente para leitura. A ferramenta opcional de compra do Astrofolio usa a Jupiter independente e a sua pr\xF3pria carteira; a Zodiacs.org n\xE3o guarda chaves nem fundos. Nada disso constitui aconselhamento financeiro.",
    footerMethodology: "Metodologia",
    footerAbout: "Sobre",
    footerPrivacy: "Privacidade",
    footerTerms: "Termos",
    footerPlaceData: "Dados de lugares",
    footerFonts: "Fontes sob a licen\xE7a",
    skipContent: "Pular para o conte\xFAdo",
    open: "Abrir",
    birthChart: "Mapa astral",
    compatibility: "Compatibilidade",
    moonSign: "Signo lunar",
    risingSign: "Ascendente",
    moonPhase: "Fase da Lua",
    saturnReturn: "Retorno de Saturno",
    transits: "Tr\xE2nsitos",
    birthday: "Anivers\xE1rio (em ingl\xEAs)",
    retrogrades: "Retr\xF3grados",
    sun: "Sol",
    moon: "Lua",
    rising: "Ascendente",
    body: "Corpo celeste",
    position: "Posi\xE7\xE3o",
    sign: "Signo",
    house: "Casa",
    chart: "Mapa",
    date: "Data",
    time: "Hora",
    place: "Local",
    motion: "Movimento",
    optional: "opcional",
    birthDate: "Data de nascimento",
    birthTime: "Hora de nascimento",
    birthplace: "Local de nascimento",
    birthDateRequired: "Informe sua data de nascimento.",
    birthDateRange: "Escolha uma data de nascimento entre 1800 e 2199.",
    birthTimeRequired: "Informe seu hor\xE1rio de nascimento.",
    houseSystem: "Sistema de casas",
    wholeSignDefault: "Signos inteiros (padr\xE3o)",
    placidus: "Placidus",
    houseSystemHelp: "Como o mapa se divide em doze \xE1reas da vida. Signos inteiros d\xE1 a cada signo uma casa inteira; Placidus varia o tamanho das casas conforme a hora e o lugar exatos. Os planetas n\xE3o se movem: s\xF3 mudam os limites das casas.",
    computing: "Calculando\u2026",
    checking: "Verificando\u2026",
    comparing: "Comparando\u2026",
    save: "Salvar",
    rename: "Renomear",
    remove: "Remover",
    getBirthChart: "Fa\xE7a seu mapa astral gr\xE1tis",
    findMoonSign: "Descubra seu signo lunar",
    findRisingSign: "Descubra seu ascendente",
    savedCharts: "Mapas salvos",
    profile: "Seu perfil",
    read: "Ler",
    rightNow: "Agora",
    enterBirthDetails: "Informe os dados de nascimento\u2026",
    privacyDevice: "Privado por padr\xE3o. Seus dados de nascimento permanecem neste navegador.",
    placePlaceholder: "Comece a digitar uma cidade\u2026",
    placeChange: "Alterar local de nascimento",
    placePickHint: "Escolha seu local de nascimento na lista.",
    placeNoResults: "N\xE3o aparece? Escolha a cidade mais pr\xF3xima \u2014 poucos quil\xF4metros raramente mudam o mapa.",
    placeError: "N\xE3o foi poss\xEDvel carregar o \xEDndice de lugares \u2014 verifique sua conex\xE3o e tente de novo.",
    searchGeo: "A busca cobre cerca de 34.000 lugares \xB7 GeoNames (CC BY 4.0)",
    chartError: "Algo deu errado ao calcular o mapa. Tente de novo.",
    moonError: "Algo deu errado ao calcular a Lua. Tente de novo.",
    localDateReferenceError: "N\xE3o foi poss\xEDvel estabelecer um hor\xE1rio de c\xE1lculo dentro desta data local. Verifique a data e o local.",
    returnError: "Algo deu errado ao calcular o retorno. Tente de novo.",
    transitError: "Algo deu errado ao calcular os tr\xE2nsitos. Tente de novo.",
    compareError: "Algo deu errado ao comparar os mapas. Tente de novo.",
    noBirthTime: "N\xE3o sei",
    risingTimeHelp: "O ascendente muda a cada duas horas \u2014 aqui, o hor\xE1rio importa.",
    chartTimeHelp: "N\xE3o sabe a hora? Voc\xEA ver\xE1 uma refer\xEAncia ao meio-dia local, sem ascendente nem casas; a Lua pode ser incerta.",
    chartSavedDevice: "Salvo \xB7 neste dispositivo",
    saveThisChart: "Salvar este mapa",
    chartSavedStatus: "Mapa salvo neste dispositivo.",
    chartSaveFull: "Voc\xEA pode salvar at\xE9 40 mapas \u2014 remova um primeiro.",
    chartSaveError: "N\xE3o foi poss\xEDvel salvar \u2014 talvez seu navegador esteja bloqueando o armazenamento local.",
    chartSavedMessage: "Salvo nos seus mapas. Entre aqui quando quiser acess\xE1-los em todos os dispositivos.",
    linkCopied: "Link copiado",
    copyChartLink: "Copiar o link deste mapa",
    rendering: "Criando\u2026",
    cardSaved: "Imagem salva",
    saveChartCard: "Salvar uma imagem do mapa",
    shareChart: "Compartilhe seu mapa",
    linkToChart: "Link para este mapa",
    chartLinkCopied: "Link do mapa copiado para a \xE1rea de transfer\xEAncia.",
    chartCardSaved: "Imagem do mapa salva.",
    cardError: "N\xE3o foi poss\xEDvel criar a imagem neste navegador \u2014 voc\xEA tamb\xE9m pode capturar a roda acima.",
    shareNote: "O link inclui os dados de nascimento que voc\xEA informou \u2014 nada \xE9 enviado a n\xF3s, ent\xE3o somente as pessoas com quem voc\xEA o compartilhar poder\xE3o abri-lo. A imagem tem 1080\xD71350 e \xE9 criada no seu dispositivo.",
    needsBirthTime: "Precisa da hora de nascimento",
    yourMoonSign: "Seu signo lunar",
    yourRisingSign: "Seu ascendente",
    moonPhaseAtBirth: "Fase da Lua no nascimento",
    chartRuler: "Regente do mapa",
    planetSteering: "o planeta que rege seu ascendente.",
    aspectsFound: "Aspectos",
    found: "no total",
    applying: "aplicativo",
    wholeSignHouses: "Casas de signos inteiros",
    placidusHouses: "Casas de Placidus",
    engine: "motor v",
    readInOrder: "A leitura, em ordem",
    readIntro: "De cima para baixo, como um astr\xF3logo faria a leitura. As tabelas acima trazem os dados; aqui est\xE1 o que eles dizem.",
    readBigThree: "Comece pelo trio principal",
    readBigThreeBody: "Sol, Lua e ascendente \u2014 os tr\xEAs cart\xF5es no topo. Identidade, instinto, presen\xE7a. Tudo abaixo acrescenta nuances; nada os substitui.",
    readRooms: "Planetas, casa por casa",
    readNoHouses: "Sem a hora de nascimento, n\xE3o h\xE1 casas, ent\xE3o cada planeta \xE9 lido apenas pelo signo. Adicione a hora e esta se\xE7\xE3o ganha suas casas.",
    readAspects: "Os aspectos com mais peso",
    readWeather: "O clima do mapa",
    readIn: "em",
    today: "hoje",
    todayBySignTitle: "O c\xE9u de hoje, por signo",
    todayBySignPrompt: "Toque no seu signo solar para uma leitura clara de hoje \u2014 n\xE3o \xE9 preciso saber a hora de nascimento.",
    todaySolarNote: "lido pelas casas solares do seu signo",
    whyThisReading: "Por que esta leitura",
    todayHoroscopeLink: "hor\xF3scopo",
    or: "ou",
    chartSavedBeforeLink: "Salvo nos seus mapas. Entre",
    chartSavedLink: "aqui",
    chartSavedAfterLink: "quando quiser acess\xE1-los em todos os dispositivos.",
    signedInAs: "Sess\xE3o iniciada como {email}",
    removeChartConfirm: "Remover \u201C{name}\u201D deste dispositivo?",
    compareSavedHeading: "Compare {a} e {b}",
    compareSavedPitch: "Dois mapas salvos pedem uma compara\xE7\xE3o: todos os aspectos entre eles, lidos com clareza e calculados neste dispositivo.",
    saturnDateHelp: "S\xF3 a data define os anos do seu retorno. Hora e local refinam as datas em alguns dias, nunca o ano.",
    saturnReturnHeading: "{ordinal} retorno",
    skyMercuryRetrograde: "Merc\xFArio retr\xF3grado",
    skyMercuryDirect: "Merc\xFArio direto",
    skyPlanetRetrograde: "{planet} retr\xF3grado",
    skyFullMoon: "Lua cheia",
    skyNewMoon: "Lua nova",
    skyMoonOn: "{event} \xB7 {date}",
    skyAsOf: "{date} \xB7 12h UTC",
    skyTickerAria: "Posi\xE7\xF5es no c\xE9u em {date}, \xE0s 12h UTC",
    moonDiscAria: "Lua, {percent}% iluminada",
    pairingCta: "Leia a combina\xE7\xE3o entre {a} e {b}",
    inviteWith: "Convide algu\xE9m para comparar com {name}",
    inviteNamedNote: "O link inclui os dados de nascimento de {name} e abre esta p\xE1gina com esse lado preenchido \u2014 nada \xE9 enviado a n\xF3s. Se n\xE3o for voc\xEA, vale pedir permiss\xE3o.",
    transitMiddayUtc: "{date} \xB7 meio-dia UTC",
    planetReturn: "Retorno de {planet}",
    natalPlanet: "{planet} natal",
    pfdToday: "Hoje para este mapa",
    pfdComing: "O que vem por a\xED para este mapa",
    pfdYearAhead: "Os pr\xF3ximos doze meses para este mapa",
    pfdYearBusy: "Calculando os pr\xF3ximos doze meses no seu dispositivo \u2014 s\xF3 alguns segundos\u2026",
    pfdYearNote: "Calculado a partir do seu mapa salvo: datas exatas para os pr\xF3ximos doze meses.",
    saveYearAheadNote: "No perfil, os mapas salvos mostram os pr\xF3ximos doze meses calculados \u2014 retorno solar, datas de J\xFApiter e Saturno e contatos com eclipses.",
    recordLabel: "Ala do acervo",
    recordOneOfTwelve: "tamb\xE9m integra os Doze \u2014 um registro can\xF4nico no acervo.",
    recordViewLink: "Ver o registro \u2014 por enquanto em ingl\xEAs \u2192",
    recordChartSun: "Seu Sol est\xE1 em {sign}.",
    recordChartBody: "{sign} \xE9 um dos Doze, com arte, hist\xF3ria e registro oficial pr\xF3prios.",
    recordChartLink: "Explore o Registro de {sign} \u2192",
    babyDueDate: "Data prevista do parto",
    babyCompute: "Ler o c\xE9u da data prevista",
    babyNeedDate: "Informe primeiro uma data prevista.",
    babyError: "Algo deu errado ao calcular o c\xE9u. Tente de novo.",
    babySunHead: "Signo solar \u2014 quase certo",
    babySunSingle: "Um nascimento nesta data ter\xE1 o Sol em",
    babySunNearEdge: "A data fica perto da transi\xE7\xE3o de signo, ent\xE3o nascer mais de um dia antes ou depois pode levar o Sol para",
    babySunNearEdgeTail: "\u2014 a data do nascimento \xE9 que decide.",
    babySunSplitA: "O Sol muda de signo nesta data: o beb\xEA nasce com o Sol em",
    babySunSplitOr: "ou",
    babySunSplitTail: "dependendo do hor\xE1rio. O momento exato do nascimento decide.",
    babyNoonNote: "signos lidos ao meio-dia no hor\xE1rio universal",
    babyMoonHead: "Signo lunar \u2014 uma entre poucas possibilidades",
    babyMoonBody: "A Lua muda de signo a cada dois ou tr\xEAs dias, ent\xE3o a semana prevista para o parto costuma abranger dois ou tr\xEAs signos lunares. Beb\xEAs que nascem na mesma semana podem ter signos lunares diferentes \u2014 o dia e a hora do nascimento decidem.",
    babyRetroHead: "Retr\xF3grados no nascimento",
    babyRetroBody: "esses planetas estar\xE3o em movimento retr\xF3grado perto da data prevista. Em um mapa astral, um planeta retr\xF3grado tende a se expressar de forma mais interiorizada \u2014 \xE9 comum e n\xE3o h\xE1 nada a corrigir.",
    babyRisingHead: "Ascendente \u2014 imposs\xEDvel saber antes do minuto exato",
    babyRisingBody: "O ascendente muda aproximadamente a cada duas horas, ent\xE3o nenhuma data prevista permite saber qual ser\xE1. \xC9 o \xFAnico posicionamento que s\xF3 pode ser conhecido depois que a hora do nascimento for registrada.",
    babyDateLink: "Leia esta data de anivers\xE1rio em detalhes",
    babyChartLink: "Depois do nascimento: o mapa completo",
    pfdChartPick: "Mapa",
    pfdQuietSky: "Um c\xE9u tranquilo para este mapa hoje \u2014 nada a menos de 3\xB0 de um ponto natal.",
    pfdQuietAhead: "Nada importante no horizonte deste mapa dentro do per\xEDodo calculado.",
    pfdSaturnBusy: "Calculando as janelas de Saturno no seu dispositivo\u2026",
    pfdEmptyTitle: "Seu c\xE9u, depois que voc\xEA salvar um mapa",
    pfdEmptyBody: "Salve um mapa astral e esta p\xE1gina abrir\xE1 todos os dias com os tr\xE2nsitos, as casas e o que vem pela frente.",
    pfdWindows: "janelas",
    openChart: "Abrir",
    dignityDomicile: "domic\xEDlio",
    dignityExaltation: "exalta\xE7\xE3o",
    dignityDetriment: "detrimento",
    dignityFall: "queda",
    explorerHint: "Toque em qualquer planeta, signo, casa ou linha de aspecto para ver os detalhes \u2014 ou selecione a roda e use as setas do teclado.",
    explorerLabel: "Mapa astral interativo",
    explorerSelectPart: "Escolha uma parte do mapa",
    explorerNoSelection: "Nenhuma sele\xE7\xE3o",
    explorerAngles: "\xC2ngulos",
    explorerControlsLoading: "Carregando as interpreta\xE7\xF5es e os controles do mapa\u2026",
    explorerControlsError: "Seu mapa est\xE1 pronto, mas as interpreta\xE7\xF5es e os controles n\xE3o puderam ser carregados. Verifique sua conex\xE3o e tente novamente.",
    explorerKeyHint: "As setas para a esquerda e para a direita percorrem as posi\xE7\xF5es; Enter abre o painel de detalhes.",
    selectionCleared: "Sele\xE7\xE3o desfeita.",
    inspectorClose: "Fechar detalhes",
    speed: "Velocidade",
    day: "dia",
    dignity: "Dignidade",
    separating: "separativo",
    dates: "Datas",
    element: "Elemento",
    ruler: "Regente",
    inThisSign: "Neste signo",
    inThisHouse: "Nesta casa",
    cusp: "C\xFAspide",
    span: "Extens\xE3o",
    emptyHouseNote: "N\xE3o h\xE1 planetas aqui. Uma casa vazia n\xE3o est\xE1 em branco \u2014 seus temas se expressam por meio do planeta que a rege.",
    angleAscNote: "O Ascendente \u2014 o grau que surgia no horizonte leste no momento do nascimento. Ele ancora toda a roda.",
    angleDscNote: "O Descendente \u2014 o grau que se punha no oeste, oposto ao Ascendente. A porta tradicional para os relacionamentos.",
    angleMcNote: "O Meio do C\xE9u \u2014 o grau que culminava no alto no momento do nascimento. Carreira, reputa\xE7\xE3o, a vida vis\xEDvel.",
    angleIcNote: "O Fundo do C\xE9u \u2014 o ponto mais baixo da roda, oposto ao Meio do C\xE9u. Lar, ra\xEDzes, a vida privada.",
    layersLabel: "Camadas do mapa",
    layerHouses: "Casas",
    editedBy: "Publicado por",
    tourStart: "Iniciar o passeio",
    firstReadingLabel: "Sua leitura de 2 minutos",
    firstReadingTitle: "O que seu mapa diz sobre voc\xEA \u2014 e o que vem depois?",
    firstReadingBody: "Veja sua mistura de personalidade, onde ela aparece, um padr\xE3o que voc\xEA talvez reconhe\xE7a e como a astrologia transforma um mapa natal em previs\xE3o.",
    firstReadingResumeTitle: "Sua leitura est\xE1 esperando",
    firstReadingResumeBody: "Continue de onde parou neste dispositivo.",
    firstReadingStart: "Ler meu mapa",
    firstReadingExplore: "Explorar por conta pr\xF3pria",
    firstReadingResume: "Continuar minha leitura",
    firstReadingStep: "Etapa",
    firstReadingFullTour: "Ver como o mapa funciona \u2014 passeio avan\xE7ado",
    firstReadingReplay: "Rever a hist\xF3ria do meu mapa",
    chartActionsMore: "Mais formas de usar este mapa",
    chartReceiptDownload: "Baixar o registro do c\xE1lculo (.json)",
    chartReceiptPrivacy: "Este arquivo cont\xE9m dados de nascimento sens\xEDveis e dados do mapa. Mantenha-o privado.",
    chartReceiptError: "N\xE3o foi poss\xEDvel baixar o arquivo. Tente novamente.",
    chartReceiptUnavailable: "N\xE3o h\xE1 um registro do c\xE1lculo dispon\xEDvel para este mapa.",
    seeTodaySky: "Ver o c\xE9u de hoje",
    contextHelpCue: "Toque nos termos sublinhados com pontos para ver uma explica\xE7\xE3o simples.",
    editorialHow: "princ\xEDpios editoriais",
    dstGapNotice: "Esse hor\xE1rio caiu no avan\xE7o para o hor\xE1rio de ver\xE3o e, por isso, nunca existiu \u2014 avan\xE7amos para depois desse intervalo, como manda a conven\xE7\xE3o padr\xE3o.",
    dstFoldNotice: "Os rel\xF3gios repetiram essa hora no seu local de nascimento; usamos a primeira ocorr\xEAncia. Se voc\xEA sabe que foi a segunda, seu mapa quase n\xE3o muda \u2014 a Lua avan\xE7a cerca de meio grau por hora.",
    lmtNotice: "Voc\xEA nasceu antes da padroniza\xE7\xE3o dos fusos hor\xE1rios \u2014 usamos a hora m\xE9dia local daquela \xE9poca, a mesma conven\xE7\xE3o dos programas profissionais.",
    polarNotice: "As casas de Placidus n\xE3o s\xE3o definidas t\xE3o perto do polo, ent\xE3o este mapa usa casas de signos inteiros.",
    noTimeNotice: "Sem a hora de nascimento, usamos 12:00 no hor\xE1rio civil local como refer\xEAncia e omitimos ascendente, \xE2ngulos e casas.",
    moonAmbiguousNotice: "A Lua tamb\xE9m mudou de signo nesse dia \u2014 \xE9 razo\xE1vel ler os dois signos vizinhos at\xE9 voc\xEA descobrir a hora.",
    fromLinkNotice: "Aberto por um link compartilhado \u2014 os dados de nascimento vieram no pr\xF3prio link, e o mapa acaba de ser calculado no seu dispositivo.",
    howWeCompute: "Como calculamos",
    welcomeBack: "Que bom ter voc\xEA de volta.",
    savedChartAria: "Seu mapa salvo",
    todayAgainstChart: "O c\xE9u de hoje sobre seu mapa",
    yourCharts: "Seus mapas",
    recommendedNext: "Pr\xF3ximo passo recomendado",
    todayForName: "Veja o que hoje significa para {name}",
    savedChartTodayBody: "Seu mapa n\xE3o muda. O c\xE9u de hoje muda \u2014 comece pelo que est\xE1 se transformando para voc\xEA agora.",
    openSavedChart: "Abrir mapa salvo",
    moonReadingSky: "Lendo o c\xE9u\u2026",
    illuminated: "iluminada",
    moonIn: "Lua em",
    findThatMoon: "Encontrar essa Lua",
    dateHelp: "Um anivers\xE1rio, uma data especial, qualquer data.",
    placeHelpMoon: "Refina a convers\xE3o do hor\xE1rio; a fase quase n\xE3o precisa disso.",
    middayLocalCaption: "Leitura ao meio-dia local \u2014 adicionar a hora exata define o grau.",
    utcTimeCaption: "A hora \xE9 interpretada como hor\xE1rio universal \u2014 adicione um local de nascimento para converter seu hor\xE1rio local.",
    middayUtcCaption: "Leitura ao meio-dia no hor\xE1rio universal \u2014 uma hora e um local definem o grau exato.",
    moonChangedNotice: "A Lua mudou de signo nesse dia e, sem a hora, n\xE3o podemos saber em qual signo ela estava quando voc\xEA nasceu. A fase n\xE3o \xE9 afetada \u2014 ela se move devagar demais para que algumas horas fa\xE7am diferen\xE7a.",
    birthChartForDate: "Fazer o mapa astral desta data",
    natalSaturn: "Seu Saturno natal",
    addBirthDetails: "Adicionar hora e local de nascimento (opcional)",
    findSaturnReturn: "Encontre seu retorno de Saturno",
    returnApprox: "Datas calculadas a partir de uma leitura ao meio-dia \u2014 com hora e local de nascimento, podem variar alguns dias para um lado ou para o outro.",
    complete: "Conclu\xEDdo",
    underwayNow: "Em andamento",
    aheadOfYou: "Mais adiante",
    first: "Primeiro",
    second: "Segundo",
    third: "Terceiro",
    fourth: "Quarto",
    aroundAge29: "por volta dos 29 anos",
    aroundAge58: "por volta dos 58 anos",
    aroundAge88: "por volta dos 88 anos",
    retrogradePass: "passagem retr\xF3grada",
    threePasses: "Tr\xEAs passagens exatas: Saturno cruza seu grau, volta sobre ele em movimento retr\xF3grado e passa por ele uma \xFAltima vez ao seguir adiante. Todo esse per\xEDodo forma o retorno.",
    seeSaturnChart: "Ver Saturno no seu mapa astral",
    whatSaturnMeans: "O que Saturno significa",
    yourChart: "Seu mapa",
    theSky: "O c\xE9u",
    transitRingLede: "Monte seu mapa e mova o controle de data para ver os planetas transitarem sobre ele \u2014 para a frente ou para tr\xE1s, por at\xE9 um ano.",
    checkTransits: "Ver seus tr\xE2nsitos",
    savedChartHelp: "Os mapas que voc\xEA calcular e salvar aparecer\xE3o aqui como atalhos, para que a pr\xF3xima consulta dispense a digita\xE7\xE3o.",
    noTransitTimeNotice: "Este mapa n\xE3o tem hora de nascimento, ent\xE3o a posi\xE7\xE3o da Lua \xE9 uma estimativa para o meio-dia \u2014 ela pode variar at\xE9 seis graus, e um tr\xE2nsito \xE0 Lua perto do limite do orbe pode aparecer ou desaparecer com a hora real.",
    skyAt: "C\xE9u em",
    noTransitsWithin: "Nenhum tr\xE2nsito a menos de",
    activeTransitsWithin: "tr\xE2nsitos ativos a menos de",
    activeTransitWithin: "tr\xE2nsito ativo a menos de",
    ofExact: "do ponto exato",
    transitMoonOmitted: "Lua em tr\xE2nsito n\xE3o inclu\xEDda \u2014 ela cruza o mapa inteiro todos os meses",
    quietSky: "Um c\xE9u tranquilo dentro do orbe estreito usado nesta p\xE1gina. Nada urgente \u2014 volte em alguns dias ou amplie a leitura com os eventos do m\xEAs abaixo.",
    natal: "Natal",
    forYourChart: "Para seu mapa",
    orb: "orbe",
    openDailyBrief: "Abrir meu resumo di\xE1rio completo",
    allTransits: "Todos os seus tr\xE2nsitos",
    personA: "Pessoa A",
    personB: "Pessoa B",
    sharedChart: "Mapa compartilhado",
    sharedWithYou: "compartilhado com voc\xEA",
    removeSharedChart: "Remover o mapa compartilhado",
    sharedSideHelp: "Este lado chegou pelo link \u2014 limpe-o para informar os dados de outra pessoa.",
    name: "Nome",
    compareCharts: "Comparar os mapas",
    sameChart: "\xC9 o mesmo mapa duas vezes \u2014 escolha dois mapas diferentes para comparar.",
    compareSavedHelp: "Os mapas que voc\xEA calcular e salvar aparecer\xE3o aqui como atalhos, para que a segunda compara\xE7\xE3o seja mais r\xE1pida que a primeira.",
    compareNoTimeNotice: "Sem hora de nascimento para",
    moonMiddayEstimate: "ent\xE3o essa Lua \xE9 uma estimativa para o meio-dia \u2014 ela pode variar at\xE9 seis graus, e um aspecto lunar perto do limite do orbe pode aparecer ou desaparecer com a hora real.",
    crossChartAspects: "aspectos entre mapas",
    easeful: "harmoniosos",
    charged: "intensos",
    readPairing: "Ler a combina\xE7\xE3o",
    inviteCompare: "Convidar algu\xE9m para comparar",
    inviteLink: "Link de convite",
    inviteNote: "O link inclui os dados de nascimento desta pessoa e abre a p\xE1gina com esse lado preenchido \u2014 nada \xE9 enviado a n\xF3s. Se n\xE3o for voc\xEA, vale pedir permiss\xE3o.",
    inviteCopied: "Link de convite copiado para a \xE1rea de transfer\xEAncia.",
    syncOn: "Sincroniza\xE7\xE3o ativa",
    keepEveryDevice: "Acesse seus mapas em todos os dispositivos",
    signedIn: "Sess\xE3o iniciada",
    syncCopyOn: "Mapas salvos e remo\xE7\xF5es s\xE3o sincronizados entre seus dispositivos.",
    syncCopyOff: "Salve mapas neste dispositivo. Entre quando quiser acess\xE1-los em todos os dispositivos.",
    weeklyDigestTitle: "E-mail semanal do c\xE9u",
    weeklyDigestCopy: "Um e-mail por semana: o c\xE9u sobre seus mapas salvos. Cancele quando quiser.",
    weeklyDigestAria: "Ativar o resumo semanal",
    digestSaved: "Prefer\xEAncia do resumo salva.",
    digestFailed: "N\xE3o foi poss\xEDvel atualizar a prefer\xEAncia do resumo. Tente de novo.",
    checkEmail: "Confira seu e-mail para acessar sua conta. Esta p\xE1gina ser\xE1 sincronizada quando voc\xEA voltar.",
    syncFailed: "A sincroniza\xE7\xE3o falhou. Tente de novo.",
    syncing: "Sincronizando\u2026",
    synced: "Sincronizado",
    syncNow: "Sincronizar agora",
    signOut: "Sair",
    emailSyncAria: "E-mail para sincronizar o perfil",
    sending: "Enviando\u2026",
    sendSignIn: "Enviar link de acesso",
    nothingSaved: "Nada salvo ainda.",
    emptyProfile: "Os mapas que voc\xEA salvar ficar\xE3o aqui, primeiro neste dispositivo. Fa\xE7a um mapa e toque em Salvar este mapa para come\xE7ar.",
    saved: "salvos",
    chartSingular: "mapa",
    chartPlural: "mapas",
    savedChartSingular: "mapa salvo",
    savedChartPlural: "mapas salvos",
    syncedWhenSignedIn: "sincronizados quando voc\xEA entra",
    storedBrowser: "armazenados neste navegador",
    chartName: "Nome do mapa",
    timeUnknown: "hora desconhecida",
    needsTime: "precisa do hor\xE1rio",
    compareThese: "Comparar estes dois mapas",
    addAnotherChart: "Adicionar outro mapa",
    ...GROWTH_UI_EN,
    footerWidgets: "Widgets",
    footerDisclosure: "Divulga\xE7\xF5es",
    emailCaptureKicker: "Previs\xE3o semanal gratuita",
    emailCaptureTitle: "Sua semana pela frente.",
    emailCapturePersonalTitle: "Sua semana de {sign} pela frente.",
    emailCaptureCopy: "Uma previs\xE3o semanal para seu signo. Gr\xE1tis, cancele quando quiser.",
    emailCaptureEmailLabel: "Endere\xE7o de e-mail",
    emailCaptureEmailPlaceholder: "voce@exemplo.com",
    emailCaptureSignLegend: "Seu signo solar (opcional)",
    emailCaptureNoSign: "Pular o signo",
    emailCaptureUsingSign: "Usando seu signo solar: {sign}",
    emailCaptureChangeSign: "Alterar",
    emailCaptureSubmit: "Enviar minha semana",
    emailCaptureSubmitting: "Inscrevendo\u2026",
    emailCaptureSuccess: "Confira seu e-mail para confirmar a assinatura.",
    emailCaptureErrorTitle: "Assinatura indispon\xEDvel",
    emailCaptureError: "N\xE3o foi poss\xEDvel iniciar a assinatura. Tente de novo.",
    emailCapturePrivacy: "Armazenamos apenas seu e-mail e o signo escolhido \u2014 nunca seus dados de nascimento.",
    emailCaptureHoneypot: "Deixe este campo em branco",
    emailPendingTitle: "Confira seu e-mail.",
    emailPendingBody: "Use o link de confirma\xE7\xE3o que enviamos antes de come\xE7ar a receber sua previs\xE3o semanal.",
    emailConfirmSubject: "Confirme sua previs\xE3o semanal do Zodiacs.org",
    emailConfirmMessage: "Confirme que voc\xEA quer receber a previs\xE3o semanal gratuita do Zodiacs.org:",
    emailConfirmIgnore: "Se voc\xEA n\xE3o solicitou isto, ignore este e-mail. Nenhuma assinatura ser\xE1 ativada.",
    emailConfirmTitle: "S\xF3 mais uma confirma\xE7\xE3o.",
    emailConfirmBody: "Confirme esta assinatura para come\xE7ar a receber a previs\xE3o semanal gratuita. At\xE9 l\xE1, nenhuma assinatura semanal estar\xE1 ativa.",
    emailConfirmAction: "Confirmar assinatura",
    emailConfirmedTitle: "Assinatura confirmada.",
    emailConfirmedBody: "Sua previs\xE3o semanal gratuita est\xE1 ativa. Toda mensagem inclui um link para cancelar a assinatura.",
    emailConfirmInvalidTitle: "Este link n\xE3o \xE9 v\xE1lido.",
    emailConfirmInvalidBody: "O link de confirma\xE7\xE3o \xE9 inv\xE1lido ou expirou. Volte ao Zodiacs.org para solicitar outro.",
    emailReturnHome: "Voltar ao Zodiacs.org"
  };
  var pt_default = pt;

  // src/lib/i18n/ui/fr.ts
  init_define_import_meta_env();
  var fr = {
    chartDepthOpen: "Voir en trois dimensions",
    chartDepthClose: "Masquer la troisi\xE8me dimension",
    calculationLoadError: "Les fichiers de calcul n\u2019ont pas pu \xEAtre charg\xE9s. V\xE9rifie ta connexion et r\xE9essaie.",
    calculationReload: "Recharger la page",
    calculationReloadWarning: "Le rechargement efface les donn\xE9es non enregistr\xE9es.",
    calculationRetry: "R\xE9essayer",
    pfdYearError: "Nous n\u2019avons pas pu terminer la lecture de l\u2019ann\xE9e \xE0 venir. R\xE9essaie.",
    placeSearching: "Recherche de lieux\u2026",
    chartWheelActions: "Actions du th\xE8me",
    chartWheelGuide: "Faire la visite guid\xE9e",
    chartWheelReplay: "Rejouer la visite",
    chartWheelAnother: "Lire un autre th\xE8me",
    chartWheelSignatureSelf: "La signature de ton th\xE8me",
    chartWheelSignatureOther: "La signature de son th\xE8me",
    chartWheelCompareMine: "Comparer avec le mien",
    chartWheelCompareAdd: "Ajouter mon th\xE8me pour comparer",
    chartWheelShareOther: "Partager ce th\xE8me",
    navPrimary: "Navigation principale",
    navSigns: "Signes",
    navTools: "Outils",
    navLearn: "Comprendre",
    navHoroscopes: "Horoscopes",
    navCollect: "Astrofolio",
    navSavedCharts: "Th\xE8mes enregistr\xE9s",
    navMenu: "Menu",
    navSite: "Le site",
    navTwelve: "Les Douze",
    footerTag: "Outils astrologiques gratuits et guides des signes, avec des th\xE8mes calcul\xE9s en toute confidentialit\xE9 dans ton navigateur.",
    footerStartHere: "Pour commencer",
    footerPlanets: "Les plan\xE8tes",
    footerHouses: "Les maisons",
    footerZodiacDates: "Dates des signes",
    footerGlossary: "Glossaire",
    footerCompute: "Nos calculs",
    footerRegistry: "Registry",
    footerThesis: "Th\xE8se",
    footerArchive: "Archives",
    footerSdk: "SDK",
    footerCollectNote: "Les fiches, recherches, profils du catalogue et le SDK du Registry sont en lecture seule. L\u2019outil d\u2019achat facultatif d\u2019Astrofolio utilise Jupiter, un service ind\xE9pendant, et ton propre portefeuille\u202F; Zodiacs.org ne d\xE9tient aucune cl\xE9 ni aucun fonds. Rien de ceci ne constitue un conseil financier.",
    footerMethodology: "M\xE9thodologie",
    footerAbout: "\xC0 propos",
    footerPrivacy: "Confidentialit\xE9",
    footerTerms: "Conditions",
    footerPlaceData: "Donn\xE9es g\xE9ographiques",
    footerFonts: "Polices sous licence",
    skipContent: "Aller au contenu",
    open: "Ouvrir",
    birthChart: "Th\xE8me astral",
    compatibility: "Compatibilit\xE9",
    moonSign: "Signe lunaire",
    risingSign: "Ascendant",
    moonPhase: "Phase de la Lune",
    saturnReturn: "Retour de Saturne",
    transits: "Transits",
    birthday: "Anniversaire (en anglais)",
    retrogrades: "R\xE9trogrades",
    sun: "Soleil",
    moon: "Lune",
    rising: "Ascendant",
    body: "Astre",
    position: "Position",
    sign: "Signe",
    house: "Maison",
    chart: "Th\xE8me",
    date: "Date",
    time: "Heure",
    place: "Lieu",
    motion: "Mouvement",
    optional: "facultatif",
    birthDate: "Date de naissance",
    birthTime: "Heure de naissance",
    birthplace: "Lieu de naissance",
    birthDateRequired: "Indique ta date de naissance.",
    birthDateRange: "Choisis une date de naissance entre 1800 et 2199.",
    birthTimeRequired: "Indique ton heure de naissance.",
    houseSystem: "Syst\xE8me de maisons",
    wholeSignDefault: "Maisons en signes entiers (par d\xE9faut)",
    placidus: "Placidus",
    houseSystemHelp: "La mani\xE8re de diviser la carte en douze domaines de vie. En signes entiers, chaque signe forme une maison enti\xE8re ; Placidus fait varier la taille des maisons selon l\u2019heure et le lieu exacts. Les plan\xE8tes ne bougent pas : seules les limites des maisons changent.",
    computing: "Calcul en cours\u2026",
    checking: "V\xE9rification en cours\u2026",
    comparing: "Comparaison en cours\u2026",
    save: "Enregistrer",
    rename: "Renommer",
    remove: "Supprimer",
    getBirthChart: "Obtiens ton th\xE8me astral gratuit",
    findMoonSign: "D\xE9couvre ton signe lunaire",
    findRisingSign: "D\xE9couvre ton ascendant",
    savedCharts: "Th\xE8mes enregistr\xE9s",
    profile: "Ton profil",
    read: "Lire",
    rightNow: "En ce moment",
    enterBirthDetails: "Saisis tes donn\xE9es de naissance\u2026",
    privacyDevice: "Priv\xE9 par d\xE9faut. Tes donn\xE9es de naissance restent dans ce navigateur.",
    placePlaceholder: "Commence \xE0 saisir une ville\u2026",
    placeChange: "Changer le lieu de naissance",
    placePickHint: "Choisis ton lieu de naissance dans la liste.",
    placeNoResults: "Pas dans la liste ? Choisis la ville la plus proche \u2014 quelques kilom\xE8tres changent rarement le th\xE8me.",
    placeError: "Impossible de charger l\u2019index des lieux \u2014 v\xE9rifie ta connexion et r\xE9essaie.",
    searchGeo: "La recherche couvre environ 34\u202F000 lieux \xB7 GeoNames (CC BY 4.0)",
    chartError: "Un probl\xE8me est survenu pendant le calcul du th\xE8me. R\xE9essaie.",
    moonError: "Un probl\xE8me est survenu pendant le calcul de la Lune. R\xE9essaie.",
    localDateReferenceError: "Nous n\u2019avons pas pu d\xE9terminer une heure de calcul correspondant \xE0 cette date locale. V\xE9rifie la date et le lieu.",
    returnError: "Un probl\xE8me est survenu pendant le calcul du retour. R\xE9essaie.",
    transitError: "Un probl\xE8me est survenu pendant le calcul des transits. R\xE9essaie.",
    compareError: "Un probl\xE8me est survenu pendant la comparaison des th\xE8mes. R\xE9essaie.",
    noBirthTime: "Je ne la connais pas",
    risingTimeHelp: "L\u2019ascendant change toutes les deux heures \u2014 ici, l\u2019heure compte.",
    chartTimeHelp: "Tu ne connais pas l\u2019heure\u202F? Tu obtiendras une r\xE9f\xE9rence \xE0 midi local, sans ascendant ni maisons\u202F; la Lune peut \xEAtre incertaine.",
    chartSavedDevice: "Enregistr\xE9 \xB7 sur cet appareil",
    saveThisChart: "Enregistrer ce th\xE8me",
    chartSavedStatus: "Th\xE8me enregistr\xE9 sur cet appareil.",
    chartSaveFull: "Tu peux enregistrer jusqu\u2019\xE0 40 th\xE8mes \u2014 supprimes-en un d\u2019abord.",
    chartSaveError: "Impossible d\u2019enregistrer \u2014 ton navigateur bloque peut-\xEAtre le stockage local.",
    chartSavedMessage: "Ajout\xE9 \xE0 tes th\xE8mes. Connecte-toi ici quand tu voudras les retrouver sur tous tes appareils.",
    linkCopied: "Lien copi\xE9",
    copyChartLink: "Copier un lien vers ce th\xE8me",
    rendering: "Cr\xE9ation en cours\u2026",
    cardSaved: "Image enregistr\xE9e",
    saveChartCard: "Enregistrer une image du th\xE8me",
    shareChart: "Partager ton th\xE8me",
    linkToChart: "Lien vers ce th\xE8me",
    chartLinkCopied: "Lien du th\xE8me copi\xE9 dans le presse-papiers.",
    chartCardSaved: "Image du th\xE8me enregistr\xE9e.",
    cardError: "Impossible de cr\xE9er l\u2019image dans ce navigateur \u2014 tu peux tout aussi bien faire une capture de la roue ci-dessus.",
    shareNote: "Le lien contient les donn\xE9es de naissance que tu as saisies \u2014 rien ne nous est envoy\xE9, et seules les personnes \xE0 qui tu le transmets peuvent l\u2019ouvrir. L\u2019image au format 1080\xD71350 est cr\xE9\xE9e sur ton appareil.",
    needsBirthTime: "Heure de naissance n\xE9cessaire",
    yourMoonSign: "Ton signe lunaire",
    yourRisingSign: "Ton ascendant",
    moonPhaseAtBirth: "Phase de la Lune \xE0 la naissance",
    chartRuler: "Ma\xEEtre du th\xE8me",
    planetSteering: "la plan\xE8te qui gouverne ton ascendant.",
    aspectsFound: "Aspects",
    found: "au total",
    applying: "appliquant",
    wholeSignHouses: "Maisons en signes entiers",
    placidusHouses: "Maisons de Placidus",
    engine: "moteur v",
    readInOrder: "Lire le th\xE8me dans l\u2019ordre",
    readIntro: "De haut en bas, comme le ferait un astrologue. Les tableaux ci-dessus pr\xE9sentent les donn\xE9es\u202F; voici ce qu\u2019elles racontent.",
    readBigThree: "Commence par les trois piliers",
    readBigThreeBody: "Soleil, Lune, ascendant \u2014 les trois cartes en haut. Identit\xE9, instinct, fa\xE7on d\u2019aborder le monde. Tout ce qui suit les nuance\u202F; rien ne les remplace.",
    readRooms: "Les plan\xE8tes, maison par maison",
    readNoHouses: "Sans heure de naissance, il n\u2019y a pas de maisons\u202F: chaque plan\xE8te se lit donc uniquement dans son signe. Ajoute l\u2019heure pour faire appara\xEEtre les maisons dans cette section.",
    readAspects: "Les aspects les plus influents",
    readWeather: "Le climat du th\xE8me",
    readIn: "en",
    today: "aujourd\u2019hui",
    todayBySignTitle: "Le ciel d\u2019aujourd\u2019hui, signe par signe",
    todayBySignPrompt: "Appuie sur ton signe solaire pour une lecture claire du jour \u2014 aucune heure de naissance n\xE9cessaire.",
    todaySolarNote: "lu \xE0 partir des maisons solaires de ton signe",
    whyThisReading: "Pourquoi cette lecture",
    todayHoroscopeLink: "horoscope",
    or: "ou",
    chartSavedBeforeLink: "Ajout\xE9 \xE0 tes th\xE8mes. Connecte-toi",
    chartSavedLink: "ici",
    chartSavedAfterLink: "quand tu voudras les retrouver sur tous tes appareils.",
    signedInAs: "Session ouverte avec {email}",
    removeChartConfirm: "Supprimer \xAB\u202F{name}\u202F\xBB de cet appareil\u202F?",
    compareSavedHeading: "Comparer {a} et {b}",
    compareSavedPitch: "Deux th\xE8mes enregistr\xE9s appellent une comparaison\u202F: tous les aspects entre les deux, interpr\xE9t\xE9s avec franchise et calcul\xE9s sur cet appareil.",
    saturnDateHelp: "La date suffit \xE0 d\xE9terminer les ann\xE9es de ton retour. L\u2019heure et le lieu pr\xE9cisent le calcul \xE0 quelques jours pr\xE8s, sans jamais changer l\u2019ann\xE9e.",
    saturnReturnHeading: "{ordinal} retour",
    skyMercuryRetrograde: "Mercure r\xE9trograde",
    skyMercuryDirect: "Mercure direct",
    skyPlanetRetrograde: "{planet} r\xE9trograde",
    skyFullMoon: "Pleine Lune",
    skyNewMoon: "Nouvelle Lune",
    skyMoonOn: "{event} \xB7 {date}",
    skyAsOf: "{date} \xB7 12\u202Fh UTC",
    skyTickerAria: "Positions dans le ciel le {date} \xE0 12\u202Fh UTC",
    moonDiscAria: "Lune \xE9clair\xE9e \xE0 {percent}\u202F%",
    pairingCta: "Lire la dynamique entre {a} et {b}",
    inviteWith: "Inviter quelqu\u2019un \xE0 comparer son th\xE8me avec celui de {name}",
    inviteNamedNote: "Le lien contient les donn\xE9es de naissance de {name} et ouvre cette page avec ce c\xF4t\xE9 d\xE9j\xE0 rempli \u2014 rien ne nous est envoy\xE9. Si ce n\u2019est pas toi, mieux vaut avoir son accord.",
    transitMiddayUtc: "{date} \xB7 midi UTC",
    planetReturn: "Retour de {planet}",
    natalPlanet: "Position natale de {planet}",
    pfdToday: "Aujourd\u2019hui pour ce th\xE8me",
    pfdComing: "\xC0 venir pour ce th\xE8me",
    pfdYearAhead: "Les douze prochains mois pour ce th\xE8me",
    pfdYearBusy: "Calcul des douze prochains mois sur ton appareil \u2014 encore quelques secondes\u2026",
    pfdYearNote: "Calcul\xE9 \xE0 partir de ton th\xE8me enregistr\xE9\u202F: les dates exactes des douze prochains mois.",
    saveYearAheadNote: "Sur la page de profil, les th\xE8mes enregistr\xE9s donnent acc\xE8s aux douze prochains mois calcul\xE9s \u2014 retour solaire, dates de Jupiter et Saturne, contacts des \xE9clipses.",
    recordLabel: "Aile des collections",
    recordOneOfTwelve: "figure aussi parmi les Douze \u2014 une notice de r\xE9f\xE9rence dans le registre.",
    recordViewLink: "Voir la notice \u2014 pour l\u2019instant en anglais \u2192",
    recordChartSun: "Ton Soleil est en {sign}.",
    recordChartBody: "{sign} fait partie des Douze, avec ses propres cr\xE9ations, son histoire et sa notice officielle dans le Registre.",
    recordChartLink: "Explorer le Registre de {sign} \u2192",
    babyDueDate: "Date pr\xE9vue d\u2019accouchement",
    babyCompute: "Lire le ciel de la date pr\xE9vue",
    babyNeedDate: "Saisis d\u2019abord une date pr\xE9vue.",
    babyError: "Un probl\xE8me est survenu pendant le calcul du ciel. R\xE9essaie.",
    babySunHead: "Signe solaire \u2014 presque certain",
    babySunSingle: "Une naissance \xE0 cette date donne un Soleil en",
    babySunNearEdge: "La date se situe pr\xE8s d\u2019un changement de signe\u202F: une arriv\xE9e plus d\u2019un jour en avance ou en retard peut faire passer le Soleil en",
    babySunNearEdgeTail: "\u2014 la date de naissance tranche.",
    babySunSplitA: "Le Soleil change de signe \xE0 cette date\u202F: \xE0 la naissance, il sera en",
    babySunSplitOr: "ou",
    babySunSplitTail: "selon l\u2019heure. Le moment exact de la naissance tranche.",
    babyNoonNote: "signes calcul\xE9s \xE0 midi en temps universel",
    babyMoonHead: "Signe lunaire \u2014 quelques possibilit\xE9s",
    babyMoonBody: "La Lune change de signe tous les deux ou trois jours\u202F: une semaine pr\xE9vue couvre donc g\xE9n\xE9ralement deux ou trois signes lunaires. Des b\xE9b\xE9s n\xE9s la m\xEAme semaine peuvent avoir des signes lunaires diff\xE9rents \u2014 le jour et l\u2019heure de naissance tranchent.",
    babyRetroHead: "Plan\xE8tes r\xE9trogrades \xE0 la naissance",
    babyRetroBody: "en p\xE9riode r\xE9trograde autour de la date pr\xE9vue. Dans un th\xE8me astral, une plan\xE8te r\xE9trograde s\u2019exprime de fa\xE7on plus int\xE9rieure que d\u2019habitude \u2014 c\u2019est courant et il n\u2019y a rien \xE0 corriger.",
    babyRisingHead: "Ascendant \u2014 impossible \xE0 conna\xEEtre avant la minute exacte",
    babyRisingBody: "L\u2019ascendant change environ toutes les deux heures\u202F: aucune date pr\xE9vue ne permet donc de le pr\xE9dire. C\u2019est le seul placement qu\u2019on ne peut d\xE9terminer qu\u2019\xE0 partir de l\u2019heure exacte inscrite sur l\u2019acte de naissance.",
    babyDateLink: "Explorer cette date de naissance",
    babyChartLink: "Apr\xE8s la naissance\u202F: le th\xE8me complet",
    pfdChartPick: "Th\xE8me",
    pfdQuietSky: "Un ciel calme pour ce th\xE8me aujourd\u2019hui \u2014 rien \xE0 moins de 3\xB0 d\u2019un point natal.",
    pfdQuietAhead: "Rien de majeur \xE0 l\u2019horizon de ce th\xE8me dans la p\xE9riode calcul\xE9e.",
    pfdSaturnBusy: "Calcul des p\xE9riodes de Saturne sur ton appareil\u2026",
    pfdEmptyTitle: "Ton ciel, d\xE8s que tu auras enregistr\xE9 un th\xE8me",
    pfdEmptyBody: "Enregistre un th\xE8me astral\u202F: chaque jour, cette page s\u2019ouvrira sur ses transits, ses maisons et ce qui l\u2019attend.",
    pfdWindows: "p\xE9riodes",
    openChart: "Ouvrir",
    dignityDomicile: "domicile",
    dignityExaltation: "exaltation",
    dignityDetriment: "exil",
    dignityFall: "chute",
    explorerHint: "Appuie sur une plan\xE8te, un signe, une maison ou une ligne d\u2019aspect pour l\u2019examiner \u2014 tu peux aussi s\xE9lectionner la roue et utiliser les touches fl\xE9ch\xE9es.",
    explorerLabel: "Th\xE8me astral interactif",
    explorerSelectPart: "Choisis une partie du th\xE8me",
    explorerNoSelection: "Aucune s\xE9lection",
    explorerAngles: "Angles",
    explorerControlsLoading: "Chargement des interpr\xE9tations et des commandes du th\xE8me\u2026",
    explorerControlsError: "Ton th\xE8me est pr\xEAt, mais ses interpr\xE9tations et ses commandes n\u2019ont pas pu \xEAtre charg\xE9es. V\xE9rifie ta connexion et r\xE9essaie.",
    explorerKeyHint: "Les fl\xE8ches gauche et droite parcourent les positions ; Entr\xE9e ouvre le panneau de d\xE9tails.",
    selectionCleared: "S\xE9lection annul\xE9e.",
    inspectorClose: "Fermer les d\xE9tails",
    speed: "Vitesse",
    day: "jour",
    dignity: "Dignit\xE9",
    separating: "s\xE9parant",
    dates: "Dates",
    element: "\xC9l\xE9ment",
    ruler: "Ma\xEEtre",
    inThisSign: "Dans ce signe",
    inThisHouse: "Dans cette maison",
    cusp: "Cuspide",
    span: "\xC9tendue",
    emptyHouseNote: "Aucune plan\xE8te ici. Une maison vide n\u2019est pas une page blanche \u2014 ses th\xE8mes s\u2019expriment \xE0 travers la plan\xE8te qui la gouverne.",
    angleAscNote: "L\u2019Ascendant \u2014 le degr\xE9 qui se levait \xE0 l\u2019est au moment de la naissance. Il ancre toute la roue.",
    angleDscNote: "Le Descendant \u2014 le degr\xE9 qui se couchait \xE0 l\u2019horizon ouest, \xE0 l\u2019oppos\xE9 de l\u2019Ascendant. La porte traditionnelle vers les partenaires.",
    angleMcNote: "Le Milieu du Ciel \u2014 le degr\xE9 qui culminait au-dessus de l\u2019horizon \xE0 la naissance. Carri\xE8re, r\xE9putation, vie publique.",
    angleIcNote: "Le Fond du Ciel \u2014 le point le plus bas de la roue, \xE0 l\u2019oppos\xE9 du Milieu du Ciel. Foyer, racines, vie priv\xE9e.",
    layersLabel: "Calques du th\xE8me",
    layerHouses: "Maisons",
    editedBy: "Publi\xE9 par",
    tourStart: "Lancer la visite",
    firstReadingLabel: "Ta lecture en 2 minutes",
    firstReadingTitle: "Que dit ton th\xE8me de toi \u2014 et de la suite ?",
    firstReadingBody: "D\xE9couvre ton m\xE9lange de personnalit\xE9, o\xF9 il s\u2019exprime, un sch\xE9ma que tu reconna\xEEtras peut-\xEAtre et comment l\u2019astrologie transforme un th\xE8me natal en pr\xE9vision.",
    firstReadingResumeTitle: "Ta lecture t\u2019attend",
    firstReadingResumeBody: "Reprends l\xE0 o\xF9 tu t\u2019es arr\xEAt\xE9 sur cet appareil.",
    firstReadingStart: "Lire mon th\xE8me",
    firstReadingExplore: "Explorer par moi-m\xEAme",
    firstReadingResume: "Continuer ma lecture",
    firstReadingStep: "\xC9tape",
    firstReadingFullTour: "Voir comment fonctionne le th\xE8me \u2014 visite avanc\xE9e",
    firstReadingReplay: "Revoir l\u2019histoire de mon th\xE8me",
    chartActionsMore: "Plus de fa\xE7ons d\u2019utiliser ce th\xE8me",
    chartReceiptDownload: "T\xE9l\xE9charger le relev\xE9 du calcul (.json)",
    chartReceiptPrivacy: "Ce fichier contient des donn\xE9es de naissance sensibles et les donn\xE9es du th\xE8me. Gardez-le priv\xE9.",
    chartReceiptError: "Le fichier n\u2019a pas pu \xEAtre t\xE9l\xE9charg\xE9. Veuillez r\xE9essayer.",
    chartReceiptUnavailable: "Aucun relev\xE9 de calcul n\u2019est disponible pour ce th\xE8me.",
    seeTodaySky: "Voir le ciel d\u2019aujourd\u2019hui",
    contextHelpCue: "Touche les termes soulign\xE9s en pointill\xE9s pour obtenir une explication simple.",
    editorialHow: "normes \xE9ditoriales",
    dstGapNotice: "Cette heure se trouvait dans l\u2019intervalle supprim\xE9 par le passage \xE0 l\u2019heure d\u2019\xE9t\xE9 et n\u2019a donc jamais exist\xE9 \u2014 nous l\u2019avons avanc\xE9e jusqu\u2019\xE0 la fin de cet intervalle, conform\xE9ment \xE0 la convention habituelle.",
    dstFoldNotice: "\xC0 ton lieu de naissance, les horloges ont affich\xE9 deux fois cette heure\u202F; nous avons retenu la premi\xE8re occurrence. Si tu sais qu\u2019il s\u2019agissait de la seconde, ton th\xE8me change \xE0 peine \u2014 la Lune avance d\u2019environ un demi-degr\xE9 par heure.",
    lmtNotice: "Ta naissance remonte \xE0 une \xE9poque ant\xE9rieure \xE0 la normalisation des fuseaux horaires \u2014 nous avons utilis\xE9 l\u2019heure moyenne locale de l\u2019\xE9poque, comme le font les logiciels professionnels.",
    polarNotice: "Les maisons de Placidus ne sont pas d\xE9finies aussi pr\xE8s du p\xF4le\u202F; ce th\xE8me utilise donc les maisons en signes entiers.",
    noTimeNotice: "Sans heure de naissance, nous utilisons 12 h en heure civile locale comme r\xE9f\xE9rence et omettons l\u2019ascendant, les angles et les maisons.",
    moonAmbiguousNotice: "La Lune a \xE9galement chang\xE9 de signe ce jour-l\xE0 \u2014 il est raisonnable de lire les deux signes voisins tant que tu n\u2019as pas retrouv\xE9 l\u2019heure.",
    fromLinkNotice: "Ce th\xE8me vient d\u2019un lien partag\xE9 \u2014 les donn\xE9es de naissance \xE9taient contenues dans le lien, et le calcul vient de se faire sur ton appareil.",
    howWeCompute: "Nos calculs",
    welcomeBack: "Bon retour parmi nous.",
    savedChartAria: "Ton th\xE8me enregistr\xE9",
    todayAgainstChart: "Le ciel d\u2019aujourd\u2019hui par rapport \xE0 ton th\xE8me",
    yourCharts: "Tes th\xE8mes",
    recommendedNext: "\xC9tape recommand\xE9e",
    todayForName: "Voir ce que cette journ\xE9e signifie pour {name}",
    savedChartTodayBody: "Ton th\xE8me ne change pas. Le ciel du jour, si \u2014 commence par ce qui \xE9volue pour toi maintenant.",
    openSavedChart: "Ouvrir le th\xE8me enregistr\xE9",
    moonReadingSky: "Lecture du ciel\u2026",
    illuminated: "\xE9clair\xE9e",
    moonIn: "Lune en",
    findThatMoon: "Retrouver la Lune de cette date",
    dateHelp: "Un anniversaire, une date marquante, n\u2019importe quelle date.",
    placeHelpMoon: "Pr\xE9cise la conversion de l\u2019heure\u202F; la phase en d\xE9pend \xE0 peine.",
    middayLocalCaption: "Lecture \xE0 midi, heure locale \u2014 ajoute l\u2019heure exacte pour d\xE9terminer pr\xE9cis\xE9ment le degr\xE9.",
    utcTimeCaption: "L\u2019heure est lue en temps universel \u2014 ajoute un lieu de naissance pour convertir ton heure locale.",
    middayUtcCaption: "Lecture \xE0 midi en temps universel \u2014 l\u2019heure et le lieu d\xE9terminent pr\xE9cis\xE9ment le degr\xE9.",
    moonChangedNotice: "La Lune a chang\xE9 de signe ce jour-l\xE0 et, sans l\u2019heure, nous ne pouvons pas savoir de quel c\xF4t\xE9 de la limite elle se trouvait \xE0 ta naissance. La phase reste la m\xEAme \u2014 elle \xE9volue trop lentement pour que quelques heures comptent.",
    birthChartForDate: "Calculer le th\xE8me astral de cette date",
    natalSaturn: "Ton Saturne natal",
    addBirthDetails: "Ajouter l\u2019heure et le lieu de naissance (facultatif)",
    findSaturnReturn: "Trouve ton retour de Saturne",
    returnApprox: "Dates calcul\xE9es \xE0 partir d\u2019une lecture \xE0 midi \u2014 avec l\u2019heure et le lieu de naissance, elles peuvent se d\xE9caler de quelques jours dans un sens ou dans l\u2019autre.",
    complete: "Termin\xE9",
    underwayNow: "En cours",
    aheadOfYou: "\xC0 venir",
    first: "Premier",
    second: "Deuxi\xE8me",
    third: "Troisi\xE8me",
    fourth: "Quatri\xE8me",
    aroundAge29: "vers 29 ans",
    aroundAge58: "vers 58 ans",
    aroundAge88: "vers 88 ans",
    retrogradePass: "passage r\xE9trograde",
    threePasses: "Trois passages exacts\u202F: Saturne franchit ton degr\xE9, revient dessus en r\xE9trograde, puis le traverse une derni\xE8re fois en repartant. Toute cette p\xE9riode forme le retour.",
    seeSaturnChart: "Voir Saturne dans ton th\xE8me astral",
    whatSaturnMeans: "Ce que signifie Saturne",
    yourChart: "Ton th\xE8me",
    theSky: "Le ciel",
    transitRingLede: "Calcule ton th\xE8me, puis d\xE9place le curseur pour observer les plan\xE8tes se d\xE9placer sur celui-ci \u2014 en avant ou en arri\xE8re, sur une p\xE9riode allant jusqu\u2019\xE0 un an.",
    checkTransits: "Voir tes transits",
    savedChartHelp: "Les th\xE8mes que tu calcules et enregistres apparaissent ici sous forme de raccourcis\u202F: tu n\u2019auras rien \xE0 ressaisir lors de la prochaine consultation.",
    noTransitTimeNotice: "Ce th\xE8me n\u2019a pas d\u2019heure de naissance\u202F: sa Lune est donc estim\xE9e \xE0 midi et peut s\u2019\xE9carter de six degr\xE9s au maximum. Un transit sur la Lune proche de la limite de son orbe peut appara\xEEtre ou dispara\xEEtre selon l\u2019heure r\xE9elle.",
    skyAt: "Ciel du",
    noTransitsWithin: "Aucun transit \xE0 moins de",
    activeTransitsWithin: "transits actifs \xE0 moins de",
    activeTransitWithin: "transit actif \xE0 moins de",
    ofExact: "du point exact",
    transitMoonOmitted: "Lune en transit non incluse \u2014 elle parcourt tout le th\xE8me chaque mois",
    quietSky: "Un ciel calme selon l\u2019orbe serr\xE9 utilis\xE9 sur cette page. Rien d\u2019urgent \u2014 reviens dans quelques jours ou \xE9largis la lecture aux \xE9v\xE9nements du mois ci-dessous.",
    natal: "Natal",
    forYourChart: "Pour ton th\xE8me",
    orb: "orbe",
    openDailyBrief: "Ouvrir mon r\xE9sum\xE9 quotidien complet",
    allTransits: "Tous tes transits",
    personA: "Personne A",
    personB: "Personne B",
    sharedChart: "Th\xE8me partag\xE9",
    sharedWithYou: "partag\xE9 avec toi",
    removeSharedChart: "Supprimer le th\xE8me partag\xE9",
    sharedSideHelp: "Ce c\xF4t\xE9 vient du lien \u2014 efface-le pour saisir les donn\xE9es de quelqu\u2019un d\u2019autre.",
    name: "Nom",
    compareCharts: "Comparer les th\xE8mes",
    sameChart: "C\u2019est le m\xEAme th\xE8me des deux c\xF4t\xE9s \u2014 choisis-en deux diff\xE9rents.",
    compareSavedHelp: "Les th\xE8mes que tu calcules et enregistres apparaissent ici sous forme de raccourcis\u202F: la deuxi\xE8me comparaison sera plus rapide que la premi\xE8re.",
    compareNoTimeNotice: "Aucune heure de naissance pour",
    moonMiddayEstimate: "\u2014 cette Lune est donc estim\xE9e \xE0 midi et peut s\u2019\xE9carter de six degr\xE9s au maximum. Un aspect lunaire proche de la limite de son orbe peut appara\xEEtre ou dispara\xEEtre selon l\u2019heure r\xE9elle.",
    crossChartAspects: "aspects entre les th\xE8mes",
    easeful: "harmonieux",
    charged: "tendus",
    readPairing: "Lire la dynamique",
    inviteCompare: "Inviter quelqu\u2019un \xE0 comparer",
    inviteLink: "Lien d\u2019invitation",
    inviteNote: "Le lien contient les donn\xE9es de naissance de cette personne et ouvre la page avec ce c\xF4t\xE9 d\xE9j\xE0 rempli \u2014 rien ne nous est envoy\xE9. Si ce n\u2019est pas toi, mieux vaut avoir son accord.",
    inviteCopied: "Lien d\u2019invitation copi\xE9 dans le presse-papiers.",
    syncOn: "Synchronisation activ\xE9e",
    keepEveryDevice: "Retrouve tes th\xE8mes sur tous tes appareils",
    signedIn: "Session ouverte",
    syncCopyOn: "L\u2019enregistrement et la suppression des th\xE8mes sont synchronis\xE9s sur tous tes appareils.",
    syncCopyOff: "Enregistre des th\xE8mes sur cet appareil. Connecte-toi quand tu voudras les retrouver sur tous tes appareils.",
    weeklyDigestTitle: "E-mail hebdomadaire du ciel",
    weeklyDigestCopy: "Un e-mail par semaine\u202F: le ciel compar\xE9 \xE0 tes th\xE8mes enregistr\xE9s. D\xE9sabonne-toi \xE0 tout moment.",
    weeklyDigestAria: "Inscription \xE0 l\u2019e-mail hebdomadaire",
    digestSaved: "Pr\xE9f\xE9rence d\u2019e-mail enregistr\xE9e.",
    digestFailed: "Impossible de mettre \xE0 jour ta pr\xE9f\xE9rence d\u2019e-mail. R\xE9essaie.",
    checkEmail: "Consulte ta messagerie pour trouver ton lien de connexion. Cette page se synchronisera \xE0 ton retour.",
    syncFailed: "La synchronisation a \xE9chou\xE9. R\xE9essaie.",
    syncing: "Synchronisation\u2026",
    synced: "\xC0 jour",
    syncNow: "Synchroniser maintenant",
    signOut: "Se d\xE9connecter",
    emailSyncAria: "E-mail pour synchroniser le profil",
    sending: "Envoi en cours\u2026",
    sendSignIn: "Envoyer le lien de connexion",
    nothingSaved: "Rien d\u2019enregistr\xE9 pour le moment.",
    emptyProfile: "Les th\xE8mes que tu enregistres appara\xEEtront ici, d\u2019abord sur cet appareil. Calcule un th\xE8me et appuie sur Enregistrer ce th\xE8me pour commencer.",
    saved: "enregistr\xE9s",
    chartSingular: "th\xE8me",
    chartPlural: "th\xE8mes",
    savedChartSingular: "th\xE8me enregistr\xE9",
    savedChartPlural: "th\xE8mes enregistr\xE9s",
    syncedWhenSignedIn: "synchronis\xE9s apr\xE8s connexion",
    storedBrowser: "conserv\xE9s dans ce navigateur",
    chartName: "Nom du th\xE8me",
    timeUnknown: "heure inconnue",
    needsTime: "\u2014 heure n\xE9cessaire",
    compareThese: "Comparer ces deux th\xE8mes",
    addAnotherChart: "Ajouter un autre th\xE8me",
    ...GROWTH_UI_EN,
    footerWidgets: "Widgets",
    footerDisclosure: "D\xE9clarations",
    emailCaptureKicker: "Pr\xE9vision hebdomadaire gratuite",
    emailCaptureTitle: "Ta semaine \xE0 venir.",
    emailCapturePersonalTitle: "Ta semaine de {sign} \xE0 venir.",
    emailCaptureCopy: "Une pr\xE9vision hebdomadaire pour ton signe. Gratuite, avec d\xE9sabonnement \xE0 tout moment.",
    emailCaptureEmailLabel: "Adresse e-mail",
    emailCaptureEmailPlaceholder: "toi@exemple.com",
    emailCaptureSignLegend: "Ton signe solaire (facultatif)",
    emailCaptureNoSign: "Passer le signe",
    emailCaptureUsingSign: "Signe solaire utilis\xE9\xA0: {sign}",
    emailCaptureChangeSign: "Changer",
    emailCaptureSubmit: "Envoie-moi ma semaine",
    emailCaptureSubmitting: "Inscription\u2026",
    emailCaptureSuccess: "Consulte ta messagerie pour confirmer ton abonnement.",
    emailCaptureErrorTitle: "Abonnement indisponible",
    emailCaptureError: "Impossible de d\xE9marrer l\u2019abonnement. R\xE9essaie.",
    emailCapturePrivacy: "Nous conservons ton e-mail uniquement avec le signe choisi \u2014 jamais tes donn\xE9es de naissance.",
    emailCaptureHoneypot: "Laisse ce champ vide",
    emailPendingTitle: "Consulte ta messagerie.",
    emailPendingBody: "Utilise le lien de confirmation que nous t\u2019avons envoy\xE9 avant le d\xE9but de ta pr\xE9vision hebdomadaire.",
    emailConfirmSubject: "Confirme ta pr\xE9vision hebdomadaire Zodiacs.org",
    emailConfirmMessage: "Confirme que tu souhaites recevoir la pr\xE9vision hebdomadaire gratuite de Zodiacs.org\u202F:",
    emailConfirmIgnore: "Si tu n\u2019as pas fait cette demande, ignore cet e-mail. Aucun abonnement ne sera activ\xE9.",
    emailConfirmTitle: "Une derni\xE8re v\xE9rification.",
    emailConfirmBody: "Confirme cet abonnement pour commencer \xE0 recevoir la pr\xE9vision hebdomadaire gratuite. D\u2019ici l\xE0, aucun abonnement hebdomadaire n\u2019est actif.",
    emailConfirmAction: "Confirmer l\u2019abonnement",
    emailConfirmedTitle: "Abonnement confirm\xE9.",
    emailConfirmedBody: "Ta pr\xE9vision hebdomadaire gratuite est activ\xE9e. Chaque message contient un lien de d\xE9sabonnement.",
    emailConfirmInvalidTitle: "Ce lien n\u2019est pas valide.",
    emailConfirmInvalidBody: "Le lien de confirmation est invalide ou a expir\xE9. Retourne sur Zodiacs.org pour en demander un autre.",
    emailReturnHome: "Retourner sur Zodiacs.org"
  };
  var fr_default = fr;

  // src/lib/i18n/ui/it.ts
  init_define_import_meta_env();
  var it = {
    chartDepthOpen: "Vedilo in tre dimensioni",
    chartDepthClose: "Nascondi la terza dimensione",
    calculationLoadError: "Impossibile caricare i file di calcolo. Controlla la connessione e riprova.",
    calculationReload: "Ricarica la pagina",
    calculationReloadWarning: "Ricaricando si cancellano i dati non salvati.",
    calculationRetry: "Riprova",
    pfdYearError: "Non siamo riusciti a completare la lettura dell\u2019anno a venire. Riprova.",
    placeSearching: "Ricerca dei luoghi\u2026",
    chartWheelActions: "Azioni del tema",
    chartWheelGuide: "Inizia il tour guidato",
    chartWheelReplay: "Ripeti il tour",
    chartWheelAnother: "Leggi un altro tema",
    chartWheelSignatureSelf: "La firma del tuo tema",
    chartWheelSignatureOther: "La firma del suo tema",
    chartWheelCompareMine: "Confronta con il mio",
    chartWheelCompareAdd: "Aggiungi il mio tema per confrontare",
    chartWheelShareOther: "Condividi questo tema",
    navPrimary: "Navigazione principale",
    navSigns: "Segni",
    navTools: "Strumenti",
    navLearn: "Capire",
    navHoroscopes: "Oroscopi",
    navCollect: "Astrofolio",
    navSavedCharts: "Temi salvati",
    navMenu: "Menu",
    navSite: "Il sito",
    navTwelve: "I Dodici",
    footerTag: "Strumenti astrologici gratuiti e guide ai segni, con temi calcolati in privato nel tuo browser.",
    footerStartHere: "Inizia qui",
    footerPlanets: "I pianeti",
    footerHouses: "Le case",
    footerZodiacDates: "Date dei segni",
    footerGlossary: "Glossario",
    footerCompute: "Come calcoliamo",
    footerRegistry: "Registry",
    footerThesis: "Tesi",
    footerArchive: "Archivio",
    footerSdk: "SDK",
    footerCollectNote: "I record, le ricerche, i profili del catalogo e l\u2019SDK del Registry sono in sola lettura. Lo strumento di acquisto facoltativo di Astrofolio usa Jupiter, un servizio indipendente, e il tuo portafoglio; Zodiacs.org non custodisce chiavi n\xE9 fondi. Nulla di tutto ci\xF2 costituisce una consulenza finanziaria.",
    footerMethodology: "Metodologia",
    footerAbout: "Il progetto",
    footerPrivacy: "Privacy",
    footerTerms: "Termini",
    footerPlaceData: "Dati sui luoghi",
    footerFonts: "Font con licenza",
    skipContent: "Vai al contenuto",
    open: "Apri",
    birthChart: "Tema natale",
    compatibility: "Compatibilit\xE0",
    moonSign: "Segno lunare",
    risingSign: "Ascendente",
    moonPhase: "Fase lunare",
    saturnReturn: "Ritorno di Saturno",
    transits: "Transiti",
    birthday: "Compleanni (in inglese)",
    retrogrades: "Retrogradi",
    sun: "Sole",
    moon: "Luna",
    rising: "Ascendente",
    body: "Corpo celeste",
    position: "Posizione",
    sign: "Segno",
    house: "Casa",
    chart: "Tema",
    date: "Data",
    time: "Ora",
    place: "Luogo",
    motion: "Moto",
    optional: "facoltativo",
    birthDate: "Data di nascita",
    birthTime: "Ora di nascita",
    birthplace: "Luogo di nascita",
    birthDateRequired: "Inserisci la data di nascita.",
    birthDateRange: "Scegli una data di nascita tra il 1800 e il 2199.",
    birthTimeRequired: "Inserisci l\u2019ora di nascita.",
    houseSystem: "Sistema di case",
    wholeSignDefault: "Case a segno intero (predefinito)",
    placidus: "Placidus",
    houseSystemHelp: "Come la carta si divide in dodici aree della vita. Con le case a segno intero ogni segno \xE8 una casa intera; Placidus varia l\u2019ampiezza delle case secondo l\u2019ora e il luogo esatti. I pianeti non si spostano: cambiano solo i confini delle case.",
    computing: "Calcolo in corso\u2026",
    checking: "Verifica in corso\u2026",
    comparing: "Confronto in corso\u2026",
    save: "Salva",
    rename: "Rinomina",
    remove: "Rimuovi",
    getBirthChart: "Calcola gratis il tuo tema natale",
    findMoonSign: "Scopri il tuo segno lunare",
    findRisingSign: "Scopri il tuo ascendente",
    savedCharts: "Temi salvati",
    profile: "Il tuo profilo",
    read: "Leggi",
    rightNow: "In questo momento",
    enterBirthDetails: "Inserisci i dati di nascita\u2026",
    privacyDevice: "Privato per impostazione predefinita. I tuoi dati di nascita restano in questo browser.",
    placePlaceholder: "Inizia a digitare una citt\xE0\u2026",
    placeChange: "Cambia luogo di nascita",
    placePickHint: "Scegli il luogo di nascita dall\u2019elenco.",
    placeNoResults: "Non \xE8 nell\u2019elenco? Scegli la citt\xE0 pi\xF9 vicina \u2014 pochi chilometri cambiano raramente il tema.",
    placeError: "Non \xE8 stato possibile caricare l\u2019indice dei luoghi \u2014 controlla la connessione e riprova.",
    searchGeo: "La ricerca include circa 34.000 luoghi \xB7 GeoNames (CC BY 4.0)",
    chartError: "Si \xE8 verificato un problema durante il calcolo del tema. Riprova.",
    moonError: "Si \xE8 verificato un problema durante il calcolo della Luna. Riprova.",
    localDateReferenceError: "Non \xE8 stato possibile stabilire un orario di calcolo all\u2019interno di questa data locale. Controlla la data e il luogo.",
    returnError: "Si \xE8 verificato un problema durante il calcolo del ritorno. Riprova.",
    transitError: "Si \xE8 verificato un problema durante il calcolo dei transiti. Riprova.",
    compareError: "Si \xE8 verificato un problema durante il confronto dei temi. Riprova.",
    noBirthTime: "Non la conosco",
    risingTimeHelp: "L\u2019ascendente cambia ogni due ore \u2014 qui l\u2019orario conta.",
    chartTimeHelp: "Non conosci l\u2019ora di nascita? Vedrai un riferimento al mezzogiorno locale, senza ascendente n\xE9 case; la Luna pu\xF2 essere incerta.",
    chartSavedDevice: "Salvato \xB7 su questo dispositivo",
    saveThisChart: "Salva questo tema",
    chartSavedStatus: "Tema salvato su questo dispositivo.",
    chartSaveFull: "Puoi salvare fino a 40 temi \u2014 prima rimuovine uno.",
    chartSaveError: "Non \xE8 stato possibile salvare \u2014 il browser potrebbe bloccare l\u2019archiviazione locale.",
    chartSavedMessage: "Salvato tra i tuoi temi. Accedi qui quando vorrai ritrovarli su ogni dispositivo.",
    linkCopied: "Link copiato",
    copyChartLink: "Copia un link a questo tema",
    rendering: "Creazione in corso\u2026",
    cardSaved: "Immagine salvata",
    saveChartCard: "Salva un\u2019immagine del tema",
    shareChart: "Condividi il tuo tema",
    linkToChart: "Link a questo tema",
    chartLinkCopied: "Link al tema copiato negli appunti.",
    chartCardSaved: "Immagine del tema salvata.",
    cardError: "Non \xE8 stato possibile creare l\u2019immagine in questo browser \u2014 puoi anche acquisire una schermata della ruota qui sopra.",
    shareNote: "Il link contiene i dati di nascita che hai inserito \u2014 non ci viene inviato nulla, quindi pu\xF2 aprirlo solo chi lo riceve da te. L\u2019immagine 1080\xD71350 viene creata sul tuo dispositivo.",
    needsBirthTime: "Serve l\u2019ora di nascita",
    yourMoonSign: "Il tuo segno lunare",
    yourRisingSign: "Il tuo ascendente",
    moonPhaseAtBirth: "Fase lunare alla nascita",
    chartRuler: "Governatore del tema",
    planetSteering: "il pianeta che governa il tuo ascendente.",
    aspectsFound: "Aspetti",
    found: "trovati",
    applying: "applicativo",
    wholeSignHouses: "Case a segno intero",
    placidusHouses: "Case Placidus",
    engine: "motore v",
    readInOrder: "Leggere il tema in ordine",
    readIntro: "Dall\u2019alto verso il basso, come farebbe un astrologo. Le tabelle qui sopra sono i dati; ecco che cosa raccontano.",
    readBigThree: "Inizia dai tre pilastri",
    readBigThreeBody: "Sole, Luna, ascendente \u2014 le tre schede in alto. Identit\xE0, istinto, modo di entrare nel mondo. Tutto il resto li precisa; nulla li sostituisce.",
    readRooms: "I pianeti, casa per casa",
    readNoHouses: "Senza l\u2019ora di nascita non ci sono case, quindi ogni pianeta si legge solo nel segno. Aggiungi l\u2019ora e in questa sezione compariranno le case.",
    readAspects: "Gli aspetti pi\xF9 influenti",
    readWeather: "Il clima del tema",
    readIn: "in",
    today: "oggi",
    todayBySignTitle: "Il cielo di oggi, segno per segno",
    todayBySignPrompt: "Tocca il tuo segno solare per una lettura chiara di oggi \u2014 non serve l\u2019ora di nascita.",
    todaySolarNote: "letto dalle case solari del tuo segno",
    whyThisReading: "Perch\xE9 questa lettura",
    todayHoroscopeLink: "oroscopo",
    or: "oppure",
    chartSavedBeforeLink: "Salvato tra i tuoi temi. Accedi",
    chartSavedLink: "qui",
    chartSavedAfterLink: "quando vorrai ritrovarli su ogni dispositivo.",
    signedInAs: "Accesso effettuato come {email}",
    removeChartConfirm: "Rimuovere \u201C{name}\u201D da questo dispositivo?",
    compareSavedHeading: "Confronta {a} e {b}",
    compareSavedPitch: "Due temi salvati aspettano solo di essere confrontati: tutti gli aspetti fra i due, letti con sincerit\xE0 e calcolati su questo dispositivo.",
    saturnDateHelp: "La sola data individua gli anni del tuo ritorno. Ora e luogo precisano le date di qualche giorno, senza cambiare mai l\u2019anno.",
    saturnReturnHeading: "{ordinal} ritorno",
    skyMercuryRetrograde: "Mercurio retrogrado",
    skyMercuryDirect: "Mercurio diretto",
    skyPlanetRetrograde: "{planet} retrogrado",
    skyFullMoon: "Luna piena",
    skyNewMoon: "Luna nuova",
    skyMoonOn: "{event} \xB7 {date}",
    skyAsOf: "{date} \xB7 12 UTC",
    skyTickerAria: "Posizioni nel cielo per il {date} alle 12:00 UTC",
    moonDiscAria: "Luna illuminata al {percent}%",
    pairingCta: "Leggi l\u2019abbinamento fra {a} e {b}",
    inviteWith: "Invita qualcuno a confrontare il proprio tema con quello di {name}",
    inviteNamedNote: "Il link contiene i dati di nascita di {name} e apre questa pagina con quel lato gi\xE0 compilato \u2014 non ci viene inviato nulla. Se non sei tu, \xE8 bene avere il suo consenso.",
    transitMiddayUtc: "{date} \xB7 mezzogiorno UTC",
    planetReturn: "Ritorno di {planet}",
    natalPlanet: "{planet} natale",
    pfdToday: "Oggi per questo tema",
    pfdComing: "In arrivo per questo tema",
    pfdYearAhead: "I prossimi dodici mesi per questo tema",
    pfdYearBusy: "Calcolo dell\u2019anno sul tuo dispositivo \u2014 ancora qualche secondo\u2026",
    pfdYearNote: "Calcolato dal tuo tema salvato: date esatte per i prossimi dodici mesi.",
    saveYearAheadNote: "Nella pagina del profilo, i temi salvati ricevono il calcolo dei prossimi dodici mesi \u2014 ritorno solare, date di Giove e Saturno, contatti con le eclissi.",
    recordLabel: "Ala della collezione",
    recordOneOfTwelve: "esiste anche come uno dei Dodici \u2014 una scheda di riferimento nel registro.",
    recordViewLink: "Vedi la scheda \u2014 per ora in inglese \u2192",
    recordChartSun: "Il tuo Sole \xE8 in {sign}.",
    recordChartBody: "{sign} \xE8 uno dei Dodici, con la propria arte, storia e scheda ufficiale nel Registro.",
    recordChartLink: "Esplora il Registro di {sign} \u2192",
    babyDueDate: "Data prevista del parto",
    babyCompute: "Leggi il cielo della data prevista",
    babyNeedDate: "Inserisci prima una data prevista.",
    babyError: "Si \xE8 verificato un problema durante il calcolo del cielo. Riprova.",
    babySunHead: "Segno solare \u2014 quasi certo",
    babySunSingle: "Una nascita in questa data avr\xE0 il Sole in",
    babySunNearEdge: "La data \xE8 vicina al confine del segno, quindi nascere pi\xF9 di un giorno prima o dopo pu\xF2 portare il Sole in",
    babySunNearEdgeTail: "\u2014 decide la data di nascita.",
    babySunSplitA: "In questa data il Sole cambia segno: alla nascita sar\xE0 in",
    babySunSplitOr: "oppure in",
    babySunSplitTail: "a seconda dell\u2019ora. Decide il momento esatto della nascita.",
    babyNoonNote: "segni letti a mezzogiorno nel tempo universale",
    babyMoonHead: "Segno lunare \u2014 una fra poche possibilit\xE0",
    babyMoonBody: "La Luna cambia segno ogni due o tre giorni, quindi la settimana prevista di solito comprende due o tre segni lunari. Chi nasce nella stessa settimana pu\xF2 avere un segno lunare diverso \u2014 decidono il giorno e l\u2019ora di nascita.",
    babyRetroHead: "Retrogradi alla nascita",
    babyRetroBody: "questi pianeti attraversano il loro periodo retrogrado intorno alla data prevista. In un tema natale, un pianeta retrogrado si interpreta come pi\xF9 rivolto all\u2019interno del solito \u2014 \xE8 comune e non c\u2019\xE8 nulla da correggere.",
    babyRisingHead: "Ascendente \u2014 impossibile saperlo fino al minuto esatto",
    babyRisingBody: "L\u2019ascendente cambia all\u2019incirca ogni due ore, quindi nessuna data prevista pu\xF2 predirlo. \xC8 l\u2019unico elemento che deve aspettare il certificato di nascita.",
    babyDateLink: "Leggi questa data di nascita in dettaglio",
    babyChartLink: "Dopo la nascita: il tema completo",
    pfdChartPick: "Tema",
    pfdQuietSky: "Un cielo tranquillo per questo tema oggi \u2014 nessun transito cade entro 3\xB0 da un punto natale.",
    pfdQuietAhead: "Niente di importante all\u2019orizzonte di questo tema nella finestra calcolata.",
    pfdSaturnBusy: "Calcolo delle finestre di Saturno sul tuo dispositivo\u2026",
    pfdEmptyTitle: "Il tuo cielo, dopo aver salvato un tema",
    pfdEmptyBody: "Salva un tema natale e ogni giorno questa pagina si aprir\xE0 con i suoi transiti, le sue case e ci\xF2 che lo aspetta.",
    pfdWindows: "finestre",
    openChart: "Apri",
    dignityDomicile: "domicilio",
    dignityExaltation: "esaltazione",
    dignityDetriment: "esilio",
    dignityFall: "caduta",
    explorerHint: "Tocca un pianeta, un segno, una casa o una linea d\u2019aspetto per esaminarli \u2014 oppure seleziona la ruota e usa i tasti freccia.",
    explorerLabel: "Tema natale interattivo",
    explorerSelectPart: "Scegli una parte del tema",
    explorerNoSelection: "Nessuna selezione",
    explorerAngles: "Angoli",
    explorerControlsLoading: "Caricamento delle interpretazioni e dei comandi del tema\u2026",
    explorerControlsError: "Il tema \xE8 pronto, ma non \xE8 stato possibile caricare le interpretazioni e i comandi. Controlla la connessione e riprova.",
    explorerKeyHint: "Le frecce sinistra e destra scorrono le posizioni; Invio apre il pannello dei dettagli.",
    selectionCleared: "Selezione annullata.",
    inspectorClose: "Chiudi i dettagli",
    speed: "Velocit\xE0",
    day: "giorno",
    dignity: "Dignit\xE0",
    separating: "separativo",
    dates: "Date",
    element: "Elemento",
    ruler: "Governatore",
    inThisSign: "In questo segno",
    inThisHouse: "In questa casa",
    cusp: "Cuspide",
    span: "Ampiezza",
    emptyHouseNote: "Nessun pianeta qui. Una casa vuota non \xE8 uno spazio bianco \u2014 i suoi temi passano attraverso il pianeta che la governa.",
    angleAscNote: "L\u2019Ascendente \u2014 il grado che sorge all\u2019orizzonte orientale al momento della nascita. \xC8 il punto di riferimento dell\u2019intera ruota.",
    angleDscNote: "Il Discendente \u2014 il grado che tramonta a ovest, opposto all\u2019Ascendente. La porta tradizionale verso le relazioni.",
    angleMcNote: "Il Medio Cielo \u2014 il grado che culmina sopra di te alla nascita. Carriera, reputazione, vita visibile.",
    angleIcNote: "Il Fondo Cielo \u2014 il punto pi\xF9 basso della ruota, opposto al Medio Cielo. Casa, radici, vita privata.",
    layersLabel: "Livelli del tema",
    layerHouses: "Case",
    editedBy: "Pubblicato da",
    tourStart: "Inizia il tour",
    firstReadingLabel: "La tua lettura in 2 minuti",
    firstReadingTitle: "Cosa dice il tuo tema di te \u2014 e di ci\xF2 che viene dopo?",
    firstReadingBody: "Scopri la tua combinazione personale, dove emerge, uno schema che potresti riconoscere e come l\u2019astrologia trasforma un tema natale in una previsione.",
    firstReadingResumeTitle: "La tua lettura ti aspetta",
    firstReadingResumeBody: "Continua da dove eri rimasto su questo dispositivo.",
    firstReadingStart: "Leggi il mio tema",
    firstReadingExplore: "Esplora in autonomia",
    firstReadingResume: "Continua la mia lettura",
    firstReadingStep: "Passaggio",
    firstReadingFullTour: "Scopri come funziona il tema \u2014 tour avanzato",
    firstReadingReplay: "Rivedi la storia del mio tema",
    chartActionsMore: "Altri modi per usare questo tema",
    chartReceiptDownload: "Scarica il resoconto del calcolo (.json)",
    chartReceiptPrivacy: "Questo file contiene dati di nascita sensibili e dati del tema. Conservalo in privato.",
    chartReceiptError: "Non \xE8 stato possibile scaricare il file. Riprova.",
    chartReceiptUnavailable: "Non \xE8 disponibile un resoconto del calcolo per questo tema.",
    seeTodaySky: "Vedi il cielo di oggi",
    contextHelpCue: "Tocca i termini sottolineati con puntini per una spiegazione semplice.",
    editorialHow: "standard editoriali",
    dstGapNotice: "Quell\u2019ora cadeva nel salto dell\u2019ora legale, quindi non \xE8 mai esistita davvero \u2014 l\u2019abbiamo spostata in avanti oltre quel salto, secondo la convenzione standard.",
    dstFoldNotice: "Nel tuo luogo di nascita quell\u2019ora si \xE8 ripetuta; abbiamo usato il primo passaggio. Se sai che era il secondo, il tema cambia appena \u2014 la Luna si muove di circa mezzo grado all\u2019ora.",
    lmtNotice: "La tua nascita precede la standardizzazione dei fusi orari \u2014 abbiamo usato il tempo medio locale dell\u2019epoca, la stessa convenzione dei software professionali.",
    polarNotice: "Le case Placidus non sono definite cos\xEC vicino al polo, quindi questo tema usa invece le case a segno intero.",
    noTimeNotice: "Senza un\u2019ora di nascita usiamo le 12:00 dell\u2019ora civile locale come riferimento e omettiamo ascendente, angoli e case.",
    moonAmbiguousNotice: "Anche la Luna ha cambiato segno quel giorno \u2014 finch\xE9 non trovi l\u2019ora, \xE8 corretto leggere entrambi i segni vicini.",
    fromLinkNotice: "Aperto da un link condiviso \u2014 i dati di nascita erano nel link e il tema \xE8 stato appena calcolato sul tuo dispositivo.",
    howWeCompute: "Come calcoliamo",
    welcomeBack: "Che bello rivederti.",
    savedChartAria: "Il tuo tema salvato",
    todayAgainstChart: "Il cielo di oggi rispetto al tuo tema",
    yourCharts: "I tuoi temi",
    recommendedNext: "Passaggio consigliato",
    todayForName: "Scopri cosa significa oggi per {name}",
    savedChartTodayBody: "Il tuo tema non cambia. Il cielo di oggi s\xEC: inizia da ci\xF2 che sta cambiando per te adesso.",
    openSavedChart: "Apri il tema salvato",
    moonReadingSky: "Lettura del cielo\u2026",
    illuminated: "illuminata",
    moonIn: "Luna in",
    findThatMoon: "Trova quella Luna",
    dateHelp: "Un compleanno, un anniversario, una data qualsiasi.",
    placeHelpMoon: "Rende pi\xF9 precisa la conversione dell\u2019ora; per la fase cambia pochissimo.",
    middayLocalCaption: "Lettura a mezzogiorno locale \u2014 aggiungi l\u2019ora per fissare esattamente il grado.",
    utcTimeCaption: "L\u2019ora \xE8 letta come tempo universale \u2014 aggiungi il luogo di nascita per convertire l\u2019ora locale.",
    middayUtcCaption: "Lettura a mezzogiorno nel tempo universale \u2014 ora e luogo fissano il grado con precisione.",
    moonChangedNotice: "Quel giorno la Luna ha cambiato segno e, senza un\u2019ora, non possiamo dire da quale lato del confine si trovasse alla tua nascita. La fase non cambia \u2014 si muove troppo lentamente perch\xE9 poche ore facciano la differenza.",
    birthChartForDate: "Calcola il tema natale per questa data",
    natalSaturn: "Il tuo Saturno natale",
    addBirthDetails: "Aggiungi ora e luogo di nascita (facoltativo)",
    findSaturnReturn: "Trova il tuo ritorno di Saturno",
    returnApprox: "Date calcolate da una lettura a mezzogiorno \u2014 con ora e luogo di nascita possono spostarsi di qualche giorno in anticipo o in ritardo.",
    complete: "Completato",
    underwayNow: "In corso ora",
    aheadOfYou: "Davanti a te",
    first: "Primo",
    second: "Secondo",
    third: "Terzo",
    fourth: "Quarto",
    aroundAge29: "intorno ai 29 anni",
    aroundAge58: "intorno ai 58 anni",
    aroundAge88: "intorno agli 88 anni",
    retrogradePass: "passaggio retrogrado",
    threePasses: "Tre passaggi esatti: Saturno attraversa il tuo grado, lo ripercorre in moto retrogrado e poi lo sigilla mentre si allontana. L\u2019intero arco \xE8 il ritorno.",
    seeSaturnChart: "Guarda Saturno nel tuo tema natale",
    whatSaturnMeans: "Che cosa significa Saturno",
    yourChart: "Il tuo tema",
    theSky: "Il cielo",
    transitRingLede: "Disegna il tuo tema, poi sposta il cursore per osservare i pianeti che lo attraversano \u2014 avanti o indietro, fino a un anno.",
    checkTransits: "Controlla i tuoi transiti",
    savedChartHelp: "I temi che calcoli e salvi compaiono qui come scelte immediate, cos\xEC al controllo successivo non dovrai reinserire i dati.",
    noTransitTimeNotice: "Questo tema non ha un\u2019ora di nascita, quindi la sua Luna \xE8 una stima di mezzogiorno \u2014 la posizione pu\xF2 essere imprecisa fino a sei gradi e un transito alla Luna vicino al limite dell\u2019orbita pu\xF2 comparire o scomparire con l\u2019ora reale.",
    skyAt: "Cielo del",
    noTransitsWithin: "Nessun transito entro",
    activeTransitsWithin: "transiti attivi entro",
    activeTransitWithin: "transito attivo entro",
    ofExact: "dall\u2019aspetto esatto",
    transitMoonOmitted: "Luna in transito esclusa \u2014 attraversa l\u2019intero tema ogni mese",
    quietSky: "Un cielo tranquillo entro l\u2019orbita stretta usata in questa pagina. Nulla di urgente \u2014 torna fra qualche giorno oppure allarga la lettura agli eventi del mese qui sotto.",
    natal: "Natale",
    forYourChart: "Per il tuo tema",
    orb: "orbita",
    openDailyBrief: "Apri il mio riepilogo quotidiano completo",
    allTransits: "Tutti i tuoi transiti",
    personA: "Persona A",
    personB: "Persona B",
    sharedChart: "Tema condiviso",
    sharedWithYou: "condiviso con te",
    removeSharedChart: "Rimuovi il tema condiviso",
    sharedSideHelp: "Questo lato \xE8 arrivato nel link \u2014 svuotalo per inserire un\u2019altra persona.",
    name: "Nome",
    compareCharts: "Confronta i temi",
    sameChart: "\xC8 lo stesso tema due volte \u2014 scegline due diversi da confrontare.",
    compareSavedHelp: "I temi che calcoli e salvi compaiono qui come scelte immediate, cos\xEC il secondo confronto sar\xE0 pi\xF9 rapido del primo.",
    compareNoTimeNotice: "Ora di nascita assente per",
    moonMiddayEstimate: "quindi quella Luna \xE8 una stima di mezzogiorno \u2014 la posizione pu\xF2 essere imprecisa fino a sei gradi e un aspetto alla Luna vicino al limite dell\u2019orbita pu\xF2 comparire o scomparire con l\u2019ora reale.",
    crossChartAspects: "aspetti fra i due temi",
    easeful: "armonici",
    charged: "intensi",
    readPairing: "Leggi l\u2019abbinamento",
    inviteCompare: "Invita qualcuno al confronto",
    inviteLink: "Link di invito",
    inviteNote: "Il link contiene i dati di nascita di questa persona e apre la pagina con quel lato gi\xE0 compilato \u2014 non ci viene inviato nulla. Se non sei tu, \xE8 bene avere il suo consenso.",
    inviteCopied: "Link di invito copiato negli appunti.",
    syncOn: "Sincronizzazione attiva",
    keepEveryDevice: "Ritrova i temi su ogni dispositivo",
    signedIn: "Accesso effettuato",
    syncCopyOn: "I temi salvati e le rimozioni vengono sincronizzati su tutti i tuoi dispositivi.",
    syncCopyOff: "Salva i temi su questo dispositivo. Accedi quando vorrai ritrovarli su ogni dispositivo.",
    weeklyDigestTitle: "Email settimanale sul cielo",
    weeklyDigestCopy: "Un\u2019email alla settimana: il cielo rispetto ai tuoi temi salvati. Puoi annullare l\u2019iscrizione in qualsiasi momento.",
    weeklyDigestAria: "Iscrizione all\u2019email settimanale",
    digestSaved: "Preferenza email salvata.",
    digestFailed: "Non \xE8 stato possibile aggiornare la preferenza email. Riprova.",
    checkEmail: "Controlla la posta per trovare il link di accesso. Questa pagina si sincronizzer\xE0 quando torni.",
    syncFailed: "Sincronizzazione non riuscita. Riprova.",
    syncing: "Sincronizzazione\u2026",
    synced: "Sincronizzato",
    syncNow: "Sincronizza ora",
    signOut: "Esci",
    emailSyncAria: "Email per sincronizzare il profilo",
    sending: "Invio in corso\u2026",
    sendSignIn: "Invia il link di accesso",
    nothingSaved: "Non hai ancora salvato nulla.",
    emptyProfile: "I temi che salvi compariranno qui, prima di tutto sul tuo dispositivo. Calcola un tema e tocca Salva questo tema per iniziare.",
    saved: "salvati",
    chartSingular: "tema",
    chartPlural: "temi",
    savedChartSingular: "tema salvato",
    savedChartPlural: "temi salvati",
    syncedWhenSignedIn: "sincronizzati dopo l\u2019accesso",
    storedBrowser: "memorizzati in questo browser",
    chartName: "Nome del tema",
    timeUnknown: "ora sconosciuta",
    needsTime: "serve un\u2019ora",
    compareThese: "Confronta questi due temi",
    addAnotherChart: "Aggiungi un altro tema",
    ...GROWTH_UI_EN,
    footerWidgets: "Widget",
    footerDisclosure: "Informativa",
    emailCaptureKicker: "Previsione settimanale gratuita",
    emailCaptureTitle: "La settimana che ti aspetta.",
    emailCapturePersonalTitle: "La tua settimana da {sign}.",
    emailCaptureCopy: "Una previsione settimanale per il tuo segno. Gratuita, puoi annullare l\u2019iscrizione quando vuoi.",
    emailCaptureEmailLabel: "Indirizzo e-mail",
    emailCaptureEmailPlaceholder: "tu@esempio.it",
    emailCaptureSignLegend: "Il tuo segno solare (facoltativo)",
    emailCaptureNoSign: "Salta il segno",
    emailCaptureUsingSign: "Segno solare usato: {sign}",
    emailCaptureChangeSign: "Cambia",
    emailCaptureSubmit: "Invia la mia settimana",
    emailCaptureSubmitting: "Iscrizione in corso\u2026",
    emailCaptureSuccess: "Controlla la posta per confermare l\u2019iscrizione.",
    emailCaptureErrorTitle: "Iscrizione non disponibile",
    emailCaptureError: "Non \xE8 stato possibile avviare l\u2019iscrizione. Riprova.",
    emailCapturePrivacy: "Conserviamo solo il tuo indirizzo e-mail e il segno scelto \u2014 mai i tuoi dati di nascita.",
    emailCaptureHoneypot: "Lascia vuoto questo campo",
    emailPendingTitle: "Controlla la posta.",
    emailPendingBody: "Usa il link di conferma che ti abbiamo inviato prima che inizi la previsione settimanale.",
    emailConfirmSubject: "Conferma la tua previsione settimanale di Zodiacs.org",
    emailConfirmMessage: "Conferma di voler ricevere la previsione settimanale gratuita di Zodiacs.org:",
    emailConfirmIgnore: "Se non hai fatto tu questa richiesta, ignora l\u2019e-mail. Non verr\xE0 attivata alcuna iscrizione.",
    emailConfirmTitle: "Un\u2019ultima verifica.",
    emailConfirmBody: "Conferma questa iscrizione per iniziare a ricevere la previsione settimanale gratuita. Fino ad allora non sar\xE0 attiva alcuna iscrizione settimanale.",
    emailConfirmAction: "Conferma l\u2019iscrizione",
    emailConfirmedTitle: "Iscrizione confermata.",
    emailConfirmedBody: "La tua previsione settimanale gratuita \xE8 attiva. Ogni messaggio contiene un link per annullare l\u2019iscrizione.",
    emailConfirmInvalidTitle: "Questo link non \xE8 valido.",
    emailConfirmInvalidBody: "Il link di conferma non \xE8 valido o \xE8 scaduto. Torna su Zodiacs.org per richiederne un altro.",
    emailReturnHome: "Torna su Zodiacs.org"
  };
  var it_default = it;

  // src/lib/i18n/ui/server.ts
  var UI = {
    en: en_default,
    es: es_default,
    pt: pt_default,
    fr: fr_default,
    it: it_default,
    ru: ru_default
  };
  function serverUiMessage(locale, key) {
    return UI[requireCatalogLocale(locale)][key];
  }

  // src/lib/i18n/english-only.ts
  init_define_import_meta_env();

  // src/lib/i18n/plural.ts
  init_define_import_meta_env();
  var EMPTY_PLURAL_CATALOG = Object.freeze({});

  // src/lib/i18n/index.ts
  var LOCALE_PATH_PREFIX = {
    en: "",
    es: "/es",
    pt: "/pt",
    fr: "/fr",
    it: "/it",
    ru: "/ru",
    ar: "/ar"
  };
  var CORE_LOCALIZED_PATHS = [
    "/",
    "/tools/",
    "/birth-chart/",
    "/compatibility/",
    "/moon-sign/",
    "/rising-sign/",
    "/moon-phase/",
    "/saturn-return/",
    "/transits/",
    "/baby-zodiac/",
    "/profile/",
    "/methodology/",
    "/privacy/",
    "/disclosure/",
    "/404.html",
    ...SIGN_SLUGS.map((slug) => `/${slug}/`)
  ];
  var CORE_ROUTE_LOCALES = ["en", "es", "pt", "fr", "it", "ru"];
  var DAILY_READING_ROUTE_LOCALES = ["en", "es", "pt"];
  var DAILY_READING_PATHS = [
    "/today/",
    "/horoscopes/",
    ...SIGN_SLUGS.map((slug) => `/horoscopes/${slug}/`)
  ];
  var INDEXABLE_SIGN_GUIDE_LOCALES = ["en", "es", "pt", "fr", "it"];
  var STAGED_CORE_ROUTE_LOCALES = [];
  var PROGRAMMATIC_ROUTE_LOCALES = ["en", "es", "pt", "fr", "it"];
  var LOCALIZED_PATHS = new Map([
    ...CORE_LOCALIZED_PATHS.map((path) => [
      path,
      SIGN_SLUGS.some((slug) => path === `/${slug}/`) ? INDEXABLE_SIGN_GUIDE_LOCALES : CORE_ROUTE_LOCALES
    ]),
    ...DAILY_READING_PATHS.map((path) => [path, DAILY_READING_ROUTE_LOCALES])
  ]);
  var BIRTHDAY_MONTH_LENGTHS = Object.freeze({
    january: 31,
    february: 29,
    march: 31,
    april: 30,
    may: 31,
    june: 30,
    july: 31,
    august: 31,
    september: 30,
    october: 31,
    november: 30,
    december: 31
  });
  var CHINESE_ZODIAC_SLUGS = /* @__PURE__ */ new Set([
    "rat",
    "ox",
    "tiger",
    "rabbit",
    "dragon",
    "snake",
    "horse",
    "goat",
    "monkey",
    "rooster",
    "dog",
    "pig"
  ]);
  function isLocalizedChineseZodiacPath(path) {
    if (path === "/learn/chinese-zodiac/") return true;
    const animal = path.match(/^\/learn\/chinese-zodiac\/([a-z]+)\/$/)?.[1];
    if (animal) return CHINESE_ZODIAC_SLUGS.has(animal);
    return false;
  }
  function isLocalizedBirthdayPath(path) {
    const birthday = path.match(/^\/birthday\/([a-z]+)-(\d{1,2})\/$/);
    if (!birthday) return false;
    const maxDay = BIRTHDAY_MONTH_LENGTHS[birthday[1]];
    const day = Number(birthday[2]);
    return Boolean(maxDay && birthday[2] === String(day) && day >= 1 && day <= maxDay);
  }
  function renderableLocalesForPath(path) {
    const canonical = stripLocale(path);
    if (CORE_LOCALIZED_PATHS.includes(canonical)) {
      return [...CORE_ROUTE_LOCALES, ...STAGED_CORE_ROUTE_LOCALES];
    }
    if (DAILY_READING_PATHS.includes(canonical)) return DAILY_READING_ROUTE_LOCALES;
    return isLocalizedChineseZodiacPath(canonical) || isLocalizedBirthdayPath(canonical) ? PROGRAMMATIC_ROUTE_LOCALES : void 0;
  }
  function stripLocale(path) {
    for (const locale of LOCALES) {
      const prefix = LOCALE_PATH_PREFIX[locale];
      if (!prefix) continue;
      if (path === prefix) return "/";
      if (path.startsWith(`${prefix}/`)) return path.slice(prefix.length) || "/";
    }
    return path;
  }
  function localizePath(locale, path) {
    if (path.startsWith("http") || path.startsWith("#")) return path;
    const clean = path.startsWith("/") ? path : `/${path}`;
    const canonical = stripLocale(clean);
    if (locale === DEFAULT_LOCALE) return canonical;
    if (!renderableLocalesForPath(canonical)?.includes(locale)) return canonical;
    return `${LOCALE_PATH_PREFIX[locale]}${canonical}`;
  }
  function t3(locale, key) {
    return define_import_meta_env_default.SSR ? serverUiMessage(locale, key) : clientUiMessage(locale, key);
  }
  function tf(locale, key, values) {
    return t3(locale, key).replace(/\{([a-zA-Z][a-zA-Z0-9]*)\}/g, (token, name) => Object.prototype.hasOwnProperty.call(values, name) ? String(values[name]) : token);
  }

  // src/lib/module-load.ts
  init_define_import_meta_env();
  var ModuleLoadError = class extends Error {
    constructor(cause) {
      super("Calculation module unavailable", { cause });
      this.name = "ModuleLoadError";
    }
  };
  async function loadModule(load) {
    try {
      return await load();
    } catch (cause) {
      throw new ModuleLoadError(cause);
    }
  }

  // src/islands/CalculationReload.tsx
  init_define_import_meta_env();
  var calculationLoadMessage = (locale) => t3(locale, "calculationLoadError");
  function calculationError(cause, locale, fallback) {
    return cause instanceof ModuleLoadError ? calculationLoadMessage(locale) : fallback;
  }
  function CalculationReload({ error, locale }) {
    if (error !== calculationLoadMessage(locale)) return null;
    return /* @__PURE__ */ u3("div", { class: "field__help", children: [
      /* @__PURE__ */ u3("button", { class: "btn btn--glass", type: "button", onClick: () => window.location.reload(), children: t3(locale, "calculationReload") }),
      " ",
      t3(locale, "calculationReloadWarning")
    ] });
  }

  // src/islands/PlaceSearch.tsx
  var loadSearch = () => loadModule(() => Promise.resolve().then(() => (init_places(), places_exports)));
  function PlaceSearch({
    onSelect,
    selected,
    id = "place",
    locale = "en",
    validationError,
    selectionHint,
    required = false
  }) {
    const [query, setQuery] = d2("");
    const [results, setResults] = d2([]);
    const [open, setOpen] = d2(false);
    const [active, setActive] = d2(0);
    const [error, setError] = d2("");
    const [loading, setLoading] = d2(false);
    const debounce = A2();
    const requestToken = A2(0);
    const inputRef = A2(null);
    const pickHint = validationError || (!selected && query.trim() ? selectionHint : "");
    h2(() => () => {
      clearTimeout(debounce.current);
      ++requestToken.current;
    }, []);
    h2(() => {
      if (selected) {
        clearTimeout(debounce.current);
        ++requestToken.current;
        setOpen(false);
        setLoading(false);
      }
    }, [selected]);
    function onInput(value) {
      const token = ++requestToken.current;
      setQuery(value);
      onSelect(null);
      clearTimeout(debounce.current);
      setOpen(false);
      setError("");
      value = value.trim();
      setLoading(value.length >= 2);
      if (!value[1]) return;
      debounce.current = setTimeout(async () => {
        try {
          const { searchCities: searchCities2 } = await loadSearch();
          if (token !== requestToken.current) return;
          const cities = await searchCities2(value);
          if (token === requestToken.current) {
            setResults(cities);
            setActive(0);
            setOpen(true);
          }
        } catch (cause) {
          if (token === requestToken.current) setError(calculationError(cause, locale, t3(locale, "placeError")));
        } finally {
          if (token === requestToken.current) setLoading(false);
        }
      }, 120);
    }
    function choose(city2) {
      clearTimeout(debounce.current);
      ++requestToken.current;
      onSelect(city2);
      setQuery("");
      setOpen(false);
      setLoading(false);
    }
    function onKeyDown(e3) {
      if (!open) return;
      if (e3.key === "ArrowDown" && results.length) {
        e3.preventDefault();
        setActive((a3) => Math.min(a3 + 1, results.length - 1));
      } else if (e3.key === "ArrowUp" && results.length) {
        e3.preventDefault();
        setActive((a3) => Math.max(a3 - 1, 0));
      } else if (e3.key === "Enter") {
        e3.preventDefault();
        if (results[active]) choose(results[active]);
      } else if (e3.key === "Escape") setOpen(false);
    }
    if (selected) {
      const chipValue = [selected.name, [selected.admin1, selected.country].filter(Boolean).join(", ")].filter(Boolean).join(" \xB7 ");
      return /* @__PURE__ */ u3("div", { class: "place place--selected", children: /* @__PURE__ */ u3("span", { class: "place__chip", children: [
        /* @__PURE__ */ u3("input", { id, class: "place__chip-value", readOnly: true, value: chipValue }),
        /* @__PURE__ */ u3("button", { type: "button", class: "place__clear", "aria-label": t3(locale, "placeChange"), onClick: () => onSelect(null), children: "\xD7" })
      ] }) });
    }
    return /* @__PURE__ */ u3("div", { class: "place", onFocusOut: (event) => {
      if (!event.currentTarget.contains(event.relatedTarget)) {
        clearTimeout(debounce.current);
        ++requestToken.current;
        setOpen(false);
        setLoading(false);
      }
    }, children: [
      /* @__PURE__ */ u3(
        "input",
        {
          id,
          ref: inputRef,
          class: "field__input",
          role: "combobox",
          "aria-expanded": open,
          "aria-autocomplete": "list",
          "aria-controls": `${id}-list`,
          "aria-activedescendant": open && results[active] ? `${id}-opt-${active}` : void 0,
          "aria-describedby": pickHint ? `${id}-pick-hint` : void 0,
          "aria-invalid": validationError ? "true" : void 0,
          "aria-required": required || void 0,
          placeholder: t3(locale, "placePlaceholder"),
          autocomplete: "off",
          value: query,
          onFocus: () => {
            void loadSearch().then(({ preloadIndex: preloadIndex2 }) => {
              void preloadIndex2();
            }, () => {
            });
          },
          onInput: (e3) => onInput(e3.target.value),
          onKeyDown
        }
      ),
      pickHint && /* @__PURE__ */ u3(
        "p",
        {
          id: `${id}-pick-hint`,
          class: validationError ? "place__error" : "place__hint",
          role: validationError ? "alert" : void 0,
          children: pickHint
        }
      ),
      loading && /* @__PURE__ */ u3("p", { class: "place__hint", role: "status", children: t3(locale, "placeSearching") }),
      error && /* @__PURE__ */ u3("div", { class: "place__error", children: [
        /* @__PURE__ */ u3("p", { role: "alert", children: error }),
        /* @__PURE__ */ u3("button", { class: "btn btn--glass", type: "button", onClick: () => {
          inputRef.current?.focus();
          onInput(query);
        }, children: t3(locale, "calculationRetry") }),
        /* @__PURE__ */ u3(CalculationReload, { error, locale })
      ] }),
      open && /* @__PURE__ */ u3("ul", { class: "place__list", id: `${id}-list`, role: "listbox", children: results.length ? results.map((c3, i3) => /* @__PURE__ */ u3("li", { role: "none", children: /* @__PURE__ */ u3(
        "button",
        {
          type: "button",
          id: `${id}-opt-${i3}`,
          role: "option",
          "aria-selected": i3 === active,
          tabIndex: -1,
          class: i3 === active ? "place__option is-active" : "place__option",
          onMouseEnter: () => setActive(i3),
          onClick: () => choose(c3),
          children: [
            /* @__PURE__ */ u3("span", { class: "place__name", children: c3.name }),
            /* @__PURE__ */ u3("span", { class: "place__meta", children: [c3.admin1, c3.country].filter(Boolean).join(", ") })
          ]
        }
      ) }, c3.name + c3.lat + c3.lon)) : /* @__PURE__ */ u3("li", { class: "place__empty", role: "option", "aria-disabled": true, children: t3(locale, "placeNoResults") }) })
    ] });
  }

  // src/islands/SignChip.tsx
  init_define_import_meta_env();
  function SignChip({ lon, locale: rawLocale = "en" }) {
    const locale = normalizeCatalogLocale(rawLocale);
    const s3 = signForLongitude(lon);
    return /* @__PURE__ */ u3("a", { class: "chip", href: localizePath(locale, `/${s3.slug}/`), style: `--sign:${s3.hue}`, children: [
      /* @__PURE__ */ u3("picture", { class: "chip__icon", children: [
        /* @__PURE__ */ u3("source", { srcset: `/assets/zodiac-icons/48/${s3.slug}.avif`, type: "image/avif" }),
        /* @__PURE__ */ u3("img", { src: `/assets/zodiac-icons/48/${s3.slug}.webp`, width: "18", height: "18", alt: "", loading: "lazy", decoding: "async" })
      ] }),
      signName(s3, locale)
    ] });
  }

  // src/lib/engine/lite.ts
  init_define_import_meta_env();
  var DEG = Math.PI / 180;
  var norm = (d3) => (d3 % 360 + 360) % 360;
  function daysSinceJ2000(date) {
    return (date.getTime() - Date.UTC(2e3, 0, 1, 12)) / 864e5;
  }
  function sunLongitude(date) {
    const n2 = daysSinceJ2000(date);
    const L2 = 280.46 + 0.9856474 * n2;
    const g2 = (357.528 + 0.9856003 * n2) * DEG;
    return norm(L2 + 1.915 * Math.sin(g2) + 0.02 * Math.sin(2 * g2));
  }
  function moonLongitude(date) {
    const n2 = daysSinceJ2000(date);
    const Lp = 218.316 + 13.176396 * n2;
    const M = (134.963 + 13.064993 * n2) * DEG;
    const Ms = (357.528 + 0.9856003 * n2) * DEG;
    const D3 = (297.85 + 12.190749 * n2) * DEG;
    const F = (93.272 + 13.22935 * n2) * DEG;
    const lon = Lp + 6.289 * Math.sin(M) + 1.274 * Math.sin(2 * D3 - M) + 0.658 * Math.sin(2 * D3) + 0.214 * Math.sin(2 * M) - 0.186 * Math.sin(Ms) - 0.114 * Math.sin(2 * F);
    return norm(lon);
  }
  function moonPhaseAngle(date) {
    return norm(moonLongitude(date) - sunLongitude(date));
  }
  function moonIllumination(date) {
    return (1 - Math.cos(moonPhaseAngle(date) * DEG)) / 2;
  }
  function moonPhaseName(date) {
    const a3 = moonPhaseAngle(date);
    if (a3 < 22.5 || a3 >= 337.5) return "New Moon";
    if (a3 < 67.5) return "Waxing Crescent";
    if (a3 < 112.5) return "First Quarter";
    if (a3 < 157.5) return "Waxing Gibbous";
    if (a3 < 202.5) return "Full Moon";
    if (a3 < 247.5) return "Waning Gibbous";
    if (a3 < 292.5) return "Last Quarter";
    return "Waning Crescent";
  }

  // src/lib/time/localToUtc.ts
  init_define_import_meta_env();

  // src/lib/time/technical-locales.ts
  init_define_import_meta_env();
  var TECHNICAL_OFFSET_LOCALE = "en-US";
  var TECHNICAL_WALL_LOCALE = "en-CA";

  // src/lib/time/civil-date.ts
  init_define_import_meta_env();
  function parseCivilDate(value) {
    if (typeof value !== "string" || value.length !== 10) return null;
    const match = /^(\d{4})-(\d{2})-(\d{2})$/.exec(value);
    if (!match) return null;
    const year = Number(match[1]);
    const month = Number(match[2]);
    const day = Number(match[3]);
    if (month < 1 || month > 12 || day < 1) return null;
    const leap = year % 4 === 0 && (year % 100 !== 0 || year % 400 === 0);
    const days = month === 2 ? leap ? 29 : 28 : [4, 6, 9, 11].includes(month) ? 30 : 31;
    return day <= days ? { year, month, day } : null;
  }
  function parseCivilTime(value) {
    if (typeof value !== "string" || value.length !== 5) return null;
    const match = /^(\d{2}):(\d{2})$/.exec(value);
    if (!match) return null;
    const hour = Number(match[1]);
    const minute = Number(match[2]);
    return hour <= 23 && minute <= 59 ? { hour, minute } : null;
  }

  // src/lib/time/localToUtc.ts
  var offsetFormatters = /* @__PURE__ */ new Map();
  var wallFormatters = /* @__PURE__ */ new Map();
  function offsetFormatter(tz) {
    if (typeof tz !== "string" || tz.length === 0) {
      throw new RangeError("An explicit supported timezone is required.");
    }
    let f4 = offsetFormatters.get(tz);
    if (!f4) {
      try {
        f4 = new Intl.DateTimeFormat(TECHNICAL_OFFSET_LOCALE, { timeZone: tz, timeZoneName: "longOffset" });
      } catch {
        throw new RangeError("An explicit supported timezone is required.");
      }
      offsetFormatters.set(tz, f4);
    }
    return f4;
  }
  function wallFormatter(tz) {
    let f4 = wallFormatters.get(tz);
    if (!f4) {
      f4 = new Intl.DateTimeFormat(TECHNICAL_WALL_LOCALE, {
        timeZone: tz,
        calendar: "gregory",
        numberingSystem: "latn",
        era: "short",
        year: "numeric",
        month: "2-digit",
        day: "2-digit",
        hour: "2-digit",
        minute: "2-digit",
        second: "2-digit",
        fractionalSecondDigits: 3,
        hourCycle: "h23"
      });
      wallFormatters.set(tz, f4);
    }
    return f4;
  }
  function offsetAt(tz, utcMs) {
    const parts = offsetFormatter(tz).formatToParts(utcMs);
    const name = parts.find((p3) => p3.type === "timeZoneName")?.value ?? "GMT";
    const m3 = name.match(/GMT([+-])?(\d{1,2})?(?::(\d{2}))?(?::(\d{2}))?/);
    if (!m3) return 0;
    const sign = m3[1] === "-" ? -1 : 1;
    const h3 = Number(m3[2] ?? 0);
    const min = Number(m3[3] ?? 0);
    const s3 = Number(m3[4] ?? 0);
    return sign * (h3 * 60 + min + s3 / 60);
  }
  function wallStringAt(tz, utcMs) {
    const parts = wallFormatter(tz).formatToParts(utcMs);
    const part = (type) => parts.find((candidate) => candidate.type === type)?.value ?? "";
    const era2 = part("era");
    if (era2 !== "AD" && era2 !== "BC") throw new RangeError("Could not read Gregorian era.");
    const year = era2 === "BC" ? 1 - Number(part("year")) : Number(part("year"));
    const isoYear = year >= 0 && year <= 9999 ? String(year).padStart(4, "0") : `${year < 0 ? "-" : "+"}${String(Math.abs(year)).padStart(6, "0")}`;
    return `${isoYear}-${part("month")}-${part("day")}T${part("hour")}:${part("minute")}:${part("second")}.${part("fractionalSecond")}`;
  }
  function localDateContainsUtc(date, utc, timeZone) {
    try {
      if (!parseCivilDate(date) || typeof timeZone !== "string" || timeZone.length === 0) {
        throw new RangeError();
      }
      const instant = Date.prototype.getTime.call(utc);
      if (!Number.isFinite(instant)) throw new RangeError();
      return wallStringAt(timeZone, instant).split("T")[0] === date;
    } catch {
      throw new RangeError("Could not determine local-date membership from the supplied date, instant and explicit timezone.");
    }
  }
  function resolveLocalToUtc(date, time, tz) {
    const civilDate = parseCivilDate(date);
    const civilTime = parseCivilTime(time);
    if (!civilDate || !civilTime) {
      throw new RangeError("resolveLocalToUtc needs a valid YYYY-MM-DD date and HH:MM time.");
    }
    const wallDate = /* @__PURE__ */ new Date(0);
    wallDate.setUTCFullYear(civilDate.year, civilDate.month - 1, civilDate.day);
    wallDate.setUTCHours(civilTime.hour, civilTime.minute, 0, 0);
    const wallMs = wallDate.getTime();
    const wallStr = `${date}T${time}:00.000`;
    const sampled = [
      offsetAt(tz, wallMs - 36 * 36e5),
      offsetAt(tz, wallMs),
      offsetAt(tz, wallMs + 36 * 36e5)
    ];
    const candidates = [...new Set(sampled)];
    const matches = [];
    for (const off of candidates) {
      const utcMs = wallMs - Math.round(off * 6e4);
      if (wallStringAt(tz, utcMs) === wallStr) {
        matches.push({ utcMs, offset: offsetAt(tz, utcMs) });
      }
    }
    const flags = [];
    let chosen;
    if (matches.length === 1) {
      chosen = matches[0];
    } else if (matches.length > 1) {
      matches.sort((a3, b2) => a3.utcMs - b2.utcMs);
      chosen = matches[0];
      flags.push("dst-fold");
    } else {
      const before = offsetAt(tz, wallMs - 36 * 36e5);
      const utcMs = wallMs - Math.round(before * 6e4);
      chosen = { utcMs, offset: offsetAt(tz, utcMs) };
      flags.push("dst-gap");
    }
    if (Math.abs(chosen.offset % 1) > 1e-9) flags.push("lmt");
    return { utc: new Date(chosen.utcMs), offsetMinutes: chosen.offset, flags };
  }

  // src/lib/i18n/dates.ts
  init_define_import_meta_env();
  function intlLocale(locale) {
    return LOCALE_META[locale].intlLocale;
  }
  function formatDateTime(locale, value, options) {
    const date = typeof value === "string" ? new Date(value) : value;
    return new Intl.DateTimeFormat(intlLocale(locale), options).format(date);
  }

  // src/lib/i18n/astrology.ts
  init_define_import_meta_env();
  var MOON_PHASE_LABELS = {
    en: {
      "New Moon": "New Moon",
      "Waxing Crescent": "Waxing Crescent",
      "First Quarter": "First Quarter",
      "Waxing Gibbous": "Waxing Gibbous",
      "Full Moon": "Full Moon",
      "Waning Gibbous": "Waning Gibbous",
      "Last Quarter": "Last Quarter",
      "Waning Crescent": "Waning Crescent"
    },
    es: {
      "New Moon": "Luna nueva",
      "Waxing Crescent": "Luna creciente",
      "First Quarter": "Cuarto creciente",
      "Waxing Gibbous": "Gibosa creciente",
      "Full Moon": "Luna llena",
      "Waning Gibbous": "Gibosa menguante",
      "Last Quarter": "Cuarto menguante",
      "Waning Crescent": "Luna menguante"
    },
    pt: {
      "New Moon": "Lua nova",
      "Waxing Crescent": "Lua crescente",
      "First Quarter": "Quarto crescente",
      "Waxing Gibbous": "Gibosa crescente",
      "Full Moon": "Lua cheia",
      "Waning Gibbous": "Gibosa minguante",
      "Last Quarter": "Quarto minguante",
      "Waning Crescent": "Lua minguante"
    },
    fr: {
      "New Moon": "Nouvelle Lune",
      "Waxing Crescent": "Premier croissant",
      "First Quarter": "Premier quartier",
      "Waxing Gibbous": "Lune gibbeuse croissante",
      "Full Moon": "Pleine Lune",
      "Waning Gibbous": "Lune gibbeuse d\xE9croissante",
      "Last Quarter": "Dernier quartier",
      "Waning Crescent": "Dernier croissant"
    },
    it: {
      "New Moon": "Luna nuova",
      "Waxing Crescent": "Falce crescente",
      "First Quarter": "Primo quarto",
      "Waxing Gibbous": "Gibbosa crescente",
      "Full Moon": "Luna piena",
      "Waning Gibbous": "Gibbosa calante",
      "Last Quarter": "Ultimo quarto",
      "Waning Crescent": "Falce calante"
    }
  };
  function moonPhaseLabel(locale, phase) {
    const catalogLocale = requireCatalogLocale(locale);
    if (catalogLocale === "ru") return russianRuntime().astrology.moonPhases[phase] ?? phase;
    return MOON_PHASE_LABELS[catalogLocale][phase] ?? phase;
  }

  // owned:loader
  init_define_import_meta_env();
  function useEngine() {
    return () => window.fixtureLoadEngine();
  }

  // src/islands/MoonPhaseTool.tsx
  function PhaseDisc({
    angle,
    locale,
    size = 120,
    ariaHidden = false
  }) {
    const r3 = 44;
    const cosA = Math.cos(angle * Math.PI / 180);
    const waxing = angle < 180;
    const rx = Math.max(0.5, Math.abs(cosA) * r3);
    const limbSweep = waxing ? 1 : 0;
    const bowRight = waxing ? cosA > 0 : cosA < 0;
    const termSweep = bowRight ? 0 : 1;
    const lit = `M 50 ${50 - r3} A ${r3} ${r3} 0 0 ${limbSweep} 50 ${50 + r3} A ${rx} ${r3} 0 0 ${termSweep} 50 ${50 - r3} Z`;
    return /* @__PURE__ */ u3(
      "svg",
      {
        class: "mp__disc",
        viewBox: "0 0 100 100",
        width: size,
        height: size,
        role: ariaHidden ? void 0 : "img",
        "aria-hidden": ariaHidden ? "true" : void 0,
        "aria-label": ariaHidden ? void 0 : tf(locale, "moonDiscAria", {
          percent: Math.round(moonIlluminationFromAngle(angle) * 100)
        }),
        children: [
          /* @__PURE__ */ u3("circle", { cx: "50", cy: "50", r: r3, fill: "var(--void-2)", stroke: "var(--hair-2)", "stroke-width": "1" }),
          angle > 2 && angle < 358 && /* @__PURE__ */ u3("path", { d: lit, fill: "var(--ink-1, #E8EAF0)", opacity: "0.92" })
        ]
      }
    );
  }
  function moonIlluminationFromAngle(angle) {
    return (1 - Math.cos(angle * Math.PI / 180)) / 2;
  }
  function MoonPhaseTool({ locale: rawLocale = "en" }) {
    const locale = normalizeCatalogLocale(rawLocale);
    const loadEngine = useEngine();
    const [now, setNow] = d2(null);
    const [date, setDate] = d2("");
    const [time, setTime] = d2("");
    const [city2, setCity] = d2(null);
    const [result, setResult] = d2(null);
    const [busy, setBusy] = d2(false);
    const [error, setError] = d2("");
    const resultHeadingRef = A2(null);
    const errorRef = A2(null);
    const focusAfterComputeRef = A2(false);
    const lookupRevisionRef = A2(0);
    h2(() => {
      setNow(/* @__PURE__ */ new Date());
      return () => {
        lookupRevisionRef.current += 1;
        focusAfterComputeRef.current = false;
      };
    }, []);
    function invalidateLookup() {
      lookupRevisionRef.current += 1;
      focusAfterComputeRef.current = false;
      setResult(null);
      setError("");
      setBusy(false);
    }
    async function lookup(e3) {
      e3.preventDefault();
      if (!date) return;
      const revision = ++lookupRevisionRef.current;
      const localDateReferenceFailure = new Error("Could not establish a calculation time within the local date.");
      const isCurrent = () => revision === lookupRevisionRef.current;
      focusAfterComputeRef.current = true;
      setBusy(true);
      setError("");
      setResult(null);
      try {
        const engine2 = await loadEngine();
        if (!isCurrent()) return;
        const hasTime = time !== "";
        let utc;
        let dayStart;
        let dayEnd;
        if (city2) {
          utc = resolveLocalToUtc(date, hasTime ? time : "12:00", city2.tz).utc;
          if (!hasTime) {
            try {
              if (!localDateContainsUtc(date, utc, city2.tz)) throw localDateReferenceFailure;
            } catch {
              throw localDateReferenceFailure;
            }
          }
          dayStart = resolveLocalToUtc(date, "00:00", city2.tz).utc;
          dayEnd = resolveLocalToUtc(date, "23:59", city2.tz).utc;
        } else {
          utc = /* @__PURE__ */ new Date(`${date}T${hasTime ? time : "12:00"}:00Z`);
          dayStart = /* @__PURE__ */ new Date(`${date}T00:00:00Z`);
          dayEnd = /* @__PURE__ */ new Date(`${date}T23:59:00Z`);
        }
        const lon = engine2.bodyLongitude("Moon", utc);
        const sunLon = engine2.bodyLongitude("Sun", utc);
        const angle = ((lon - sunLon) % 360 + 360) % 360;
        let altLon = null;
        if (!hasTime) {
          const early = engine2.bodyLongitude("Moon", dayStart);
          const late = engine2.bodyLongitude("Moon", dayEnd);
          if (signForLongitude(early).slug !== signForLongitude(late).slug) {
            altLon = signForLongitude(lon).slug === signForLongitude(early).slug ? late : early;
          }
        }
        const caption = city2 && hasTime ? "" : city2 ? t3(locale, "middayLocalCaption") : hasTime ? t3(locale, "utcTimeCaption") : t3(locale, "middayUtcCaption");
        if (!isCurrent()) return;
        setResult({
          phase: moonPhaseName(utc),
          angle,
          illum: moonIlluminationFromAngle(angle),
          lon,
          altLon,
          caption
        });
      } catch (err) {
        if (!isCurrent()) return;
        setResult(null);
        setError(err === localDateReferenceFailure ? t3(locale, "localDateReferenceError") : calculationError(err, locale, t3(locale, "moonError")));
        console.error(err);
      } finally {
        if (isCurrent()) setBusy(false);
      }
    }
    h2(() => {
      if (busy || !focusAfterComputeRef.current) return;
      if (error) {
        errorRef.current?.focus();
        focusAfterComputeRef.current = false;
        return;
      }
      if (result) {
        resultHeadingRef.current?.focus();
        focusAfterComputeRef.current = false;
      }
    }, [busy, error, result]);
    return /* @__PURE__ */ u3("div", { class: "calc mp", children: [
      /* @__PURE__ */ u3("div", { class: "mp__tonight shell", children: /* @__PURE__ */ u3("div", { class: "core mp__tonight-core", children: [
        /* @__PURE__ */ u3(PhaseDisc, { angle: now ? moonPhaseAngle(now) : 0, locale, ariaHidden: now === null }),
        /* @__PURE__ */ u3("div", { class: "mp__tonight-facts", children: [
          /* @__PURE__ */ u3("em", { class: "kicker", children: t3(locale, "rightNow") }),
          /* @__PURE__ */ u3("strong", { class: "mp__phase", children: now ? moonPhaseLabel(locale, moonPhaseName(now)) : t3(locale, "moonReadingSky") }),
          /* @__PURE__ */ u3("span", { class: "mono mp__meta", children: now ? `${Math.round(moonIllumination(now) * 100)}% ${t3(locale, "illuminated")} \xB7 ${t3(locale, "moonIn")} ${locale === "ru" ? signPrepositional(signForLongitude(moonLongitude(now))) : signName(signForLongitude(moonLongitude(now)), locale)}` : "\u2014" }),
          now && /* @__PURE__ */ u3(EvidenceDisclosure_default, { label: t3(locale, "howWeCompute"), children: /* @__PURE__ */ u3("span", { class: "mono mp__meta mp__meta--faint", children: [
            formatDateTime(locale, now, {
              year: "numeric",
              month: "short",
              day: "numeric",
              hour: "2-digit",
              minute: "2-digit",
              timeZone: "UTC",
              hour12: false
            }),
            " UTC"
          ] }) })
        ] })
      ] }) }),
      /* @__PURE__ */ u3("form", { class: "calc__form shell", onSubmit: lookup, "aria-busy": busy, children: /* @__PURE__ */ u3("div", { class: "core calc__core", children: [
        /* @__PURE__ */ u3("div", { class: "calc__fields", children: [
          /* @__PURE__ */ u3("div", { class: "field", children: [
            /* @__PURE__ */ u3("label", { class: "field__label", for: "mp-date", children: t3(locale, "date") }),
            /* @__PURE__ */ u3(
              "input",
              {
                id: "mp-date",
                class: "field__input",
                type: "date",
                required: true,
                min: "1800-01-01",
                max: "2199-12-31",
                value: date,
                onFocus: () => loadEngine(),
                onInput: (e3) => {
                  invalidateLookup();
                  setDate(e3.target.value);
                }
              }
            ),
            /* @__PURE__ */ u3("p", { class: "field__help", children: t3(locale, "dateHelp") })
          ] }),
          /* @__PURE__ */ u3("div", { class: "field", children: [
            /* @__PURE__ */ u3("label", { class: "field__label", for: "mp-time", children: [
              t3(locale, "time"),
              " ",
              /* @__PURE__ */ u3("span", { class: "field__optional", children: t3(locale, "optional") })
            ] }),
            /* @__PURE__ */ u3(
              "input",
              {
                id: "mp-time",
                class: "field__input",
                type: "time",
                value: time,
                onInput: (e3) => {
                  invalidateLookup();
                  setTime(e3.target.value);
                }
              }
            )
          ] }),
          /* @__PURE__ */ u3("div", { class: "field", children: [
            /* @__PURE__ */ u3("label", { class: "field__label", for: "mp-place", children: [
              t3(locale, "place"),
              " ",
              /* @__PURE__ */ u3("span", { class: "field__optional", children: t3(locale, "optional") })
            ] }),
            /* @__PURE__ */ u3(PlaceSearch, { id: "mp-place", selected: city2, onSelect: (value) => {
              invalidateLookup();
              setCity(value);
            }, locale }),
            /* @__PURE__ */ u3("p", { class: "field__help", children: t3(locale, "placeHelpMoon") })
          ] })
        ] }),
        /* @__PURE__ */ u3("button", { class: "btn btn--primary calc__submit", type: "submit", disabled: !date || busy, children: [
          /* @__PURE__ */ u3("span", { children: busy ? t3(locale, "computing") : t3(locale, "findThatMoon") }),
          /* @__PURE__ */ u3("span", { class: "orb", children: "\u2197" })
        ] }),
        /* @__PURE__ */ u3("p", { class: "calc__privacy", children: t3(locale, "privacyDevice") }),
        error && /* @__PURE__ */ u3("p", { class: "calc__error", role: "alert", tabIndex: -1, ref: errorRef, children: error }),
        /* @__PURE__ */ u3(CalculationReload, { error, locale })
      ] }) }),
      result && /* @__PURE__ */ u3("div", { class: "calc__result", children: [
        /* @__PURE__ */ u3("h2", { class: "sr-only", tabIndex: -1, ref: resultHeadingRef, children: t3(locale, "moonPhase") }),
        /* @__PURE__ */ u3("div", { class: "mp__lookup shell tinted", style: `--sign:${signForLongitude(result.lon).hue}`, children: /* @__PURE__ */ u3("div", { class: "core tinted mp__tonight-core", children: [
          /* @__PURE__ */ u3(PhaseDisc, { angle: result.angle, locale }),
          /* @__PURE__ */ u3("div", { class: "mp__tonight-facts", children: [
            /* @__PURE__ */ u3("strong", { class: "mp__phase", children: moonPhaseLabel(locale, result.phase) }),
            /* @__PURE__ */ u3("span", { class: "mono mp__meta", children: [
              Math.round(result.illum * 100),
              "% ",
              t3(locale, "illuminated")
            ] }),
            /* @__PURE__ */ u3("span", { class: "mp__signline", children: [
              t3(locale, "moonIn"),
              " ",
              locale === "ru" ? signPrepositional(signForLongitude(result.lon)) : /* @__PURE__ */ u3(SignChip, { lon: result.lon, locale }),
              result.altLon !== null && /* @__PURE__ */ u3(S, { children: [
                " ",
                t3(locale, "or"),
                " ",
                /* @__PURE__ */ u3(SignChip, { lon: result.altLon, locale })
              ] })
            ] }),
            /* @__PURE__ */ u3(EvidenceDisclosure_default, { label: t3(locale, "howWeCompute"), children: [
              /* @__PURE__ */ u3("span", { class: "mono mp__meta mp__meta--faint", children: formatLongitude(result.lon, locale) }),
              result.caption !== "" && result.altLon === null && /* @__PURE__ */ u3("p", { children: result.caption })
            ] })
          ] })
        ] }) }),
        result.altLon !== null && /* @__PURE__ */ u3("p", { class: "notice", role: "status", children: t3(locale, "moonChangedNotice") }),
        /* @__PURE__ */ u3("div", { class: "calc__actions", children: /* @__PURE__ */ u3("a", { class: "btn btn--ghost", href: localizePath(locale, "/birth-chart/"), children: [
          /* @__PURE__ */ u3("span", { children: t3(locale, "birthChartForDate") }),
          /* @__PURE__ */ u3("span", { class: "orb", children: "\u2197" })
        ] }) })
      ] })
    ] });
  }

  // src/lib/engine/full.ts
  var full_exports = {};
  __export(full_exports, {
    bodyLongitude: () => bodyLongitude2,
    computeBodies: () => computeBodies2,
    computeChart: () => computeChart2,
    longitudeSpeed: () => longitudeSpeed2
  });
  init_define_import_meta_env();

  // ../../../Users/chiburashka/.codex/worktrees/4806/site/node_modules/@zodiacs/engine/dist/internal.js
  init_define_import_meta_env();

  // ../../../Users/chiburashka/.codex/worktrees/4806/site/node_modules/@zodiacs/engine/dist/chunk-GBH7JIYF.js
  init_define_import_meta_env();

  // ../../../Users/chiburashka/.codex/worktrees/4806/site/node_modules/@zodiacs/engine/dist/chunk-H7RJKCBO.js
  init_define_import_meta_env();

  // ../../../Users/chiburashka/.codex/worktrees/4806/site/node_modules/@zodiacs/engine/dist/chunk-INI453VG.js
  init_define_import_meta_env();
  var ASPECTS = [
    { type: "conjunction", angle: 0, orb: 8, luminaryOrb: 10 },
    { type: "sextile", angle: 60, orb: 4, luminaryOrb: 5 },
    { type: "square", angle: 90, orb: 7, luminaryOrb: 8 },
    { type: "trine", angle: 120, orb: 7, luminaryOrb: 8 },
    { type: "opposition", angle: 180, orb: 8, luminaryOrb: 10 }
  ];
  var LUMINARIES = /* @__PURE__ */ new Set(["Sun", "Moon"]);
  var ASPECT_BODIES = /* @__PURE__ */ new Set([
    "Sun",
    "Moon",
    "Mercury",
    "Venus",
    "Mars",
    "Jupiter",
    "Saturn",
    "Uranus",
    "Neptune",
    "Pluto"
  ]);
  function separation(a3, b2) {
    const difference = Math.abs(((a3 - b2) % 360 + 360) % 360);
    return difference > 180 ? 360 - difference : difference;
  }
  function matchAspect(aBody, aLongitude, bBody, bLongitude) {
    const distance = separation(aLongitude, bLongitude);
    const hasLuminary = LUMINARIES.has(aBody) || LUMINARIES.has(bBody);
    let best = null;
    for (const definition of ASPECTS) {
      const orb = Math.abs(distance - definition.angle);
      const maximum = hasLuminary ? definition.luminaryOrb : definition.orb;
      if (orb <= maximum && (!best || orb < best.orb)) {
        best = { definition, orb };
      }
    }
    return best;
  }
  function findAspects(bodies) {
    const candidates = bodies.filter((body) => ASPECT_BODIES.has(body.body));
    const aspects = [];
    for (let first = 0; first < candidates.length; first += 1) {
      for (let second = first + 1; second < candidates.length; second += 1) {
        const a3 = candidates[first];
        const b2 = candidates[second];
        if (!a3 || !b2) continue;
        const match = matchAspect(a3.body, a3.lon, b2.body, b2.lon);
        if (!match) continue;
        const stepDays = 0.02;
        const nextSeparation = separation(a3.lon + a3.speed * stepDays, b2.lon + b2.speed * stepDays);
        aspects.push({
          a: a3.body,
          b: b2.body,
          type: match.definition.type,
          orb: match.orb,
          applying: Math.abs(nextSeparation - match.definition.angle) < match.orb
        });
      }
    }
    return aspects.sort((a3, b2) => a3.orb - b2.orb);
  }
  var SIGNS2 = [
    {
      slug: "aries",
      name: "Aries",
      element: "fire",
      modality: "cardinal",
      polarity: "day",
      naturalHouse: 1
    },
    {
      slug: "taurus",
      name: "Taurus",
      element: "earth",
      modality: "fixed",
      polarity: "night",
      naturalHouse: 2
    },
    {
      slug: "gemini",
      name: "Gemini",
      element: "air",
      modality: "mutable",
      polarity: "day",
      naturalHouse: 3
    },
    {
      slug: "cancer",
      name: "Cancer",
      element: "water",
      modality: "cardinal",
      polarity: "night",
      naturalHouse: 4
    },
    {
      slug: "leo",
      name: "Leo",
      element: "fire",
      modality: "fixed",
      polarity: "day",
      naturalHouse: 5
    },
    {
      slug: "virgo",
      name: "Virgo",
      element: "earth",
      modality: "mutable",
      polarity: "night",
      naturalHouse: 6
    },
    {
      slug: "libra",
      name: "Libra",
      element: "air",
      modality: "cardinal",
      polarity: "day",
      naturalHouse: 7
    },
    {
      slug: "scorpio",
      name: "Scorpio",
      element: "water",
      modality: "fixed",
      polarity: "night",
      naturalHouse: 8
    },
    {
      slug: "sagittarius",
      name: "Sagittarius",
      element: "fire",
      modality: "mutable",
      polarity: "day",
      naturalHouse: 9
    },
    {
      slug: "capricorn",
      name: "Capricorn",
      element: "earth",
      modality: "cardinal",
      polarity: "night",
      naturalHouse: 10
    },
    {
      slug: "aquarius",
      name: "Aquarius",
      element: "air",
      modality: "fixed",
      polarity: "day",
      naturalHouse: 11
    },
    {
      slug: "pisces",
      name: "Pisces",
      element: "water",
      modality: "mutable",
      polarity: "night",
      naturalHouse: 12
    }
  ];
  var SIGN_NAMES = SIGNS2.map((sign) => sign.slug);
  function normalizeLongitude(lon) {
    if (!Number.isFinite(lon)) throw new RangeError("Longitude must be finite.");
    return (lon % 360 + 360) % 360;
  }
  function signIndexForLongitude2(lon) {
    return Math.floor(normalizeLongitude(lon) / 30);
  }
  function signForLongitude2(lon) {
    const sign = SIGNS2[signIndexForLongitude2(lon)];
    if (!sign) throw new RangeError("Could not resolve zodiac sign.");
    return sign;
  }
  function degreeInSign2(lon) {
    return normalizeLongitude(lon) % 30;
  }

  // ../../../Users/chiburashka/.codex/worktrees/4806/site/node_modules/@zodiacs/engine/dist/chunk-H7RJKCBO.js
  var DEG2 = Math.PI / 180;
  var RAD = 180 / Math.PI;
  function meanObliquity(julianCenturies) {
    const t4 = julianCenturies;
    const arcseconds = 84381.406 - 46.836769 * t4 - 1831e-7 * t4 * t4 + 20034e-7 * t4 ** 3 - 576e-9 * t4 ** 4 - 434e-10 * t4 ** 5;
    return arcseconds / 3600;
  }
  function eclipticLongitudeOfRightAscension(ra, obliquity) {
    return normalizeLongitude(
      Math.atan2(Math.sin(ra * DEG2), Math.cos(ra * DEG2) * Math.cos(obliquity * DEG2)) * RAD
    );
  }
  function declinationOfLongitude(lon, obliquity) {
    return Math.asin(Math.sin(obliquity * DEG2) * Math.sin(lon * DEG2)) * RAD;
  }
  function ramcOf(input) {
    return normalizeLongitude(input.gastHours * 15 + input.longitude);
  }
  function computeAngles(input) {
    const ramc = ramcOf(input);
    const mc = eclipticLongitudeOfRightAscension(ramc, input.obliquity);
    const ra = ramc * DEG2;
    const eps = input.obliquity * DEG2;
    const phi = input.latitude * DEG2;
    let asc = normalizeLongitude(
      Math.atan2(Math.cos(ra), -(Math.sin(ra) * Math.cos(eps) + Math.tan(phi) * Math.sin(eps))) * RAD
    );
    if (normalizeLongitude(asc - mc) >= 180) asc = normalizeLongitude(asc + 180);
    return {
      asc,
      mc,
      dsc: normalizeLongitude(asc + 180),
      ic: normalizeLongitude(mc + 180)
    };
  }
  function wholeSignCusps(ascendant) {
    const first = Math.floor(normalizeLongitude(ascendant) / 30) * 30;
    return Array.from({ length: 12 }, (_2, index) => normalizeLongitude(first + index * 30));
  }
  function placidusCusps(input, angles) {
    if (Math.abs(input.latitude) > 66) return null;
    const ramc = ramcOf(input);
    const phi = input.latitude * DEG2;
    function iterate(offset, multiplier) {
      let ra = ramc + offset;
      let converged = false;
      for (let index = 0; index < 64; index += 1) {
        const lon = eclipticLongitudeOfRightAscension(normalizeLongitude(ra), input.obliquity);
        const declination = declinationOfLongitude(lon, input.obliquity);
        const argument = Math.tan(phi) * Math.tan(declination * DEG2);
        if (Math.abs(argument) >= 1) return null;
        const ascensionalDifference = Math.asin(argument) * RAD;
        const next = ramc + offset + multiplier * ascensionalDifference;
        if (Math.abs(normalizeLongitude(next - ra + 180) - 180) < 1e-9) {
          ra = next;
          converged = true;
          break;
        }
        ra = next;
      }
      return converged ? eclipticLongitudeOfRightAscension(normalizeLongitude(ra), input.obliquity) : null;
    }
    const cusp11 = iterate(30, 1 / 3);
    const cusp12 = iterate(60, 2 / 3);
    const cusp2 = iterate(120, 2 / 3);
    const cusp3 = iterate(150, 1 / 3);
    if (cusp11 === null || cusp12 === null || cusp2 === null || cusp3 === null) {
      return null;
    }
    return [
      angles.asc,
      cusp2,
      cusp3,
      angles.ic,
      normalizeLongitude(cusp11 + 180),
      normalizeLongitude(cusp12 + 180),
      angles.dsc,
      normalizeLongitude(cusp2 + 180),
      normalizeLongitude(cusp3 + 180),
      angles.mc,
      cusp11,
      cusp12
    ];
  }
  function computeHouses(system, input, angles) {
    if (system === "placidus") {
      const cusps = placidusCusps(input, angles);
      if (cusps) {
        return { houses: { system: "placidus", cusps }, fellBack: false };
      }
      return {
        houses: { system: "whole", cusps: wholeSignCusps(angles.asc) },
        fellBack: true
      };
    }
    return {
      houses: { system: "whole", cusps: wholeSignCusps(angles.asc) },
      fellBack: false
    };
  }
  var ENGINE_VERSION = "0.1.1-rc.6";

  // ../../../Users/chiburashka/.codex/worktrees/4806/site/node_modules/astronomy-engine/esm/astronomy.js
  init_define_import_meta_env();
  var C_AUDAY = 173.1446326846693;
  var KM_PER_AU = 14959787069098932e-8;
  var DEG2RAD = 0.017453292519943295;
  var RAD2DEG = 57.29577951308232;
  var DAYS_PER_TROPICAL_YEAR = 365.24217;
  var J2000 = /* @__PURE__ */ new Date("2000-01-01T12:00:00Z");
  var PI2 = 2 * Math.PI;
  var ARC = 3600 * (180 / Math.PI);
  var ASEC2RAD = 484813681109536e-20;
  var ASEC180 = 180 * 60 * 60;
  var ASEC360 = 2 * ASEC180;
  var AU_PER_PARSEC = ASEC180 / Math.PI;
  var SUN_MAG_1AU = -0.17 - 5 * Math.log10(AU_PER_PARSEC);
  var SECONDS_PER_DAY = 24 * 3600;
  var MILLIS_PER_DAY = SECONDS_PER_DAY * 1e3;
  var SUN_RADIUS_KM = 695700;
  var SUN_RADIUS_AU = SUN_RADIUS_KM / KM_PER_AU;
  var EARTH_FLATTENING = 0.996647180302104;
  var EARTH_FLATTENING_SQUARED = EARTH_FLATTENING * EARTH_FLATTENING;
  var EARTH_EQUATORIAL_RADIUS_KM = 6378.1366;
  var EARTH_EQUATORIAL_RADIUS_AU = EARTH_EQUATORIAL_RADIUS_KM / KM_PER_AU;
  var EARTH_POLAR_RADIUS_KM = EARTH_EQUATORIAL_RADIUS_KM * EARTH_FLATTENING;
  var EARTH_MEAN_RADIUS_KM = 6371;
  var EARTH_ATMOSPHERE_KM = 88;
  var EARTH_ECLIPSE_RADIUS_KM = EARTH_MEAN_RADIUS_KM + EARTH_ATMOSPHERE_KM;
  var MOON_EQUATORIAL_RADIUS_KM = 1738.1;
  var MOON_EQUATORIAL_RADIUS_AU = MOON_EQUATORIAL_RADIUS_KM / KM_PER_AU;
  var MOON_POLAR_RADIUS_KM = 1736;
  var MOON_POLAR_RADIUS_AU = MOON_POLAR_RADIUS_KM / KM_PER_AU;
  var REFRACTION_NEAR_HORIZON = 34 / 60;
  var EARTH_MOON_MASS_RATIO = 81.30056;
  var SUN_GM = 2959122082855911e-19;
  var EARTH_GM = 8887692390113509e-25;
  var JUPITER_GM = 2825345909524226e-22;
  var SATURN_GM = 8459715185680659e-23;
  var URANUS_GM = 1292024916781969e-23;
  var NEPTUNE_GM = 1524358900784276e-23;
  var MOON_GM = EARTH_GM / EARTH_MOON_MASS_RATIO;
  function VerifyBoolean(b2) {
    if (b2 !== true && b2 !== false) {
      console.trace();
      throw `Value is not boolean: ${b2}`;
    }
    return b2;
  }
  function VerifyNumber(x2) {
    if (!Number.isFinite(x2)) {
      console.trace();
      throw `Value is not a finite number: ${x2}`;
    }
    return x2;
  }
  function Frac(x2) {
    return x2 - Math.floor(x2);
  }
  var Body;
  (function(Body2) {
    Body2["Sun"] = "Sun";
    Body2["Moon"] = "Moon";
    Body2["Mercury"] = "Mercury";
    Body2["Venus"] = "Venus";
    Body2["Earth"] = "Earth";
    Body2["Mars"] = "Mars";
    Body2["Jupiter"] = "Jupiter";
    Body2["Saturn"] = "Saturn";
    Body2["Uranus"] = "Uranus";
    Body2["Neptune"] = "Neptune";
    Body2["Pluto"] = "Pluto";
    Body2["SSB"] = "SSB";
    Body2["EMB"] = "EMB";
    Body2["Star1"] = "Star1";
    Body2["Star2"] = "Star2";
    Body2["Star3"] = "Star3";
    Body2["Star4"] = "Star4";
    Body2["Star5"] = "Star5";
    Body2["Star6"] = "Star6";
    Body2["Star7"] = "Star7";
    Body2["Star8"] = "Star8";
  })(Body || (Body = {}));
  var StarList = [
    Body.Star1,
    Body.Star2,
    Body.Star3,
    Body.Star4,
    Body.Star5,
    Body.Star6,
    Body.Star7,
    Body.Star8
  ];
  var StarTable = [
    { ra: 0, dec: 0, dist: 0 },
    { ra: 0, dec: 0, dist: 0 },
    { ra: 0, dec: 0, dist: 0 },
    { ra: 0, dec: 0, dist: 0 },
    { ra: 0, dec: 0, dist: 0 },
    { ra: 0, dec: 0, dist: 0 },
    { ra: 0, dec: 0, dist: 0 },
    { ra: 0, dec: 0, dist: 0 }
  ];
  function GetStar(body) {
    const index = StarList.indexOf(body);
    return index >= 0 ? StarTable[index] : null;
  }
  function UserDefinedStar(body) {
    const star = GetStar(body);
    return star && star.dist > 0 ? star : null;
  }
  var PrecessDirection;
  (function(PrecessDirection2) {
    PrecessDirection2[PrecessDirection2["From2000"] = 0] = "From2000";
    PrecessDirection2[PrecessDirection2["Into2000"] = 1] = "Into2000";
  })(PrecessDirection || (PrecessDirection = {}));
  var vsop = {
    Mercury: [
      [
        [
          [4.40250710144, 0, 0],
          [0.40989414977, 1.48302034195, 26087.9031415742],
          [0.050462942, 4.47785489551, 52175.8062831484],
          [0.00855346844, 1.16520322459, 78263.70942472259],
          [0.00165590362, 4.11969163423, 104351.61256629678],
          [34561897e-11, 0.77930768443, 130439.51570787099],
          [7583476e-11, 3.71348404924, 156527.41884944518]
        ],
        [
          [26087.90313685529, 0, 0],
          [0.01131199811, 6.21874197797, 26087.9031415742],
          [0.00292242298, 3.04449355541, 52175.8062831484],
          [75775081e-11, 6.08568821653, 78263.70942472259],
          [19676525e-11, 2.80965111777, 104351.61256629678]
        ]
      ],
      [
        [
          [0.11737528961, 1.98357498767, 26087.9031415742],
          [0.02388076996, 5.03738959686, 52175.8062831484],
          [0.01222839532, 3.14159265359, 0],
          [0.0054325181, 1.79644363964, 78263.70942472259],
          [0.0012977877, 4.83232503958, 104351.61256629678],
          [31866927e-11, 1.58088495658, 130439.51570787099],
          [7963301e-11, 4.60972126127, 156527.41884944518]
        ],
        [
          [0.00274646065, 3.95008450011, 26087.9031415742],
          [99737713e-11, 3.14159265359, 0]
        ]
      ],
      [
        [
          [0.39528271651, 0, 0],
          [0.07834131818, 6.19233722598, 26087.9031415742],
          [0.00795525558, 2.95989690104, 52175.8062831484],
          [0.00121281764, 6.01064153797, 78263.70942472259],
          [21921969e-11, 2.77820093972, 104351.61256629678],
          [4354065e-11, 5.82894543774, 130439.51570787099]
        ],
        [
          [0.0021734774, 4.65617158665, 26087.9031415742],
          [44141826e-11, 1.42385544001, 52175.8062831484]
        ]
      ]
    ],
    Venus: [
      [
        [
          [3.17614666774, 0, 0],
          [0.01353968419, 5.59313319619, 10213.285546211],
          [89891645e-11, 5.30650047764, 20426.571092422],
          [5477194e-11, 4.41630661466, 7860.4193924392],
          [3455741e-11, 2.6996444782, 11790.6290886588],
          [2372061e-11, 2.99377542079, 3930.2096962196],
          [1317168e-11, 5.18668228402, 26.2983197998],
          [1664146e-11, 4.25018630147, 1577.3435424478],
          [1438387e-11, 4.15745084182, 9683.5945811164],
          [1200521e-11, 6.15357116043, 30639.856638633]
        ],
        [
          [10213.28554621638, 0, 0],
          [95617813e-11, 2.4640651111, 10213.285546211],
          [7787201e-11, 0.6247848222, 20426.571092422]
        ]
      ],
      [
        [
          [0.05923638472, 0.26702775812, 10213.285546211],
          [40107978e-11, 1.14737178112, 20426.571092422],
          [32814918e-11, 3.14159265359, 0]
        ],
        [
          [0.00287821243, 1.88964962838, 10213.285546211]
        ]
      ],
      [
        [
          [0.72334820891, 0, 0],
          [0.00489824182, 4.02151831717, 10213.285546211],
          [1658058e-11, 4.90206728031, 20426.571092422],
          [1378043e-11, 1.12846591367, 11790.6290886588],
          [1632096e-11, 2.84548795207, 7860.4193924392],
          [498395e-11, 2.58682193892, 9683.5945811164],
          [221985e-11, 2.01346696541, 19367.1891622328],
          [237454e-11, 2.55136053886, 15720.8387848784]
        ],
        [
          [34551041e-11, 0.89198706276, 10213.285546211]
        ]
      ]
    ],
    Earth: [
      [
        [
          [1.75347045673, 0, 0],
          [0.03341656453, 4.66925680415, 6283.0758499914],
          [34894275e-11, 4.62610242189, 12566.1516999828],
          [3417572e-11, 2.82886579754, 3.523118349],
          [3497056e-11, 2.74411783405, 5753.3848848968],
          [3135899e-11, 3.62767041756, 77713.7714681205],
          [2676218e-11, 4.41808345438, 7860.4193924392],
          [2342691e-11, 6.13516214446, 3930.2096962196],
          [1273165e-11, 2.03709657878, 529.6909650946],
          [1324294e-11, 0.74246341673, 11506.7697697936],
          [901854e-11, 2.04505446477, 26.2983197998],
          [1199167e-11, 1.10962946234, 1577.3435424478],
          [857223e-11, 3.50849152283, 398.1490034082],
          [779786e-11, 1.17882681962, 5223.6939198022],
          [99025e-10, 5.23268072088, 5884.9268465832],
          [753141e-11, 2.53339052847, 5507.5532386674],
          [505267e-11, 4.58292599973, 18849.2275499742],
          [492392e-11, 4.20505711826, 775.522611324],
          [356672e-11, 2.91954114478, 0.0673103028],
          [284125e-11, 1.89869240932, 796.2980068164],
          [242879e-11, 0.34481445893, 5486.777843175],
          [317087e-11, 5.84901948512, 11790.6290886588],
          [271112e-11, 0.31486255375, 10977.078804699],
          [206217e-11, 4.80646631478, 2544.3144198834],
          [205478e-11, 1.86953770281, 5573.1428014331],
          [202318e-11, 2.45767790232, 6069.7767545534],
          [126225e-11, 1.08295459501, 20.7753954924],
          [155516e-11, 0.83306084617, 213.299095438]
        ],
        [
          [6283.0758499914, 0, 0],
          [0.00206058863, 2.67823455808, 6283.0758499914],
          [4303419e-11, 2.63512233481, 12566.1516999828]
        ],
        [
          [8721859e-11, 1.07253635559, 6283.0758499914]
        ]
      ],
      [
        [],
        [
          [0.00227777722, 3.4137662053, 6283.0758499914],
          [3805678e-11, 3.37063423795, 12566.1516999828]
        ]
      ],
      [
        [
          [1.00013988784, 0, 0],
          [0.01670699632, 3.09846350258, 6283.0758499914],
          [13956024e-11, 3.05524609456, 12566.1516999828],
          [308372e-10, 5.19846674381, 77713.7714681205],
          [1628463e-11, 1.17387558054, 5753.3848848968],
          [1575572e-11, 2.84685214877, 7860.4193924392],
          [924799e-11, 5.45292236722, 11506.7697697936],
          [542439e-11, 4.56409151453, 3930.2096962196],
          [47211e-10, 3.66100022149, 5884.9268465832],
          [85831e-11, 1.27079125277, 161000.6857376741],
          [57056e-11, 2.01374292245, 83996.84731811189],
          [55736e-11, 5.2415979917, 71430.69561812909],
          [174844e-11, 3.01193636733, 18849.2275499742],
          [243181e-11, 4.2734953079, 11790.6290886588]
        ],
        [
          [0.00103018607, 1.10748968172, 6283.0758499914],
          [1721238e-11, 1.06442300386, 12566.1516999828]
        ],
        [
          [4359385e-11, 5.78455133808, 6283.0758499914]
        ]
      ]
    ],
    Mars: [
      [
        [
          [6.20347711581, 0, 0],
          [0.18656368093, 5.0503710027, 3340.6124266998],
          [0.01108216816, 5.40099836344, 6681.2248533996],
          [91798406e-11, 5.75478744667, 10021.8372800994],
          [27744987e-11, 5.97049513147, 3.523118349],
          [10610235e-11, 2.93958560338, 2281.2304965106],
          [12315897e-11, 0.84956094002, 2810.9214616052],
          [8926784e-11, 4.15697846427, 0.0172536522],
          [8715691e-11, 6.11005153139, 13362.4497067992],
          [6797556e-11, 0.36462229657, 398.1490034082],
          [7774872e-11, 3.33968761376, 5621.8429232104],
          [3575078e-11, 1.6618650571, 2544.3144198834],
          [4161108e-11, 0.22814971327, 2942.4634232916],
          [3075252e-11, 0.85696614132, 191.4482661116],
          [2628117e-11, 0.64806124465, 3337.0893083508],
          [2937546e-11, 6.07893711402, 0.0673103028],
          [2389414e-11, 5.03896442664, 796.2980068164],
          [2579844e-11, 0.02996736156, 3344.1355450488],
          [1528141e-11, 1.14979301996, 6151.533888305],
          [1798806e-11, 0.65634057445, 529.6909650946],
          [1264357e-11, 3.62275122593, 5092.1519581158],
          [1286228e-11, 3.06796065034, 2146.1654164752],
          [1546404e-11, 2.91579701718, 1751.539531416],
          [1024902e-11, 3.69334099279, 8962.4553499102],
          [891566e-11, 0.18293837498, 16703.062133499],
          [858759e-11, 2.4009381194, 2914.0142358238],
          [832715e-11, 2.46418619474, 3340.5951730476],
          [83272e-10, 4.49495782139, 3340.629680352],
          [712902e-11, 3.66335473479, 1059.3819301892],
          [748723e-11, 3.82248614017, 155.4203994342],
          [723861e-11, 0.67497311481, 3738.761430108],
          [635548e-11, 2.92182225127, 8432.7643848156],
          [655162e-11, 0.48864064125, 3127.3133312618],
          [550474e-11, 3.81001042328, 0.9803210682],
          [55275e-10, 4.47479317037, 1748.016413067],
          [425966e-11, 0.55364317304, 6283.0758499914],
          [415131e-11, 0.49662285038, 213.299095438],
          [472167e-11, 3.62547124025, 1194.4470102246],
          [306551e-11, 0.38052848348, 6684.7479717486],
          [312141e-11, 0.99853944405, 6677.7017350506],
          [293198e-11, 4.22131299634, 20.7753954924],
          [302375e-11, 4.48618007156, 3532.0606928114],
          [274027e-11, 0.54222167059, 3340.545116397],
          [281079e-11, 5.88163521788, 1349.8674096588],
          [231183e-11, 1.28242156993, 3870.3033917944],
          [283602e-11, 5.7688543494, 3149.1641605882],
          [236117e-11, 5.75503217933, 3333.498879699],
          [274033e-11, 0.13372524985, 3340.6797370026],
          [299395e-11, 2.78323740866, 6254.6266625236]
        ],
        [
          [3340.61242700512, 0, 0],
          [0.01457554523, 3.60433733236, 3340.6124266998],
          [0.00168414711, 3.92318567804, 6681.2248533996],
          [20622975e-11, 4.26108844583, 10021.8372800994],
          [3452392e-11, 4.7321039319, 3.523118349],
          [2586332e-11, 4.60670058555, 13362.4497067992],
          [841535e-11, 4.45864030426, 2281.2304965106]
        ],
        [
          [58152577e-11, 2.04961712429, 3340.6124266998],
          [13459579e-11, 2.45738706163, 6681.2248533996]
        ]
      ],
      [
        [
          [0.03197134986, 3.76832042431, 3340.6124266998],
          [0.00298033234, 4.10616996305, 6681.2248533996],
          [0.00289104742, 0, 0],
          [31365539e-11, 4.4465105309, 10021.8372800994],
          [34841e-9, 4.7881254926, 13362.4497067992]
        ],
        [
          [0.00217310991, 6.04472194776, 3340.6124266998],
          [20976948e-11, 3.14159265359, 0],
          [12834709e-11, 1.60810667915, 6681.2248533996]
        ]
      ],
      [
        [
          [1.53033488271, 0, 0],
          [0.1418495316, 3.47971283528, 3340.6124266998],
          [0.00660776362, 3.81783443019, 6681.2248533996],
          [46179117e-11, 4.15595316782, 10021.8372800994],
          [8109733e-11, 5.55958416318, 2810.9214616052],
          [7485318e-11, 1.77239078402, 5621.8429232104],
          [5523191e-11, 1.3643630377, 2281.2304965106],
          [382516e-10, 4.49407183687, 13362.4497067992],
          [2306537e-11, 0.09081579001, 2544.3144198834],
          [1999396e-11, 5.36059617709, 3337.0893083508],
          [2484394e-11, 4.9254563992, 2942.4634232916],
          [1960195e-11, 4.74249437639, 3344.1355450488],
          [1167119e-11, 2.11260868341, 5092.1519581158],
          [1102816e-11, 5.00908403998, 398.1490034082],
          [899066e-11, 4.40791133207, 529.6909650946],
          [992252e-11, 5.83861961952, 6151.533888305],
          [807354e-11, 2.10217065501, 1059.3819301892],
          [797915e-11, 3.44839203899, 796.2980068164],
          [740975e-11, 1.49906336885, 2146.1654164752]
        ],
        [
          [0.01107433345, 2.03250524857, 3340.6124266998],
          [0.00103175887, 2.37071847807, 6681.2248533996],
          [128772e-9, 0, 0],
          [1081588e-10, 2.70888095665, 10021.8372800994]
        ],
        [
          [44242249e-11, 0.47930604954, 3340.6124266998],
          [8138042e-11, 0.86998389204, 6681.2248533996]
        ]
      ]
    ],
    Jupiter: [
      [
        [
          [0.59954691494, 0, 0],
          [0.09695898719, 5.06191793158, 529.6909650946],
          [0.00573610142, 1.44406205629, 7.1135470008],
          [0.00306389205, 5.41734730184, 1059.3819301892],
          [97178296e-11, 4.14264726552, 632.7837393132],
          [72903078e-11, 3.64042916389, 522.5774180938],
          [64263975e-11, 3.41145165351, 103.0927742186],
          [39806064e-11, 2.29376740788, 419.4846438752],
          [38857767e-11, 1.27231755835, 316.3918696566],
          [27964629e-11, 1.7845459182, 536.8045120954],
          [1358973e-10, 5.7748104079, 1589.0728952838],
          [8246349e-11, 3.5822792584, 206.1855484372],
          [8768704e-11, 3.63000308199, 949.1756089698],
          [7368042e-11, 5.0810119427, 735.8765135318],
          [626315e-10, 0.02497628807, 213.299095438],
          [6114062e-11, 4.51319998626, 1162.4747044078],
          [4905396e-11, 1.32084470588, 110.2063212194],
          [5305285e-11, 1.30671216791, 14.2270940016],
          [5305441e-11, 4.18625634012, 1052.2683831884],
          [4647248e-11, 4.69958103684, 3.9321532631],
          [3045023e-11, 4.31676431084, 426.598190876],
          [2609999e-11, 1.56667394063, 846.0828347512],
          [2028191e-11, 1.06376530715, 3.1813937377],
          [1764763e-11, 2.14148655117, 1066.49547719],
          [1722972e-11, 3.88036268267, 1265.5674786264],
          [1920945e-11, 0.97168196472, 639.897286314],
          [1633223e-11, 3.58201833555, 515.463871093],
          [1431999e-11, 4.29685556046, 625.6701923124],
          [973272e-11, 4.09764549134, 95.9792272178]
        ],
        [
          [529.69096508814, 0, 0],
          [0.00489503243, 4.2208293947, 529.6909650946],
          [0.00228917222, 6.02646855621, 7.1135470008],
          [30099479e-11, 4.54540782858, 1059.3819301892],
          [2072092e-10, 5.45943156902, 522.5774180938],
          [12103653e-11, 0.16994816098, 536.8045120954],
          [6067987e-11, 4.42422292017, 103.0927742186],
          [5433968e-11, 3.98480737746, 419.4846438752],
          [4237744e-11, 5.89008707199, 14.2270940016]
        ],
        [
          [47233601e-11, 4.32148536482, 7.1135470008],
          [30649436e-11, 2.929777887, 529.6909650946],
          [14837605e-11, 3.14159265359, 0]
        ]
      ],
      [
        [
          [0.02268615702, 3.55852606721, 529.6909650946],
          [0.00109971634, 3.90809347197, 1059.3819301892],
          [0.00110090358, 0, 0],
          [8101428e-11, 3.60509572885, 522.5774180938],
          [6043996e-11, 4.25883108339, 1589.0728952838],
          [6437782e-11, 0.30627119215, 536.8045120954]
        ],
        [
          [78203446e-11, 1.52377859742, 529.6909650946]
        ]
      ],
      [
        [
          [5.20887429326, 0, 0],
          [0.25209327119, 3.49108639871, 529.6909650946],
          [0.00610599976, 3.84115365948, 1059.3819301892],
          [0.00282029458, 2.57419881293, 632.7837393132],
          [0.00187647346, 2.07590383214, 522.5774180938],
          [86792905e-11, 0.71001145545, 419.4846438752],
          [72062974e-11, 0.21465724607, 536.8045120954],
          [65517248e-11, 5.9799588479, 316.3918696566],
          [29134542e-11, 1.67759379655, 103.0927742186],
          [30135335e-11, 2.16132003734, 949.1756089698],
          [23453271e-11, 3.54023522184, 735.8765135318],
          [22283743e-11, 4.19362594399, 1589.0728952838],
          [23947298e-11, 0.2745803748, 7.1135470008],
          [13032614e-11, 2.96042965363, 1162.4747044078],
          [970336e-10, 1.90669633585, 206.1855484372],
          [12749023e-11, 2.71550286592, 1052.2683831884],
          [7057931e-11, 2.18184839926, 1265.5674786264],
          [6137703e-11, 6.26418240033, 846.0828347512],
          [2616976e-11, 2.00994012876, 1581.959348283]
        ],
        [
          [0.0127180152, 2.64937512894, 529.6909650946],
          [61661816e-11, 3.00076460387, 1059.3819301892],
          [53443713e-11, 3.89717383175, 522.5774180938],
          [31185171e-11, 4.88276958012, 536.8045120954],
          [41390269e-11, 0, 0]
        ]
      ]
    ],
    Saturn: [
      [
        [
          [0.87401354025, 0, 0],
          [0.11107659762, 3.96205090159, 213.299095438],
          [0.01414150957, 4.58581516874, 7.1135470008],
          [0.00398379389, 0.52112032699, 206.1855484372],
          [0.00350769243, 3.30329907896, 426.598190876],
          [0.00206816305, 0.24658372002, 103.0927742186],
          [792713e-9, 3.84007056878, 220.4126424388],
          [23990355e-11, 4.66976924553, 110.2063212194],
          [16573588e-11, 0.43719228296, 419.4846438752],
          [14906995e-11, 5.76903183869, 316.3918696566],
          [1582029e-10, 0.93809155235, 632.7837393132],
          [14609559e-11, 1.56518472, 3.9321532631],
          [13160301e-11, 4.44891291899, 14.2270940016],
          [15053543e-11, 2.71669915667, 639.897286314],
          [13005299e-11, 5.98119023644, 11.0457002639],
          [10725067e-11, 3.12939523827, 202.2533951741],
          [5863206e-11, 0.23656938524, 529.6909650946],
          [5227757e-11, 4.20783365759, 3.1813937377],
          [6126317e-11, 1.76328667907, 277.0349937414],
          [5019687e-11, 3.17787728405, 433.7117378768],
          [459255e-10, 0.61977744975, 199.0720014364],
          [4005867e-11, 2.24479718502, 63.7358983034],
          [2953796e-11, 0.98280366998, 95.9792272178],
          [387367e-10, 3.22283226966, 138.5174968707],
          [2461186e-11, 2.03163875071, 735.8765135318],
          [3269484e-11, 0.77492638211, 949.1756089698],
          [1758145e-11, 3.2658010994, 522.5774180938],
          [1640172e-11, 5.5050445305, 846.0828347512],
          [1391327e-11, 4.02333150505, 323.5054166574],
          [1580648e-11, 4.37265307169, 309.2783226558],
          [1123498e-11, 2.83726798446, 415.5524906121],
          [1017275e-11, 3.71700135395, 227.5261894396],
          [848642e-11, 3.1915017083, 209.3669421749]
        ],
        [
          [213.2990952169, 0, 0],
          [0.01297370862, 1.82834923978, 213.299095438],
          [0.00564345393, 2.88499717272, 7.1135470008],
          [93734369e-11, 1.06311793502, 426.598190876],
          [0.00107674962, 2.27769131009, 206.1855484372],
          [40244455e-11, 2.04108104671, 220.4126424388],
          [19941774e-11, 1.2795439047, 103.0927742186],
          [10511678e-11, 2.7488034213, 14.2270940016],
          [6416106e-11, 0.38238295041, 639.897286314],
          [4848994e-11, 2.43037610229, 419.4846438752],
          [4056892e-11, 2.92133209468, 110.2063212194],
          [3768635e-11, 3.6496533078, 3.9321532631]
        ],
        [
          [0.0011644133, 1.17988132879, 7.1135470008],
          [91841837e-11, 0.0732519584, 213.299095438],
          [36661728e-11, 0, 0],
          [15274496e-11, 4.06493179167, 206.1855484372]
        ]
      ],
      [
        [
          [0.04330678039, 3.60284428399, 213.299095438],
          [0.00240348302, 2.85238489373, 426.598190876],
          [84745939e-11, 0, 0],
          [30863357e-11, 3.48441504555, 220.4126424388],
          [34116062e-11, 0.57297307557, 206.1855484372],
          [1473407e-10, 2.11846596715, 639.897286314],
          [9916667e-11, 5.79003188904, 419.4846438752],
          [6993564e-11, 4.7360468972, 7.1135470008],
          [4807588e-11, 5.43305312061, 316.3918696566]
        ],
        [
          [0.00198927992, 4.93901017903, 213.299095438],
          [36947916e-11, 3.14159265359, 0],
          [17966989e-11, 0.5197943111, 426.598190876]
        ]
      ],
      [
        [
          [9.55758135486, 0, 0],
          [0.52921382865, 2.39226219573, 213.299095438],
          [0.01873679867, 5.2354960466, 206.1855484372],
          [0.01464663929, 1.64763042902, 426.598190876],
          [0.00821891141, 5.93520042303, 316.3918696566],
          [0.00547506923, 5.0153261898, 103.0927742186],
          [0.0037168465, 2.27114821115, 220.4126424388],
          [0.00361778765, 3.13904301847, 7.1135470008],
          [0.00140617506, 5.70406606781, 632.7837393132],
          [0.00108974848, 3.29313390175, 110.2063212194],
          [69006962e-11, 5.94099540992, 419.4846438752],
          [61053367e-11, 0.94037691801, 639.897286314],
          [48913294e-11, 1.55733638681, 202.2533951741],
          [34143772e-11, 0.19519102597, 277.0349937414],
          [32401773e-11, 5.47084567016, 949.1756089698],
          [20936596e-11, 0.46349251129, 735.8765135318],
          [9796004e-11, 5.20477537945, 1265.5674786264],
          [11993338e-11, 5.98050967385, 846.0828347512],
          [208393e-9, 1.52102476129, 433.7117378768],
          [15298404e-11, 3.0594381494, 529.6909650946],
          [6465823e-11, 0.17732249942, 1052.2683831884],
          [11380257e-11, 1.7310542704, 522.5774180938],
          [3419618e-11, 4.94550542171, 1581.959348283]
        ],
        [
          [0.0618298134, 0.2584351148, 213.299095438],
          [0.00506577242, 0.71114625261, 206.1855484372],
          [0.00341394029, 5.79635741658, 426.598190876],
          [0.00188491195, 0.47215589652, 220.4126424388],
          [0.00186261486, 3.14159265359, 0],
          [0.00143891146, 1.40744822888, 7.1135470008]
        ],
        [
          [0.00436902572, 4.78671677509, 213.299095438]
        ]
      ]
    ],
    Uranus: [
      [
        [
          [5.48129294297, 0, 0],
          [0.09260408234, 0.89106421507, 74.7815985673],
          [0.01504247898, 3.6271926092, 1.4844727083],
          [0.00365981674, 1.89962179044, 73.297125859],
          [0.00272328168, 3.35823706307, 149.5631971346],
          [70328461e-11, 5.39254450063, 63.7358983034],
          [68892678e-11, 6.09292483287, 76.2660712756],
          [61998615e-11, 2.26952066061, 2.9689454166],
          [61950719e-11, 2.85098872691, 11.0457002639],
          [2646877e-10, 3.14152083966, 71.8126531507],
          [25710476e-11, 6.11379840493, 454.9093665273],
          [2107885e-10, 4.36059339067, 148.0787244263],
          [17818647e-11, 1.74436930289, 36.6485629295],
          [14613507e-11, 4.73732166022, 3.9321532631],
          [11162509e-11, 5.8268179635, 224.3447957019],
          [1099791e-10, 0.48865004018, 138.5174968707],
          [9527478e-11, 2.95516862826, 35.1640902212],
          [7545601e-11, 5.236265824, 109.9456887885],
          [4220241e-11, 3.23328220918, 70.8494453042],
          [40519e-9, 2.277550173, 151.0476698429],
          [3354596e-11, 1.0654900738, 4.4534181249],
          [2926718e-11, 4.62903718891, 9.5612275556],
          [349034e-10, 5.48306144511, 146.594251718],
          [3144069e-11, 4.75199570434, 77.7505439839],
          [2922333e-11, 5.35235361027, 85.8272988312],
          [2272788e-11, 4.36600400036, 70.3281804424],
          [2051219e-11, 1.51773566586, 0.1118745846],
          [2148602e-11, 0.60745949945, 38.1330356378],
          [1991643e-11, 4.92437588682, 277.0349937414],
          [1376226e-11, 2.04283539351, 65.2203710117],
          [1666902e-11, 3.62744066769, 380.12776796],
          [1284107e-11, 3.11347961505, 202.2533951741],
          [1150429e-11, 0.93343589092, 3.1813937377],
          [1533221e-11, 2.58594681212, 52.6901980395],
          [1281604e-11, 0.54271272721, 222.8603229936],
          [1372139e-11, 4.19641530878, 111.4301614968],
          [1221029e-11, 0.1990065003, 108.4612160802],
          [946181e-11, 1.19253165736, 127.4717966068],
          [1150989e-11, 4.17898916639, 33.6796175129]
        ],
        [
          [74.7815986091, 0, 0],
          [0.00154332863, 5.24158770553, 74.7815985673],
          [24456474e-11, 1.71260334156, 1.4844727083],
          [9258442e-11, 0.4282973235, 11.0457002639],
          [8265977e-11, 1.50218091379, 63.7358983034],
          [915016e-10, 1.41213765216, 149.5631971346]
        ]
      ],
      [
        [
          [0.01346277648, 2.61877810547, 74.7815985673],
          [623414e-9, 5.08111189648, 149.5631971346],
          [61601196e-11, 3.14159265359, 0],
          [9963722e-11, 1.61603805646, 76.2660712756],
          [992616e-10, 0.57630380333, 73.297125859]
        ],
        [
          [34101978e-11, 0.01321929936, 74.7815985673]
        ]
      ],
      [
        [
          [19.21264847206, 0, 0],
          [0.88784984413, 5.60377527014, 74.7815985673],
          [0.03440836062, 0.32836099706, 73.297125859],
          [0.0205565386, 1.7829515933, 149.5631971346],
          [0.0064932241, 4.52247285911, 76.2660712756],
          [0.00602247865, 3.86003823674, 63.7358983034],
          [0.00496404167, 1.40139935333, 454.9093665273],
          [0.00338525369, 1.58002770318, 138.5174968707],
          [0.00243509114, 1.57086606044, 71.8126531507],
          [0.00190522303, 1.99809394714, 1.4844727083],
          [0.00161858838, 2.79137786799, 148.0787244263],
          [0.00143706183, 1.38368544947, 11.0457002639],
          [93192405e-11, 0.17437220467, 36.6485629295],
          [71424548e-11, 4.24509236074, 224.3447957019],
          [89806014e-11, 3.66105364565, 109.9456887885],
          [39009723e-11, 1.66971401684, 70.8494453042],
          [46677296e-11, 1.39976401694, 35.1640902212],
          [39025624e-11, 3.36234773834, 277.0349937414],
          [36755274e-11, 3.88649278513, 146.594251718],
          [30348723e-11, 0.70100838798, 151.0476698429],
          [29156413e-11, 3.180563367, 77.7505439839],
          [22637073e-11, 0.72518687029, 529.6909650946],
          [11959076e-11, 1.7504339214, 984.6003316219],
          [25620756e-11, 5.25656086672, 380.12776796]
        ],
        [
          [0.01479896629, 3.67205697578, 74.7815985673]
        ]
      ]
    ],
    Neptune: [
      [
        [
          [5.31188633046, 0, 0],
          [0.0179847553, 2.9010127389, 38.1330356378],
          [0.01019727652, 0.48580922867, 1.4844727083],
          [0.00124531845, 4.83008090676, 36.6485629295],
          [42064466e-11, 5.41054993053, 2.9689454166],
          [37714584e-11, 6.09221808686, 35.1640902212],
          [33784738e-11, 1.24488874087, 76.2660712756],
          [16482741e-11, 7727998e-11, 491.5579294568],
          [9198584e-11, 4.93747051954, 39.6175083461],
          [899425e-10, 0.27462171806, 175.1660598002]
        ],
        [
          [38.13303563957, 0, 0],
          [16604172e-11, 4.86323329249, 1.4844727083],
          [15744045e-11, 2.27887427527, 38.1330356378]
        ]
      ],
      [
        [
          [0.03088622933, 1.44104372644, 38.1330356378],
          [27780087e-11, 5.91271884599, 76.2660712756],
          [27623609e-11, 0, 0],
          [15355489e-11, 2.52123799551, 36.6485629295],
          [15448133e-11, 3.50877079215, 39.6175083461]
        ]
      ],
      [
        [
          [30.07013205828, 0, 0],
          [0.27062259632, 1.32999459377, 38.1330356378],
          [0.01691764014, 3.25186135653, 36.6485629295],
          [0.00807830553, 5.18592878704, 1.4844727083],
          [0.0053776051, 4.52113935896, 35.1640902212],
          [0.00495725141, 1.5710564165, 491.5579294568],
          [0.00274571975, 1.84552258866, 175.1660598002],
          [1201232e-10, 1.92059384991, 1021.2488945514],
          [0.00121801746, 5.79754470298, 76.2660712756],
          [0.00100896068, 0.3770272493, 73.297125859],
          [0.00135134092, 3.37220609835, 39.6175083461],
          [7571796e-11, 1.07149207335, 388.4651552382]
        ]
      ]
    ]
  };
  function DeltaT_EspenakMeeus(ut) {
    var u4, u22, u32, u42, u5, u6, u7;
    const y3 = 2e3 + (ut - 14) / DAYS_PER_TROPICAL_YEAR;
    if (y3 < -500) {
      u4 = (y3 - 1820) / 100;
      return -20 + 32 * u4 * u4;
    }
    if (y3 < 500) {
      u4 = y3 / 100;
      u22 = u4 * u4;
      u32 = u4 * u22;
      u42 = u22 * u22;
      u5 = u22 * u32;
      u6 = u32 * u32;
      return 10583.6 - 1014.41 * u4 + 33.78311 * u22 - 5.952053 * u32 - 0.1798452 * u42 + 0.022174192 * u5 + 0.0090316521 * u6;
    }
    if (y3 < 1600) {
      u4 = (y3 - 1e3) / 100;
      u22 = u4 * u4;
      u32 = u4 * u22;
      u42 = u22 * u22;
      u5 = u22 * u32;
      u6 = u32 * u32;
      return 1574.2 - 556.01 * u4 + 71.23472 * u22 + 0.319781 * u32 - 0.8503463 * u42 - 5050998e-9 * u5 + 0.0083572073 * u6;
    }
    if (y3 < 1700) {
      u4 = y3 - 1600;
      u22 = u4 * u4;
      u32 = u4 * u22;
      return 120 - 0.9808 * u4 - 0.01532 * u22 + u32 / 7129;
    }
    if (y3 < 1800) {
      u4 = y3 - 1700;
      u22 = u4 * u4;
      u32 = u4 * u22;
      u42 = u22 * u22;
      return 8.83 + 0.1603 * u4 - 59285e-7 * u22 + 13336e-8 * u32 - u42 / 1174e3;
    }
    if (y3 < 1860) {
      u4 = y3 - 1800;
      u22 = u4 * u4;
      u32 = u4 * u22;
      u42 = u22 * u22;
      u5 = u22 * u32;
      u6 = u32 * u32;
      u7 = u32 * u42;
      return 13.72 - 0.332447 * u4 + 68612e-7 * u22 + 41116e-7 * u32 - 37436e-8 * u42 + 121272e-10 * u5 - 1699e-10 * u6 + 875e-12 * u7;
    }
    if (y3 < 1900) {
      u4 = y3 - 1860;
      u22 = u4 * u4;
      u32 = u4 * u22;
      u42 = u22 * u22;
      u5 = u22 * u32;
      return 7.62 + 0.5737 * u4 - 0.251754 * u22 + 0.01680668 * u32 - 4473624e-10 * u42 + u5 / 233174;
    }
    if (y3 < 1920) {
      u4 = y3 - 1900;
      u22 = u4 * u4;
      u32 = u4 * u22;
      u42 = u22 * u22;
      return -2.79 + 1.494119 * u4 - 0.0598939 * u22 + 61966e-7 * u32 - 197e-6 * u42;
    }
    if (y3 < 1941) {
      u4 = y3 - 1920;
      u22 = u4 * u4;
      u32 = u4 * u22;
      return 21.2 + 0.84493 * u4 - 0.0761 * u22 + 20936e-7 * u32;
    }
    if (y3 < 1961) {
      u4 = y3 - 1950;
      u22 = u4 * u4;
      u32 = u4 * u22;
      return 29.07 + 0.407 * u4 - u22 / 233 + u32 / 2547;
    }
    if (y3 < 1986) {
      u4 = y3 - 1975;
      u22 = u4 * u4;
      u32 = u4 * u22;
      return 45.45 + 1.067 * u4 - u22 / 260 - u32 / 718;
    }
    if (y3 < 2005) {
      u4 = y3 - 2e3;
      u22 = u4 * u4;
      u32 = u4 * u22;
      u42 = u22 * u22;
      u5 = u22 * u32;
      return 63.86 + 0.3345 * u4 - 0.060374 * u22 + 17275e-7 * u32 + 651814e-9 * u42 + 2373599e-11 * u5;
    }
    if (y3 < 2050) {
      u4 = y3 - 2e3;
      return 62.92 + 0.32217 * u4 + 5589e-6 * u4 * u4;
    }
    if (y3 < 2150) {
      u4 = (y3 - 1820) / 100;
      return -20 + 32 * u4 * u4 - 0.5628 * (2150 - y3);
    }
    u4 = (y3 - 1820) / 100;
    return -20 + 32 * u4 * u4;
  }
  var DeltaT = DeltaT_EspenakMeeus;
  function TerrestrialTime(ut) {
    return ut + DeltaT(ut) / 86400;
  }
  var AstroTime = class _AstroTime {
    /**
     * @param {FlexibleDateTime} date
     *      A JavaScript Date object, a numeric UTC value expressed in J2000 days, or another AstroTime object.
     */
    constructor(date) {
      if (date instanceof _AstroTime) {
        this.date = date.date;
        this.ut = date.ut;
        this.tt = date.tt;
        return;
      }
      const MillisPerDay = 1e3 * 3600 * 24;
      if (date instanceof Date && Number.isFinite(date.getTime())) {
        this.date = date;
        this.ut = (date.getTime() - J2000.getTime()) / MillisPerDay;
        this.tt = TerrestrialTime(this.ut);
        return;
      }
      if (Number.isFinite(date)) {
        this.date = new Date(J2000.getTime() + date * MillisPerDay);
        this.ut = date;
        this.tt = TerrestrialTime(this.ut);
        return;
      }
      throw "Argument must be a Date object, an AstroTime object, or a numeric UTC Julian date.";
    }
    /**
     * @brief Creates an `AstroTime` value from a Terrestrial Time (TT) day value.
     *
     * This function can be used in rare cases where a time must be based
     * on Terrestrial Time (TT) rather than Universal Time (UT).
     * Most developers will want to invoke `new AstroTime(ut)` with a universal time
     * instead of this function, because usually time is based on civil time adjusted
     * by leap seconds to match the Earth's rotation, rather than the uniformly
     * flowing TT used to calculate solar system dynamics. In rare cases
     * where the caller already knows TT, this function is provided to create
     * an `AstroTime` value that can be passed to Astronomy Engine functions.
     *
     * @param {number} tt
     *      The number of days since the J2000 epoch as expressed in Terrestrial Time.
     *
     * @returns {AstroTime}
     *      An `AstroTime` object for the specified terrestrial time.
     */
    static FromTerrestrialTime(tt) {
      let time = new _AstroTime(tt);
      for (; ; ) {
        const err = tt - time.tt;
        if (Math.abs(err) < 1e-12)
          return time;
        time = time.AddDays(err);
      }
    }
    /**
     * Formats an `AstroTime` object as an [ISO 8601](https://en.wikipedia.org/wiki/ISO_8601)
     * date/time string in UTC, to millisecond resolution.
     * Example: `2018-08-17T17:22:04.050Z`
     * @returns {string}
     */
    toString() {
      return this.date.toISOString();
    }
    /**
     * Returns a new `AstroTime` object adjusted by the floating point number of days.
     * Does NOT modify the original `AstroTime` object.
     *
     * @param {number} days
     *      The floating point number of days by which to adjust the given date and time.
     *      Positive values adjust the date toward the future, and
     *      negative values adjust the date toward the past.
     *
     * @returns {AstroTime}
     */
    AddDays(days) {
      return new _AstroTime(this.ut + days);
    }
  };
  function MakeTime(date) {
    if (date instanceof AstroTime) {
      return date;
    }
    return new AstroTime(date);
  }
  function iau2000b(time) {
    function mod(x2) {
      return x2 % ASEC360 * ASEC2RAD;
    }
    const t4 = time.tt / 36525;
    const elp = mod(128710479305e-5 + t4 * 1295965810481e-4);
    const f4 = mod(335779.526232 + t4 * 17395272628478e-4);
    const d3 = mod(107226070369e-5 + t4 * 1602961601209e-3);
    const om = mod(450160.398036 - t4 * 69628905431e-4);
    let sarg = Math.sin(om);
    let carg = Math.cos(om);
    let dp = (-172064161 - 174666 * t4) * sarg + 33386 * carg;
    let de = (92052331 + 9086 * t4) * carg + 15377 * sarg;
    let arg = 2 * (f4 - d3 + om);
    sarg = Math.sin(arg);
    carg = Math.cos(arg);
    dp += (-13170906 - 1675 * t4) * sarg - 13696 * carg;
    de += (5730336 - 3015 * t4) * carg - 4587 * sarg;
    arg = 2 * (f4 + om);
    sarg = Math.sin(arg);
    carg = Math.cos(arg);
    dp += (-2276413 - 234 * t4) * sarg + 2796 * carg;
    de += (978459 - 485 * t4) * carg + 1374 * sarg;
    arg = 2 * om;
    sarg = Math.sin(arg);
    carg = Math.cos(arg);
    dp += (2074554 + 207 * t4) * sarg - 698 * carg;
    de += (-897492 + 470 * t4) * carg - 291 * sarg;
    sarg = Math.sin(elp);
    carg = Math.cos(elp);
    dp += (1475877 - 3633 * t4) * sarg + 11817 * carg;
    de += (73871 - 184 * t4) * carg - 1924 * sarg;
    return {
      dpsi: -135e-6 + dp * 1e-7,
      deps: 388e-6 + de * 1e-7
    };
  }
  function mean_obliq(time) {
    var t4 = time.tt / 36525;
    var asec = ((((-434e-10 * t4 - 576e-9) * t4 + 20034e-7) * t4 - 1831e-7) * t4 - 46.836769) * t4 + 84381.406;
    return asec / 3600;
  }
  var cache_e_tilt;
  function e_tilt(time) {
    if (!cache_e_tilt || Math.abs(cache_e_tilt.tt - time.tt) > 1e-6) {
      const nut = iau2000b(time);
      const mean_ob = mean_obliq(time);
      const true_ob = mean_ob + nut.deps / 3600;
      cache_e_tilt = {
        tt: time.tt,
        dpsi: nut.dpsi,
        deps: nut.deps,
        ee: nut.dpsi * Math.cos(mean_ob * DEG2RAD) / 15,
        mobl: mean_ob,
        tobl: true_ob
      };
    }
    return cache_e_tilt;
  }
  function obl_ecl2equ_vec(oblDegrees, pos) {
    const obl = oblDegrees * DEG2RAD;
    const cos_obl = Math.cos(obl);
    const sin_obl = Math.sin(obl);
    return [
      pos[0],
      pos[1] * cos_obl - pos[2] * sin_obl,
      pos[1] * sin_obl + pos[2] * cos_obl
    ];
  }
  function ecl2equ_vec(time, pos) {
    return obl_ecl2equ_vec(mean_obliq(time), pos);
  }
  var CalcMoonCount = 0;
  function CalcMoon(time) {
    ++CalcMoonCount;
    const T3 = time.tt / 36525;
    function DeclareArray1(xmin, xmax) {
      const array = [];
      let i3;
      for (i3 = 0; i3 <= xmax - xmin; ++i3) {
        array.push(0);
      }
      return { min: xmin, array };
    }
    function DeclareArray2(xmin, xmax, ymin, ymax) {
      const array = [];
      for (let i3 = 0; i3 <= xmax - xmin; ++i3) {
        array.push(DeclareArray1(ymin, ymax));
      }
      return { min: xmin, array };
    }
    function ArrayGet2(a3, x2, y3) {
      const m3 = a3.array[x2 - a3.min];
      return m3.array[y3 - m3.min];
    }
    function ArraySet2(a3, x2, y3, v3) {
      const m3 = a3.array[x2 - a3.min];
      m3.array[y3 - m3.min] = v3;
    }
    let S2, MAX, ARG, FAC, I2, J2, T22, DGAM, DLAM, N2, GAM1C, SINPI, L0, L2, LS, F, D3, DL0, DL, DLS, DF, DD, DS;
    let coArray = DeclareArray2(-6, 6, 1, 4);
    let siArray = DeclareArray2(-6, 6, 1, 4);
    function CO(x2, y3) {
      return ArrayGet2(coArray, x2, y3);
    }
    function SI(x2, y3) {
      return ArrayGet2(siArray, x2, y3);
    }
    function SetCO(x2, y3, v3) {
      return ArraySet2(coArray, x2, y3, v3);
    }
    function SetSI(x2, y3, v3) {
      return ArraySet2(siArray, x2, y3, v3);
    }
    function AddThe(c1, s1, c22, s22, func) {
      func(c1 * c22 - s1 * s22, s1 * c22 + c1 * s22);
    }
    function Sine(phi) {
      return Math.sin(PI2 * phi);
    }
    T22 = T3 * T3;
    DLAM = 0;
    DS = 0;
    GAM1C = 0;
    SINPI = 3422.7;
    var S1 = Sine(0.19833 + 0.05611 * T3);
    var S22 = Sine(0.27869 + 0.04508 * T3);
    var S3 = Sine(0.16827 - 0.36903 * T3);
    var S4 = Sine(0.34734 - 5.37261 * T3);
    var S5 = Sine(0.10498 - 5.37899 * T3);
    var S6 = Sine(0.42681 - 0.41855 * T3);
    var S7 = Sine(0.14943 - 5.37511 * T3);
    DL0 = 0.84 * S1 + 0.31 * S22 + 14.27 * S3 + 7.26 * S4 + 0.28 * S5 + 0.24 * S6;
    DL = 2.94 * S1 + 0.31 * S22 + 14.27 * S3 + 9.34 * S4 + 1.12 * S5 + 0.83 * S6;
    DLS = -6.4 * S1 - 1.89 * S6;
    DF = 0.21 * S1 + 0.31 * S22 + 14.27 * S3 - 88.7 * S4 - 15.3 * S5 + 0.24 * S6 - 1.86 * S7;
    DD = DL0 - DLS;
    DGAM = -3332e-9 * Sine(0.59734 - 5.37261 * T3) - 539e-9 * Sine(0.35498 - 5.37899 * T3) - 64e-9 * Sine(0.39943 - 5.37511 * T3);
    L0 = PI2 * Frac(0.60643382 + 1336.85522467 * T3 - 313e-8 * T22) + DL0 / ARC;
    L2 = PI2 * Frac(0.37489701 + 1325.55240982 * T3 + 2565e-8 * T22) + DL / ARC;
    LS = PI2 * Frac(0.99312619 + 99.99735956 * T3 - 44e-8 * T22) + DLS / ARC;
    F = PI2 * Frac(0.25909118 + 1342.2278298 * T3 - 892e-8 * T22) + DF / ARC;
    D3 = PI2 * Frac(0.82736186 + 1236.85308708 * T3 - 397e-8 * T22) + DD / ARC;
    for (I2 = 1; I2 <= 4; ++I2) {
      switch (I2) {
        case 1:
          ARG = L2;
          MAX = 4;
          FAC = 1.000002208;
          break;
        case 2:
          ARG = LS;
          MAX = 3;
          FAC = 0.997504612 - 2495388e-9 * T3;
          break;
        case 3:
          ARG = F;
          MAX = 4;
          FAC = 1.000002708 + 139.978 * DGAM;
          break;
        case 4:
          ARG = D3;
          MAX = 6;
          FAC = 1;
          break;
        default:
          throw `Internal error: I = ${I2}`;
      }
      SetCO(0, I2, 1);
      SetCO(1, I2, Math.cos(ARG) * FAC);
      SetSI(0, I2, 0);
      SetSI(1, I2, Math.sin(ARG) * FAC);
      for (J2 = 2; J2 <= MAX; ++J2) {
        AddThe(CO(J2 - 1, I2), SI(J2 - 1, I2), CO(1, I2), SI(1, I2), (c3, s3) => (SetCO(J2, I2, c3), SetSI(J2, I2, s3)));
      }
      for (J2 = 1; J2 <= MAX; ++J2) {
        SetCO(-J2, I2, CO(J2, I2));
        SetSI(-J2, I2, -SI(J2, I2));
      }
    }
    function Term(p3, q2, r3, s3) {
      var result = { x: 1, y: 0 };
      var I3 = [0, p3, q2, r3, s3];
      for (var k3 = 1; k3 <= 4; ++k3)
        if (I3[k3] !== 0)
          AddThe(result.x, result.y, CO(I3[k3], k3), SI(I3[k3], k3), (c3, s4) => (result.x = c3, result.y = s4));
      return result;
    }
    function AddSol(coeffl, coeffs, coeffg, coeffp, p3, q2, r3, s3) {
      var result = Term(p3, q2, r3, s3);
      DLAM += coeffl * result.y;
      DS += coeffs * result.y;
      GAM1C += coeffg * result.x;
      SINPI += coeffp * result.x;
    }
    AddSol(13.902, 14.06, -1e-3, 0.2607, 0, 0, 0, 4);
    AddSol(0.403, -4.01, 0.394, 23e-4, 0, 0, 0, 3);
    AddSol(2369.912, 2373.36, 0.601, 28.2333, 0, 0, 0, 2);
    AddSol(-125.154, -112.79, -0.725, -0.9781, 0, 0, 0, 1);
    AddSol(1.979, 6.98, -0.445, 0.0433, 1, 0, 0, 4);
    AddSol(191.953, 192.72, 0.029, 3.0861, 1, 0, 0, 2);
    AddSol(-8.466, -13.51, 0.455, -0.1093, 1, 0, 0, 1);
    AddSol(22639.5, 22609.07, 0.079, 186.5398, 1, 0, 0, 0);
    AddSol(18.609, 3.59, -0.094, 0.0118, 1, 0, 0, -1);
    AddSol(-4586.465, -4578.13, -0.077, 34.3117, 1, 0, 0, -2);
    AddSol(3.215, 5.44, 0.192, -0.0386, 1, 0, 0, -3);
    AddSol(-38.428, -38.64, 1e-3, 0.6008, 1, 0, 0, -4);
    AddSol(-0.393, -1.43, -0.092, 86e-4, 1, 0, 0, -6);
    AddSol(-0.289, -1.59, 0.123, -53e-4, 0, 1, 0, 4);
    AddSol(-24.42, -25.1, 0.04, -0.3, 0, 1, 0, 2);
    AddSol(18.023, 17.93, 7e-3, 0.1494, 0, 1, 0, 1);
    AddSol(-668.146, -126.98, -1.302, -0.3997, 0, 1, 0, 0);
    AddSol(0.56, 0.32, -1e-3, -37e-4, 0, 1, 0, -1);
    AddSol(-165.145, -165.06, 0.054, 1.9178, 0, 1, 0, -2);
    AddSol(-1.877, -6.46, -0.416, 0.0339, 0, 1, 0, -4);
    AddSol(0.213, 1.02, -0.074, 54e-4, 2, 0, 0, 4);
    AddSol(14.387, 14.78, -0.017, 0.2833, 2, 0, 0, 2);
    AddSol(-0.586, -1.2, 0.054, -0.01, 2, 0, 0, 1);
    AddSol(769.016, 767.96, 0.107, 10.1657, 2, 0, 0, 0);
    AddSol(1.75, 2.01, -0.018, 0.0155, 2, 0, 0, -1);
    AddSol(-211.656, -152.53, 5.679, -0.3039, 2, 0, 0, -2);
    AddSol(1.225, 0.91, -0.03, -88e-4, 2, 0, 0, -3);
    AddSol(-30.773, -34.07, -0.308, 0.3722, 2, 0, 0, -4);
    AddSol(-0.57, -1.4, -0.074, 0.0109, 2, 0, 0, -6);
    AddSol(-2.921, -11.75, 0.787, -0.0484, 1, 1, 0, 2);
    AddSol(1.267, 1.52, -0.022, 0.0164, 1, 1, 0, 1);
    AddSol(-109.673, -115.18, 0.461, -0.949, 1, 1, 0, 0);
    AddSol(-205.962, -182.36, 2.056, 1.4437, 1, 1, 0, -2);
    AddSol(0.233, 0.36, 0.012, -25e-4, 1, 1, 0, -3);
    AddSol(-4.391, -9.66, -0.471, 0.0673, 1, 1, 0, -4);
    AddSol(0.283, 1.53, -0.111, 6e-3, 1, -1, 0, 4);
    AddSol(14.577, 31.7, -1.54, 0.2302, 1, -1, 0, 2);
    AddSol(147.687, 138.76, 0.679, 1.1528, 1, -1, 0, 0);
    AddSol(-1.089, 0.55, 0.021, 0, 1, -1, 0, -1);
    AddSol(28.475, 23.59, -0.443, -0.2257, 1, -1, 0, -2);
    AddSol(-0.276, -0.38, -6e-3, -36e-4, 1, -1, 0, -3);
    AddSol(0.636, 2.27, 0.146, -0.0102, 1, -1, 0, -4);
    AddSol(-0.189, -1.68, 0.131, -28e-4, 0, 2, 0, 2);
    AddSol(-7.486, -0.66, -0.037, -86e-4, 0, 2, 0, 0);
    AddSol(-8.096, -16.35, -0.74, 0.0918, 0, 2, 0, -2);
    AddSol(-5.741, -0.04, 0, -9e-4, 0, 0, 2, 2);
    AddSol(0.255, 0, 0, 0, 0, 0, 2, 1);
    AddSol(-411.608, -0.2, 0, -0.0124, 0, 0, 2, 0);
    AddSol(0.584, 0.84, 0, 71e-4, 0, 0, 2, -1);
    AddSol(-55.173, -52.14, 0, -0.1052, 0, 0, 2, -2);
    AddSol(0.254, 0.25, 0, -17e-4, 0, 0, 2, -3);
    AddSol(0.025, -1.67, 0, 31e-4, 0, 0, 2, -4);
    AddSol(1.06, 2.96, -0.166, 0.0243, 3, 0, 0, 2);
    AddSol(36.124, 50.64, -1.3, 0.6215, 3, 0, 0, 0);
    AddSol(-13.193, -16.4, 0.258, -0.1187, 3, 0, 0, -2);
    AddSol(-1.187, -0.74, 0.042, 74e-4, 3, 0, 0, -4);
    AddSol(-0.293, -0.31, -2e-3, 46e-4, 3, 0, 0, -6);
    AddSol(-0.29, -1.45, 0.116, -51e-4, 2, 1, 0, 2);
    AddSol(-7.649, -10.56, 0.259, -0.1038, 2, 1, 0, 0);
    AddSol(-8.627, -7.59, 0.078, -0.0192, 2, 1, 0, -2);
    AddSol(-2.74, -2.54, 0.022, 0.0324, 2, 1, 0, -4);
    AddSol(1.181, 3.32, -0.212, 0.0213, 2, -1, 0, 2);
    AddSol(9.703, 11.67, -0.151, 0.1268, 2, -1, 0, 0);
    AddSol(-0.352, -0.37, 1e-3, -28e-4, 2, -1, 0, -1);
    AddSol(-2.494, -1.17, -3e-3, -17e-4, 2, -1, 0, -2);
    AddSol(0.36, 0.2, -0.012, -43e-4, 2, -1, 0, -4);
    AddSol(-1.167, -1.25, 8e-3, -0.0106, 1, 2, 0, 0);
    AddSol(-7.412, -6.12, 0.117, 0.0484, 1, 2, 0, -2);
    AddSol(-0.311, -0.65, -0.032, 44e-4, 1, 2, 0, -4);
    AddSol(0.757, 1.82, -0.105, 0.0112, 1, -2, 0, 2);
    AddSol(2.58, 2.32, 0.027, 0.0196, 1, -2, 0, 0);
    AddSol(2.533, 2.4, -0.014, -0.0212, 1, -2, 0, -2);
    AddSol(-0.344, -0.57, -0.025, 36e-4, 0, 3, 0, -2);
    AddSol(-0.992, -0.02, 0, 0, 1, 0, 2, 2);
    AddSol(-45.099, -0.02, 0, -1e-3, 1, 0, 2, 0);
    AddSol(-0.179, -9.52, 0, -0.0833, 1, 0, 2, -2);
    AddSol(-0.301, -0.33, 0, 14e-4, 1, 0, 2, -4);
    AddSol(-6.382, -3.37, 0, -0.0481, 1, 0, -2, 2);
    AddSol(39.528, 85.13, 0, -0.7136, 1, 0, -2, 0);
    AddSol(9.366, 0.71, 0, -0.0112, 1, 0, -2, -2);
    AddSol(0.202, 0.02, 0, 0, 1, 0, -2, -4);
    AddSol(0.415, 0.1, 0, 13e-4, 0, 1, 2, 0);
    AddSol(-2.152, -2.26, 0, -66e-4, 0, 1, 2, -2);
    AddSol(-1.44, -1.3, 0, 14e-4, 0, 1, -2, 2);
    AddSol(0.384, -0.04, 0, 0, 0, 1, -2, -2);
    AddSol(1.938, 3.6, -0.145, 0.0401, 4, 0, 0, 0);
    AddSol(-0.952, -1.58, 0.052, -0.013, 4, 0, 0, -2);
    AddSol(-0.551, -0.94, 0.032, -97e-4, 3, 1, 0, 0);
    AddSol(-0.482, -0.57, 5e-3, -45e-4, 3, 1, 0, -2);
    AddSol(0.681, 0.96, -0.026, 0.0115, 3, -1, 0, 0);
    AddSol(-0.297, -0.27, 2e-3, -9e-4, 2, 2, 0, -2);
    AddSol(0.254, 0.21, -3e-3, 0, 2, -2, 0, -2);
    AddSol(-0.25, -0.22, 4e-3, 14e-4, 1, 3, 0, -2);
    AddSol(-3.996, 0, 0, 4e-4, 2, 0, 2, 0);
    AddSol(0.557, -0.75, 0, -9e-3, 2, 0, 2, -2);
    AddSol(-0.459, -0.38, 0, -53e-4, 2, 0, -2, 2);
    AddSol(-1.298, 0.74, 0, 4e-4, 2, 0, -2, 0);
    AddSol(0.538, 1.14, 0, -0.0141, 2, 0, -2, -2);
    AddSol(0.263, 0.02, 0, 0, 1, 1, 2, 0);
    AddSol(0.426, 0.07, 0, -6e-4, 1, 1, -2, -2);
    AddSol(-0.304, 0.03, 0, 3e-4, 1, -1, 2, 0);
    AddSol(-0.372, -0.19, 0, -27e-4, 1, -1, -2, 2);
    AddSol(0.418, 0, 0, 0, 0, 0, 4, 0);
    AddSol(-0.33, -0.04, 0, 0, 3, 0, 2, 0);
    function ADDN(coeffn, p3, q2, r3, s3) {
      return coeffn * Term(p3, q2, r3, s3).y;
    }
    N2 = 0;
    N2 += ADDN(-526.069, 0, 0, 1, -2);
    N2 += ADDN(-3.352, 0, 0, 1, -4);
    N2 += ADDN(44.297, 1, 0, 1, -2);
    N2 += ADDN(-6, 1, 0, 1, -4);
    N2 += ADDN(20.599, -1, 0, 1, 0);
    N2 += ADDN(-30.598, -1, 0, 1, -2);
    N2 += ADDN(-24.649, -2, 0, 1, 0);
    N2 += ADDN(-2, -2, 0, 1, -2);
    N2 += ADDN(-22.571, 0, 1, 1, -2);
    N2 += ADDN(10.985, 0, -1, 1, -2);
    DLAM += 0.82 * Sine(0.7736 - 62.5512 * T3) + 0.31 * Sine(0.0466 - 125.1025 * T3) + 0.35 * Sine(0.5785 - 25.1042 * T3) + 0.66 * Sine(0.4591 + 1335.8075 * T3) + 0.64 * Sine(0.313 - 91.568 * T3) + 1.14 * Sine(0.148 + 1331.2898 * T3) + 0.21 * Sine(0.5918 + 1056.5859 * T3) + 0.44 * Sine(0.5784 + 1322.8595 * T3) + 0.24 * Sine(0.2275 - 5.7374 * T3) + 0.28 * Sine(0.2965 + 2.6929 * T3) + 0.33 * Sine(0.3132 + 6.3368 * T3);
    S2 = F + DS / ARC;
    let lat_seconds = (1.000002708 + 139.978 * DGAM) * (18518.511 + 1.189 + GAM1C) * Math.sin(S2) - 6.24 * Math.sin(3 * S2) + N2;
    return {
      geo_eclip_lon: PI2 * Frac((L0 + DLAM / ARC) / PI2),
      geo_eclip_lat: Math.PI / (180 * 3600) * lat_seconds,
      distance_au: ARC * EARTH_EQUATORIAL_RADIUS_AU / (0.999953253 * SINPI)
    };
  }
  function rotate(rot, vec) {
    return [
      rot.rot[0][0] * vec[0] + rot.rot[1][0] * vec[1] + rot.rot[2][0] * vec[2],
      rot.rot[0][1] * vec[0] + rot.rot[1][1] * vec[1] + rot.rot[2][1] * vec[2],
      rot.rot[0][2] * vec[0] + rot.rot[1][2] * vec[1] + rot.rot[2][2] * vec[2]
    ];
  }
  function precession(pos, time, dir) {
    const r3 = precession_rot(time, dir);
    return rotate(r3, pos);
  }
  function precession_rot(time, dir) {
    const t4 = time.tt / 36525;
    let eps0 = 84381.406;
    let psia = ((((-951e-10 * t4 + 132851e-9) * t4 - 114045e-8) * t4 - 1.0790069) * t4 + 5038.481507) * t4;
    let omegaa = ((((3337e-10 * t4 - 467e-9) * t4 - 772503e-8) * t4 + 0.0512623) * t4 - 0.025754) * t4 + eps0;
    let chia = ((((-56e-9 * t4 + 170663e-9) * t4 - 121197e-8) * t4 - 2.3814292) * t4 + 10.556403) * t4;
    eps0 *= ASEC2RAD;
    psia *= ASEC2RAD;
    omegaa *= ASEC2RAD;
    chia *= ASEC2RAD;
    const sa = Math.sin(eps0);
    const ca = Math.cos(eps0);
    const sb = Math.sin(-psia);
    const cb = Math.cos(-psia);
    const sc = Math.sin(-omegaa);
    const cc = Math.cos(-omegaa);
    const sd = Math.sin(chia);
    const cd = Math.cos(chia);
    const xx = cd * cb - sb * sd * cc;
    const yx = cd * sb * ca + sd * cc * cb * ca - sa * sd * sc;
    const zx = cd * sb * sa + sd * cc * cb * sa + ca * sd * sc;
    const xy = -sd * cb - sb * cd * cc;
    const yy = -sd * sb * ca + cd * cc * cb * ca - sa * cd * sc;
    const zy = -sd * sb * sa + cd * cc * cb * sa + ca * cd * sc;
    const xz = sb * sc;
    const yz = -sc * cb * ca - sa * cc;
    const zz = -sc * cb * sa + cc * ca;
    if (dir === PrecessDirection.Into2000) {
      return new RotationMatrix([
        [xx, yx, zx],
        [xy, yy, zy],
        [xz, yz, zz]
      ]);
    }
    if (dir === PrecessDirection.From2000) {
      return new RotationMatrix([
        [xx, xy, xz],
        [yx, yy, yz],
        [zx, zy, zz]
      ]);
    }
    throw "Invalid precess direction";
  }
  function era(time) {
    const thet1 = 0.779057273264 + 0.00273781191135448 * time.ut;
    const thet3 = time.ut % 1;
    let theta = 360 * ((thet1 + thet3) % 1);
    if (theta < 0) {
      theta += 360;
    }
    return theta;
  }
  var sidereal_time_cache;
  function sidereal_time(time) {
    if (!sidereal_time_cache || sidereal_time_cache.tt !== time.tt) {
      const t4 = time.tt / 36525;
      let eqeq = 15 * e_tilt(time).ee;
      const theta = era(time);
      const st = eqeq + 0.014506 + ((((-368e-10 * t4 - 29956e-9) * t4 - 44e-8) * t4 + 1.3915817) * t4 + 4612.156534) * t4;
      let gst = (st / 3600 + theta) % 360 / 15;
      if (gst < 0) {
        gst += 24;
      }
      sidereal_time_cache = {
        tt: time.tt,
        st: gst
      };
    }
    return sidereal_time_cache.st;
  }
  function SiderealTime(date) {
    const time = MakeTime(date);
    return sidereal_time(time);
  }
  function nutation(pos, time, dir) {
    const r3 = nutation_rot(time, dir);
    return rotate(r3, pos);
  }
  function nutation_rot(time, dir) {
    const tilt = e_tilt(time);
    const oblm = tilt.mobl * DEG2RAD;
    const oblt = tilt.tobl * DEG2RAD;
    const psi = tilt.dpsi * ASEC2RAD;
    const cobm = Math.cos(oblm);
    const sobm = Math.sin(oblm);
    const cobt = Math.cos(oblt);
    const sobt = Math.sin(oblt);
    const cpsi = Math.cos(psi);
    const spsi = Math.sin(psi);
    const xx = cpsi;
    const yx = -spsi * cobm;
    const zx = -spsi * sobm;
    const xy = spsi * cobt;
    const yy = cpsi * cobm * cobt + sobm * sobt;
    const zy = cpsi * sobm * cobt - cobm * sobt;
    const xz = spsi * sobt;
    const yz = cpsi * cobm * sobt - sobm * cobt;
    const zz = cpsi * sobm * sobt + cobm * cobt;
    if (dir === PrecessDirection.From2000) {
      return new RotationMatrix([
        [xx, xy, xz],
        [yx, yy, yz],
        [zx, zy, zz]
      ]);
    }
    if (dir === PrecessDirection.Into2000) {
      return new RotationMatrix([
        [xx, yx, zx],
        [xy, yy, zy],
        [xz, yz, zz]
      ]);
    }
    throw "Invalid precess direction";
  }
  var Vector = class {
    constructor(x2, y3, z3, t4) {
      this.x = x2;
      this.y = y3;
      this.z = z3;
      this.t = t4;
    }
    /**
     * Returns the length of the vector in astronomical units (AU).
     * @returns {number}
     */
    Length() {
      return Math.hypot(this.x, this.y, this.z);
    }
  };
  var StateVector = class {
    constructor(x2, y3, z3, vx, vy, vz, t4) {
      this.x = x2;
      this.y = y3;
      this.z = z3;
      this.vx = vx;
      this.vy = vy;
      this.vz = vz;
      this.t = t4;
    }
  };
  var Spherical = class {
    constructor(lat, lon, dist) {
      this.lat = VerifyNumber(lat);
      this.lon = VerifyNumber(lon);
      this.dist = VerifyNumber(dist);
    }
  };
  var RotationMatrix = class {
    constructor(rot) {
      this.rot = rot;
    }
  };
  var EclipticCoordinates = class {
    constructor(vec, elat, elon) {
      this.vec = vec;
      this.elat = VerifyNumber(elat);
      this.elon = VerifyNumber(elon);
    }
  };
  function VectorFromArray(av, time) {
    return new Vector(av[0], av[1], av[2], time);
  }
  function RotateEquatorialToEcliptic(equ, cos_ob, sin_ob) {
    const ex = equ.x;
    const ey = equ.y * cos_ob + equ.z * sin_ob;
    const ez = -equ.y * sin_ob + equ.z * cos_ob;
    const xyproj = Math.hypot(ex, ey);
    let elon = 0;
    if (xyproj > 0) {
      elon = RAD2DEG * Math.atan2(ey, ex);
      if (elon < 0)
        elon += 360;
    }
    let elat = RAD2DEG * Math.atan2(ez, xyproj);
    let ecl = new Vector(ex, ey, ez, equ.t);
    return new EclipticCoordinates(ecl, elat, elon);
  }
  function GeoMoon(date) {
    const time = MakeTime(date);
    const moon = CalcMoon(time);
    const dist_cos_lat = moon.distance_au * Math.cos(moon.geo_eclip_lat);
    const gepos = [
      dist_cos_lat * Math.cos(moon.geo_eclip_lon),
      dist_cos_lat * Math.sin(moon.geo_eclip_lon),
      moon.distance_au * Math.sin(moon.geo_eclip_lat)
    ];
    const mpos1 = ecl2equ_vec(time, gepos);
    const mpos2 = precession(mpos1, time, PrecessDirection.Into2000);
    return new Vector(mpos2[0], mpos2[1], mpos2[2], time);
  }
  function EclipticGeoMoon(date) {
    const time = MakeTime(date);
    const moon = CalcMoon(time);
    const dist_cos_lat = moon.distance_au * Math.cos(moon.geo_eclip_lat);
    const ecm = [
      dist_cos_lat * Math.cos(moon.geo_eclip_lon),
      dist_cos_lat * Math.sin(moon.geo_eclip_lon),
      moon.distance_au * Math.sin(moon.geo_eclip_lat)
    ];
    const et = e_tilt(time);
    const eqm = obl_ecl2equ_vec(et.mobl, ecm);
    const eqd = nutation(eqm, time, PrecessDirection.From2000);
    const eqd_vec = VectorFromArray(eqd, time);
    const toblRad = et.tobl * DEG2RAD;
    const cos_tobl = Math.cos(toblRad);
    const sin_tobl = Math.sin(toblRad);
    const eclip = RotateEquatorialToEcliptic(eqd_vec, cos_tobl, sin_tobl);
    return new Spherical(eclip.elat, eclip.elon, moon.distance_au);
  }
  function GeoMoonState(date) {
    const time = MakeTime(date);
    const dt = 1e-5;
    const t1 = time.AddDays(-dt);
    const t22 = time.AddDays(+dt);
    const r1 = GeoMoon(t1);
    const r22 = GeoMoon(t22);
    return new StateVector((r1.x + r22.x) / 2, (r1.y + r22.y) / 2, (r1.z + r22.z) / 2, (r22.x - r1.x) / (2 * dt), (r22.y - r1.y) / (2 * dt), (r22.z - r1.z) / (2 * dt), time);
  }
  function GeoEmbState(date) {
    const time = MakeTime(date);
    const s3 = GeoMoonState(time);
    const d3 = 1 + EARTH_MOON_MASS_RATIO;
    return new StateVector(s3.x / d3, s3.y / d3, s3.z / d3, s3.vx / d3, s3.vy / d3, s3.vz / d3, time);
  }
  function VsopFormula(formula, t4, clamp_angle) {
    let tpower = 1;
    let coord = 0;
    for (let series of formula) {
      let sum = 0;
      for (let [ampl, phas, freq] of series)
        sum += ampl * Math.cos(phas + t4 * freq);
      let incr = tpower * sum;
      if (clamp_angle)
        incr %= PI2;
      coord += incr;
      tpower *= t4;
    }
    return coord;
  }
  function VsopDeriv(formula, t4) {
    let tpower = 1;
    let dpower = 0;
    let deriv = 0;
    let s3 = 0;
    for (let series of formula) {
      let sin_sum = 0;
      let cos_sum = 0;
      for (let [ampl, phas, freq] of series) {
        let angle = phas + t4 * freq;
        sin_sum += ampl * freq * Math.sin(angle);
        if (s3 > 0)
          cos_sum += ampl * Math.cos(angle);
      }
      deriv += s3 * dpower * cos_sum - tpower * sin_sum;
      dpower = tpower;
      tpower *= t4;
      ++s3;
    }
    return deriv;
  }
  var DAYS_PER_MILLENNIUM = 365250;
  var LON_INDEX = 0;
  var LAT_INDEX = 1;
  var RAD_INDEX = 2;
  function VsopRotate(eclip) {
    return new TerseVector(eclip[0] + 44036e-11 * eclip[1] - 190919e-12 * eclip[2], -479966e-12 * eclip[0] + 0.917482137087 * eclip[1] - 0.397776982902 * eclip[2], 0.397776982902 * eclip[1] + 0.917482137087 * eclip[2]);
  }
  function VsopSphereToRect(lon, lat, radius) {
    const r_coslat = radius * Math.cos(lat);
    const coslon = Math.cos(lon);
    const sinlon = Math.sin(lon);
    return [
      r_coslat * coslon,
      r_coslat * sinlon,
      radius * Math.sin(lat)
    ];
  }
  function CalcVsop(model, time) {
    const t4 = time.tt / DAYS_PER_MILLENNIUM;
    const lon = VsopFormula(model[LON_INDEX], t4, true);
    const lat = VsopFormula(model[LAT_INDEX], t4, false);
    const rad = VsopFormula(model[RAD_INDEX], t4, false);
    const eclip = VsopSphereToRect(lon, lat, rad);
    return VsopRotate(eclip).ToAstroVector(time);
  }
  function CalcVsopPosVel(model, tt) {
    const t4 = tt / DAYS_PER_MILLENNIUM;
    const lon = VsopFormula(model[LON_INDEX], t4, true);
    const lat = VsopFormula(model[LAT_INDEX], t4, false);
    const rad = VsopFormula(model[RAD_INDEX], t4, false);
    const dlon_dt = VsopDeriv(model[LON_INDEX], t4);
    const dlat_dt = VsopDeriv(model[LAT_INDEX], t4);
    const drad_dt = VsopDeriv(model[RAD_INDEX], t4);
    const coslon = Math.cos(lon);
    const sinlon = Math.sin(lon);
    const coslat = Math.cos(lat);
    const sinlat = Math.sin(lat);
    const vx = +(drad_dt * coslat * coslon) - rad * sinlat * coslon * dlat_dt - rad * coslat * sinlon * dlon_dt;
    const vy = +(drad_dt * coslat * sinlon) - rad * sinlat * sinlon * dlat_dt + rad * coslat * coslon * dlon_dt;
    const vz = +(drad_dt * sinlat) + rad * coslat * dlat_dt;
    const eclip_pos = VsopSphereToRect(lon, lat, rad);
    const eclip_vel = [
      vx / DAYS_PER_MILLENNIUM,
      vy / DAYS_PER_MILLENNIUM,
      vz / DAYS_PER_MILLENNIUM
    ];
    const equ_pos = VsopRotate(eclip_pos);
    const equ_vel = VsopRotate(eclip_vel);
    return new body_state_t(tt, equ_pos, equ_vel);
  }
  function AdjustBarycenter(ssb, time, body, pmass) {
    const shift = pmass / (pmass + SUN_GM);
    const planet = CalcVsop(vsop[body], time);
    ssb.x += shift * planet.x;
    ssb.y += shift * planet.y;
    ssb.z += shift * planet.z;
  }
  function CalcSolarSystemBarycenter(time) {
    const ssb = new Vector(0, 0, 0, time);
    AdjustBarycenter(ssb, time, Body.Jupiter, JUPITER_GM);
    AdjustBarycenter(ssb, time, Body.Saturn, SATURN_GM);
    AdjustBarycenter(ssb, time, Body.Uranus, URANUS_GM);
    AdjustBarycenter(ssb, time, Body.Neptune, NEPTUNE_GM);
    return ssb;
  }
  var PLUTO_NUM_STATES = 51;
  var PLUTO_TIME_STEP = 29200;
  var PLUTO_DT = 146;
  var PLUTO_NSTEPS = 201;
  var PlutoStateTable = [
    [-73e4, [-26.118207232108, -14.376168177825, 3.384402515299], [0.0016339372163656, -0.0027861699588508, -0.0013585880229445]],
    [-700800, [41.974905202127, -0.448502952929, -12.770351505989], [73458569351457e-17, 0.0022785014891658, 48619778602049e-17]],
    [-671600, [14.706930780744, 44.269110540027, 9.353698474772], [-0.00210001479998, 22295915939915e-17, 70143443551414e-17]],
    [-642400, [-29.441003929957, -6.43016153057, 6.858481011305], [84495803960544e-17, -0.0030783914758711, -0.0012106305981192]],
    [-613200, [39.444396946234, -6.557989760571, -13.913760296463], [0.0011480029005873, 0.0022400006880665, 35168075922288e-17]],
    [-584e3, [20.2303809507, 43.266966657189, 7.382966091923], [-0.0019754081700585, 53457141292226e-17, 75929169129793e-17]],
    [-554800, [-30.65832536462, 2.093818874552, 9.880531138071], [61010603013347e-18, -0.0031326500935382, -99346125151067e-17]],
    [-525600, [35.737703251673, -12.587706024764, -14.677847247563], [0.0015802939375649, 0.0021347678412429, 19074436384343e-17]],
    [-496400, [25.466295188546, 41.367478338417, 5.216476873382], [-0.0018054401046468, 8328308359951e-16, 80260156912107e-17]],
    [-467200, [-29.847174904071, 10.636426313081, 12.297904180106], [-63257063052907e-17, -0.0029969577578221, -74476074151596e-17]],
    [-438e3, [30.774692107687, -18.236637015304, -14.945535879896], [0.0020113162005465, 0.0019353827024189, -20937793168297e-19]],
    [-408800, [30.243153324028, 38.656267888503, 2.938501750218], [-0.0016052508674468, 0.0011183495337525, 83333973416824e-17]],
    [-379600, [-27.288984772533, 18.643162147874, 14.023633623329], [-0.0011856388898191, -0.0027170609282181, -49015526126399e-17]],
    [-350400, [24.519605196774, -23.245756064727, -14.626862367368], [0.0024322321483154, 0.0016062008146048, -23369181613312e-17]],
    [-321200, [34.505274805875, 35.125338586954, 0.557361475637], [-0.0013824391637782, 0.0013833397561817, 84823598806262e-17]],
    [-292e3, [-23.275363915119, 25.818514298769, 15.055381588598], [-0.0016062295460975, -0.0023395961498533, -24377362639479e-17]],
    [-262800, [17.050384798092, -27.180376290126, -13.608963321694], [0.0028175521080578, 0.0011358749093955, -49548725258825e-17]],
    [-233600, [38.093671910285, 30.880588383337, -1.843688067413], [-0.0011317697153459, 0.0016128814698472, 84177586176055e-17]],
    [-204400, [-18.197852930878, 31.932869934309, 15.438294826279], [-0.0019117272501813, -0.0019146495909842, -19657304369835e-18]],
    [-175200, [8.528924039997, -29.618422200048, -11.805400994258], [0.0031034370787005, 5139363329243e-16, -77293066202546e-17]],
    [-146e3, [40.94685725864, 25.904973592021, -4.256336240499], [-83652705194051e-17, 0.0018129497136404, 8156422827306e-16]],
    [-116800, [-12.326958895325, 36.881883446292, 15.217158258711], [-0.0021166103705038, -0.001481442003599, 17401209844705e-17]],
    [-87600, [-0.633258375909, -30.018759794709, -9.17193287495], [0.0032016994581737, -25279858672148e-17, -0.0010411088271861]],
    [-58400, [42.936048423883, 20.344685584452, -6.588027007912], [-50525450073192e-17, 0.0019910074335507, 77440196540269e-17]],
    [-29200, [-5.975910552974, 40.61180995846, 14.470131723673], [-0.0022184202156107, -0.0010562361130164, 33652250216211e-17]],
    [0, [-9.875369580774, -27.978926224737, -5.753711824704], [0.0030287533248818, -0.0011276087003636, -0.0012651326732361]],
    [29200, [43.958831986165, 14.214147973292, -8.808306227163], [-14717608981871e-17, 0.0021404187242141, 71486567806614e-17]],
    [58400, [0.67813676352, 43.094461639362, 13.243238780721], [-0.0022358226110718, -63233636090933e-17, 47664798895648e-17]],
    [87600, [-18.282602096834, -23.30503958666, -1.766620508028], [0.0025567245263557, -0.0019902940754171, -0.0013943491701082]],
    [116800, [43.873338744526, 7.700705617215, -10.814273666425], [23174803055677e-17, 0.0022402163127924, 62988756452032e-17]],
    [146e3, [7.392949027906, 44.382678951534, 11.629500214854], [-0.002193281545383, -21751799585364e-17, 59556516201114e-17]],
    [175200, [-24.981690229261, -16.204012851426, 2.466457544298], [0.001819398914958, -0.0026765419531201, -0.0013848283502247]],
    [204400, [42.530187039511, 0.845935508021, -12.554907527683], [65059779150669e-17, 0.0022725657282262, 51133743202822e-17]],
    [233600, [13.999526486822, 44.462363044894, 9.669418486465], [-0.0021079296569252, 17533423831993e-17, 69128485798076e-17]],
    [262800, [-29.184024803031, -7.371243995762, 6.493275957928], [93581363109681e-17, -0.0030610357109184, -0.0012364201089345]],
    [292e3, [39.831980671753, -6.078405766765, -13.909815358656], [0.0011117769689167, 0.0022362097830152, 36230548231153e-17]],
    [321200, [20.294955108476, 43.417190420251, 7.450091985932], [-0.0019742157451535, 53102050468554e-17, 75938408813008e-17]],
    [350400, [-30.66999230216, 2.318743558955, 9.973480913858], [45605107450676e-18, -0.0031308219926928, -99066533301924e-17]],
    [379600, [35.626122155983, -12.897647509224, -14.777586508444], [0.0016015684949743, 0.0021171931182284, 18002516202204e-17]],
    [408800, [26.133186148561, 41.232139187599, 5.00640132622], [-0.0017857704419579, 86046232702817e-17, 80614690298954e-17]],
    [438e3, [-29.57674022923, 11.863535943587, 12.631323039872], [-72292830060955e-17, -0.0029587820140709, -708242964503e-15]],
    [467200, [29.910805787391, -19.159019294, -15.013363865194], [0.0020871080437997, 0.0018848372554514, -38528655083926e-18]],
    [496400, [31.375957451819, 38.050372720763, 2.433138343754], [-0.0015546055556611, 0.0011699815465629, 83565439266001e-17]],
    [525600, [-26.360071336928, 20.662505904952, 14.414696258958], [-0.0013142373118349, -0.0026236647854842, -42542017598193e-17]],
    [554800, [22.599441488648, -24.508879898306, -14.484045731468], [0.0025454108304806, 0.0014917058755191, -30243665086079e-17]],
    [584e3, [35.877864013014, 33.894226366071, -0.224524636277], [-0.0012941245730845, 0.0014560427668319, 84762160640137e-17]],
    [613200, [-21.538149762417, 28.204068269761, 15.321973799534], [-0.001731211740901, -0.0021939631314577, -1631691327518e-16]],
    [642400, [13.971521374415, -28.339941764789, -13.083792871886], [0.0029334630526035, 91860931752944e-17, -59939422488627e-17]],
    [671600, [39.526942044143, 28.93989736011, -2.872799527539], [-0.0010068481658095, 0.001702113288809, 83578230511981e-17]],
    [700800, [-15.576200701394, 34.399412961275, 15.466033737854], [-0.0020098814612884, -0.0017191109825989, 70414782780416e-18]],
    [73e4, [4.24325283709, -30.118201690825, -10.707441231349], [0.0031725847067411, 1609846120227e-16, -90672150593868e-17]]
  ];
  var TerseVector = class _TerseVector {
    constructor(x2, y3, z3) {
      this.x = x2;
      this.y = y3;
      this.z = z3;
    }
    clone() {
      return new _TerseVector(this.x, this.y, this.z);
    }
    ToAstroVector(t4) {
      return new Vector(this.x, this.y, this.z, t4);
    }
    static zero() {
      return new _TerseVector(0, 0, 0);
    }
    quadrature() {
      return this.x * this.x + this.y * this.y + this.z * this.z;
    }
    add(other) {
      return new _TerseVector(this.x + other.x, this.y + other.y, this.z + other.z);
    }
    sub(other) {
      return new _TerseVector(this.x - other.x, this.y - other.y, this.z - other.z);
    }
    incr(other) {
      this.x += other.x;
      this.y += other.y;
      this.z += other.z;
    }
    decr(other) {
      this.x -= other.x;
      this.y -= other.y;
      this.z -= other.z;
    }
    mul(scalar) {
      return new _TerseVector(scalar * this.x, scalar * this.y, scalar * this.z);
    }
    div(scalar) {
      return new _TerseVector(this.x / scalar, this.y / scalar, this.z / scalar);
    }
    mean(other) {
      return new _TerseVector((this.x + other.x) / 2, (this.y + other.y) / 2, (this.z + other.z) / 2);
    }
    neg() {
      return new _TerseVector(-this.x, -this.y, -this.z);
    }
  };
  var body_state_t = class _body_state_t {
    constructor(tt, r3, v3) {
      this.tt = tt;
      this.r = r3;
      this.v = v3;
    }
    clone() {
      return new _body_state_t(this.tt, this.r, this.v);
    }
    sub(other) {
      return new _body_state_t(this.tt, this.r.sub(other.r), this.v.sub(other.v));
    }
  };
  function BodyStateFromTable(entry) {
    let [tt, [rx, ry, rz], [vx, vy, vz]] = entry;
    return new body_state_t(tt, new TerseVector(rx, ry, rz), new TerseVector(vx, vy, vz));
  }
  function AdjustBarycenterPosVel(ssb, tt, body, planet_gm) {
    const shift = planet_gm / (planet_gm + SUN_GM);
    const planet = CalcVsopPosVel(vsop[body], tt);
    ssb.r.incr(planet.r.mul(shift));
    ssb.v.incr(planet.v.mul(shift));
    return planet;
  }
  function AccelerationIncrement(small_pos, gm, major_pos) {
    const delta = major_pos.sub(small_pos);
    const r22 = delta.quadrature();
    return delta.mul(gm / (r22 * Math.sqrt(r22)));
  }
  var major_bodies_t = class {
    constructor(tt) {
      let ssb = new body_state_t(tt, new TerseVector(0, 0, 0), new TerseVector(0, 0, 0));
      this.Jupiter = AdjustBarycenterPosVel(ssb, tt, Body.Jupiter, JUPITER_GM);
      this.Saturn = AdjustBarycenterPosVel(ssb, tt, Body.Saturn, SATURN_GM);
      this.Uranus = AdjustBarycenterPosVel(ssb, tt, Body.Uranus, URANUS_GM);
      this.Neptune = AdjustBarycenterPosVel(ssb, tt, Body.Neptune, NEPTUNE_GM);
      this.Jupiter.r.decr(ssb.r);
      this.Jupiter.v.decr(ssb.v);
      this.Saturn.r.decr(ssb.r);
      this.Saturn.v.decr(ssb.v);
      this.Uranus.r.decr(ssb.r);
      this.Uranus.v.decr(ssb.v);
      this.Neptune.r.decr(ssb.r);
      this.Neptune.v.decr(ssb.v);
      this.Sun = new body_state_t(tt, ssb.r.mul(-1), ssb.v.mul(-1));
    }
    Acceleration(pos) {
      let acc = AccelerationIncrement(pos, SUN_GM, this.Sun.r);
      acc.incr(AccelerationIncrement(pos, JUPITER_GM, this.Jupiter.r));
      acc.incr(AccelerationIncrement(pos, SATURN_GM, this.Saturn.r));
      acc.incr(AccelerationIncrement(pos, URANUS_GM, this.Uranus.r));
      acc.incr(AccelerationIncrement(pos, NEPTUNE_GM, this.Neptune.r));
      return acc;
    }
  };
  var body_grav_calc_t = class _body_grav_calc_t {
    constructor(tt, r3, v3, a3) {
      this.tt = tt;
      this.r = r3;
      this.v = v3;
      this.a = a3;
    }
    clone() {
      return new _body_grav_calc_t(this.tt, this.r.clone(), this.v.clone(), this.a.clone());
    }
  };
  var grav_sim_t = class {
    constructor(bary, grav) {
      this.bary = bary;
      this.grav = grav;
    }
  };
  function UpdatePosition(dt, r3, v3, a3) {
    return new TerseVector(r3.x + dt * (v3.x + dt * a3.x / 2), r3.y + dt * (v3.y + dt * a3.y / 2), r3.z + dt * (v3.z + dt * a3.z / 2));
  }
  function UpdateVelocity(dt, v3, a3) {
    return new TerseVector(v3.x + dt * a3.x, v3.y + dt * a3.y, v3.z + dt * a3.z);
  }
  function GravSim(tt2, calc1) {
    const dt = tt2 - calc1.tt;
    const bary2 = new major_bodies_t(tt2);
    const approx_pos = UpdatePosition(dt, calc1.r, calc1.v, calc1.a);
    const mean_acc = bary2.Acceleration(approx_pos).mean(calc1.a);
    const pos = UpdatePosition(dt, calc1.r, calc1.v, mean_acc);
    const vel = calc1.v.add(mean_acc.mul(dt));
    const acc = bary2.Acceleration(pos);
    const grav = new body_grav_calc_t(tt2, pos, vel, acc);
    return new grav_sim_t(bary2, grav);
  }
  var pluto_cache = [];
  function ClampIndex(frac, nsteps) {
    const index = Math.floor(frac);
    if (index < 0)
      return 0;
    if (index >= nsteps)
      return nsteps - 1;
    return index;
  }
  function GravFromState(entry) {
    const state = BodyStateFromTable(entry);
    const bary = new major_bodies_t(state.tt);
    const r3 = state.r.add(bary.Sun.r);
    const v3 = state.v.add(bary.Sun.v);
    const a3 = bary.Acceleration(r3);
    const grav = new body_grav_calc_t(state.tt, r3, v3, a3);
    return new grav_sim_t(bary, grav);
  }
  function GetSegment(cache, tt) {
    const t0 = PlutoStateTable[0][0];
    if (tt < t0 || tt > PlutoStateTable[PLUTO_NUM_STATES - 1][0]) {
      return null;
    }
    const seg_index = ClampIndex((tt - t0) / PLUTO_TIME_STEP, PLUTO_NUM_STATES - 1);
    if (!cache[seg_index]) {
      const seg = cache[seg_index] = [];
      seg[0] = GravFromState(PlutoStateTable[seg_index]).grav;
      seg[PLUTO_NSTEPS - 1] = GravFromState(PlutoStateTable[seg_index + 1]).grav;
      let i3;
      let step_tt = seg[0].tt;
      for (i3 = 1; i3 < PLUTO_NSTEPS - 1; ++i3)
        seg[i3] = GravSim(step_tt += PLUTO_DT, seg[i3 - 1]).grav;
      step_tt = seg[PLUTO_NSTEPS - 1].tt;
      var reverse = [];
      reverse[PLUTO_NSTEPS - 1] = seg[PLUTO_NSTEPS - 1];
      for (i3 = PLUTO_NSTEPS - 2; i3 > 0; --i3)
        reverse[i3] = GravSim(step_tt -= PLUTO_DT, reverse[i3 + 1]).grav;
      for (i3 = PLUTO_NSTEPS - 2; i3 > 0; --i3) {
        const ramp = i3 / (PLUTO_NSTEPS - 1);
        seg[i3].r = seg[i3].r.mul(1 - ramp).add(reverse[i3].r.mul(ramp));
        seg[i3].v = seg[i3].v.mul(1 - ramp).add(reverse[i3].v.mul(ramp));
        seg[i3].a = seg[i3].a.mul(1 - ramp).add(reverse[i3].a.mul(ramp));
      }
    }
    return cache[seg_index];
  }
  function CalcPlutoOneWay(entry, target_tt, dt) {
    let sim = GravFromState(entry);
    const n2 = Math.ceil((target_tt - sim.grav.tt) / dt);
    for (let i3 = 0; i3 < n2; ++i3)
      sim = GravSim(i3 + 1 === n2 ? target_tt : sim.grav.tt + dt, sim.grav);
    return sim;
  }
  function CalcPluto(time, helio) {
    let r3, v3, bary;
    const seg = GetSegment(pluto_cache, time.tt);
    if (!seg) {
      let sim;
      if (time.tt < PlutoStateTable[0][0])
        sim = CalcPlutoOneWay(PlutoStateTable[0], time.tt, -PLUTO_DT);
      else
        sim = CalcPlutoOneWay(PlutoStateTable[PLUTO_NUM_STATES - 1], time.tt, +PLUTO_DT);
      r3 = sim.grav.r;
      v3 = sim.grav.v;
      bary = sim.bary;
    } else {
      const left = ClampIndex((time.tt - seg[0].tt) / PLUTO_DT, PLUTO_NSTEPS - 1);
      const s1 = seg[left];
      const s22 = seg[left + 1];
      const acc = s1.a.mean(s22.a);
      const ra = UpdatePosition(time.tt - s1.tt, s1.r, s1.v, acc);
      const va = UpdateVelocity(time.tt - s1.tt, s1.v, acc);
      const rb = UpdatePosition(time.tt - s22.tt, s22.r, s22.v, acc);
      const vb = UpdateVelocity(time.tt - s22.tt, s22.v, acc);
      const ramp = (time.tt - s1.tt) / PLUTO_DT;
      r3 = ra.mul(1 - ramp).add(rb.mul(ramp));
      v3 = va.mul(1 - ramp).add(vb.mul(ramp));
    }
    if (helio) {
      if (!bary)
        bary = new major_bodies_t(time.tt);
      r3 = r3.sub(bary.Sun.r);
      v3 = v3.sub(bary.Sun.v);
    }
    return new StateVector(r3.x, r3.y, r3.z, v3.x, v3.y, v3.z, time);
  }
  var Rotation_JUP_EQJ = new RotationMatrix([
    [0.999432765338654, -0.0336771074697641, 0],
    [0.0303959428906285, 0.902057912352809, 0.430543388542295],
    [-0.0144994559663353, -0.430299169409101, 0.902569881273754]
  ]);
  function HelioVector(body, date) {
    var time = MakeTime(date);
    if (body in vsop)
      return CalcVsop(vsop[body], time);
    if (body === Body.Pluto) {
      const p3 = CalcPluto(time, true);
      return new Vector(p3.x, p3.y, p3.z, time);
    }
    if (body === Body.Sun)
      return new Vector(0, 0, 0, time);
    if (body === Body.Moon) {
      var e3 = CalcVsop(vsop.Earth, time);
      var m3 = GeoMoon(time);
      return new Vector(e3.x + m3.x, e3.y + m3.y, e3.z + m3.z, time);
    }
    if (body === Body.EMB) {
      const e4 = CalcVsop(vsop.Earth, time);
      const m4 = GeoMoon(time);
      const denom = 1 + EARTH_MOON_MASS_RATIO;
      return new Vector(e4.x + m4.x / denom, e4.y + m4.y / denom, e4.z + m4.z / denom, time);
    }
    if (body === Body.SSB)
      return CalcSolarSystemBarycenter(time);
    const star = UserDefinedStar(body);
    if (star) {
      const sphere = new Spherical(star.dec, 15 * star.ra, star.dist);
      return VectorFromSphere(sphere, time);
    }
    throw `HelioVector: Unknown body "${body}"`;
  }
  function CorrectLightTravel(func, time) {
    let ltime = time;
    let dt = 0;
    for (let iter = 0; iter < 10; ++iter) {
      const pos = func(ltime);
      const lt = pos.Length() / C_AUDAY;
      if (lt > 1)
        throw `Object is too distant for light-travel solver.`;
      const ltime2 = time.AddDays(-lt);
      dt = Math.abs(ltime2.tt - ltime.tt);
      if (dt < 1e-9)
        return pos;
      ltime = ltime2;
    }
    throw `Light-travel time solver did not converge: dt = ${dt}`;
  }
  var BodyPosition = class {
    constructor(observerBody, targetBody, aberration, observerPos) {
      this.observerBody = observerBody;
      this.targetBody = targetBody;
      this.aberration = aberration;
      this.observerPos = observerPos;
    }
    Position(time) {
      if (this.aberration) {
        this.observerPos = HelioVector(this.observerBody, time);
      } else {
      }
      const targetPos = HelioVector(this.targetBody, time);
      return new Vector(targetPos.x - this.observerPos.x, targetPos.y - this.observerPos.y, targetPos.z - this.observerPos.z, time);
    }
  };
  function BackdatePosition(date, observerBody, targetBody, aberration) {
    VerifyBoolean(aberration);
    const time = MakeTime(date);
    if (UserDefinedStar(targetBody)) {
      const tvec = HelioVector(targetBody, time);
      if (aberration) {
        const ostate = HelioState(observerBody, time);
        const rvec = new Vector(tvec.x - ostate.x, tvec.y - ostate.y, tvec.z - ostate.z, time);
        const s3 = C_AUDAY / rvec.Length();
        return new Vector(rvec.x + ostate.vx / s3, rvec.y + ostate.vy / s3, rvec.z + ostate.vz / s3, time);
      }
      const ovec = HelioVector(observerBody, time);
      return new Vector(tvec.x - ovec.x, tvec.y - ovec.y, tvec.z - ovec.z, time);
    }
    let observerPos;
    if (aberration) {
      observerPos = new Vector(0, 0, 0, time);
    } else {
      observerPos = HelioVector(observerBody, time);
    }
    const bpos = new BodyPosition(observerBody, targetBody, aberration, observerPos);
    return CorrectLightTravel((t4) => bpos.Position(t4), time);
  }
  function GeoVector(body, date, aberration) {
    VerifyBoolean(aberration);
    const time = MakeTime(date);
    switch (body) {
      case Body.Earth:
        return new Vector(0, 0, 0, time);
      case Body.Moon:
        return GeoMoon(time);
      default:
        const vec = BackdatePosition(time, Body.Earth, body, aberration);
        vec.t = time;
        return vec;
    }
  }
  function ExportState(terse, time) {
    return new StateVector(terse.r.x, terse.r.y, terse.r.z, terse.v.x, terse.v.y, terse.v.z, time);
  }
  function HelioState(body, date) {
    const time = MakeTime(date);
    switch (body) {
      case Body.Sun:
        return new StateVector(0, 0, 0, 0, 0, 0, time);
      case Body.SSB:
        const bary = new major_bodies_t(time.tt);
        return new StateVector(-bary.Sun.r.x, -bary.Sun.r.y, -bary.Sun.r.z, -bary.Sun.v.x, -bary.Sun.v.y, -bary.Sun.v.z, time);
      case Body.Mercury:
      case Body.Venus:
      case Body.Earth:
      case Body.Mars:
      case Body.Jupiter:
      case Body.Saturn:
      case Body.Uranus:
      case Body.Neptune:
        const planet = CalcVsopPosVel(vsop[body], time.tt);
        return ExportState(planet, time);
      case Body.Pluto:
        return CalcPluto(time, true);
      case Body.Moon:
      case Body.EMB:
        const earth = CalcVsopPosVel(vsop.Earth, time.tt);
        const state = body == Body.Moon ? GeoMoonState(time) : GeoEmbState(time);
        return new StateVector(state.x + earth.r.x, state.y + earth.r.y, state.z + earth.r.z, state.vx + earth.v.x, state.vy + earth.v.y, state.vz + earth.v.z, time);
      default:
        if (UserDefinedStar(body)) {
          const vec = HelioVector(body, time);
          return new StateVector(vec.x, vec.y, vec.z, 0, 0, 0, time);
        }
        throw `HelioState: Unsupported body "${body}"`;
    }
  }
  var ApsisKind;
  (function(ApsisKind2) {
    ApsisKind2[ApsisKind2["Pericenter"] = 0] = "Pericenter";
    ApsisKind2[ApsisKind2["Apocenter"] = 1] = "Apocenter";
  })(ApsisKind || (ApsisKind = {}));
  function CombineRotation(a3, b2) {
    return new RotationMatrix([
      [
        b2.rot[0][0] * a3.rot[0][0] + b2.rot[1][0] * a3.rot[0][1] + b2.rot[2][0] * a3.rot[0][2],
        b2.rot[0][1] * a3.rot[0][0] + b2.rot[1][1] * a3.rot[0][1] + b2.rot[2][1] * a3.rot[0][2],
        b2.rot[0][2] * a3.rot[0][0] + b2.rot[1][2] * a3.rot[0][1] + b2.rot[2][2] * a3.rot[0][2]
      ],
      [
        b2.rot[0][0] * a3.rot[1][0] + b2.rot[1][0] * a3.rot[1][1] + b2.rot[2][0] * a3.rot[1][2],
        b2.rot[0][1] * a3.rot[1][0] + b2.rot[1][1] * a3.rot[1][1] + b2.rot[2][1] * a3.rot[1][2],
        b2.rot[0][2] * a3.rot[1][0] + b2.rot[1][2] * a3.rot[1][1] + b2.rot[2][2] * a3.rot[1][2]
      ],
      [
        b2.rot[0][0] * a3.rot[2][0] + b2.rot[1][0] * a3.rot[2][1] + b2.rot[2][0] * a3.rot[2][2],
        b2.rot[0][1] * a3.rot[2][0] + b2.rot[1][1] * a3.rot[2][1] + b2.rot[2][1] * a3.rot[2][2],
        b2.rot[0][2] * a3.rot[2][0] + b2.rot[1][2] * a3.rot[2][1] + b2.rot[2][2] * a3.rot[2][2]
      ]
    ]);
  }
  function VectorFromSphere(sphere, time) {
    time = MakeTime(time);
    const radlat = sphere.lat * DEG2RAD;
    const radlon = sphere.lon * DEG2RAD;
    const rcoslat = sphere.dist * Math.cos(radlat);
    return new Vector(rcoslat * Math.cos(radlon), rcoslat * Math.sin(radlon), sphere.dist * Math.sin(radlat), time);
  }
  function RotateVector(rotation, vector) {
    return new Vector(rotation.rot[0][0] * vector.x + rotation.rot[1][0] * vector.y + rotation.rot[2][0] * vector.z, rotation.rot[0][1] * vector.x + rotation.rot[1][1] * vector.y + rotation.rot[2][1] * vector.z, rotation.rot[0][2] * vector.x + rotation.rot[1][2] * vector.y + rotation.rot[2][2] * vector.z, vector.t);
  }
  function Rotation_EQJ_EQD(time) {
    time = MakeTime(time);
    const prec = precession_rot(time, PrecessDirection.From2000);
    const nut = nutation_rot(time, PrecessDirection.From2000);
    return CombineRotation(prec, nut);
  }
  function Rotation_EQJ_ECT(time) {
    const t4 = MakeTime(time);
    const rot = Rotation_EQJ_EQD(t4);
    const step = Rotation_EQD_ECT(t4);
    return CombineRotation(rot, step);
  }
  function Rotation_EQD_ECT(time) {
    const et = e_tilt(MakeTime(time));
    const tobl = et.tobl * DEG2RAD;
    const c3 = Math.cos(tobl);
    const s3 = Math.sin(tobl);
    return new RotationMatrix([
      [1, 0, 0],
      [0, +c3, -s3],
      [0, +s3, +c3]
    ]);
  }
  var EclipseKind;
  (function(EclipseKind2) {
    EclipseKind2["Penumbral"] = "penumbral";
    EclipseKind2["Partial"] = "partial";
    EclipseKind2["Annular"] = "annular";
    EclipseKind2["Total"] = "total";
  })(EclipseKind || (EclipseKind = {}));
  var NodeEventKind;
  (function(NodeEventKind2) {
    NodeEventKind2[NodeEventKind2["Invalid"] = 0] = "Invalid";
    NodeEventKind2[NodeEventKind2["Ascending"] = 1] = "Ascending";
    NodeEventKind2[NodeEventKind2["Descending"] = -1] = "Descending";
  })(NodeEventKind || (NodeEventKind = {}));

  // ../../../Users/chiburashka/.codex/worktrees/4806/site/node_modules/@zodiacs/engine/dist/chunk-GBH7JIYF.js
  var RAD2 = 180 / Math.PI;
  var PLANETS = [
    { name: "Sun", body: Body.Sun },
    { name: "Mercury", body: Body.Mercury },
    { name: "Venus", body: Body.Venus },
    { name: "Mars", body: Body.Mars },
    { name: "Jupiter", body: Body.Jupiter },
    { name: "Saturn", body: Body.Saturn },
    { name: "Uranus", body: Body.Uranus },
    { name: "Neptune", body: Body.Neptune },
    { name: "Pluto", body: Body.Pluto }
  ];
  function eclipticOfDate(body, date) {
    const time = MakeTime(date);
    const equatorial = GeoVector(body, time, true);
    const ecliptic = RotateVector(Rotation_EQJ_ECT(time), equatorial);
    const lon = normalizeLongitude(Math.atan2(ecliptic.y, ecliptic.x) * RAD2);
    const lat = Math.asin(ecliptic.z / Math.hypot(ecliptic.x, ecliptic.y, ecliptic.z)) * RAD2;
    return { lon, lat };
  }
  function moonOfDate(date) {
    const moon = EclipticGeoMoon(MakeTime(date));
    return { lon: normalizeLongitude(moon.lon), lat: moon.lat };
  }
  function trueNodeLongitude(date) {
    const time = MakeTime(date);
    const state = GeoMoonState(time);
    const angularMomentum = {
      x: state.y * state.vz - state.z * state.vy,
      y: state.z * state.vx - state.x * state.vz,
      z: state.x * state.vy - state.y * state.vx
    };
    const eclipticMomentum = RotateVector(
      Rotation_EQJ_ECT(time),
      new Vector(angularMomentum.x, angularMomentum.y, angularMomentum.z, time)
    );
    return normalizeLongitude(Math.atan2(eclipticMomentum.x, -eclipticMomentum.y) * RAD2);
  }
  function longitudeAt(body, date) {
    if (body === "Moon") return moonOfDate(date).lon;
    if (body === "North Node") return trueNodeLongitude(date);
    if (body === "South Node") {
      return normalizeLongitude(trueNodeLongitude(date) + 180);
    }
    const planet = PLANETS.find((candidate) => candidate.name === body);
    if (!planet) throw new RangeError(`Unknown body: ${body}`);
    return eclipticOfDate(planet.body, date).lon;
  }
  function bodyLongitude(body, date) {
    return longitudeAt(body, date);
  }
  function longitudeSpeed(body, date) {
    const stepDays = 0.25;
    const before = longitudeAt(body, new Date(date.getTime() - stepDays * 864e5));
    const after = longitudeAt(body, new Date(date.getTime() + stepDays * 864e5));
    let difference = after - before;
    if (difference > 180) difference -= 360;
    if (difference < -180) difference += 360;
    return difference / (2 * stepDays);
  }
  function position(body, lon, lat, speed) {
    return {
      body,
      lon,
      lat,
      speed,
      retrograde: speed < 0,
      sign: signForLongitude2(lon).slug,
      degree: degreeInSign2(lon)
    };
  }
  function computeBodies(date) {
    const bodies = [];
    for (const planet of PLANETS) {
      const coordinates = eclipticOfDate(planet.body, date);
      bodies.push(
        position(planet.name, coordinates.lon, coordinates.lat, longitudeSpeed(planet.name, date))
      );
    }
    const moon = moonOfDate(date);
    bodies.splice(1, 0, position("Moon", moon.lon, moon.lat, longitudeSpeed("Moon", date)));
    const northNode = trueNodeLongitude(date);
    const nodeSpeed = longitudeSpeed("North Node", date);
    bodies.push(
      position("North Node", northNode, 0, nodeSpeed),
      position("South Node", normalizeLongitude(northNode + 180), 0, nodeSpeed)
    );
    return bodies;
  }
  function centuriesSinceJ2000(date) {
    return (date.getTime() - Date.UTC(2e3, 0, 1, 12)) / (864e5 * 36525);
  }
  function computeChart(input) {
    const flags = [...input.flags ?? []];
    const bodies = computeBodies(input.utc);
    let angles = null;
    let houses = null;
    if (input.timeKnown && input.latitude !== void 0 && input.longitude !== void 0) {
      const angleInput = {
        gastHours: SiderealTime(MakeTime(input.utc)),
        latitude: input.latitude,
        longitude: input.longitude,
        obliquity: meanObliquity(centuriesSinceJ2000(input.utc))
      };
      angles = computeAngles(angleInput);
      const result = computeHouses(input.houseSystem, angleInput, angles);
      houses = result.houses;
      if (result.fellBack) flags.push("polar-fallback");
    } else if (!input.timeKnown) {
      flags.push("no-time");
    }
    return {
      input,
      bodies,
      angles,
      houses,
      aspects: findAspects(bodies),
      flags,
      engineVersion: ENGINE_VERSION
    };
  }

  // src/lib/engine/chart-adapter.ts
  init_define_import_meta_env();
  var adaptBody = (position2) => ({
    body: position2.body,
    lon: position2.lon,
    lat: position2.lat,
    speed: position2.speed,
    retrograde: position2.retrograde
  });
  function adaptChart(chart, input) {
    return {
      input,
      bodies: chart.bodies.map(adaptBody),
      angles: chart.angles,
      houses: chart.houses,
      aspects: chart.aspects,
      flags: [...chart.flags],
      engineVersion: chart.engineVersion
    };
  }

  // src/lib/engine/full.ts
  function bodyLongitude2(name, date) {
    return bodyLongitude(name, date);
  }
  function longitudeSpeed2(name, date) {
    return longitudeSpeed(name, date);
  }
  function computeBodies2(date) {
    return computeBodies(date).map(adaptBody);
  }
  function computeChart2(input) {
    return adaptChart(computeChart(input), input);
  }

  // <stdin>
  var catalogs = { en: en_default, es: es_default, fr: fr_default, it: it_default, pt: pt_default, ru: ru_default };
  var pending = [];
  var calls = [];
  var current = null;
  var failCalculation = false;
  var engine = { ...full_exports, bodyLongitude(body, utc) {
    calls.push({ body, utc: new Date(utc).toISOString() });
    if (failCalculation) throw new Error("Synthetic calculation failure");
    return bodyLongitude2(body, utc);
  } };
  window.fixtureLoadEngine = () => current ? current.promise : Promise.resolve(engine);
  window.fixture = {
    calls,
    pending,
    hold() {
      let yes, no;
      const promise = new Promise((resolve, reject) => {
        yes = resolve;
        no = reject;
      });
      current = { promise, yes, no };
      pending.push(current);
      return pending.length - 1;
    },
    release(id) {
      pending[id].yes(engine);
    },
    reject(id) {
      pending[id].no(new Error("Synthetic loader failure"));
    },
    immediate() {
      current = null;
    },
    failCalculation(value) {
      failCalculation = value;
    },
    mount(locale = "en") {
      window.__ZDX_UI__ = { locale, messages: catalogs[locale] };
      window.__ZDX_RU__ = { locale: "ru", data: RUSSIAN_RUNTIME };
      R(k(MoonPhaseTool, { locale }), document.getElementById("mount"));
    },
    unmount() {
      R(null, document.getElementById("mount"));
    }
  };
  window.fixture.mount(new URL(location.href).searchParams.get("locale") ?? "en");
})();
/*! Bundled license information:

astronomy-engine/esm/astronomy.js:
  (**
      @preserve
  
      Astronomy library for JavaScript (browser and Node.js).
      https://github.com/cosinekitty/astronomy
  
      MIT License
  
      Copyright (c) 2019-2023 Don Cross <cosinekitty@gmail.com>
  
      Permission is hereby granted, free of charge, to any person obtaining a copy
      of this software and associated documentation files (the "Software"), to deal
      in the Software without restriction, including without limitation the rights
      to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
      copies of the Software, and to permit persons to whom the Software is
      furnished to do so, subject to the following conditions:
  
      The above copyright notice and this permission notice shall be included in all
      copies or substantial portions of the Software.
  
      THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
      IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
      FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
      AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
      LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
      OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
      SOFTWARE.
  *)
  (**
   * @fileoverview Astronomy calculation library for browser scripting and Node.js.
   * @author Don Cross <cosinekitty@gmail.com>
   * @license MIT
   *)
*/
