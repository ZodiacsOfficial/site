import gzip, hashlib, io, json, pathlib, shutil, subprocess, tarfile

out = pathlib.Path('/private/tmp/zodiacs-platform-local-date-reference-evidence')
root = pathlib.Path('/private/tmp/zodiacs-platform-local-date-reference')
prep = pathlib.Path('/private/tmp/zodiacs-platform-skipped-date-preparation')
def sha(data): return hashlib.sha256(data).hexdigest()
freeze = json.loads((out / 'source-freeze.json').read_text())
for row in freeze['files']:
    assert sha((root / row['path']).read_bytes()) == row['sha256']
    assert sha((out / 'frozen-source' / row['path']).read_bytes()) == row['sha256']
support = out / 'preparation-support'
support.mkdir(exist_ok=True)
for name, path in [
    ('main-REVIEW.md.log', prep / 'main/REVIEW.md'),
    ('linked-evidence-verification.json.log', prep / 'main/linked-evidence-verification.json'),
    ('counterexample-REVIEW.md.log', prep / 'independent-counterexamples/delivery/REVIEW.md'),
    ('counterexample-manifest.json.log', prep / 'independent-counterexamples/delivery/manifest.json'),
    ('synthetic-README.md.log', prep / 'independent-counterexamples/synthetic-addendum/README.md'),
    ('synthetic-manifest.json.log', prep / 'independent-counterexamples/synthetic-addendum/manifest.json'),
]:
    shutil.copyfile(path, support / name)
shutil.copyfile(root / 'tests/moon-result-ownership-drive.mjs', out / 'retained-moon-driver.mjs.log')
environment = {}
for name, executable in [
    ('node22', '/private/tmp/zodiacs-platform-runtime/node_modules/node/bin/node'),
    ('node24', '/Users/chiburashka/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/bin/node'),
]:
    environment[name] = json.loads(subprocess.check_output([executable, '-e', 'process.stdout.write(JSON.stringify({version:process.version,versions:process.versions,arch:process.arch,platform:process.platform}))']))
environment['dependencies'] = []
for name in ['@zodiacs/engine', 'astronomy-engine', 'preact', 'esbuild', 'playwright-core', 'typescript', 'vitest', 'astro']:
    path = root / 'node_modules' / name / 'package.json'
    data = path.read_bytes()
    environment['dependencies'].append({'name': name, 'version': json.loads(data)['version'], 'packageSha256': sha(data)})
(out / 'environment.json').write_text(json.dumps(environment, indent=2) + '\n')
native = json.loads((out / 'native-complete/result.json').read_text())
from urllib.parse import urlparse
summary = {'groupsPassed': native['passed'], 'requestCount': len(native['requests']),
           'methods': sorted(set(row['method'] for row in native['requests'])),
           'origins': sorted(set(urlparse(row['url']).netloc for row in native['requests'])),
           'sourceStable': native['identity'] == native['finalIdentity'], 'cleanup': native['cleanup']}
(out / 'native-summary.json').write_text(json.dumps(summary, indent=2) + '\n')
delivery = out / 'delivery'
delivery.mkdir(exist_ok=True)
copies = {'AUTHOR.md': 'AUTHOR.md.log', 'implementation.patch': 'implementation.patch.log',
          'source-freeze.json': 'source-freeze.json.log', 'scope-proof.json': 'scope-proof.json.log',
          'commands.md': 'commands.md.log'}
for source, target in copies.items(): shutil.copyfile(out / source, delivery / target)
files = sorted(path for path in out.rglob('*') if path.is_file() and delivery not in path.parents)
members = []
archive = delivery / 'raw-evidence.tar.gz'
with archive.open('wb') as target:
    with gzip.GzipFile(filename='', fileobj=target, mode='wb', mtime=0) as compressed:
        with tarfile.open(fileobj=compressed, mode='w') as tar:
            for path in files:
                data = path.read_bytes()
                relative = path.relative_to(out).as_posix()
                members.append({'path': relative, 'bytes': len(data), 'sha256': sha(data)})
                info = tarfile.TarInfo(relative)
                info.size = len(data); info.mode = 0o644; info.mtime = 0
                tar.addfile(info, io.BytesIO(data))
with tarfile.open(archive, 'r:gz') as tar:
    for row in members:
        data = tar.extractfile(row['path']).read()
        assert len(data) == row['bytes'] and sha(data) == row['sha256']
(delivery / 'raw-members.json.log').write_text(json.dumps({'members': members, 'totalBytes': sum(row['bytes'] for row in members)}, indent=2) + '\n')
records = []
for path in sorted(delivery.iterdir()):
    if path.name == 'manifest.json': continue
    data = path.read_bytes()
    records.append({'path': path.name, 'bytes': len(data), 'sha256': sha(data)})
manifest = {'description': 'C-014 bounded unknown-time local-date membership author delivery, Freeze 1; independent review and root integration pending.',
            'sourceBase': freeze['base'], 'records': records, 'totalBytes': sum(row['bytes'] for row in records),
            'archiveMemberCount': len(members), 'archiveUncompressedBytes': sum(row['bytes'] for row in members)}
(delivery / 'manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
print(json.dumps({'manifestSha256': sha((delivery / 'manifest.json').read_bytes()), 'records': len(records), 'bytes': manifest['totalBytes'], 'rawMembers': len(members), 'rawBytes': manifest['archiveUncompressedBytes']}))
