import hashlib, json, pathlib, subprocess

root = pathlib.Path('/private/tmp/zodiacs-platform-local-date-reference')
out = pathlib.Path('/private/tmp/zodiacs-platform-local-date-reference-evidence')
base = 'c7b9eb4a769e39a46aebc0a5ecedcb9fc40949e3'
def sha(data): return hashlib.sha256(data).hexdigest()
def git(*args): return subprocess.check_output(['git', '-C', str(root), *args])
assert git('rev-parse', 'HEAD').decode().strip() == base
paths = git('diff', '--name-only').decode().splitlines()
assert len(paths) == 12
rows = []
for path in paths:
    data = (root / path).read_bytes()
    target = out / 'frozen-source' / path
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(data)
    rows.append({'path': path, 'bytes': len(data), 'sha256': sha(data)})
patch = git('diff', '--binary', '--no-ext-diff')
assert patch == (out / 'implementation.patch').read_bytes()
native = json.loads((out / 'native-complete/result.json').read_text())
assert native['passed'] == 35 and native['failed'] == 0
assert native['identity'] == native['finalIdentity']
for row in native['identity']:
    assert sha((root / row['path']).read_bytes()) == row['sha256']
assert sha((root / 'tests/local-date-reference-drive.mjs').read_bytes()) == native['driverSha256']
assert (out / 'types-final.log').read_bytes() == b''
for version in ['22', '24']:
    assert '234 passed (234)' in (out / f'focused-final-node{version}.log').read_text()
moon = json.loads((out / 'moon-ownership/result.json').read_text())
assert len(moon['groups']) == 20 and all(row['passed'] for row in moon['groups'])
for row in moon['inputs']:
    assert sha((root / row['path']).read_bytes()) == row['sha256']
freeze = {'freeze': 1, 'base': base, 'sourceRoot': str(root), 'files': rows,
          'patch': {'path': 'implementation.patch', 'bytes': len(patch), 'sha256': sha(patch)},
          'validation': {'node22FocusedPassed': 234, 'node24FocusedPassed': 234,
                         'strictProjectTypes': 'passed after Astro sync', 'nativeCallerGroupsPassed': 35,
                         'retainedMoonOwnershipGroupsPassed': 20},
          'state': 'Author implemented and tested. Awaiting independent review and root integration; no publication or deployment.'}
(out / 'source-freeze.json').write_text(json.dumps(freeze, indent=2) + '\n')
proof = []
for path in ['src/lib/time/localToUtc.ts', 'src/islands/ChartCalculator.tsx', 'src/islands/MoonPhaseTool.tsx']:
    before = git('show', f'{base}:{path}').decode()
    after = (root / path).read_text()
    if path.endswith('/localToUtc.ts'):
        start = after.index('/**\n * Whether this instant belongs')
        end = after.index('/**\n * Resolve a wall-clock', start)
        stripped = after[:start] + after[end:]
    else:
        stripped = after.replace('import { localDateContainsUtc, resolveLocalToUtc }', 'import { resolveLocalToUtc }')
        stripped = stripped.replace("    const localDateReferenceFailure = new Error('Could not establish a calculation time within the local date.');\n", '')
        start = stripped.index('      if (!input.timeKnown) {\n        try {') if path.endswith('ChartCalculator.tsx') else stripped.index('        if (!hasTime) {\n          try {')
        end = stripped.index('      const calculationInput', start) if path.endswith('ChartCalculator.tsx') else stripped.index('        dayStart =', start)
        stripped = stripped[:start] + stripped[end:]
        key = 'chartError' if path.endswith('ChartCalculator.tsx') else 'moonError'
        stripped = stripped.replace("setError(err === localDateReferenceFailure ? t(locale, 'localDateReferenceError')\n        : calculationError(err, locale, t(locale, '" + key + "')));", "setError(calculationError(err, locale, t(locale, '" + key + "')));")
    assert stripped == before, path
    proof.append({'path': path, 'baseSha256': sha(before.encode()), 'candidateSha256': sha(after.encode()),
                  'unchangedApartFromExplicitMembershipBoundary': True})
for locale in ['en', 'es', 'fr', 'it', 'pt', 'ru']:
    path = f'src/lib/i18n/ui/{locale}.ts'
    before = git('show', f'{base}:{path}').decode()
    after = (root / path).read_text()
    lines = after.splitlines(keepends=True)
    added = [line for line in lines if line.lstrip().startswith('localDateReferenceError:')]
    assert len(added) == 1
    assert ''.join(line for line in lines if line not in added) == before
    proof.append({'path': path, 'onlyChange': added[0].strip()})
(out / 'scope-proof.json').write_text(json.dumps({'base': base, 'proof': proof}, indent=2) + '\n')
print(json.dumps({'files': len(rows), 'patchSha256': sha(patch), 'freezeSha256': sha((out / 'source-freeze.json').read_bytes())}))
