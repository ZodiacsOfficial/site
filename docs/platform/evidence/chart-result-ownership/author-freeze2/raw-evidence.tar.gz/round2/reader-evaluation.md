# Reader reentrancy evaluation

The independent frozen profile/save review exercised the actual Base provider in native Chrome: missing lease, mismatched owner and revoked lease fail, while matching owner succeeds. It separately reproduces a synthetic canRead callback that revokes synchronously but returns true after old currentness equality was already evaluated. This is a conditional arbitrary-callback counterexample, not an observed ordinary application account-switch bypass.

Author source inspection confirms the actual Base provider is a frozen object reading its lease, native sessionStorage/localStorage and parsed grant/owner values synchronously; it does not call dispatchEvent or an application callback. The actual profileAccessAllowed adapter catches thrown reader errors and admits only exact true when enabled. The actual hook increments its generation before the denial scrub. The three exact source files are preserved under reader-sources/.

No broad currentness/authentication rewrite was made for the synthetic reader. This ownership correction applies captured generation checks at the demonstrated async positions/save boundaries. The positions helper checks access before comparing its captured access generation, and preserves unmarked public mine inputs. No auth authority is inferred from fragment provenance.

Independent evidence attribution: /private/tmp/zodiacs-platform-chart-ownership-independent-review/frozen-profile-save/delivery-freeze1/REVIEW-FREEZE1.md and native-run2/result.json. These are separate reviewer controls, not claimed as newly executed author tests.
