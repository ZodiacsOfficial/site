/** C016 exact hosted preview acceptance, adapted from the accepted normal-page driver. */
import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
import {createServer} from 'node:http';
import {readFile,writeFile,mkdir,stat} from 'node:fs/promises';
import {resolve,extname,sep} from 'node:path';
import {pathToFileURL} from 'node:url';
import {createRequire} from 'node:module';
import {execFileSync} from 'node:child_process';
const root=resolve(process.env.SOURCE_ROOT??'/Users/chiburashka/.codex/worktrees/4806/site');
const dist=resolve(root,'dist'),out=process.env.OUT_DIR&&resolve(process.env.OUT_DIR);
if(!out||!process.env.C016_SOURCE_MANIFEST)throw new Error('New OUT_DIR and frozen C016_SOURCE_MANIFEST required');
await mkdir(out,{recursive:false});
const require=createRequire(resolve(root,'package.json'));
const {chromium}=require('playwright-core'),{build}=require('esbuild');
const {findChromium,STABLE_CHROMIUM_ARGS,isSiteFooterIconTeardownAbort}=await import(pathToFileURL(resolve(root,'tests/visual/browser.mjs')));
const sha=b=>createHash('sha256').update(b).digest('hex');
const freezeBytes=await readFile(process.env.C016_SOURCE_MANIFEST),freeze=JSON.parse(freezeBytes);
const identities=async()=>Promise.all(freeze.records.map(async r=>{const b=await readFile(resolve(root,r.path));return {path:r.path,bytes:b.length,sha256:sha(b)};}));
const before=await identities();assert.deepEqual(before,freeze.records);
const compiled=await build({entryPoints:[resolve(root,'src/lib/i18n/ui/server.ts')],bundle:true,platform:'node',format:'esm',write:false,logLevel:'silent'});
await writeFile(resolve(out,'expected-ui.mjs'),compiled.outputFiles[0].contents);
const {UI}=await import(pathToFileURL(resolve(out,'expected-ui.mjs')));
const locales=['en','es','fr','it','pt','ru'];
const cityIndex=JSON.parse(await readFile(resolve(dist,'data/cities/index.json')));
const khartoumRows=JSON.parse(await readFile(resolve(dist,'data/cities/k.json'))).filter(r=>r[0]==='Khartoum'&&cityIndex.tz[r[6]]==='Africa/Khartoum');assert.equal(khartoumRows.length,1);
const city=khartoumRows[0],chip=[city[0],[cityIndex.admin1[city[2]],cityIndex.countries[city[3]]].filter(Boolean).join(', ')].join(' · ');
const served=new Map(),serverRequests=[],results=[],contexts=new Set(),pending=[];let cookies=[];
const provider=JSON.parse(await readFile('/private/tmp/zodiacs-r1-r2-preview/deployment-before.json'));
assert.equal(provider.id,'dpl_4zpQGsJvWzaM9kqsA7e8StU3vUnV');assert.equal(provider.state,'READY');assert.equal(provider.target,null);
assert.equal(provider.meta.githubCommitSha,'35301d24907b6eb7117a1f4b0ae690ca42c57de6');assert.equal(provider.meta.githubPrId,'469');
let browser;const origin='https://zodiacs-dafnwih1r-zodiacsofficial.vercel.app';assert.equal('https://'+provider.url,origin);
await mkdir(resolve(out,'served'));
const report={time:new Date().toISOString(),root,node:process.version,head:provider.meta.githubCommitSha,provider,freezeSha256:sha(freezeBytes),sourceBefore:before,city:{name:city[0],zone:cityIndex.tz[city[6]],chip},results,outcome:'failed',qualification:'Actual unmodified normal-build pages with actual offline city data. Expected copy is compiled for assertions only. No source/clock/engine/network-response substitution. Actual remote preview. No numerical-call count, oracle, backend/account or exhaustive browser/a11y claim. Preview-access bootstrap is isolated and unobserved. Anonymous flow blocks external/non-GET/API requests.'};
async function settle(page){await page.evaluate(()=>new Promise(done=>requestAnimationFrame(()=>requestAnimationFrame(done))));}
async function snapshot(page){return page.evaluate(()=>({result:!!document.querySelector('.calc__result'),text:document.querySelector('.calc__result')?.textContent??null,notices:[...document.querySelectorAll('.calc__result > .notice')].map(x=>({text:x.textContent,visible:x.getClientRects().length>0,insideDetails:!!x.closest('details')})),phase:document.querySelector('.calc__phase')?.textContent??null,signline:document.querySelector('.mp__lookup .mp__signline')?.textContent??null,phaseTool:document.querySelector('.mp__lookup .mp__phase')?.textContent??null,illumination:document.querySelector('.mp__lookup .mp__meta')?.textContent??null,openDetails:document.querySelectorAll('.calc__result details[open]').length,focus:{tag:document.activeElement?.tagName,id:document.activeElement?.id,text:document.activeElement?.textContent},error:document.querySelector('.calc__form [role=alert]')?.textContent??null,profile:localStorage.getItem('zodiacs.profile.v1'),overflow:document.documentElement.scrollWidth>innerWidth+1}));}
async function clear(page){await settle(page);const s=await snapshot(page);assert.equal(s.result,false);assert.equal(s.error,null);assert.equal(s.profile,null);return s;}
async function compute(page){await page.locator('.calc__submit').click();await page.locator('.calc__result').waitFor({state:'visible'});await page.waitForFunction(()=>document.querySelector('.calc__form')?.getAttribute('aria-busy')==='false');await settle(page);const s=await snapshot(page);assert.equal(s.error,null);assert.equal(s.profile,null);assert.equal(s.overflow,false);return s;}
function caption(s,locale,key){assert.equal(s.notices.length,key?1:0);if(key){assert.equal(s.notices[0].text,UI[locale][key]);assert.equal(s.notices[0].visible,true);assert.equal(s.notices[0].insideDetails,false);}assert.equal(s.openDetails,0);}
async function capture(page,name){const p=resolve(out,name+'.png');await page.locator('.calc__result').scrollIntoViewIfNeeded();await settle(page);await page.screenshot({path:p,animations:'disabled'});const b=await readFile(p);return {path:name+'.png',bytes:b.length,sha256:sha(b)};}
async function select(page,id){await page.locator(id).fill('Khartoum');const option=page.getByRole('option').filter({has:page.locator('.place__name',{hasText:/^Khartoum$/})});await option.waitFor({state:'visible'});assert.equal(await option.count(),1);await option.click();assert.equal(await page.locator(id).inputValue(),chip);}
async function group(locale,mode,width){const name=`${locale}-${mode}-${width}`,ctx=await browser.newContext({viewport:{width,height:1000},reducedMotion:'reduce',timezoneId:'UTC',serviceWorkers:'block'});contexts.add(ctx);await ctx.addCookies(cookies);ctx.setDefaultTimeout(30000);const row={name,locale,mode,width,pageErrors:[],consoleErrors:[],requests:[],failures:[],captures:[],passed:false};let page;
try{await ctx.route('**/*',async route=>{const r=route.request(),u=new URL(r.url()),blocked=u.origin!==origin||r.method()!=='GET'||u.pathname.startsWith('/api/');row.requests.push({url:r.url(),method:r.method(),blocked});if(blocked)await route.abort('blockedbyclient');else await route.continue();});page=await ctx.newPage();page.on('pageerror',e=>row.pageErrors.push(String(e)));page.on('console',m=>{if(m.type()==='error')row.consoleErrors.push({text:m.text(),location:m.location()});});page.on('requestfailed',r=>row.failures.push({url:r.url(),error:r.failure()?.errorText,knownFooterTeardown:isSiteFooterIconTeardownAbort(r)}));
page.on('response',response=>{const u=new URL(response.url());if(u.origin!==origin)return;pending.push((async()=>{const record={group:name,path:u.pathname,status:response.status()};try{const data=await response.body();record.bytes=data.length;record.sha256=sha(data);if(response.status()===200&&(/\.(js|json)$/.test(u.pathname)||response.request().resourceType()==='document')){const key=u.pathname;if(served.has(key))assert.equal(served.get(key).sha256,record.sha256);else{const file=record.sha256+'.bin';await writeFile(resolve(out,'served',file),data);served.set(key,{path:key,bytes:data.length,sha256:record.sha256,file});}}}catch(e){record.bodyUnavailable=true;record.error=String(e);}serverRequests.push(record);})());});

const route=(locale==='en'?'':'/'+locale)+(mode==='tool'?'/moon-phase/':'/moon-sign/');assert.equal((await page.goto(origin+route,{waitUntil:'domcontentloaded'})).status(),200);assert.equal(await page.locator('footer.zfooter').count(),1);const date=page.locator(mode==='tool'?'#mp-date':'#birth-date'),time=page.locator(mode==='tool'?'#mp-time':'#birth-time');await date.focus();await page.locator(`astro-island[component-url*="${mode==='tool'?'MoonPhaseTool':'ChartCalculator'}"]:not([ssr])`).waitFor();await date.fill('2000-01-15');
if(mode==='tool'){
 await time.fill('');row.utcReference=await compute(page);caption(row.utcReference,locale,'referenceUtcCaption');row.captures.push(await capture(page,name+'-utc-reference'));
 await time.fill('06:17');row.utcEdit=await clear(page);row.utcKnown=await compute(page);caption(row.utcKnown,locale,'utcTimeCaption');
 await time.fill('');await clear(page);await select(page,'#mp-place');row.localReference=await compute(page);caption(row.localReference,locale,'referenceLocalCaption');row.captures.push(await capture(page,name+'-local-reference'));
 await time.fill('13:00');await clear(page);row.localKnown=await compute(page);caption(row.localKnown,locale,null);assert.equal(row.localKnown.phaseTool,row.localReference.phaseTool);assert.equal(row.localKnown.signline,row.localReference.signline);assert.equal(row.localKnown.illumination,row.localReference.illumination);
 await page.locator('#mp-place').locator('..').locator('.place__clear').click();row.cityEdit=await clear(page);row.returnToUtc=await compute(page);caption(row.returnToUtc,locale,'utcTimeCaption');
}else{
 await time.fill('13:00');await page.locator('.field__toggle input[type=checkbox]').check();await select(page,'#place');row.reference=await compute(page);assert.ok(row.reference.phase.startsWith(UI[locale].moonPhaseAtReference+': '));assert.ok(!row.reference.phase.startsWith(UI[locale].moonPhaseAtBirth+': '));row.captures.push(await capture(page,name+'-reference'));
 await page.locator('.field__toggle input[type=checkbox]').uncheck();await clear(page);row.known=await compute(page);assert.ok(row.known.phase.startsWith(UI[locale].moonPhaseAtBirth+': '));assert.equal(row.reference.phase.slice(UI[locale].moonPhaseAtReference.length),row.known.phase.slice(UI[locale].moonPhaseAtBirth.length));row.captures.push(await capture(page,name+'-known'));
}
assert.deepEqual(row.pageErrors,[]);assert.deepEqual(row.requests.filter(r=>r.method!=='GET'||new URL(r.url).pathname.startsWith('/api/')),[]);assert.deepEqual(row.failures.filter(f=>!f.knownFooterTeardown&&!row.requests.some(r=>r.blocked&&r.url===f.url)),[]);assert.deepEqual(row.consoleErrors.filter(e=>!e.text.includes('net::ERR_BLOCKED_BY_CLIENT')),[]);row.passed=true;
}catch(error){row.failure=String(error.stack??error);if(page){row.state=await snapshot(page).catch(()=>null);row.captures.push(await capture(page,name+'-failure').catch(e=>({error:String(e)})));}}finally{await ctx.close();contexts.delete(ctx);row.contextClosed=true;results.push(row);await writeFile(resolve(out,name+'.json'),JSON.stringify(row,null,2)+'\n');console.log(JSON.stringify({name,passed:row.passed}));}}
async function editionViews() {
 const ctx=await browser.newContext({viewport:{width:1280,height:900},reducedMotion:'reduce',timezoneId:'UTC',serviceWorkers:'block'});contexts.add(ctx);await ctx.addCookies(cookies);
 const requests=[],errors=[];
 await ctx.route('**/*',async route=>{const r=route.request(),u=new URL(r.url()),blocked=u.origin!==origin||r.method()!=='GET'||u.pathname.startsWith('/api/');requests.push({path:u.pathname,method:r.method(),blocked});if(blocked)await route.abort('blockedbyclient');else await route.continue();});
 try {
  const page=await ctx.newPage();page.on('pageerror',e=>errors.push(String(e)));
  const dataPaths=['/assets/data/registry-market-history.v1.json','/assets/registry-outlook.json','/assets/registry-research-feed.json','/assets/data/registry-research/index.json','/assets/data/registry-research/items/zrx-daily-market-brief-2026-09-12.json'];
  report.editionArtifacts=[];
  for(const path of dataPaths){const response=await page.goto(origin+path,{waitUntil:'load'});assert.equal(response.status(),200);const b=await response.body();assert.equal(sha(b),sha(await readFile(resolve(root,'public'+path))));await writeFile(resolve(out,'served',sha(b)+'.bin'),b);report.editionArtifacts.push({path,bytes:b.length,sha256:sha(b)});}
  report.editionViews=[];
  for(const width of [390,1280])for(const path of ['/today/','/horoscopes/aries/','/registry/aries/','/terminal/research/']){
   await page.setViewportSize({width,height:900});assert.equal((await page.goto(origin+path,{waitUntil:'networkidle'})).status(),200);
   await page.evaluate(async()=>{await document.fonts.ready;});
   const state=await page.evaluate(()=>({text:document.body.innerText,heading:document.querySelector('h1')?.textContent,overflow:document.documentElement.scrollWidth>innerWidth+1,overlay:!!document.querySelector('astro-error-overlay,.vite-error-overlay'),footer:document.querySelectorAll('footer.zfooter').length,profile:localStorage.getItem('zodiacs.profile.v1')}));
   assert.ok(state.text.length>100);assert.ok(state.heading);assert.equal(state.overflow,false);assert.equal(state.overlay,false);assert.equal(state.footer,1);assert.equal(state.profile,null);
   if(path==='/today/'||path==='/horoscopes/aries/')assert.ok(state.text.includes('September 12, 2026'));
   if(path==='/registry/aries/')assert.ok(state.text.includes('Sep 12, 2026'));
   const file='edition-'+path.replaceAll('/','-')+width+'.png';await page.screenshot({path:resolve(out,file),fullPage:true,animations:'disabled'});const b=await readFile(resolve(out,file));
   report.editionViews.push({path,width,state,screenshot:{file,bytes:b.length,sha256:sha(b)},passed:true});console.log(JSON.stringify({edition:path,width,passed:true}));
  }
  assert.deepEqual(errors,[]);assert.deepEqual(requests.filter(r=>r.method!=='GET'),[]);report.editionRequests=requests;report.editionErrors=errors;
 }finally{await ctx.close();contexts.delete(ctx);}
}
try{
 browser=await chromium.launch({executablePath:await findChromium(),headless:true,args:STABLE_CHROMIUM_ARGS});report.browser=browser.version();
 const bootstrap=await browser.newContext();try{const auth=JSON.parse(await readFile('/private/tmp/zodiacs-r1-r2-preview-private/access.json'));const page=await bootstrap.newPage();await page.goto(auth.url,{waitUntil:'networkidle',timeout:60000});cookies=await bootstrap.cookies();report.authBootstrap={completed:true,isolated:true,observed:false};}catch{throw Error('Protected preview bootstrap failed');}finally{await bootstrap.close();}
 await editionViews();
 for(const locale of locales)for(const mode of ['tool','moon-mode'])for(const width of (locale==='en'?[1280,390]:[390]))await group(locale,mode,width);
 await Promise.all(pending);report.sourceAfter=await identities();assert.deepEqual(report.sourceAfter,before);assert.equal(results.length,14);assert.ok(results.every(r=>r.passed));
 const actualIndex=served.get('/data/cities/index.json'),actualK=served.get('/data/cities/k.json');assert.ok(actualIndex&&actualK);
 assert.equal(actualIndex.sha256,sha(await readFile(resolve(dist,'data/cities/index.json'))));assert.equal(actualK.sha256,sha(await readFile(resolve(dist,'data/cities/k.json'))));
 assert.ok(serverRequests.every(r=>r.status===200));assert.ok(!serverRequests.some(r=>r.bodyUnavailable&&(/\.(js|json)$/.test(r.path))));
 report.outcome='passed';
}catch(error){report.failure=String(error.stack??error);process.exitCode=1;}finally{
 for(const ctx of contexts)await ctx.close().catch(()=>{});await browser?.close();await Promise.allSettled(pending);cookies=[];
 report.responses=serverRequests;report.served=[...served.values()];report.driverSha256=sha(await readFile(new URL(import.meta.url)));report.cleanup={contextsClosed:true,browserClosed:true,localServerStarted:false};
 await writeFile(resolve(out,'result.json'),JSON.stringify(report,null,2)+'\n');console.log(JSON.stringify({outcome:report.outcome,passed:results.filter(r=>r.passed).length,failed:results.filter(r=>!r.passed).length}));
}
