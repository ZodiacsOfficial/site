import {h,render}from'preact';
import{PostChartDailyBrief}from'./source/src/islands/PostChartDailyBrief';
import{clearPostChartContext,publishPostChartContext,currentPostChartContext}from'./source/src/lib/profile/post-chart-context';
const pending:any[]=[],gates=new Map<string,any>(),events:any[]=[],authListeners=new Set<any>();
const deferred=()=>{let resolve:any;const promise=new Promise(r=>resolve=r);return{promise,resolve};};
const review:any={events,authListeners,session:{access_token:'synthetic-token-A',user:{id:'90000000-0000-4000-8000-000000000009'}},synced:['10000000-0000-4000-8000-000000000001','20000000-0000-4000-8000-000000000002'],
hold(key:string){const d=deferred();gates.set(key,d);pending.push(d);return pending.length-1;},release(id:number){pending[id].resolve();},resetEvents(){events.length=0;},
async load(key:string,importer:any){events.push({kind:'import',key});if(gates.has(key))await gates.get(key).promise;return importer();},
async getSession(){events.push({kind:'get-session'});const value=review.session;if(gates.has('session'))await gates.get('session').promise;return value;},
onAuth(callback:any){authListeners.add(callback);events.push({kind:'auth-subscribe'});return()=>{authListeners.delete(callback);events.push({kind:'auth-unsubscribe'});};},
auth(session:any){review.session=session;for(const listener of authListeners)listener(session);},
supabase(){return{from(table:string){events.push({kind:'db-table',table});return{select(columns:string){events.push({kind:'db-columns',columns});return{async eq(field:string,userId:string){events.push({kind:'db-owner',field,userId});if(gates.has('synced'))await gates.get('synced').promise;return{data:review.synced.map((id:string)=>({id})),error:null};}};}};}};},
mount(){render(h(PostChartDailyBrief,{idPrefix:'review'}),document.getElementById('mount')!);},unmount(){render(null,document.getElementById('mount')!);},
publish(context:any){publishPostChartContext(context);},clear(){clearPostChartContext();},current(){return currentPostChartContext();},
};
window.review=review;addEventListener('zodiacs:chart-context-cleared',(e:any)=>events.push({kind:'clear-observed',current:currentPostChartContext(),detailType:typeof e.detail,eventType:e.constructor.name}));
