from pathlib import Path
import json,hashlib,shutil,tarfile,gzip,io
r=Path.cwd();d=r.parent/'delivery-freeze2';d.mkdir(exist_ok=False);sha=lambda b:hashlib.sha256(b).hexdigest()
f=json.loads((r/'candidate-freeze.json').read_text())
for x in f['files']:
 p=r/'candidate-source'/x['path'];assert sha(p.read_bytes())==x['sha256']
for kind in ('native','focus-refined','refresh-admission'):
 x=json.loads((r/f'candidate-{kind}-result.json').read_text());assert x['passed']==x['groups'];assert all(not row['errors'] for row in x['results'])
report='''# Independent C-012 downstream review — Freeze 2

No blocking defect remains in this bounded six-file source review. The exact corrected source passes all 25 independently written native controller criteria. The previously tested, byte-identical email enhancement retains its separate 20/20 native result. The proposed CI wiring remains compatible by independent source review. Root integration, full release gates and the separate combined C-012/C-014 actual-page control are not claimed by these results.

## Exact subject and source scope

Base c7b9eb4a769e39a46aebc0a5ecedcb9fc40949e3. Freeze identity SHA256 fc22bd7c2c6d3efa44022f49f42427545a35915afd49ee66fee6b4d7b6a09cbc. Patch SHA256 7202443237f2bebf826a9a0ef24da3fd8062b4cd2aff2b4edfed02f3a51fc5d8. PostChartDailyBrief.tsx SHA256 3dd16171ac8f19d47d380ed9ec22d51fcfc6f8284697c27f0418a68a1be66158. Six overlay files were physically copied and independently verified before compilation and at sealing.

Only three are product files: the context publisher/clear helper, daily controller and email enhancement. Source-proof.json verifies unchanged static/dynamic module specifiers for these product files and byte-identical actual fixture inputs for ChartCalculator, MoonPhaseTool, preference client, auth implementation, profile store, access reader/hook and daily-state derivation. No calculator, numerical, receipt, endpoint policy, locale, dependency, service, SDK or account authority change is part of this freeze. This source comparison is not a production emitted-module or backend enforcement proof.

## Rejected freeze and corrected state model

Freeze 1 is preserved separately, with manifest dfca7b0f414784c874b2225363d0677def41a7c00048e0b3c6f97ee7b7e313e0. It passed 22 of 23 final main criteria and failed the independently reproduced profile-refresh regression. A successful pending view was cleared, a fresh context was published with its authoritative session read held, then an actual profile-synced event overtook that read. Freeze 1 wrongly remained device-only and did not read a replacement preference; identical baseline remained pending.

The only Freeze 2 product delta from Freeze 1 is the explicit Session | null | undefined cache declaration and its reset values, with a clarifying comment. Undefined means the context's session has not been resolved. Null remains a positively observed signed-out result. Ordinary refresh may resolve an unknown cache, but does not reinterpret authoritative null as missing or retry it. Actual Auth callbacks and access checks remain the same boundaries.

## Independent native results

Node 22.23.2 on macOS arm64 compiled the fixture; runtime.json retains actual ICU 78.2/tzdb2026a metadata. All native checks ran in Chrome 152.0.7977.83. Candidate bundle SHA256 f9e89949596bca1fd7e4348f01ea412b155aade3a02740c8e35d400fd780aa7a, with 70 source-input identities. The source is transformed only to hold declared dynamic-import timing in the real component; the actual context helper, daily native-fetch client, derivation, store and profile-access hook execute. Synthetic Auth/Supabase values, structural DOM, session/import timing, route responses and selective animation-frame delivery are declared fixture boundaries. There is no real account, provider, remote deployment or production page claim.

- 19 general controller groups rerun unchanged: synchronous data-free clear/global deletion; cached-context invalidation; pending/active hiding and typed value preservation; delayed imports/preferences; same-contextId fresh-object and session-token replacement; same-credential clone and profile-sync positives; allowed-access epoch; actual fail-closed reader absence; once-issued resend retention; old refresh/status/focus suppression; ordinary success/error retry; unmount cleanup; non-full event preservation; contradictory preference hidden.
- Three refined focus/session groups rerun unchanged: an obsolete queued frame cannot focus an actually replaced pending button; current queued focus still succeeds; clearing during an already-started session read prevents the preference request.
- Three cache-domain groups pass: the exact rejected-freeze profile-sync interleave now returns pending; explicit signed-out Auth null overtakes a pending lookup and remains authoritative through later refresh; an observed anonymous null stays cached through ordinary profile sync without an extra session lookup.

The original 23 corresponding baseline criteria passed 10 and failed 13. The two newly added known-null controls were executed on Freeze 2 and are not claimed as additional historical baseline executions. All independent drivers, original weak focus probe and refined proof, failed Freeze 1 results, current results, source transformations and input identities remain available in the two deliveries. Our diagnostic drivers collect failing assertions into result ledgers and can exit zero after a collected failure; acceptance is based on those per-case booleans, not the shell exit code.

All 25 current groups have zero page errors. Native preference GET and resend POST use an owned intercepted origin; already-issued POSTs are recorded once and allowed to finish locally. No external write, automatic retry, cancellation or rollback is claimed. Cleanup closes owned contexts and browser. Source/profile-access fixture behavior is conditional on the actual reader contract, not fabricated authorization from a test callback.

## Email, CI and retained limits

The child independently rehashed all six Freeze 2 files. Email SHA256 remains 173f5ec0452cc25c4c9e4279fe203a9fabd79e965302ecab02990e1a070f2deb. Its 20/20 independent native tests versus 10/20 baseline were not rerun because the executed bytes are identical. Original report and exact result ledgers are copied under email/; the separate parity supplement is under email-freeze2-parity/.

This fix owns chart generations, not each later form edit. On the same still-current chart, a submitted successful Cancer request can still reset later typed email/Leo values; both baseline and corrected email code preserve that behavior. Existing payload and once-only success analytics remain intact. Only chart-triggered captures respond to clear/full-computed signals. Native reset listeners and current analytics wrapper were inspected; arbitrary injected synchronous reset/global-hook reentrancy was not promoted to an actual product finding.

The final native driver SHA256 is 3e98393b5ce53e0f15d9ccc6a49fd6da199186da7076e35f9a22938daec9ccfe. Its four added cache controls preserve source-root/OUT_DIR/browser/transport/artifact/cleanup behavior. The separately proposed workflow SHA256 286ca48156fb294f2af629fdf973d921565c5601142396a4d31fe5f1d95633a9 adds the scoped five-minute step and retains existing Node22, pinned Chromium, permissions and always-upload policy. That review is compatibility only, not Linux execution or remote CI success. Author's 21 native/294 full-page results are separate author evidence and were not substituted for these independent controls.

The combined actual-page safeguard check is a separate pending supplement. No whole-date astronomical candidate completeness, skipped-date emptiness proof, production delivery or published/release-ready state is implied. All records are SHA256 hashed/sealed, not cryptographically signed.
'''
(d/'REVIEW.md').write_text(report)
for n in ('candidate-freeze.json','implementation.patch.log','source-proof.json','runtime.json','candidate-native-result.json','candidate-focus-refined-result.json','candidate-refresh-admission-result.json','candidate-identity.json'):
 shutil.copy2(r/n,d/n)
raw={}
for p in r.iterdir():
 if p.is_file() and p.suffix in ('.mjs','.tsx','.json','.js','.log','.py'):raw[p.name]=p
for x in json.loads((r/'candidate-identity.json').read_text())['inputs']:
 p=Path(x['path']);
 if str(p).startswith('source/'):raw[str(p)]=r/p
for p in (r/'candidate-source').rglob('*'):
 if p.is_file():raw[str(p.relative_to(r))]=p
with open(d/'raw.tar.gz','wb') as out:
 with gzip.GzipFile(fileobj=out,mode='wb',mtime=0,filename='') as gz:
  with tarfile.open(fileobj=gz,mode='w') as tar:
   for name,p in sorted(raw.items()):
    data=p.read_bytes();i=tarfile.TarInfo(name);i.size=len(data);i.mode=0o644;i.mtime=0;tar.addfile(i,io.BytesIO(data))
archive=[]
with tarfile.open(d/'raw.tar.gz') as tar:
 for m in tar:
  assert m.isfile();b=tar.extractfile(m).read();assert b==raw[m.name].read_bytes();archive.append({'path':m.name,'bytes':len(b),'sha256':sha(b)})
(d/'raw-members.json').write_text(json.dumps(archive,indent=2)+'\n')
for source,target,expected in [('email/delivery','email','188c751e4820e34a2d98673c7a1e713e05f7bbcd09101808f107b8a605ae66a7'),('email/freeze2-parity','email-freeze2-parity','541701b4957a22ef320e3165de96a7d901e9d3c0e8f5c256ea19c4860396fb78')]:
 a=r.parent/source;assert sha((a/'manifest.json').read_bytes())==expected
 for x in json.loads((a/'manifest.json').read_text())['records']:
  b=(a/x['path']).read_bytes();assert len(b)==x['bytes'] and sha(b)==x['sha256']
 shutil.copytree(a,d/target)
records=[]
for p in sorted(d.rglob('*')):
 if p.is_file():records.append({'path':str(p.relative_to(d)),'bytes':p.stat().st_size,'sha256':sha(p.read_bytes())})
(d/'manifest.json').write_text(json.dumps({'state':'Bounded six-file Freeze2 independent source/runtime review accepted; integration/release/combined-page evidence separate','records':records},indent=2)+'\n')
print(json.dumps({'delivery':str(d),'manifestSha256':sha((d/'manifest.json').read_bytes()),'files':len(records),'bytes':sum(x['bytes'] for x in records),'rawMembers':len(archive)}))
