import fs from 'node:fs';
import assert from 'node:assert/strict';
import {createRequire} from 'node:module';
const require=createRequire(import.meta.url),{chromium}=require('playwright-core');
const variant=process.argv[2]||'candidate';
const A='10000000-0000-4000-8000-000000000001', B='20000000-0000-4000-8000-000000000002';
const context={mode:'full',sunSign:'Cancer',chartId:A,contextId:7};
const pending={enabled:false,pending:true,paused:false,requiresConfirmation:false,chartId:A,timezone:'Etc/UTC',confirmedAt:null,maskedEmail:'a***@example.invalid'};
const active={...pending,enabled:true,pending:false,confirmedAt:'2026-01-01T00:00:00Z'};
const html=`<!doctype html><html data-daily-email-lifecycle><body><section id="shell" data-email-capture-shell hidden><div class="email-capture__copy">Synthetic capture</div><form data-email-capture><input id="email" type="email" value="typed@example.invalid"><select id="sign"><option value="Cancer">Cancer</option><option value="Leo">Leo</option></select><button class="email-capture__submit" type="submit">Join</button></form><p data-post-chart-device-note>Device note</p><div id="mount"></div></section><input id="outside" value="outside"></body></html>`;
const browser=await chromium.launch({executablePath:'/Applications/Google Chrome.app/Contents/MacOS/Google Chrome',headless:true,args:['--no-first-run','--no-default-browser-check']});
const results=[];
const settle=p=>p.waitForTimeout(140);
async function fixture(){
 const ctx=await browser.newContext(),page=await ctx.newPage(),requests=[],errors=[],queue=[],held=[];
 const f={ctx,page,requests,errors,queue,held,preference:pending, hold(method){const slot={method,held:true};queue.push(slot);return slot;}, async release(slot,body,status=200){assert.ok(slot.route,'held route exists');await slot.route.fulfill({status,contentType:'application/json',body:JSON.stringify(body??(slot.method==='POST'?{ok:true,pending:true}:f.preference))});slot.released=true;}, count(method){return requests.filter(x=>x.method===method).length;}};
 page.on('pageerror',e=>errors.push(String(e)));
 await page.route('**/*',async route=>{const req=route.request(),url=new URL(req.url());if(url.pathname==='/api/email/chart-preference'){
   requests.push({method:req.method(),body:req.postData(),authorization:req.headers().authorization});const at=queue.findIndex(x=>x.method===req.method());const slot=at<0?null:queue.splice(at,1)[0];if(slot?.held){slot.route=route;held.push(slot);return;}
   await route.fulfill({contentType:'application/json',body:JSON.stringify(req.method()==='POST'?{ok:true,pending:true}:f.preference)});return;
 }if(req.isNavigationRequest()&&url.hostname==='owned-daily-review.invalid'){await route.fulfill({contentType:'text/html',body:html});return;}requests.push({blocked:true,url:req.url(),method:req.method()});await route.abort();});
 await page.goto('http://owned-daily-review.invalid/');await page.addScriptTag({path:variant+'.js'});
 await page.evaluate(()=>{window.review.mount();window.focuses=[];document.addEventListener('focusin',e=>window.focuses.push({id:e.target.id,text:e.target.textContent}));});
 await page.waitForFunction(()=>window.review.events.some(e=>e.kind==='auth-subscribe'));
 f.publish=async(c=context)=>{await page.evaluate(c=>window.review.publish(c),c);};
 f.state=async s=>page.waitForFunction(s=>document.querySelector('#shell').dataset.postChartState===s,s,{timeout:1800});
 f.hidden=async()=>{await settle(page);assert.equal(await page.locator('#shell').evaluate(e=>e.hidden),true);};
 f.start=async()=>{await f.publish();await f.state('pending');};
 f.resend=async()=>{const slot=f.hold('POST');await page.locator('.post-chart-daily__actions button').click();await page.waitForFunction(()=>document.querySelector('.post-chart-daily__actions button')?.disabled);for(let i=0;i<100&&!slot.route;i++)await page.waitForTimeout(10);assert.ok(slot.route);return slot;};
 return f;
}
async function test(name,run){const f=await fixture();let passed=false,error;try{await run(f);assert.deepEqual(f.errors,[]);passed=true;}catch(e){error=String(e.stack||e);}const state=await f.page.evaluate(()=>({shell:{hidden:document.querySelector('#shell').hidden,state:document.querySelector('#shell').dataset.postChartState},body:document.body.innerText,events:window.review.events,focuses:window.focuses,active:document.activeElement?.id,buttonDisabled:document.querySelector('.post-chart-daily__actions button')?.disabled}));results.push({name,passed,error,requests:f.requests,errors:f.errors,state});console.log(JSON.stringify({name,passed,error:error?.split('\n')[0]}));for(const slot of f.held)if(!slot.released)await slot.route.abort().catch(()=>{});await f.ctx.close();}
try{
 await test('profile sync while the replacement authoritative session is pending preserves authenticated result',async f=>{await f.start();await f.page.evaluate(()=>window.review.clear());const id=await f.page.evaluate(()=>window.review.hold('session'));await f.publish({...context,contextId:8});await f.page.waitForFunction(()=>window.review.events.filter(e=>e.kind==='get-session').length===2);await f.page.evaluate(()=>dispatchEvent(new Event('zodiacs:profile-synced')));await settle(f.page);const interim=await f.page.locator('#shell').getAttribute('data-post-chart-state');await f.page.evaluate(id=>window.review.release(id),id);await settle(f.page);const final=await f.page.locator('#shell').getAttribute('data-post-chart-state');assert.equal(final,'pending',JSON.stringify({interim,final,requests:f.requests}));assert.equal(f.count('POST'),0);});
 await test('explicit signed-out Auth null supersedes a pending session lookup and stays authoritative through refresh',async f=>{await f.start();await f.page.evaluate(()=>window.review.clear());const id=await f.page.evaluate(()=>window.review.hold('session'));await f.publish({...context,contextId:8});await f.page.waitForFunction(()=>window.review.events.filter(e=>e.kind==='get-session').length===2);await f.page.evaluate(()=>{window.review.auth(null);dispatchEvent(new Event('zodiacs:profile-synced'));});await f.state('device-only');await f.page.evaluate(id=>window.review.release(id),id);await settle(f.page);await f.state('device-only');assert.equal(f.count('GET'),1);assert.equal(f.count('POST'),0);assert.equal(await f.page.evaluate(()=>window.review.events.filter(e=>e.kind==='get-session').length),2);});
 await test('resolved anonymous session remains cached through ordinary profile sync without another auth lookup',async f=>{await f.page.evaluate(()=>window.review.session=null);await f.publish();await f.state('device-only');await f.page.evaluate(()=>dispatchEvent(new Event('zodiacs:profile-synced')));await settle(f.page);await f.state('device-only');assert.equal(f.count('GET'),0);assert.equal(await f.page.evaluate(()=>window.review.events.filter(e=>e.kind==='get-session').length),1);});
}finally{fs.writeFileSync(variant+'-refresh-admission-result.json',JSON.stringify({variant,browser:await browser.version(),groups:results.length,passed:results.filter(x=>x.passed).length,results,scope:'Real Preact controller/context/helper/profile access/client; native fetch to fulfilled owned endpoint. Synthetic auth/Supabase boundary, structural DOM and declared import delay gates. No backend/public page claim.'},null,2)+'\n');await browser.close();}
console.log(JSON.stringify({variant,passed:results.filter(x=>x.passed).length,total:results.length}));
