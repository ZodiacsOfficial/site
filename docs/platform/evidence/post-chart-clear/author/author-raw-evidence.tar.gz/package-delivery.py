from pathlib import Path
import hashlib, json, tarfile, shutil, subprocess
out=Path('/private/tmp/zodiacs-platform-post-chart-clear-evidence')
root=Path('/private/tmp/zodiacs-platform-post-chart-clear')
def sha(b): return hashlib.sha256(b).hexdigest()
freeze=json.loads((out/'source-freeze2.json').read_text())
for row in freeze['files']:
 assert sha((root/row['path']).read_bytes())==row['sha256']
 assert sha((out/'frozen-source2'/row['path']).read_bytes())==row['sha256']
first=json.loads((out/'source-freeze.json').read_text())
for row in first['files']: assert sha((out/'frozen-source'/row['path']).read_bytes())==row['sha256']
assert sha((out/'implementation.patch').read_bytes())==first['patch']['sha256']
assert subprocess.run(['git','-C',str(root),'diff','--check'],capture_output=True).returncode==0
files=sorted(p for p in out.rglob('*') if p.is_file() and 'delivery' not in p.relative_to(out).parts)
rows=[{'path':p.relative_to(out).as_posix(),'bytes':p.stat().st_size,'sha256':sha(p.read_bytes())} for p in files]
delivery=out/'delivery';delivery.mkdir(exist_ok=True)
archive=delivery/'author-raw-evidence.tar.gz'
with tarfile.open(archive,'w:gz',compresslevel=9) as tar:
 for p in files: tar.add(p,arcname=p.relative_to(out).as_posix(),recursive=False)
with tarfile.open(archive,'r:gz') as tar:
 for row in rows: assert sha(tar.extractfile(row['path']).read())==row['sha256']
(delivery/'archive-members.json').write_text(json.dumps({'files':rows,'fileCount':len(rows),'bytes':sum(r['bytes'] for r in rows),'archiveSha256':sha(archive.read_bytes())},indent=2)+'\n')
for name in ['AUTHOR.md','COMMANDS.md','source-freeze2.json','implementation-freeze2.patch']:
 shutil.copyfile(out/name,delivery/(name+'.log'))
items=[{'path':p.name,'bytes':p.stat().st_size,'sha256':sha(p.read_bytes())} for p in sorted(delivery.iterdir()) if p.name!='manifest.json']
manifest={'base':freeze['base'],'freeze':2,'sourceFreezeSha256':sha((out/'source-freeze2.json').read_bytes()),'files':items,'fileCount':len(items),'bytes':sum(r['bytes'] for r in items),'qualification':'Author implementation and execution evidence only. Source frozen for independent review; root owns delivery/CI/publication. Archive members preserve original failures and rejected Freeze1.'}
(delivery/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps({'delivery':str(delivery),'manifestSha256':sha((delivery/'manifest.json').read_bytes()),'payloads':len(items),'bytes':manifest['bytes'],'rawMembers':len(rows),'rawBytes':sum(r['bytes'] for r in rows)}))
