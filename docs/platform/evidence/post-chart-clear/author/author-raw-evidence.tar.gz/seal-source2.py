import pathlib, json, hashlib, subprocess
root=pathlib.Path('/private/tmp/zodiacs-platform-post-chart-clear')
out=pathlib.Path('/private/tmp/zodiacs-platform-post-chart-clear-evidence')
base='c7b9eb4a769e39a46aebc0a5ecedcb9fc40949e3'
def sha(data):return hashlib.sha256(data).hexdigest()
def git(*args):return subprocess.check_output(['git','-C',str(root),*args])
assert git('rev-parse','HEAD').decode().strip()==base
paths=git('diff','--name-only').decode().splitlines()
assert len(paths)==6,paths
rows=[]
for path in paths:
 data=(root/path).read_bytes();target=out/'frozen-source2'/path;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(data)
 rows.append({'path':path,'bytes':len(data),'sha256':sha(data)})
patch=git('diff','--binary','--no-ext-diff')
(out/'implementation-freeze2.patch').write_bytes(patch)
native=json.loads((out/'native-freeze2/result.json').read_text())
assert native['passed']==21 and native['failed']==0
assert native['identity']==native['finalIdentity']
for row in native['identity']:assert sha((root/row['path']).read_bytes())==row['sha256']
assert native['driverSha256']==sha((root/'tests/post-chart-context-clear-drive.mjs').read_bytes())
assert (out/'types-freeze2.log').read_bytes()==b''
assert '52 passed (52)' in (out/'focused-freeze2.log').read_text()
assert '- 0 errors\n- 0 warnings\n- 11 hints' in (out/'astro-check-freeze2.log').read_text()
assert 'PASS — 294/294 checks' in (out/'full-post-chart-gate-freeze2.log').read_text()
freeze={'freeze':2,'base':base,'files':rows,'patch':{'path':'implementation-freeze2.patch','bytes':len(patch),'sha256':sha(patch)},
 'validation':{'focusedTestsPassed':52,'strictProjectTypes':'passed','astroCheck':{'files':1043,'errors':0,'warnings':0,'hints':11},'nativeGroupsPassed':21,'fullExistingPageGate':'fixture build and 294/294 checks passed'},
 'scope':'Six-file downstream presentation ownership only; no calculator/date, backend, auth, SQL, provider or publication change.',
 'supersedes':'Freeze1 retained and rejected after a demonstrated unknown-session refresh regression; explicit undefined cache corrects it without weakening authoritative null.',
 'state':'Author source freeze for independent review; not release-ready/published/deployed.'}
(out/'source-freeze2.json').write_text(json.dumps(freeze,indent=2)+'\n')
print(json.dumps({'files':len(rows),'patchSha256':sha(patch),'freezeSha256':sha((out/'source-freeze2.json').read_bytes())}))
