from pathlib import Path
root=Path('/private/tmp/zodiacs-platform-post-chart-clear')
out=Path('/private/tmp/zodiacs-platform-post-chart-clear-evidence')
text=(root/'tests/post-chart-daily-drive.mjs').read_text().split('await withPreview({ port: 4426 }')[0]
text=text.replace("import { chromium } from 'playwright-core';", "import { createRequire } from 'node:module';\nimport {writeFile} from 'node:fs/promises';\nconst {chromium}=createRequire('"+str(root)+"/package.json')('playwright-core');")
text=text.replace("'./visual/browser.mjs'", "'"+str(root)+"/tests/visual/browser.mjs'")
text=text.replace("'./visual/preview-server.mjs'", "'"+str(root)+"/tests/visual/preview-server.mjs'")
text=text.replace('    localStorage.clear();', "    window.__clearObservations=[];for(const type of ['zodiacs:chart-computed','zodiacs:chart-context','zodiacs:chart-context-cleared','zodiacs:profile-access'])addEventListener(type,event=>window.__clearObservations.push({type,detail:event.detail,context:window.zodiacsPostChartContext??null,at:performance.now()}));\n    localStorage.clear();")
text=text.replace('  await shell.waitFor({ state: \'visible\', timeout: 30_000 });', """  try {await shell.waitFor({state:'visible',timeout:30000});}catch(error){
    const snapshot=await page.evaluate(()=>({events:window.__clearObservations,context:window.zodiacsPostChartContext??null,capture:document.querySelector('[data-email-capture-shell]')?.outerHTML,result:!!document.querySelector('.calc__result'),date:document.querySelector('#birth-date')?.value,busy:document.querySelector('.calc__form')?.getAttribute('aria-busy'),error:document.querySelector('.calc__error')?.textContent}));
    await writeFile('"""+str(out)+"""/paused-diagnostic-'+testCase.name+'-'+viewport.width+'.json',JSON.stringify({snapshot,errors,requests,requestFailures,unexpectedRequests},null,2));
    await page.screenshot({path:'"""+str(out)+"""/paused-diagnostic-'+testCase.name+'-'+viewport.width+'.png',fullPage:true});await context.close();throw error;
  }""")
text+="""
await withPreview({port:4438},async baseURL=>{
 const browser=await chromium.launch({executablePath:await findChromium(),headless:true,args:STABLE_CHROMIUM_ARGS});
 try{for(let trial=0;trial<3;trial++)for(const width of [360,1280]){
  try{const run=await preparePage(browser,baseURL,{...cases[5],name:'paused-'+trial},{width,height:900});const snapshot=await run.page.evaluate(()=>({events:window.__clearObservations,context:window.zodiacsPostChartContext??null,caption:document.querySelector('[data-email-capture-shell]')?.textContent}));await writeFile('"""+str(out)+"""/paused-diagnostic-pass-'+trial+'-'+width+'.json',JSON.stringify({snapshot,errors:run.errors,requests:run.requests,requestFailures:run.requestFailures},null,2));await run.context.close();console.log(JSON.stringify({trial,width,passed:true}));}
  catch(error){console.log(JSON.stringify({trial,width,passed:false,error:String(error)}));}
 }}finally{await browser.close();}
});
"""
(out/'paused-diagnostic.mjs').write_text(text)
