/**
 * Phase 3 post-chart state acceptance.
 *
 * Run against a build made with the documented Phase 3 test provider env.
 * Every Supabase/preference request is intercepted; no external service or
 * real subscriber is contacted.
 */
import { createRequire } from 'node:module';
import {writeFile} from 'node:fs/promises';
const {chromium}=createRequire('/private/tmp/zodiacs-platform-post-chart-clear/package.json')('playwright-core');
import {
  findChromium,
  isSiteFooterIconTeardownAbort,
  STABLE_CHROMIUM_ARGS,
} from '/private/tmp/zodiacs-platform-post-chart-clear/tests/visual/browser.mjs';
import { withPreview } from '/private/tmp/zodiacs-platform-post-chart-clear/tests/visual/preview-server.mjs';

const PROFILE_KEY = 'zodiacs.profile.v1';
const AUTH_KEY = 'sb-phase3-test-auth-token';
const USER_ID = '110e8400-e29b-41d4-a716-446655440000';
const CURRENT_ID = '220e8400-e29b-41d4-a716-446655440000';
const OTHER_ID = '330e8400-e29b-41d4-a716-446655440000';
const MASKED_EMAIL = 'f…@example.com';
const LONG_MASKED_EMAIL = 'f…@a-very-long-example-domain-for-proof.example';

const results = [];
const check = (name, ok, detail = '') => results.push({ name, ok, detail });

function base64url(value) {
  return Buffer.from(JSON.stringify(value)).toString('base64url');
}

const accessToken = [
  base64url({ alg: 'HS256', typ: 'JWT' }),
  base64url({ aud: 'authenticated', exp: 4102444800, sub: USER_ID }),
  'phase3-test-signature',
].join('.');

const session = {
  access_token: accessToken,
  refresh_token: 'phase3-test-refresh',
  expires_at: 4102444800,
  expires_in: 2147483647,
  token_type: 'bearer',
  user: {
    id: USER_ID,
    aud: 'authenticated',
    role: 'authenticated',
    email: 'frida@example.com',
    app_metadata: {},
    user_metadata: {},
    identities: [],
    created_at: '2026-07-20T00:00:00.000Z',
  },
};

function savedChart(id = CURRENT_ID, name = 'Frida Kahlo') {
  return {
    id,
    name,
    createdAt: '2026-07-01T00:00:00.000Z',
    updatedAt: '2026-07-01T00:00:00.000Z',
    birth: {
      date: '1907-07-06',
      time: '08:30',
      timeKnown: true,
      place: {
        name: 'Coyoacán',
        admin1: 'Ciudad de México',
        country: 'MX',
        lat: 19.35,
        lon: -99.16,
        tz: 'America/Mexico_City',
      },
    },
    summary: {
      engineVersion: 'test',
      utcISO: '1907-07-06T15:06:36.000Z',
      houseSystem: 'whole',
      bodies: [{ body: 'Sun', lon: 103.91, retrograde: false }],
      angles: { asc: 143.2, mc: 58.4 },
      flags: [],
    },
  };
}

const profile = (charts) => ({ version: 1, settings: { houseSystem: 'whole' }, charts });

const fragment = `#c=1.${base64url({
  d: '1907-07-06',
  t: '08:30',
  z: 'America/Mexico_City',
  la: 19.35,
  lo: -99.16,
  n: 'Frida Kahlo',
  p: 'Coyoacán, Mexico',
})}`;

const emptyPreference = {
  enabled: false,
  pending: false,
  paused: false,
  requiresConfirmation: false,
  chartId: null,
  timezone: null,
  confirmedAt: null,
  maskedEmail: null,
};

const cases = [
  {
    name: 'device-only', expected: 'device-only', signedIn: false, charts: [], synced: [],
    preference: emptyPreference, form: true, note: true, panel: null,
  },
  {
    name: 'signed-in-unsynced', expected: 'signed-in-unsynced', signedIn: true,
    charts: [savedChart()], synced: [], preference: emptyPreference,
    form: true, note: true, panel: null,
  },
  {
    name: 'synced-eligible', expected: 'synced-eligible', signedIn: true,
    charts: [savedChart()], synced: [CURRENT_ID], preference: emptyPreference,
    form: true, note: false, panel: 'synced-eligible',
  },
  {
    name: 'pending', expected: 'pending', signedIn: true,
    charts: [savedChart()], synced: [CURRENT_ID],
    preference: {
      enabled: false, pending: true, paused: false, requiresConfirmation: false, chartId: CURRENT_ID,
      timezone: 'America/Mexico_City', confirmedAt: null, maskedEmail: MASKED_EMAIL,
    },
    form: true, note: false, panel: 'pending',
  },
  {
    name: 'active', expected: 'active', signedIn: true,
    charts: [savedChart()], synced: [CURRENT_ID],
    preference: {
      enabled: true, pending: false, paused: false, requiresConfirmation: false, chartId: CURRENT_ID,
      timezone: 'America/Mexico_City', confirmedAt: '2026-07-20T00:00:00.000Z', maskedEmail: null,
    },
    form: false, note: false, panel: 'active',
  },
  {
    name: 'paused', expected: 'paused', signedIn: true,
    charts: [savedChart()], synced: [CURRENT_ID],
    preference: {
      enabled: true, pending: false, paused: true, requiresConfirmation: false, chartId: null,
      timezone: 'America/Mexico_City', confirmedAt: '2026-07-20T00:00:00.000Z', maskedEmail: null,
    },
    form: false, note: false, panel: 'paused',
  },
];

async function preparePage(browser, baseURL, testCase, viewport) {
  const context = await browser.newContext({
    viewport,
    colorScheme: 'dark',
    locale: 'en-US',
    timezoneId: 'UTC',
    reducedMotion: 'reduce',
  });
  await context.addInitScript(({ authKey, auth, profileKey, profileValue }) => {
    window.__clearObservations=[];for(const type of ['zodiacs:chart-computed','zodiacs:chart-context','zodiacs:chart-context-cleared','zodiacs:profile-access'])addEventListener(type,event=>window.__clearObservations.push({type,detail:event.detail,context:window.zodiacsPostChartContext??null,at:performance.now()}));
    localStorage.clear();
    if (auth) localStorage.setItem(authKey, JSON.stringify(auth));
    localStorage.setItem(profileKey, JSON.stringify(profileValue));
  }, {
    authKey: AUTH_KEY,
    auth: testCase.signedIn ? session : null,
    profileKey: PROFILE_KEY,
    profileValue: profile(testCase.charts),
  });
  const page = await context.newPage();
  const errors = [];
  const requests = [];
  const requestFailures = [];
  const unexpectedRequests = [];
  let resendBody = null;
  let resendAttempted = false;
  let preferenceReads = 0;
  page.on('console', (message) => {
    if (message.type() === 'error') errors.push(`console: ${message.text()}`);
  });
  page.on('pageerror', (error) => errors.push(`page: ${error.message}`));
  page.on('request', (request) => requests.push(request.url()));
  page.on('requestfailed', (request) => {
    if (isSiteFooterIconTeardownAbort(request)) return;
    requestFailures.push(
      `${request.method()} ${request.url()} — ${request.failure()?.errorText ?? 'failed'}`,
    );
  });

  await page.route('https://phase3-test.supabase.co/**', async (route) => {
    const request = route.request();
    const url = new URL(request.url());
    const method = request.method();
    let body = null;
    if (url.pathname === '/auth/v1/user' && method === 'GET') {
      body = session.user;
    } else if (url.pathname === '/rest/v1/charts' && method === 'GET') {
      const select = url.searchParams.get('select') ?? '';
      body = select === 'id'
        ? testCase.synced.map((id) => ({ id }))
        : (testCase.remoteCharts ?? []).map((chart) => ({
          id: chart.id,
          payload: chart,
          updated_at: chart.updatedAt,
        }));
    } else if (url.pathname === '/rest/v1/profiles' && method === 'GET') {
      body = [];
    } else if (url.pathname === '/rest/v1/chart_deletions' && method === 'GET') {
      body = [];
    } else if (url.pathname.startsWith('/rest/v1/')
      && ['POST', 'PATCH', 'DELETE'].includes(method)) {
      body = {};
    } else {
      unexpectedRequests.push(`${method} ${url.pathname}${url.search}`);
      await route.fulfill({
        status: 418,
        contentType: 'application/json',
        body: JSON.stringify({ error: 'unexpected_fixture_request' }),
      });
      return;
    }
    await route.fulfill({
      status: 200,
      contentType: 'application/json',
      headers: {
        'Content-Range': Array.isArray(body)
          ? body.length > 0 ? `0-${body.length - 1}/${body.length}` : '*/0'
          : '0-0/1',
      },
      body: JSON.stringify(body),
    });
  });
  await page.route('**/api/email/chart-preference', async (route) => {
    if (route.request().method() === 'POST') {
      resendBody = JSON.parse(route.request().postData() ?? '{}');
      resendAttempted = true;
      const status = testCase.resendStatus ?? 200;
      await route.fulfill({
        status,
        contentType: 'application/json',
        body: JSON.stringify(status === 200
          ? { ok: true, pending: true, requestId: 'browser-proof' }
          : { error: testCase.resendError ?? 'unavailable' }),
      });
      return;
    }
    preferenceReads += 1;
    await route.fulfill({
      status: 200,
      contentType: 'application/json',
      body: JSON.stringify(
        resendAttempted && testCase.preferenceAfterResend
          ? testCase.preferenceAfterResend
          : testCase.preference,
      ),
    });
  });

  const response = await page.goto(`${baseURL}/birth-chart/${fragment}`, { waitUntil: 'domcontentloaded' });
  const shell = page.locator(`[data-email-capture-shell][data-post-chart-state="${testCase.expected}"]`);
  try {await shell.waitFor({state:'visible',timeout:30000});}catch(error){
    const snapshot=await page.evaluate(()=>({events:window.__clearObservations,context:window.zodiacsPostChartContext??null,capture:document.querySelector('[data-email-capture-shell]')?.outerHTML,result:!!document.querySelector('.calc__result'),date:document.querySelector('#birth-date')?.value,busy:document.querySelector('.calc__form')?.getAttribute('aria-busy'),error:document.querySelector('.calc__error')?.textContent}));
    await writeFile('/private/tmp/zodiacs-platform-post-chart-clear-evidence/paused-diagnostic-freeze2-'+testCase.name+'-'+viewport.width+'.json',JSON.stringify({snapshot,errors,requests,requestFailures,unexpectedRequests},null,2));
    await page.screenshot({path:'/private/tmp/zodiacs-platform-post-chart-clear-evidence/paused-diagnostic-freeze2-'+testCase.name+'-'+viewport.width+'.png',fullPage:true});await context.close();throw error;
  }
  await page.waitForTimeout(75);
  const fixturePrefix = `${testCase.name}@${viewport.width}`;
  check(`${fixturePrefix} has no request failures`, requestFailures.length === 0, requestFailures.join(' | '));
  check(`${fixturePrefix} makes no unexpected fixture requests`, unexpectedRequests.length === 0, unexpectedRequests.join(' | '));
  return {
    context,
    page,
    shell,
    errors,
    requests,
    requestFailures,
    unexpectedRequests,
    getResendBody: () => resendBody,
    getPreferenceReads: () => preferenceReads,
    response,
  };
}

async function prepareProfilePage(browser, baseURL, initialPreference, options = {}) {
  const context = await browser.newContext({
    viewport: { width: 360, height: 800 },
    colorScheme: 'dark',
    locale: 'en-US',
    timezoneId: 'UTC',
    reducedMotion: 'reduce',
  });
  await context.addInitScript(({ authKey, auth, profileKey, profileValue }) => {
    window.__clearObservations=[];for(const type of ['zodiacs:chart-computed','zodiacs:chart-context','zodiacs:chart-context-cleared','zodiacs:profile-access'])addEventListener(type,event=>window.__clearObservations.push({type,detail:event.detail,context:window.zodiacsPostChartContext??null,at:performance.now()}));
    localStorage.clear();
    localStorage.setItem(authKey, JSON.stringify(auth));
    localStorage.setItem(profileKey, JSON.stringify(profileValue));
  }, {
    authKey: AUTH_KEY,
    auth: session,
    profileKey: PROFILE_KEY,
    profileValue: profile([savedChart()]),
  });
  const page = await context.newPage();
  const requestFailures = [];
  const unexpectedRequests = [];
  let preference = initialPreference;
  let mutationBody = null;
  page.on('requestfailed', (request) => {
    if (isSiteFooterIconTeardownAbort(request)) return;
    requestFailures.push(
      `${request.method()} ${request.url()} — ${request.failure()?.errorText ?? 'failed'}`,
    );
  });
  await page.route('https://phase3-test.supabase.co/**', async (route) => {
    const request = route.request();
    const url = new URL(request.url());
    const method = request.method();
    let body = null;
    if (url.pathname === '/auth/v1/user' && method === 'GET') {
      body = session.user;
    } else if (url.pathname === '/rest/v1/charts' && method === 'GET') {
      body = (url.searchParams.get('select') ?? '') === 'id'
        ? [{ id: CURRENT_ID }]
        : [];
    } else if (url.pathname === '/rest/v1/profiles' && method === 'GET') {
      body = [];
    } else if (url.pathname === '/rest/v1/chart_deletions' && method === 'GET') {
      body = [];
    } else if (url.pathname === '/rest/v1/living_chart_sync_consents' && method === 'GET') {
      // Profile now mounts the Living Chart recovery surface alongside the
      // Phase 3 email controls. Keep this fixture explicitly device-only so
      // the unrelated email scenarios cannot contact a real sync backend.
      body = [];
    } else if (url.pathname.startsWith('/rest/v1/')
      && ['POST', 'PATCH', 'DELETE'].includes(method)) {
      body = {};
    } else {
      unexpectedRequests.push(`${method} ${url.pathname}${url.search}`);
      await route.fulfill({
        status: 418,
        contentType: 'application/json',
        body: JSON.stringify({ error: 'unexpected_fixture_request' }),
      });
      return;
    }
    await route.fulfill({
      status: 200,
      contentType: 'application/json',
      headers: { 'Content-Range': Array.isArray(body) && body.length === 0 ? '*/0' : '0-0/1' },
      body: JSON.stringify(body),
    });
  });
  await page.route('**/api/email/chart-preference', async (route) => {
    if (route.request().method() === 'POST') {
      mutationBody = JSON.parse(route.request().postData() ?? '{}');
      const isResend = mutationBody.action === 'resend';
      const status = isResend ? options.resendStatus ?? 200 : 200;
      if (isResend && options.preferenceAfterResend) {
        preference = options.preferenceAfterResend;
      } else {
        preference = {
          enabled: false,
          pending: true,
          paused: false,
          requiresConfirmation: false,
          chartId: CURRENT_ID,
          timezone: 'UTC',
          confirmedAt: null,
          maskedEmail: MASKED_EMAIL,
        };
      }
      await route.fulfill({
        status,
        contentType: 'application/json',
        body: JSON.stringify(status === 200
          ? { ok: true, pending: true, requestId: 'profile-browser-proof' }
          : { error: options.resendError ?? 'not_pending' }),
      });
      return;
    }
    await route.fulfill({
      status: 200,
      contentType: 'application/json',
      body: JSON.stringify(preference),
    });
  });
  const response = await page.goto(`${baseURL}/profile/`, { waitUntil: 'domcontentloaded' });
  const panel = page.locator('#daily-brief');
  await panel.waitFor({ state: 'visible', timeout: 30_000 });
  return {
    context,
    page,
    panel,
    requestFailures,
    unexpectedRequests,
    response,
    getMutationBody: () => mutationBody,
  };
}


await withPreview({port:4438},async baseURL=>{
 const browser=await chromium.launch({executablePath:await findChromium(),headless:true,args:STABLE_CHROMIUM_ARGS});
 try{for(let trial=0;trial<3;trial++)for(const width of [360,1280]){
  try{const run=await preparePage(browser,baseURL,{...cases[5],name:'paused-'+trial},{width,height:900});const snapshot=await run.page.evaluate(()=>({events:window.__clearObservations,context:window.zodiacsPostChartContext??null,caption:document.querySelector('[data-email-capture-shell]')?.textContent}));await writeFile('/private/tmp/zodiacs-platform-post-chart-clear-evidence/paused-diagnostic-freeze2-pass-'+trial+'-'+width+'.json',JSON.stringify({snapshot,errors:run.errors,requests:run.requests,requestFailures:run.requestFailures},null,2));await run.context.close();console.log(JSON.stringify({trial,width,passed:true}));}
  catch(error){console.log(JSON.stringify({trial,width,passed:false,error:String(error)}));}
 }}finally{await browser.close();}
});
