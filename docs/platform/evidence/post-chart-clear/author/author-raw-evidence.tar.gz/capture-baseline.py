import hashlib, json, pathlib, subprocess
root=pathlib.Path('/private/tmp/zodiacs-platform-post-chart-clear')
out=pathlib.Path('/private/tmp/zodiacs-platform-post-chart-clear-evidence')
base='c7b9eb4a769e39a46aebc0a5ecedcb9fc40949e3'
assert subprocess.check_output(['git','-C',str(root),'rev-parse','HEAD']).decode().strip()==base
rows=[]
for path in ['src/lib/profile/post-chart-context.ts','src/islands/PostChartDailyBrief.tsx','src/components/EmailCaptureEnhancement.astro','tests/post-chart-daily-drive.mjs']:
 data=(root/path).read_bytes();dest=out/'baseline-source'/path;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(data)
 rows.append({'path':path,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()})
(out/'base.json').write_text(json.dumps({'base':base,'files':rows},indent=2)+'\n')
