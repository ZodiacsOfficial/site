/** Native ownership controls for the actual daily island, preference client,
 * context publisher, and Astro enhancement script. Only auth/store fixtures and
 * endpoint responses are controlled; no subscriber/provider is contacted.
 */
import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { readFile, writeFile, mkdir } from 'node:fs/promises';
import { createServer } from 'node:http';
import { resolve } from 'node:path';
import { build } from 'esbuild';
import { chromium } from 'playwright-core';
import { findChromium, STABLE_CHROMIUM_ARGS } from './visual/browser.mjs';

const root=resolve(import.meta.dirname,'..');
const out=resolve(process.env.OUT_DIR??resolve(root,'tests/visual/artifacts/post-chart-context-clear'));
await mkdir(out,{recursive:true});
const sha=bytes=>createHash('sha256').update(bytes).digest('hex');
const paths=['src/lib/profile/post-chart-context.ts','src/islands/PostChartDailyBrief.tsx','src/components/EmailCaptureEnhancement.astro'];
const identity=await Promise.all(paths.map(async path=>({path,sha256:sha(await readFile(resolve(root,path)))})));
const enhancement=(await readFile(resolve(root,paths[2]),'utf8')).match(/<script>([\s\S]*?)<\/script>/)?.[1];assert.ok(enhancement);
const ID='10000000-0000-4000-8000-000000000001';
const entry=`
import {h,render} from 'preact';
import {PostChartDailyBrief} from './src/islands/PostChartDailyBrief';
import {clearPostChartContext,publishPostChartContext} from './src/lib/profile/post-chart-context';
window.fixture={reads:[],analytics:[],clearEvents:[],session:{access_token:'synthetic-local-token',user:{id:'${ID}'}},sessionHold:null,auth:null,focusFrames:[],holdFocus:false,
 holdSession(){let done;const promise=new Promise(resolve=>done=resolve);this.sessionHold={promise,done};},
 releaseSession(){const old=this.sessionHold;this.sessionHold=null;old?.done(this.session);},
 async getSession(){this.reads.push('session');return this.sessionHold?this.sessionHold.promise:this.session;},
 ids(){this.reads.push('ids');return Promise.resolve({data:[{id:'${ID}'}],error:null});},
 clear(){clearPostChartContext();},
 publish(contextId=1,sunSign='cancer'){const context={mode:'full',sunSign,chartId:'${ID}',contextId};dispatchEvent(new CustomEvent('zodiacs:chart-computed',{detail:context}));publishPostChartContext(context);},
 refresh(){dispatchEvent(new Event('zodiacs:profile-synced'));dispatchEvent(new Event('zodiacs:profile-access'));this.auth?.(this.session);},
 mount(){render(h(PostChartDailyBrief,{idPrefix:'managed'}),document.getElementById('controller'));},
 unmount(){render(null,document.getElementById('controller'));},
 releaseFocus(){this.holdFocus=false;for(const callback of this.focusFrames.splice(0))callback(performance.now());},
};
window.zodiacsAnalytics={track:(name,props)=>window.fixture.analytics.push({name,props})};
addEventListener('zodiacs:chart-context-cleared',event=>window.fixture.clearEvents.push({type:event.type,detail:event.detail,globalAbsent:window.zodiacsPostChartContext===undefined}));
const nativeFrame=requestAnimationFrame;
window.requestAnimationFrame=callback=>window.fixture.holdFocus&&callback.toString().includes('focus')?(window.fixture.focusFrames.push(callback),-1):nativeFrame(callback);
window.fixture.mount();
${enhancement}
`;
const compilation=await build({absWorkingDir:root,stdin:{contents:entry,resolveDir:root,loader:'tsx'},bundle:true,write:false,outfile:resolve(out,'fixture.js'),platform:'browser',format:'iife',target:'es2022',jsx:'automatic',jsxImportSource:'preact',define:{'import.meta.env':'{}'},metafile:true,
 plugins:[{name:'declared-auth-and-store-fixtures',setup(builder){
  builder.onResolve({filter:/lib\/profile\/(?:sync|store)$/},args=>({path:args.path.endsWith('/sync')?'sync':'store',namespace:'owned'}));
  builder.onResolve({filter:/supabase\/client$/},()=>({path:'client',namespace:'owned'}));
  builder.onLoad({filter:/.*/,namespace:'owned'},({path})=>({contents:path==='sync'
   ?'export const getSyncSession=()=>window.fixture.getSession();export function onSyncAuthChange(callback){window.fixture.auth=callback;return ()=>{window.fixture.auth=null;};}'
   :path==='store'?'export const loadProfile=()=>({charts:[{id:"'+ID+'",name:"Synthetic saved chart"}]});'
   :'export const getSupabaseClient=()=>({from:()=>({select:()=>({eq:()=>window.fixture.ids()})})});'}));
 }}]});
const bundle=compilation.outputFiles.find(file=>file.path.endsWith('.js')).contents;
const inputs=await Promise.all(Object.keys(compilation.metafile.inputs).filter(path=>!path.startsWith('<')&&!path.startsWith('owned:')).map(async path=>{const data=await readFile(resolve(root,path));return {path,bytes:data.length,sha256:sha(data)};}));
await writeFile(resolve(out,'fixture.js'),bundle);await writeFile(resolve(out,'entry.tsx.log'),entry);
await writeFile(resolve(out,'build.json'),JSON.stringify({inputs,identity,bundleSha256:sha(bundle),metafile:compilation.metafile},null,2)+'\n');
function capture(name,{managed=false,reveal=true}={}){return `<section data-email-capture-shell data-placement="${name}" ${reveal?'data-reveal-on-chart="true" hidden':''} ${managed?'data-post-chart-managed="true" data-daily-capture="true"':''} id="${name}">${managed?'<div id="controller"></div>':''}<div class="email-capture__copy"><h2 data-email-title data-default-title="Choose a brief" data-personal-title="For {sign}">Choose a brief</h2></div><form data-email-capture action="/api/email/subscribe" data-placement="${name}"><input type="email" name="email" required><button class="email-capture__submit" type="submit" data-label="Subscribe" data-busy-label="Working">Subscribe</button><div data-email-sign-summary data-summary-template="Using {sign}" hidden><span data-email-sign-summary-copy></span><button type="button" data-email-sign-change>Change sign</button></div><fieldset data-email-signs><legend>Sign</legend><label><input type="radio" name="sign" value="cancer" data-sign-name="Cancer">Cancer</label><label><input type="radio" name="sign" value="leo" data-sign-name="Leo">Leo</label></fieldset><p data-email-status></p><span hidden data-success-copy>Done</span><span hidden data-error-copy>Error</span><span hidden data-missing-sign-copy>Choose</span><span hidden data-invalid-email-copy>Invalid</span><p data-post-chart-device-note hidden>Local</p></form></section>`;}
const html='<!doctype html><html data-daily-email-lifecycle><title>Post-chart context clear fixture</title><style>[hidden]{display:none!important}</style><input id="outside" value="unrelated">'+capture('managed',{managed:true})+capture('weekly')+capture('footer',{reveal:false})+'<script src="/fixture.js"></script></html>';
const server=createServer((req,res)=>{if(req.url==='/fixture.js'){res.setHeader('Content-Type','text/javascript');res.end(bundle);}else{res.setHeader('Content-Type','text/html');res.end(req.url.includes('lifecycle=0')?html.replace('data-daily-email-lifecycle',''):html);}});
const empty={enabled:false,pending:false,paused:false,requiresConfirmation:false,chartId:null,timezone:null,confirmedAt:null,maskedEmail:null};
const pending={...empty,pending:true,chartId:ID,timezone:'UTC',maskedEmail:'s…@example.com'};
let browser,origin;const contexts=[],results=[];
async function frames(s){await s.page.evaluate(()=>new Promise(done=>requestAnimationFrame(()=>requestAnimationFrame(()=>setTimeout(done,0)))));}
async function setup(preference=empty,lifecycle=true){
 const context=await browser.newContext({viewport:{width:1000,height:900}});contexts.push(context);context.setDefaultTimeout(5000);
 const s={context,page:await context.newPage(),preference,requests:[],errors:[],gates:[]};s.page.on('pageerror',error=>s.errors.push(String(error)));
 await context.route('**/*',async route=>{
  const req=route.request(),url=new URL(req.url());
  if(url.origin!==origin)return route.abort();
  if(!url.pathname.startsWith('/api/'))return route.continue();
  const record={method:req.method(),path:url.pathname,body:req.postData()};s.requests.push(record);
  const gate=s.gates.find(value=>!value.used&&value.path===url.pathname&&value.method===req.method());
  if(gate){gate.used=true;gate.started();await gate.wait;}
  const body=url.pathname.endsWith('/subscribe')?{ok:true}:req.method()==='POST'?{ok:true,pending:true}:s.preference;
  await route.fulfill({status:gate?.status??200,contentType:'application/json',body:JSON.stringify(body)}).catch(()=>{});
 });
 await s.page.goto(origin+(lifecycle?'':'?lifecycle=0'));await s.page.waitForFunction(()=>!!window.fixture);await frames(s);return s;
}
function gate(s,path,method,status=200){let started,release;const begun=new Promise(done=>started=done),wait=new Promise(done=>release=done);const value={path,method,status,started,release,wait,begun,used:false};s.gates.push(value);return value;}
async function publish(s,id=1,sign='cancer'){await s.page.evaluate(({id,sign})=>window.fixture.publish(id,sign),{id,sign});await s.page.locator('#managed[data-post-chart-state]').waitFor({state:'visible'});await frames(s);}
async function observation(s){return s.page.evaluate(()=>({context:window.zodiacsPostChartContext??null,events:window.fixture.clearEvents,reads:window.fixture.reads,analytics:window.fixture.analytics,focus:document.activeElement?.id,managedHidden:document.querySelector('#managed').hidden,managedState:document.querySelector('#managed').dataset.postChartState??null,weeklyHidden:document.querySelector('#weekly').hidden,footerHidden:document.querySelector('#footer').hidden,weeklyEmail:document.querySelector('#weekly input[type=email]').value,weeklyStatus:document.querySelector('#weekly [data-email-status]').textContent,weeklySign:document.querySelector('#weekly input[name=sign]:checked')?.value??null,weeklyButton:document.querySelector('#weekly button[type=submit]').textContent}));}
async function group(name,action,lifecycle=true){const s=await setup(name.includes('resend')?pending:empty,lifecycle);try{const detail=await action(s);assert.deepEqual(s.errors,[]);results.push({name,passed:true,detail,requests:s.requests,observation:await observation(s)});}catch(error){results.push({name,passed:false,error:String(error.stack??error),requests:s.requests,observation:await observation(s),pageErrors:s.errors});await s.page.screenshot({path:resolve(out,name+'.png'),fullPage:true}).catch(()=>{});}finally{for(const g of s.gates)g.release();await s.context.close();}console.log(JSON.stringify({name,passed:results.at(-1).passed}));}
try{
 await new Promise(done=>server.listen(0,'127.0.0.1',done));origin=`http://127.0.0.1:${server.address().port}`;
 browser=await chromium.launch({executablePath:await findChromium(),headless:true,args:STABLE_CHROMIUM_ARGS});
 await group('clear-propagates-and-preserves-fields',async s=>{
  await publish(s);await s.page.locator('#managed input[type=email]').fill('typed@example.com');await s.page.locator('#weekly input[type=email]').fill('weekly@example.com');
  const before=s.requests.length;await s.page.evaluate(()=>window.fixture.clear());await frames(s);const cleared=await observation(s);
  assert.equal(cleared.context,null);assert.equal(cleared.events.length,1);assert.equal(cleared.events[0].detail,undefined);assert.equal(cleared.events[0].globalAbsent,true);assert.equal(cleared.events[0].type,'zodiacs:chart-context-cleared');assert.equal(cleared.managedHidden,true);assert.equal(cleared.managedState,null);assert.equal(cleared.weeklyHidden,true);assert.equal(cleared.footerHidden,false);assert.equal(cleared.weeklyEmail,'weekly@example.com');assert.equal(cleared.weeklySign,'cancer');assert.equal(await s.page.locator('#managed input[type=email]').inputValue(),'typed@example.com');
  await s.page.evaluate(()=>window.fixture.refresh());await frames(s);assert.equal(s.requests.length,before);assert.equal((await observation(s)).managedHidden,true);await publish(s,2,'leo');assert.equal((await observation(s)).weeklySign,'leo');return {cleared,recovered:true};
 });
 await group('clear-before-session-read',async s=>{await s.page.evaluate(()=>{window.fixture.publish();window.fixture.clear();});await frames(s);assert.deepEqual((await observation(s)).reads,[]);assert.equal(s.requests.length,0);return {noNewReads:true};});
 await group('clear-during-session-read',async s=>{await s.page.evaluate(()=>{window.fixture.holdSession();window.fixture.publish();});await s.page.waitForFunction(()=>window.fixture.reads.includes('session'));await s.page.evaluate(()=>{window.fixture.clear();window.fixture.releaseSession();});await frames(s);assert.equal(s.requests.length,0);assert.equal((await observation(s)).managedHidden,true);return {noPreferenceRead:true};});
 await group('clear-during-preference-read',async s=>{const held=gate(s,'/api/email/chart-preference','GET');await s.page.evaluate(()=>window.fixture.publish());await held.begun;await s.page.evaluate(()=>window.fixture.clear());held.release();await frames(s);await s.page.waitForTimeout(50);const value=await observation(s);assert.equal(value.managedHidden,true);assert.equal(value.managedState,null);assert.equal(s.requests.length,1);return {value};});
 await group('submitted-resend-clears-without-retry',async s=>{
  await publish(s);const held=gate(s,'/api/email/chart-preference','POST');await s.page.locator('#managed .post-chart-daily__actions button').click();await held.begun;await s.page.evaluate(()=>window.fixture.clear());held.release();await frames(s);await s.page.waitForTimeout(50);const value=await observation(s);assert.equal(value.managedHidden,true);assert.equal(value.managedState,null);assert.equal(s.requests.filter(r=>r.method==='POST').length,1);assert.equal(s.requests.filter(r=>r.method==='GET').length,1);assert.equal(s.requests.find(r=>r.method==='POST').body,'{"action":"resend"}');return value;
 });
 await group('resend-frame-cannot-focus-replacement',async s=>{
  await publish(s);await s.page.evaluate(()=>{window.fixture.holdFocus=true;});await s.page.locator('#managed .post-chart-daily__actions button').click();await s.page.waitForFunction(()=>window.fixture.focusFrames.length>0);await s.page.evaluate(()=>window.fixture.clear());await publish(s,1,'leo');await s.page.locator('#outside').focus();await s.page.evaluate(()=>window.fixture.releaseFocus());assert.equal((await observation(s)).focus,'outside');assert.equal(s.requests.filter(r=>r.method==='POST').length,1);return {sameContextIdReplacement:true};
 });
 for(const replacement of [false,true])await group('submitted-capture-'+(replacement?'replacement':'clear'),async s=>{
  await publish(s);await s.page.locator('#weekly input[type=email]').fill('first@example.com');const held=gate(s,'/api/email/subscribe','POST');await s.page.locator('#weekly button[type=submit]').click();await held.begun;await s.page.evaluate(()=>window.fixture.clear());
  if(replacement){await publish(s,2,'leo');await s.page.locator('#weekly input[type=email]').fill('replacement@example.com');}
  held.release();await frames(s);await s.page.waitForTimeout(50);const value=await observation(s);assert.equal(value.weeklyHidden,!replacement);assert.equal(value.weeklyEmail,replacement?'replacement@example.com':'first@example.com');assert.equal(value.weeklyStatus,'');assert.equal(value.weeklySign,replacement?'leo':'cancer');assert.equal(value.weeklyButton,'Subscribe');assert.equal(s.requests.filter(r=>r.path.endsWith('/subscribe')).length,1);assert.equal(value.analytics.filter(row=>row.name==='email_subscribed').length,1);return value;
 });
 await group('unrelated-footer-request-completes',async s=>{await publish(s);await s.page.locator('#footer input[type=email]').fill('footer@example.com');const held=gate(s,'/api/email/subscribe','POST');await s.page.locator('#footer button[type=submit]').click();await held.begun;await s.page.evaluate(()=>window.fixture.clear());held.release();await s.page.locator('#footer [data-email-status]').filter({hasText:'Done'}).waitFor();assert.equal(await s.page.locator('#footer').isVisible(),true);assert.equal(await s.page.locator('#footer input[type=email]').inputValue(),'');assert.equal(s.requests.filter(r=>r.path.endsWith('/subscribe')).length,1);return {unrelatedCompletionPreserved:true};});
 await group('sign-focus-frame-cannot-escape-clear',async s=>{await publish(s);await s.page.evaluate(()=>{window.fixture.holdFocus=true;});await s.page.locator('#weekly [data-email-sign-change]').click();await s.page.waitForFunction(()=>window.fixture.focusFrames.length>0);await s.page.evaluate(()=>window.fixture.clear());await publish(s,2,'leo');await s.page.locator('#weekly [data-email-sign-change]').click();await s.page.locator('#outside').focus();await s.page.evaluate(()=>window.fixture.focusFrames.shift()(performance.now()));assert.equal((await observation(s)).focus,'outside');await s.page.evaluate(()=>window.fixture.releaseFocus());assert.equal(await s.page.evaluate(()=>document.activeElement?.getAttribute('value')),'leo');return {obsoleteFocusSuppressed:true,currentFocusPreserved:true};});
 await group('capture-markup-with-lifecycle-off',async s=>{await s.page.evaluate(()=>window.fixture.publish());await s.page.locator('#weekly').waitFor({state:'visible'});await s.page.locator('#weekly input[type=email]').fill('retained@example.com');await s.page.evaluate(()=>window.fixture.clear());const cleared=await observation(s);assert.equal(cleared.weeklyHidden,true);assert.equal(cleared.managedHidden,true);assert.equal(cleared.footerHidden,false);assert.equal(cleared.weeklyEmail,'retained@example.com');assert.equal(s.requests.length,0);await s.page.evaluate(()=>window.fixture.publish(2,'leo'));await s.page.locator('#weekly').waitFor({state:'visible'});assert.equal((await observation(s)).weeklySign,'leo');assert.equal(s.requests.length,0);return {markupPresent:true,lifecycleFlag:false,cleared};},false);
}finally{
 for(const context of contexts)await context.close().catch(()=>{});const version=browser?.version();await browser?.close();await new Promise(done=>server.close(done));
 const report={node:process.version,browser:version,identity,finalIdentity:await Promise.all(paths.map(async path=>({path,sha256:sha(await readFile(resolve(root,path)))}))),driverSha256:sha(await readFile(new URL(import.meta.url))),results,passed:results.filter(r=>r.passed).length,failed:results.filter(r=>!r.passed).length,qualification:'Actual island, context module, preference fetch client and extracted Astro enhancement script; synthetic structural DOM and controlled auth/store/endpoint responses. No production layout or real authentication/provider claim.',cleanup:{browserClosed:true,contextsClosed:true,serverClosed:true}};
 await writeFile(resolve(out,'result.json'),JSON.stringify(report,null,2)+'\n');console.log(JSON.stringify({passed:report.passed,failed:report.failed}));if(report.failed)process.exitCode=1;
}
