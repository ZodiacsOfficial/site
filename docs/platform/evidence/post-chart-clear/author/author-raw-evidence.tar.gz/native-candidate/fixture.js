(() => {
  var __defProp = Object.defineProperty;
  var __getOwnPropNames = Object.getOwnPropertyNames;
  var __esm = (fn, res, err) => function __init() {
    if (err) throw err[0];
    try {
      return fn && (res = (0, fn[__getOwnPropNames(fn)[0]])(fn = 0)), res;
    } catch (e3) {
      throw err = [e3], e3;
    }
  };
  var __export = (target, all) => {
    for (var name in all)
      __defProp(target, name, { get: all[name], enumerable: true });
  };

  // <define:import.meta.env>
  var init_define_import_meta_env = __esm({
    "<define:import.meta.env>"() {
    }
  });

  // src/lib/account-v2/profile-access-reader.ts
  function browserProfileAccessReader() {
    if (typeof window === "undefined") return null;
    try {
      const reader = Reflect.get(window, "zodiacsProfileAccess");
      if (!reader || typeof reader !== "object") return null;
      return typeof Reflect.get(reader, "canRead") === "function" ? reader : null;
    } catch {
      return null;
    }
  }
  function accountProfileAccessEnabled() {
    if (typeof document === "undefined") return false;
    try {
      return document.documentElement.hasAttribute("data-account-sync-v2");
    } catch {
      return true;
    }
  }
  function profileAccessAllowed(reader = browserProfileAccessReader(), enabled = accountProfileAccessEnabled()) {
    if (!enabled) return true;
    try {
      return reader?.canRead() === true;
    } catch {
      return false;
    }
  }
  var init_profile_access_reader = __esm({
    "src/lib/account-v2/profile-access-reader.ts"() {
      "use strict";
      init_define_import_meta_env();
    }
  });

  // owned:sync
  var sync_exports = {};
  __export(sync_exports, {
    getSyncSession: () => getSyncSession,
    onSyncAuthChange: () => onSyncAuthChange
  });
  function onSyncAuthChange(callback) {
    window.fixture.auth = callback;
    return () => {
      window.fixture.auth = null;
    };
  }
  var getSyncSession;
  var init_sync = __esm({
    "owned:sync"() {
      init_define_import_meta_env();
      getSyncSession = () => window.fixture.getSession();
    }
  });

  // owned:client
  var client_exports = {};
  __export(client_exports, {
    getSupabaseClient: () => getSupabaseClient
  });
  var getSupabaseClient;
  var init_client = __esm({
    "owned:client"() {
      init_define_import_meta_env();
      getSupabaseClient = () => ({ from: () => ({ select: () => ({ eq: () => window.fixture.ids() }) }) });
    }
  });

  // src/lib/profile/daily-email-client.ts
  var daily_email_client_exports = {};
  __export(daily_email_client_exports, {
    DailyChartPreferenceError: () => DailyChartPreferenceError,
    browserTimezoneChoices: () => browserTimezoneChoices,
    deleteDailyChartPreference: () => deleteDailyChartPreference,
    getDailyChartPreference: () => getDailyChartPreference,
    getSyncedChartIds: () => getSyncedChartIds,
    isBrowserIanaTimezone: () => isBrowserIanaTimezone,
    maskDailyEmail: () => maskDailyEmail,
    pauseDailyChartPreferenceForDeletion: () => pauseDailyChartPreferenceForDeletion,
    rememberDailyChartSelection: () => rememberDailyChartSelection,
    rememberedDailyChartSelection: () => rememberedDailyChartSelection,
    resendDailyChartPreference: () => resendDailyChartPreference,
    setDailyChartPreference: () => setDailyChartPreference
  });
  function bearerHeaders(accessToken, json = false) {
    return {
      Accept: "application/json",
      Authorization: `Bearer ${accessToken}`,
      ...json ? { "Content-Type": "application/json" } : {}
    };
  }
  async function responseJson(response) {
    if (!response.ok) throw new DailyChartPreferenceError(response.status);
    const value = await response.json();
    if (!value || typeof value !== "object" || Array.isArray(value)) {
      throw new DailyChartPreferenceError(502);
    }
    return value;
  }
  async function getDailyChartPreference(accessToken, fetcher = fetch) {
    const response = await fetcher("/api/email/chart-preference", {
      method: "GET",
      credentials: "same-origin",
      headers: bearerHeaders(accessToken)
    });
    const value = await responseJson(response);
    const enabled = value.enabled === true;
    const pending = value.pending === true;
    const paused = value.paused === true;
    const requiresConfirmation = value.requiresConfirmation === true;
    const chartId = typeof value.chartId === "string" && UUID2.test(value.chartId) ? value.chartId : value.chartId === null ? null : void 0;
    const timezone = typeof value.timezone === "string" ? value.timezone : null;
    const confirmedAt = typeof value.confirmedAt === "string" ? value.confirmedAt : null;
    const maskedEmail = typeof value.maskedEmail === "string" ? value.maskedEmail : null;
    if (value.enabled === false && !pending && !paused && !requiresConfirmation) {
      return {
        enabled: false,
        pending: false,
        paused: false,
        requiresConfirmation: false,
        chartId: null,
        timezone: null,
        confirmedAt: null,
        maskedEmail
      };
    }
    if (pending && !enabled && !paused && !requiresConfirmation && chartId && timezone) {
      return {
        enabled: false,
        pending: true,
        paused: false,
        requiresConfirmation: false,
        chartId,
        timezone,
        confirmedAt: null,
        maskedEmail
      };
    }
    if (enabled && !pending && !requiresConfirmation && timezone && confirmedAt && (paused && chartId === null || !paused && typeof chartId === "string")) {
      return {
        enabled: true,
        pending: false,
        paused,
        requiresConfirmation: false,
        chartId,
        timezone,
        confirmedAt,
        maskedEmail
      };
    }
    if (!enabled && !pending && requiresConfirmation && timezone && confirmedAt && (paused && chartId === null || !paused && typeof chartId === "string")) {
      return {
        enabled: false,
        pending: false,
        paused,
        requiresConfirmation: true,
        chartId,
        timezone,
        confirmedAt,
        maskedEmail: null
      };
    }
    throw new DailyChartPreferenceError(502);
  }
  async function setDailyChartPreference(accessToken, input, fetcher = fetch) {
    const response = await fetcher("/api/email/chart-preference", {
      method: "POST",
      credentials: "same-origin",
      headers: bearerHeaders(accessToken, true),
      body: JSON.stringify(input)
    });
    const value = await responseJson(response);
    if (value.ok !== true || typeof value.pending !== "boolean") {
      throw new DailyChartPreferenceError(502);
    }
    return {
      ok: true,
      pending: value.pending,
      ...typeof value.requestId === "string" ? { requestId: value.requestId } : {}
    };
  }
  async function resendDailyChartPreference(accessToken, fetcher = fetch) {
    const response = await fetcher("/api/email/chart-preference", {
      method: "POST",
      credentials: "same-origin",
      headers: bearerHeaders(accessToken, true),
      body: JSON.stringify({ action: "resend" })
    });
    const value = await responseJson(response);
    if (value.ok !== true || value.pending !== true) {
      throw new DailyChartPreferenceError(502);
    }
    return {
      ok: true,
      pending: true,
      ...typeof value.requestId === "string" ? { requestId: value.requestId } : {}
    };
  }
  async function deleteDailyChartPreference(accessToken, fetcher = fetch) {
    const response = await fetcher("/api/email/chart-preference", {
      method: "DELETE",
      credentials: "same-origin",
      headers: bearerHeaders(accessToken)
    });
    const value = await responseJson(response);
    if (value.ok !== true) throw new DailyChartPreferenceError(502);
  }
  async function pauseDailyChartPreferenceForDeletion(accessToken, chartId, fetcher = fetch) {
    if (!UUID2.test(chartId)) throw new DailyChartPreferenceError(400);
    const response = await fetcher("/api/email/chart-preference", {
      method: "PATCH",
      credentials: "same-origin",
      headers: bearerHeaders(accessToken, true),
      body: JSON.stringify({ chartId })
    });
    const value = await responseJson(response);
    const selectedChartId = typeof value.selectedChartId === "string" && UUID2.test(value.selectedChartId) ? value.selectedChartId : value.selectedChartId === null ? null : void 0;
    if (value.ok !== true || typeof value.paused !== "boolean" || typeof value.cancelled !== "boolean" || selectedChartId === void 0) {
      throw new DailyChartPreferenceError(502);
    }
    if (value.paused && value.cancelled) throw new DailyChartPreferenceError(502);
    const outcome = value.paused ? "paused" : value.cancelled ? "cancelled" : "not-selected";
    if (outcome !== "not-selected" && selectedChartId !== null) {
      throw new DailyChartPreferenceError(502);
    }
    return { outcome, selectedChartId };
  }
  function rememberDailyChartSelection(chartId) {
    if (!profileAccessAllowed()) return;
    try {
      if (chartId && UUID2.test(chartId)) localStorage.setItem(DAILY_CHART_SELECTION_KEY, chartId);
      else localStorage.removeItem(DAILY_CHART_SELECTION_KEY);
    } catch {
    }
  }
  function rememberedDailyChartSelection() {
    if (!profileAccessAllowed()) return null;
    try {
      const chartId = localStorage.getItem(DAILY_CHART_SELECTION_KEY);
      return chartId && UUID2.test(chartId) ? chartId : null;
    } catch {
      return null;
    }
  }
  async function getSyncedChartIds(userId) {
    const { getSupabaseClient: getSupabaseClient2 } = await Promise.resolve().then(() => (init_client(), client_exports));
    const client = getSupabaseClient2();
    if (!client || !UUID2.test(userId)) return [];
    const { data, error } = await client.from("charts").select("id").eq("user_id", userId);
    if (error) throw error;
    return (data ?? []).map((row) => row.id).filter((id) => typeof id === "string" && UUID2.test(id));
  }
  function maskDailyEmail(email) {
    if (!email) return "\u2026";
    const [local, domain, ...rest] = email.trim().split("@");
    if (!local || !domain || rest.length > 0) return "\u2026";
    return `${local[0]}\u2026@${domain}`;
  }
  function isBrowserIanaTimezone(value) {
    if (!value || value.trim() !== value || value.length > 255) return false;
    try {
      new Intl.DateTimeFormat("en-US", { timeZone: value }).format(0);
      return true;
    } catch {
      return false;
    }
  }
  function browserTimezoneChoices(extra = []) {
    const supportedValuesOf = Intl.supportedValuesOf;
    const candidates = supportedValuesOf ? supportedValuesOf("timeZone") : [
      "America/Chicago",
      "America/Los_Angeles",
      "America/Mexico_City",
      "America/New_York",
      "Asia/Bangkok",
      "Asia/Tokyo",
      "Australia/Sydney",
      "Europe/Lisbon",
      "Europe/London",
      "Europe/Paris"
    ];
    return Array.from(/* @__PURE__ */ new Set(["UTC", ...extra, ...candidates])).filter(isBrowserIanaTimezone);
  }
  var UUID2, DAILY_CHART_SELECTION_KEY, DailyChartPreferenceError;
  var init_daily_email_client = __esm({
    "src/lib/profile/daily-email-client.ts"() {
      "use strict";
      init_define_import_meta_env();
      init_profile_access_reader();
      UUID2 = /^[0-9a-f]{8}-[0-9a-f]{4}-[1-8][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;
      DAILY_CHART_SELECTION_KEY = "zodiacs.daily-chart-selection.v1";
      DailyChartPreferenceError = class extends Error {
        constructor(status) {
          super(`Daily chart preference request failed (${status}).`);
          this.status = status;
          this.name = "DailyChartPreferenceError";
        }
        status;
      };
    }
  });

  // owned:store
  var store_exports = {};
  __export(store_exports, {
    loadProfile: () => loadProfile
  });
  var loadProfile;
  var init_store = __esm({
    "owned:store"() {
      init_define_import_meta_env();
      loadProfile = () => ({ charts: [{ id: "10000000-0000-4000-8000-000000000001", name: "Synthetic saved chart" }] });
    }
  });

  // <stdin>
  init_define_import_meta_env();

  // ../../../Users/chiburashka/.codex/worktrees/4806/site/node_modules/preact/dist/preact.module.js
  init_define_import_meta_env();
  var n;
  var l;
  var u;
  var t;
  var i;
  var r;
  var o;
  var e;
  var f;
  var c;
  var a;
  var s;
  var h;
  var p;
  var v;
  var y;
  var d = {};
  var w = [];
  var _ = /acit|ex(?:s|g|n|p|$)|rph|grid|ows|mnc|ntw|ine[ch]|zoo|^ord|itera/i;
  var g = Array.isArray;
  function m(n2, l3) {
    for (var u4 in l3) n2[u4] = l3[u4];
    return n2;
  }
  function b(n2) {
    n2 && n2.parentNode && n2.parentNode.removeChild(n2);
  }
  function k(l3, u4, t3) {
    var i3, r3, o3, e3 = {};
    for (o3 in u4) "key" == o3 ? i3 = u4[o3] : "ref" == o3 ? r3 = u4[o3] : e3[o3] = u4[o3];
    if (arguments.length > 2 && (e3.children = arguments.length > 3 ? n.call(arguments, 2) : t3), "function" == typeof l3 && null != l3.defaultProps) for (o3 in l3.defaultProps) void 0 === e3[o3] && (e3[o3] = l3.defaultProps[o3]);
    return x(l3, e3, i3, r3, null);
  }
  function x(n2, t3, i3, r3, o3) {
    var e3 = { type: n2, props: t3, key: i3, ref: r3, __k: null, __: null, __b: 0, __e: null, __c: null, constructor: void 0, __v: null == o3 ? ++u : o3, __i: -1, __u: 0 };
    return null == o3 && null != l.vnode && l.vnode(e3), e3;
  }
  function S(n2) {
    return n2.children;
  }
  function C(n2, l3) {
    this.props = n2, this.context = l3;
  }
  function $(n2, l3) {
    if (null == l3) return n2.__ ? $(n2.__, n2.__i + 1) : null;
    for (var u4; l3 < n2.__k.length; l3++) if (null != (u4 = n2.__k[l3]) && null != u4.__e) return u4.__e;
    return "function" == typeof n2.type ? $(n2) : null;
  }
  function I(n2) {
    if (n2.__P && n2.__d) {
      var u4 = n2.__v, t3 = u4.__e, i3 = [], r3 = [], o3 = m({}, u4);
      o3.__v = u4.__v + 1, l.vnode && l.vnode(o3), q(n2.__P, o3, u4, n2.__n, n2.__P.namespaceURI, 32 & u4.__u ? [t3] : null, i3, null == t3 ? $(u4) : t3, !!(32 & u4.__u), r3), o3.__v = u4.__v, o3.__.__k[o3.__i] = o3, D(i3, o3, r3), u4.__e = u4.__ = null, o3.__e != t3 && P(o3);
    }
  }
  function P(n2) {
    if (null != (n2 = n2.__) && null != n2.__c) return n2.__e = n2.__c.base = null, n2.__k.some(function(l3) {
      if (null != l3 && null != l3.__e) return n2.__e = n2.__c.base = l3.__e;
    }), P(n2);
  }
  function A(n2) {
    (!n2.__d && (n2.__d = true) && i.push(n2) && !H.__r++ || r != l.debounceRendering) && ((r = l.debounceRendering) || o)(H);
  }
  function H() {
    try {
      for (var n2, l3 = 1; i.length; ) i.length > l3 && i.sort(e), n2 = i.shift(), l3 = i.length, I(n2);
    } finally {
      i.length = H.__r = 0;
    }
  }
  function L(n2, l3, u4, t3, i3, r3, o3, e3, f4, c3, a3) {
    var s3, h3, p3, v3, y3, _2, g2, m3 = t3 && t3.__k || w, b2 = l3.length;
    for (f4 = T(u4, l3, m3, f4, b2), s3 = 0; s3 < b2; s3++) null != (p3 = u4.__k[s3]) && (h3 = -1 != p3.__i && m3[p3.__i] || d, p3.__i = s3, _2 = q(n2, p3, h3, i3, r3, o3, e3, f4, c3, a3), v3 = p3.__e, p3.ref && h3.ref != p3.ref && (h3.ref && J(h3.ref, null, p3), a3.push(p3.ref, p3.__c || v3, p3)), null == y3 && null != v3 && (y3 = v3), (g2 = !!(4 & p3.__u)) || h3.__k === p3.__k ? (f4 = j(p3, f4, n2, g2), g2 && h3.__e && (h3.__e = null)) : "function" == typeof p3.type && void 0 !== _2 ? f4 = _2 : v3 && (f4 = v3.nextSibling), p3.__u &= -7);
    return u4.__e = y3, f4;
  }
  function T(n2, l3, u4, t3, i3) {
    var r3, o3, e3, f4, c3, a3 = u4.length, s3 = a3, h3 = 0;
    for (n2.__k = new Array(i3), r3 = 0; r3 < i3; r3++) null != (o3 = l3[r3]) && "boolean" != typeof o3 && "function" != typeof o3 ? ("string" == typeof o3 || "number" == typeof o3 || "bigint" == typeof o3 || o3.constructor == String ? o3 = n2.__k[r3] = x(null, o3, null, null, null) : g(o3) ? o3 = n2.__k[r3] = x(S, { children: o3 }, null, null, null) : void 0 === o3.constructor && o3.__b > 0 ? o3 = n2.__k[r3] = x(o3.type, o3.props, o3.key, o3.ref ? o3.ref : null, o3.__v) : n2.__k[r3] = o3, f4 = r3 + h3, o3.__ = n2, o3.__b = n2.__b + 1, e3 = null, -1 != (c3 = o3.__i = O(o3, u4, f4, s3)) && (s3--, (e3 = u4[c3]) && (e3.__u |= 2)), null == e3 || null == e3.__v ? (-1 == c3 && (i3 > a3 ? h3-- : i3 < a3 && h3++), "function" != typeof o3.type && (o3.__u |= 4)) : c3 != f4 && (c3 == f4 - 1 ? h3-- : c3 == f4 + 1 ? h3++ : (c3 > f4 ? h3-- : h3++, o3.__u |= 4))) : n2.__k[r3] = null;
    if (s3) for (r3 = 0; r3 < a3; r3++) null != (e3 = u4[r3]) && 0 == (2 & e3.__u) && (e3.__e == t3 && (t3 = $(e3)), K(e3, e3));
    return t3;
  }
  function j(n2, l3, u4, t3) {
    var i3, r3;
    if ("function" == typeof n2.type) {
      for (i3 = n2.__k, r3 = 0; i3 && r3 < i3.length; r3++) i3[r3] && (i3[r3].__ = n2, l3 = j(i3[r3], l3, u4, t3));
      return l3;
    }
    n2.__e != l3 && (t3 && (l3 && n2.type && !l3.parentNode && (l3 = $(n2)), u4.insertBefore(n2.__e, l3 || null)), l3 = n2.__e);
    do {
      l3 = l3 && l3.nextSibling;
    } while (null != l3 && 8 == l3.nodeType);
    return l3;
  }
  function O(n2, l3, u4, t3) {
    var i3, r3, o3, e3 = n2.key, f4 = n2.type, c3 = l3[u4], a3 = null != c3 && 0 == (2 & c3.__u);
    if (null === c3 && null == e3 || a3 && e3 == c3.key && f4 == c3.type) return u4;
    if (t3 > (a3 ? 1 : 0)) {
      for (i3 = u4 - 1, r3 = u4 + 1; i3 >= 0 || r3 < l3.length; ) if (null != (c3 = l3[o3 = i3 >= 0 ? i3-- : r3++]) && 0 == (2 & c3.__u) && e3 == c3.key && f4 == c3.type) return o3;
    }
    return -1;
  }
  function z(n2, l3, u4) {
    "-" == l3[0] ? n2.setProperty(l3, null == u4 ? "" : u4) : n2[l3] = null == u4 ? "" : "number" != typeof u4 || _.test(l3) ? u4 : u4 + "px";
  }
  function N(n2, l3, u4, t3, i3) {
    var r3, o3;
    n: if ("style" == l3) if ("string" == typeof u4) n2.style.cssText = u4;
    else {
      if ("string" == typeof t3 && (n2.style.cssText = t3 = ""), t3) for (l3 in t3) u4 && l3 in u4 || z(n2.style, l3, "");
      if (u4) for (l3 in u4) t3 && u4[l3] == t3[l3] || z(n2.style, l3, u4[l3]);
    }
    else if ("o" == l3[0] && "n" == l3[1]) r3 = l3 != (l3 = l3.replace(s, "$1")), o3 = l3.toLowerCase(), l3 = o3 in n2 || "onFocusOut" == l3 || "onFocusIn" == l3 ? o3.slice(2) : l3.slice(2), n2.l || (n2.l = {}), n2.l[l3 + r3] = u4, u4 ? t3 ? u4[a] = t3[a] : (u4[a] = h, n2.addEventListener(l3, r3 ? v : p, r3)) : n2.removeEventListener(l3, r3 ? v : p, r3);
    else {
      if ("http://www.w3.org/2000/svg" == i3) l3 = l3.replace(/xlink(H|:h)/, "h").replace(/sName$/, "s");
      else if ("width" != l3 && "height" != l3 && "href" != l3 && "list" != l3 && "form" != l3 && "tabIndex" != l3 && "download" != l3 && "rowSpan" != l3 && "colSpan" != l3 && "role" != l3 && "popover" != l3 && l3 in n2) try {
        n2[l3] = null == u4 ? "" : u4;
        break n;
      } catch (n3) {
      }
      "function" == typeof u4 || (null == u4 || false === u4 && "-" != l3[4] ? n2.removeAttribute(l3) : n2.setAttribute(l3, "popover" == l3 && 1 == u4 ? "" : u4));
    }
  }
  function V(n2) {
    return function(u4) {
      if (this.l) {
        var t3 = this.l[u4.type + n2];
        if (null == u4[c]) u4[c] = h++;
        else if (u4[c] < t3[a]) return;
        return t3(l.event ? l.event(u4) : u4);
      }
    };
  }
  function q(n2, u4, t3, i3, r3, o3, e3, f4, c3, a3) {
    var s3, h3, p3, v3, y3, d3, _2, k3, x2, M, $2, I2, P2, A3, H2, T3, j3 = u4.type;
    if (void 0 !== u4.constructor) return null;
    128 & t3.__u && (c3 = !!(32 & t3.__u), o3 = [f4 = u4.__e = t3.__e]), (s3 = l.__b) && s3(u4);
    n: if ("function" == typeof j3) {
      h3 = e3.length;
      try {
        if (x2 = u4.props, M = j3.prototype && j3.prototype.render, $2 = (s3 = j3.contextType) && i3[s3.__c], I2 = s3 ? $2 ? $2.props.value : s3.__ : i3, t3.__c ? k3 = (p3 = u4.__c = t3.__c).__ = p3.__E : (M ? u4.__c = p3 = new j3(x2, I2) : (u4.__c = p3 = new C(x2, I2), p3.constructor = j3, p3.render = Q), $2 && $2.sub(p3), p3.state || (p3.state = {}), p3.__n = i3, v3 = p3.__d = true, p3.__h = [], p3._sb = []), M && null == p3.__s && (p3.__s = p3.state), M && null != j3.getDerivedStateFromProps && (p3.__s == p3.state && (p3.__s = m({}, p3.__s)), m(p3.__s, j3.getDerivedStateFromProps(x2, p3.__s))), y3 = p3.props, d3 = p3.state, p3.__v = u4, v3) M && null == j3.getDerivedStateFromProps && null != p3.componentWillMount && p3.componentWillMount(), M && null != p3.componentDidMount && p3.__h.push(p3.componentDidMount);
        else {
          if (M && null == j3.getDerivedStateFromProps && x2 !== y3 && null != p3.componentWillReceiveProps && p3.componentWillReceiveProps(x2, I2), u4.__v == t3.__v || !p3.__e && null != p3.shouldComponentUpdate && false === p3.shouldComponentUpdate(x2, p3.__s, I2)) {
            u4.__v != t3.__v && (p3.props = x2, p3.state = p3.__s, p3.__d = false), u4.__e = t3.__e, u4.__k = t3.__k, u4.__k.some(function(n3) {
              n3 && (n3.__ = u4);
            }), w.push.apply(p3.__h, p3._sb), p3._sb = [], p3.__h.length && e3.push(p3);
            break n;
          }
          null != p3.componentWillUpdate && p3.componentWillUpdate(x2, p3.__s, I2), M && null != p3.componentDidUpdate && p3.__h.push(function() {
            p3.componentDidUpdate(y3, d3, _2);
          });
        }
        if (p3.context = I2, p3.props = x2, p3.__P = n2, p3.__e = false, P2 = l.__r, A3 = 0, M) p3.state = p3.__s, p3.__d = false, P2 && P2(u4), s3 = p3.render(p3.props, p3.state, p3.context), w.push.apply(p3.__h, p3._sb), p3._sb = [];
        else do {
          p3.__d = false, P2 && P2(u4), s3 = p3.render(p3.props, p3.state, p3.context), p3.state = p3.__s;
        } while (p3.__d && ++A3 < 25);
        p3.state = p3.__s, null != p3.getChildContext && (i3 = m(m({}, i3), p3.getChildContext())), M && !v3 && null != p3.getSnapshotBeforeUpdate && (_2 = p3.getSnapshotBeforeUpdate(y3, d3)), H2 = null != s3 && s3.type === S && null == s3.key ? E(s3.props.children) : s3, f4 = L(n2, g(H2) ? H2 : [H2], u4, t3, i3, r3, o3, e3, f4, c3, a3), p3.base = u4.__e, u4.__u &= -161, p3.__h.length && e3.push(p3), k3 && (p3.__E = p3.__ = null);
      } catch (n3) {
        if (e3.length = h3, u4.__v = null, c3 || null != o3) {
          if (n3.then) {
            for (u4.__u |= c3 ? 160 : 128; f4 && 8 == f4.nodeType && f4.nextSibling; ) f4 = f4.nextSibling;
            null != o3 && (o3[o3.indexOf(f4)] = null), u4.__e = f4;
          } else if (null != o3) for (T3 = o3.length; T3--; ) b(o3[T3]);
        } else u4.__e = t3.__e;
        null == u4.__k && (u4.__k = t3.__k || []), n3.then || B(u4), l.__e(n3, u4, t3);
      }
    } else null == o3 && u4.__v == t3.__v ? (u4.__k = t3.__k, u4.__e = t3.__e) : f4 = u4.__e = G(t3.__e, u4, t3, i3, r3, o3, e3, c3, a3);
    return (s3 = l.diffed) && s3(u4), 128 & u4.__u ? void 0 : f4;
  }
  function B(n2) {
    n2 && (n2.__c && (n2.__c.__e = true), n2.__k && n2.__k.some(B));
  }
  function D(n2, u4, t3) {
    for (var i3 = 0; i3 < t3.length; i3++) J(t3[i3], t3[++i3], t3[++i3]);
    l.__c && l.__c(u4, n2), n2.some(function(u5) {
      try {
        n2 = u5.__h, u5.__h = [], n2.some(function(n3) {
          n3.call(u5);
        });
      } catch (n3) {
        l.__e(n3, u5.__v);
      }
    });
  }
  function E(n2) {
    return "object" != typeof n2 || null == n2 || n2.__b > 0 ? n2 : g(n2) ? n2.map(E) : void 0 !== n2.constructor ? null : m({}, n2);
  }
  function G(u4, t3, i3, r3, o3, e3, f4, c3, a3) {
    var s3, h3, p3, v3, y3, w3, _2, m3 = i3.props || d, k3 = t3.props, x2 = t3.type;
    if ("svg" == x2 ? o3 = "http://www.w3.org/2000/svg" : "math" == x2 ? o3 = "http://www.w3.org/1998/Math/MathML" : o3 || (o3 = "http://www.w3.org/1999/xhtml"), null != e3) {
      for (s3 = 0; s3 < e3.length; s3++) if ((y3 = e3[s3]) && "setAttribute" in y3 == !!x2 && (x2 ? y3.localName == x2 : 3 == y3.nodeType)) {
        u4 = y3, e3[s3] = null;
        break;
      }
    }
    if (null == u4) {
      if (null == x2) return document.createTextNode(k3);
      u4 = document.createElementNS(o3, x2, k3.is && k3), c3 && (l.__m && l.__m(t3, e3), c3 = false), e3 = null;
    }
    if (null == x2) m3 === k3 || c3 && u4.data == k3 || (u4.data = k3);
    else {
      if (e3 = "textarea" == x2 && null != k3.defaultValue ? null : e3 && n.call(u4.childNodes), !c3 && null != e3) for (m3 = {}, s3 = 0; s3 < u4.attributes.length; s3++) m3[(y3 = u4.attributes[s3]).name] = y3.value;
      for (s3 in m3) y3 = m3[s3], "dangerouslySetInnerHTML" == s3 ? p3 = y3 : "children" == s3 || s3 in k3 || "value" == s3 && "defaultValue" in k3 || "checked" == s3 && "defaultChecked" in k3 || N(u4, s3, null, y3, o3);
      for (s3 in k3) y3 = k3[s3], "children" == s3 ? v3 = y3 : "dangerouslySetInnerHTML" == s3 ? h3 = y3 : "value" == s3 ? w3 = y3 : "checked" == s3 ? _2 = y3 : c3 && "function" != typeof y3 || m3[s3] === y3 || N(u4, s3, y3, m3[s3], o3);
      if (h3) c3 || p3 && (h3.__html == p3.__html || h3.__html == u4.innerHTML) || (u4.innerHTML = h3.__html), t3.__k = [];
      else if (p3 && (u4.innerHTML = ""), L("template" == t3.type ? u4.content : u4, g(v3) ? v3 : [v3], t3, i3, r3, "foreignObject" == x2 ? "http://www.w3.org/1999/xhtml" : o3, e3, f4, e3 ? e3[0] : i3.__k && $(i3, 0), c3, a3), null != e3) for (s3 = e3.length; s3--; ) b(e3[s3]);
      c3 && "textarea" != x2 || (s3 = "value", "progress" == x2 && null == w3 ? u4.removeAttribute("value") : null != w3 && (w3 !== u4[s3] || "progress" == x2 && !w3 || "option" == x2 && w3 != m3[s3]) && N(u4, s3, w3, m3[s3], o3), s3 = "checked", null != _2 && _2 != u4[s3] && N(u4, s3, _2, m3[s3], o3));
    }
    return u4;
  }
  function J(n2, u4, t3) {
    try {
      if ("function" == typeof n2) {
        var i3 = "function" == typeof n2.__u;
        i3 && n2.__u(), i3 && null == u4 || (n2.__u = n2(u4));
      } else n2.current = u4;
    } catch (n3) {
      l.__e(n3, t3);
    }
  }
  function K(n2, u4, t3) {
    var i3, r3;
    if (l.unmount && l.unmount(n2), (i3 = n2.ref) && (i3.current && i3.current != n2.__e || J(i3, null, u4)), null != (i3 = n2.__c)) {
      if (i3.componentWillUnmount) try {
        i3.componentWillUnmount();
      } catch (n3) {
        l.__e(n3, u4);
      }
      i3.base = i3.__P = i3.__n = null;
    }
    if (i3 = n2.__k) for (r3 = 0; r3 < i3.length; r3++) i3[r3] && K(i3[r3], u4, t3 || "function" != typeof n2.type);
    t3 || b(n2.__e), n2.__c = n2.__ = n2.__e = void 0;
  }
  function Q(n2, l3, u4) {
    return this.constructor(n2, u4);
  }
  function R(u4, t3, i3) {
    var r3, o3, e3, f4;
    t3 == document && (t3 = document.documentElement), l.__ && l.__(u4, t3), o3 = (r3 = "function" == typeof i3) ? null : i3 && i3.__k || t3.__k, e3 = [], f4 = [], q(t3, u4 = (!r3 && i3 || t3).__k = k(S, null, [u4]), o3 || d, d, t3.namespaceURI, !r3 && i3 ? [i3] : o3 ? null : t3.firstChild ? n.call(t3.childNodes) : null, e3, !r3 && i3 ? i3 : o3 ? o3.__e : t3.firstChild, r3, f4), D(e3, u4, f4), u4.props.children = null;
  }
  n = w.slice, l = { __e: function(n2, l3, u4, t3) {
    for (var i3, r3, o3; l3 = l3.__; ) if ((i3 = l3.__c) && !i3.__) try {
      if ((r3 = i3.constructor) && null != r3.getDerivedStateFromError && (i3.setState(r3.getDerivedStateFromError(n2)), o3 = i3.__d), null != i3.componentDidCatch && (i3.componentDidCatch(n2, t3 || {}), o3 = i3.__d), o3) return i3.__E = i3;
    } catch (l4) {
      n2 = l4;
    }
    throw n2;
  } }, u = 0, t = function(n2) {
    return null != n2 && void 0 === n2.constructor;
  }, C.prototype.setState = function(n2, l3) {
    var u4;
    u4 = null != this.__s && this.__s != this.state ? this.__s : this.__s = m({}, this.state), "function" == typeof n2 && (n2 = n2(m({}, u4), this.props)), n2 && m(u4, n2), null != n2 && this.__v && (l3 && this._sb.push(l3), A(this));
  }, C.prototype.forceUpdate = function(n2) {
    this.__v && (this.__e = true, n2 && this.__h.push(n2), A(this));
  }, C.prototype.render = S, i = [], o = "function" == typeof Promise ? Promise.prototype.then.bind(Promise.resolve()) : setTimeout, e = function(n2, l3) {
    return n2.__v.__b - l3.__v.__b;
  }, H.__r = 0, f = Math.random().toString(8), c = "__d" + f, a = "__a" + f, s = /(PointerCapture)$|Capture$/i, h = 0, p = V(false), v = V(true), y = 0;

  // src/islands/PostChartDailyBrief.tsx
  init_define_import_meta_env();

  // ../../../Users/chiburashka/.codex/worktrees/4806/site/node_modules/preact/hooks/dist/hooks.module.js
  init_define_import_meta_env();
  var t2;
  var r2;
  var u2;
  var i2;
  var o2 = 0;
  var f2 = [];
  var c2 = l;
  var e2 = c2.__b;
  var a2 = c2.__r;
  var v2 = c2.diffed;
  var l2 = c2.__c;
  var m2 = c2.unmount;
  var p2 = c2.__;
  function s2(n2, t3) {
    c2.__h && c2.__h(r2, n2, o2 || t3), o2 = 0;
    var u4 = r2.__H || (r2.__H = { __: [], __h: [] });
    return n2 >= u4.__.length && u4.__.push({}), u4.__[n2];
  }
  function d2(n2) {
    return o2 = 1, y2(D2, n2);
  }
  function y2(n2, u4, i3) {
    var o3 = s2(t2++, 2);
    if (o3.t = n2, !o3.__c && (o3.__ = [i3 ? i3(u4) : D2(void 0, u4), function(n3) {
      var t3 = o3.__N ? o3.__N[0] : o3.__[0], r3 = o3.t(t3, n3);
      t3 !== r3 && (o3.__N = [r3, o3.__[1]], o3.__c.setState({}));
    }], o3.__c = r2, !r2.__f)) {
      var f4 = function(n3, t3, r3) {
        if (!o3.__c.__H) return true;
        var u5 = false, i4 = o3.__c.props !== n3;
        if (o3.__c.__H.__.some(function(n4) {
          if (n4.__N) {
            u5 = true;
            var t4 = n4.__[0];
            n4.__ = n4.__N, n4.__N = void 0, t4 !== n4.__[0] && (i4 = true);
          }
        }), c3) {
          var f5 = c3.call(this, n3, t3, r3);
          return u5 ? f5 || i4 : f5;
        }
        return !u5 || i4;
      };
      r2.__f = true;
      var c3 = r2.shouldComponentUpdate, e3 = r2.componentWillUpdate;
      r2.componentWillUpdate = function(n3, t3, r3) {
        if (this.__e) {
          var u5 = c3;
          c3 = void 0, f4(n3, t3, r3), c3 = u5;
        }
        e3 && e3.call(this, n3, t3, r3);
      }, r2.shouldComponentUpdate = f4;
    }
    return o3.__N || o3.__;
  }
  function h2(n2, u4) {
    var i3 = s2(t2++, 3);
    !c2.__s && C2(i3.__H, u4) && (i3.__ = n2, i3.u = u4, r2.__H.__h.push(i3));
  }
  function A2(n2) {
    return o2 = 5, T2(function() {
      return { current: n2 };
    }, []);
  }
  function T2(n2, r3) {
    var u4 = s2(t2++, 7);
    return C2(u4.__H, r3) && (u4.__ = n2(), u4.__H = r3, u4.__h = n2), u4.__;
  }
  function j2() {
    for (var n2; n2 = f2.shift(); ) {
      var t3 = n2.__H;
      if (n2.__P && t3) try {
        t3.__h.some(z2), t3.__h.some(B2), t3.__h = [];
      } catch (r3) {
        t3.__h = [], c2.__e(r3, n2.__v);
      }
    }
  }
  c2.__b = function(n2) {
    r2 = null, e2 && e2(n2);
  }, c2.__ = function(n2, t3) {
    n2 && t3.__k && t3.__k.__m && (n2.__m = t3.__k.__m), p2 && p2(n2, t3);
  }, c2.__r = function(n2) {
    a2 && a2(n2), t2 = 0;
    var i3 = (r2 = n2.__c).__H;
    i3 && (u2 === r2 ? (i3.__h = [], r2.__h = [], i3.__.some(function(n3) {
      n3.__N && (n3.__ = n3.__N), n3.u = n3.__N = void 0;
    })) : (i3.__h.length && j2(), t2 = 0)), u2 = r2;
  }, c2.diffed = function(n2) {
    v2 && v2(n2);
    var t3 = n2.__c;
    t3 && t3.__H && (t3.__H.__h.length && (1 !== f2.push(t3) && i2 === c2.requestAnimationFrame || ((i2 = c2.requestAnimationFrame) || w2)(j2)), t3.__H.__.some(function(n3) {
      n3.u && (n3.__H = n3.u, n3.u = void 0);
    })), u2 = r2 = null;
  }, c2.__c = function(n2, t3) {
    t3.some(function(n3) {
      try {
        n3.__h.some(z2), n3.__h = n3.__h.filter(function(n4) {
          return !n4.__ || B2(n4);
        });
      } catch (r3) {
        t3.some(function(n4) {
          n4.__h && (n4.__h = []);
        }), t3 = [], c2.__e(r3, n3.__v);
      }
    }), l2 && l2(n2, t3);
  }, c2.unmount = function(n2) {
    m2 && m2(n2);
    var t3, r3 = n2.__c;
    r3 && r3.__H && (r3.__H.__.some(function(n3) {
      try {
        z2(n3);
      } catch (n4) {
        t3 = n4;
      }
    }), r3.__H = void 0, t3 && c2.__e(t3, r3.__v));
  };
  var k2 = "function" == typeof requestAnimationFrame;
  function w2(n2) {
    var t3, r3 = function() {
      clearTimeout(u4), k2 && cancelAnimationFrame(t3), setTimeout(n2);
    }, u4 = setTimeout(r3, 35);
    k2 && (t3 = requestAnimationFrame(r3));
  }
  function z2(n2) {
    var t3 = r2, u4 = n2.__c;
    "function" == typeof u4 && (n2.__c = void 0, u4()), r2 = t3;
  }
  function B2(n2) {
    var t3 = r2;
    n2.__c = n2.__(), r2 = t3;
  }
  function C2(n2, t3) {
    return !n2 || n2.length !== t3.length || t3.some(function(t4, r3) {
      return t4 !== n2[r3];
    });
  }
  function D2(n2, t3) {
    return "function" == typeof t3 ? t3(n2) : t3;
  }

  // src/islands/PostChartDailyBrief.tsx
  init_profile_access_reader();

  // src/lib/hooks/useProfileAccessGeneration.ts
  init_define_import_meta_env();
  init_profile_access_reader();
  function useProfileAccessGeneration(onRevoke) {
    const generation = A2(0);
    const onRevokeRef = A2(onRevoke);
    onRevokeRef.current = onRevoke;
    h2(() => {
      const onAccess = () => {
        generation.current += 1;
        if (!profileAccessAllowed()) onRevokeRef.current();
      };
      window.addEventListener("zodiacs:profile-access", onAccess);
      return () => window.removeEventListener("zodiacs:profile-access", onAccess);
    }, []);
    return generation;
  }

  // src/lib/email/post-chart-state.ts
  init_define_import_meta_env();
  function derivePostChartDailyState({
    authenticated,
    currentChartId,
    syncedChartIds,
    preference
  }) {
    if (!authenticated) return { kind: "device-only" };
    const synced = new Set(syncedChartIds);
    if (preference.paused) {
      return preference.chartId === null && !preference.pending && preference.enabled !== preference.requiresConfirmation && Boolean(preference.timezone) && Boolean(preference.confirmedAt) ? { kind: "paused" } : null;
    }
    if (preference.enabled && !preference.pending && !preference.paused && !preference.requiresConfirmation && preference.chartId && preference.timezone && preference.confirmedAt && !synced.has(preference.chartId)) {
      return { kind: "paused" };
    }
    if (!currentChartId) return { kind: "device-only" };
    if (!synced.has(currentChartId)) return { kind: "signed-in-unsynced" };
    if (preference.pending) {
      if (preference.enabled || preference.paused || preference.requiresConfirmation || !preference.chartId || !preference.timezone || preference.confirmedAt !== null) {
        return null;
      }
      return {
        kind: "pending",
        chartId: preference.chartId,
        timezone: preference.timezone,
        maskedEmail: preference.maskedEmail
      };
    }
    if (preference.requiresConfirmation) {
      if (preference.enabled || preference.pending || !preference.chartId || !preference.timezone || !preference.confirmedAt) {
        return null;
      }
      return synced.has(preference.chartId) ? { kind: "synced-eligible", chartId: currentChartId } : { kind: "paused" };
    }
    if (preference.enabled) {
      if (!preference.timezone || !preference.confirmedAt) return null;
      if (preference.paused) return null;
      if (!preference.chartId) return null;
      return synced.has(preference.chartId) ? { kind: "active", chartId: preference.chartId } : { kind: "paused" };
    }
    if (preference.paused || preference.requiresConfirmation || preference.chartId !== null || preference.timezone !== null || preference.confirmedAt !== null) {
      return null;
    }
    return { kind: "synced-eligible", chartId: currentChartId };
  }
  function postChartStateShowsSunCapture(state) {
    return state.kind !== "active" && state.kind !== "paused";
  }

  // src/lib/profile/post-chart-context.ts
  init_define_import_meta_env();
  var UUID = /^[0-9a-f]{8}-[0-9a-f]{4}-[1-8][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;
  function isPostChartContext(value) {
    if (!value || typeof value !== "object") return false;
    const context = value;
    return context.mode === "full" && Number.isSafeInteger(context.contextId) && (context.sunSign === null || typeof context.sunSign === "string") && (context.chartId === null || typeof context.chartId === "string" && UUID.test(context.chartId));
  }
  function clearPostChartContext() {
    if (typeof window === "undefined") return;
    delete window.zodiacsPostChartContext;
    window.dispatchEvent(new Event("zodiacs:chart-context-cleared"));
  }
  function publishPostChartContext(context) {
    if (typeof window === "undefined") return;
    window.zodiacsPostChartContext = context;
    window.dispatchEvent(new CustomEvent("zodiacs:chart-context", {
      detail: context
    }));
  }
  function currentPostChartContext() {
    if (typeof window === "undefined") return null;
    const context = window.zodiacsPostChartContext;
    return isPostChartContext(context) ? context : null;
  }

  // ../../../Users/chiburashka/.codex/worktrees/4806/site/node_modules/preact/jsx-runtime/dist/jsxRuntime.module.js
  init_define_import_meta_env();
  var f3 = 0;
  function u3(e3, t3, n2, o3, i3, u4) {
    t3 || (t3 = {});
    var a3, c3, p3 = t3;
    if ("ref" in p3) for (c3 in p3 = {}, t3) "ref" == c3 ? a3 = t3[c3] : p3[c3] = t3[c3];
    var l3 = { type: e3, props: p3, key: n2, ref: a3, __k: null, __: null, __b: 0, __e: null, __c: null, constructor: void 0, __v: --f3, __i: -1, __u: 0, __source: i3, __self: u4 };
    if ("function" == typeof e3 && (a3 = e3.defaultProps)) for (c3 in a3) void 0 === p3[c3] && (p3[c3] = a3[c3]);
    return l.vnode && l.vnode(l3), l3;
  }

  // src/islands/PostChartDailyBrief.tsx
  var COPY = {
    syncedTitle: "This chart can have its own daily brief.",
    syncedCta: "Set it up in your profile",
    pendingTitle: "Almost on.",
    pendingAddressChanged: "A confirmation is still pending. Resend the link to your current account email, then confirm it to begin the daily brief.",
    pendingResend: "Resend the link",
    pendingAgain: "Another confirmation link is on its way. The newest link is the one that works.",
    activeLink: "Manage it in your profile.",
    pausedTitle: "Your daily brief is paused.",
    pausedBody: "The chart it read was deleted, so delivery stopped. Choose another synced chart whenever you\u2019re ready \u2014 nothing is chosen for you.",
    pausedCta: "Choose in your profile",
    error: "Couldn't resend the link. Please try again."
  };
  function isStableView(view) {
    return view.kind !== "idle" && view.kind !== "unavailable";
  }
  function fallbackChartName(current) {
    return current ? "this saved chart" : "your selected chart";
  }
  function PostChartDailyBrief({ idPrefix }) {
    const [view, setView] = d2({ kind: "idle" });
    const [resendBusy, setResendBusy] = d2(false);
    const [resendStatus, setResendStatus] = d2("");
    const rootRef = A2(null);
    const resendButtonRef = A2(null);
    const contextRef = A2(null);
    const sessionRef = A2(null);
    const generationRef = A2(0);
    const profileAccessGeneration = useProfileAccessGeneration(() => {
      generationRef.current += 1;
      sessionRef.current = null;
      setView({ kind: "idle" });
      setResendBusy(false);
      setResendStatus("");
    });
    async function resolveContext(context, suppliedSession, options = {}) {
      if (!document.documentElement.hasAttribute("data-daily-email-lifecycle")) return;
      const generation = ++generationRef.current;
      const accessGeneration = profileAccessGeneration.current;
      const requestIsCurrent = () => generation === generationRef.current && accessGeneration === profileAccessGeneration.current && context.contextId === contextRef.current?.contextId && profileAccessAllowed();
      if (!options.preserveStable) setView({ kind: "idle" });
      setResendStatus("");
      try {
        const [sync, daily, store] = await Promise.all([
          Promise.resolve().then(() => (init_sync(), sync_exports)),
          Promise.resolve().then(() => (init_daily_email_client(), daily_email_client_exports)),
          Promise.resolve().then(() => (init_store(), store_exports))
        ]);
        if (!requestIsCurrent()) return;
        const session = suppliedSession === void 0 ? await sync.getSyncSession() : suppliedSession;
        if (!requestIsCurrent()) return;
        sessionRef.current = session;
        if (!session) {
          setView({ kind: "device-only" });
          return;
        }
        const [syncedChartIds, preference] = await Promise.all([
          daily.getSyncedChartIds(session.user.id),
          daily.getDailyChartPreference(session.access_token)
        ]);
        if (!requestIsCurrent()) return;
        const state = derivePostChartDailyState({
          authenticated: true,
          currentChartId: context.chartId,
          syncedChartIds,
          preference
        });
        if (!state) {
          setView({ kind: "unavailable" });
          return;
        }
        const chartNames = new Map(store.loadProfile().charts.map((chart) => [chart.id, chart.name]));
        if (state.kind === "synced-eligible") {
          setView({
            ...state,
            chartName: chartNames.get(state.chartId) ?? fallbackChartName(true)
          });
        } else if (state.kind === "active") {
          setView({
            ...state,
            chartName: chartNames.get(state.chartId) ?? fallbackChartName(state.chartId === context.chartId)
          });
        } else {
          setView(state);
        }
        if (state.kind === "pending" && options.pendingStatus) {
          setResendStatus(options.pendingStatus);
        }
      } catch {
        if (requestIsCurrent()) setView({ kind: "unavailable" });
      }
    }
    h2(() => {
      if (!document.documentElement.hasAttribute("data-daily-email-lifecycle")) return;
      let active = true;
      let unsubscribe = () => {
      };
      const onClear = () => {
        generationRef.current += 1;
        contextRef.current = null;
        sessionRef.current = null;
        setView({ kind: "idle" });
        setResendBusy(false);
        setResendStatus("");
      };
      const onComputed = (event) => {
        const detail = event.detail;
        if (detail?.mode !== "full") return;
        onClear();
      };
      const onContext = (event) => {
        const context = event.detail;
        if (!isPostChartContext(context)) return;
        contextRef.current = context;
        void resolveContext(context);
      };
      const refresh = () => {
        const context = contextRef.current;
        if (context) void resolveContext(context, sessionRef.current, { preserveStable: true });
      };
      const onProfileAccess = () => {
        const context = contextRef.current;
        if (context && profileAccessAllowed()) {
          void resolveContext(context, void 0, { preserveStable: true });
        }
      };
      window.addEventListener("zodiacs:chart-computed", onComputed);
      window.addEventListener("zodiacs:chart-context-cleared", onClear);
      window.addEventListener("zodiacs:chart-context", onContext);
      window.addEventListener("zodiacs:profile-synced", refresh);
      window.addEventListener("zodiacs:profile-access", onProfileAccess);
      const initial = currentPostChartContext();
      if (initial) {
        contextRef.current = initial;
        void resolveContext(initial);
      }
      void Promise.resolve().then(() => (init_sync(), sync_exports)).then((sync) => {
        if (!active) return;
        unsubscribe = sync.onSyncAuthChange((session) => {
          sessionRef.current = session;
          const context = contextRef.current;
          if (context) void resolveContext(context, session, { preserveStable: true });
        });
      }).catch(() => {
      });
      return () => {
        active = false;
        generationRef.current += 1;
        contextRef.current = null;
        sessionRef.current = null;
        unsubscribe();
        window.removeEventListener("zodiacs:chart-computed", onComputed);
        window.removeEventListener("zodiacs:chart-context-cleared", onClear);
        window.removeEventListener("zodiacs:chart-context", onContext);
        window.removeEventListener("zodiacs:profile-synced", refresh);
        window.removeEventListener("zodiacs:profile-access", onProfileAccess);
      };
    }, []);
    h2(() => {
      const root = rootRef.current;
      const shell = root?.closest("[data-email-capture-shell]");
      if (!root || !shell) return;
      const copy = shell.querySelector(".email-capture__copy");
      const form = shell.querySelector("[data-email-capture]");
      const note = shell.querySelector("[data-post-chart-device-note]");
      if (!isStableView(view)) {
        shell.hidden = true;
        shell.setAttribute("aria-busy", "true");
        delete shell.dataset.postChartState;
        return;
      }
      const showSun = postChartStateShowsSunCapture(view);
      const submit = form?.querySelector(".email-capture__submit");
      const sunIsSecondary = view.kind === "synced-eligible";
      if (copy) copy.hidden = !showSun;
      if (form) form.hidden = !showSun;
      if (submit) {
        submit.classList.toggle("btn--primary", !sunIsSecondary);
        submit.classList.toggle("btn--ghost", sunIsSecondary);
      }
      if (note) note.hidden = view.kind !== "device-only" && view.kind !== "signed-in-unsynced";
      shell.dataset.postChartState = view.kind;
      shell.removeAttribute("aria-busy");
      if (view.kind === "device-only" || view.kind === "signed-in-unsynced") {
        shell.setAttribute("aria-labelledby", `${idPrefix}-title`);
        shell.removeAttribute("aria-label");
      } else if (view.kind === "active") {
        shell.removeAttribute("aria-labelledby");
        shell.setAttribute("aria-label", "Personal daily brief");
      } else {
        shell.setAttribute("aria-labelledby", `${idPrefix}-post-title`);
        shell.removeAttribute("aria-label");
      }
      shell.hidden = false;
    }, [idPrefix, view]);
    async function resendPending() {
      if (view.kind !== "pending" || !sessionRef.current || !contextRef.current) return;
      const startingContext = contextRef.current;
      const startingSession = sessionRef.current;
      const accessGeneration = profileAccessGeneration.current;
      const requestIsCurrent = () => accessGeneration === profileAccessGeneration.current && contextRef.current === startingContext && sessionRef.current === startingSession && profileAccessAllowed();
      let restoreFocus = false;
      setResendBusy(true);
      setResendStatus("");
      try {
        const daily = await Promise.resolve().then(() => (init_daily_email_client(), daily_email_client_exports));
        if (!requestIsCurrent()) return;
        await daily.resendDailyChartPreference(startingSession.access_token);
        if (!requestIsCurrent()) return;
        await resolveContext(startingContext, startingSession, {
          preserveStable: true,
          pendingStatus: COPY.pendingAgain
        });
        restoreFocus = requestIsCurrent();
      } catch {
        if (!requestIsCurrent()) return;
        await resolveContext(startingContext, startingSession, {
          preserveStable: true,
          pendingStatus: COPY.error
        });
        restoreFocus = requestIsCurrent();
      } finally {
        if (!requestIsCurrent()) return;
        setResendBusy(false);
        if (restoreFocus) {
          const generation = generationRef.current;
          requestAnimationFrame(() => {
            if (generation === generationRef.current && requestIsCurrent()) {
              resendButtonRef.current?.focus({ preventScroll: true });
            }
          });
        }
      }
    }
    let content = null;
    if (view.kind === "synced-eligible") {
      content = /* @__PURE__ */ u3(S, { children: [
        /* @__PURE__ */ u3("h2", { id: `${idPrefix}-post-title`, children: COPY.syncedTitle }),
        /* @__PURE__ */ u3("p", { children: [
          "A personal morning email for",
          " ",
          /* @__PURE__ */ u3("span", { class: "post-chart-daily__inline-value", title: view.chartName, children: view.chartName }),
          " ",
          "\u2014 where each day\u2019s sky touches its saved placements, not just its Sun sign."
        ] }),
        /* @__PURE__ */ u3("div", { class: "post-chart-daily__actions", children: /* @__PURE__ */ u3("a", { class: "btn btn--primary", href: "/profile/#daily-brief", children: COPY.syncedCta }) })
      ] });
    } else if (view.kind === "pending") {
      content = /* @__PURE__ */ u3(S, { children: [
        /* @__PURE__ */ u3("h2", { id: `${idPrefix}-post-title`, children: COPY.pendingTitle }),
        view.maskedEmail ? /* @__PURE__ */ u3("p", { class: "post-chart-daily__status-line", title: view.maskedEmail, children: [
          "Confirm from the email we sent to",
          " ",
          /* @__PURE__ */ u3("span", { class: "post-chart-daily__inline-value", title: view.maskedEmail, children: view.maskedEmail }),
          " ",
          "and the daily brief begins."
        ] }) : /* @__PURE__ */ u3("p", { children: COPY.pendingAddressChanged }),
        /* @__PURE__ */ u3("div", { class: "post-chart-daily__actions", children: /* @__PURE__ */ u3(
          "button",
          {
            ref: resendButtonRef,
            class: "btn btn--ghost",
            type: "button",
            disabled: resendBusy,
            "aria-busy": resendBusy,
            onClick: () => void resendPending(),
            children: COPY.pendingResend
          }
        ) }),
        /* @__PURE__ */ u3("p", { class: "post-chart-daily__status", role: "status", "aria-live": "polite", children: resendStatus })
      ] });
    } else if (view.kind === "active") {
      content = /* @__PURE__ */ u3("p", { class: "post-chart-daily__active", children: [
        /* @__PURE__ */ u3("span", { class: "post-chart-daily__status-line", title: view.chartName, children: [
          "The personal daily brief is on for ",
          view.chartName,
          "."
        ] }),
        " ",
        /* @__PURE__ */ u3("a", { href: "/profile/#daily-brief", children: COPY.activeLink })
      ] });
    } else if (view.kind === "paused") {
      content = /* @__PURE__ */ u3(S, { children: [
        /* @__PURE__ */ u3("h2", { id: `${idPrefix}-post-title`, children: COPY.pausedTitle }),
        /* @__PURE__ */ u3("p", { children: COPY.pausedBody }),
        /* @__PURE__ */ u3("div", { class: "post-chart-daily__actions", children: /* @__PURE__ */ u3("a", { class: "btn btn--primary", href: "/profile/#daily-brief", children: COPY.pausedCta }) })
      ] });
    }
    const panelVisible = view.kind === "synced-eligible" || view.kind === "pending" || view.kind === "active" || view.kind === "paused";
    return /* @__PURE__ */ u3(
      "div",
      {
        ref: rootRef,
        class: `post-chart-daily${panelVisible ? " post-chart-daily--visible" : ""}`,
        "data-post-chart-controller": true,
        "data-post-chart-panel": panelVisible ? view.kind : void 0,
        hidden: !panelVisible,
        children: content
      }
    );
  }

  // <stdin>
  window.fixture = {
    reads: [],
    analytics: [],
    clearEvents: [],
    session: { access_token: "synthetic-local-token", user: { id: "10000000-0000-4000-8000-000000000001" } },
    sessionHold: null,
    auth: null,
    focusFrames: [],
    holdFocus: false,
    holdSession() {
      let done;
      const promise = new Promise((resolve) => done = resolve);
      this.sessionHold = { promise, done };
    },
    releaseSession() {
      const old = this.sessionHold;
      this.sessionHold = null;
      old?.done(this.session);
    },
    async getSession() {
      this.reads.push("session");
      return this.sessionHold ? this.sessionHold.promise : this.session;
    },
    ids() {
      this.reads.push("ids");
      return Promise.resolve({ data: [{ id: "10000000-0000-4000-8000-000000000001" }], error: null });
    },
    clear() {
      clearPostChartContext();
    },
    publish(contextId = 1, sunSign = "cancer") {
      const context = { mode: "full", sunSign, chartId: "10000000-0000-4000-8000-000000000001", contextId };
      dispatchEvent(new CustomEvent("zodiacs:chart-computed", { detail: context }));
      publishPostChartContext(context);
    },
    refresh() {
      dispatchEvent(new Event("zodiacs:profile-synced"));
      dispatchEvent(new Event("zodiacs:profile-access"));
      this.auth?.(this.session);
    },
    mount() {
      R(k(PostChartDailyBrief, { idPrefix: "managed" }), document.getElementById("controller"));
    },
    unmount() {
      R(null, document.getElementById("controller"));
    },
    releaseFocus() {
      this.holdFocus = false;
      for (const callback of this.focusFrames.splice(0)) callback(performance.now());
    }
  };
  window.zodiacsAnalytics = { track: (name, props) => window.fixture.analytics.push({ name, props }) };
  addEventListener("zodiacs:chart-context-cleared", (event) => window.fixture.clearEvents.push({ type: event.type, detail: event.detail, globalAbsent: window.zodiacsPostChartContext === void 0 }));
  var nativeFrame = requestAnimationFrame;
  window.requestAnimationFrame = (callback) => window.fixture.holdFocus && callback.toString().includes("focus") ? (window.fixture.focusFrames.push(callback), -1) : nativeFrame(callback);
  window.fixture.mount();
  var captureGenerations = /* @__PURE__ */ new WeakMap();
  var captureGeneration = (surface) => surface ? captureGenerations.get(surface) ?? 0 : 0;
  function advanceCapture(surface) {
    captureGenerations.set(surface, captureGeneration(surface) + 1);
    const button = surface.querySelector('button[type="submit"]');
    const status = surface.querySelector("[data-email-status]");
    if (button) {
      button.disabled = false;
      button.textContent = button.dataset.label ?? button.textContent;
    }
    if (status) status.textContent = "";
  }
  function trackCaptureView(surface) {
    if (surface.dataset.viewTracked === "true") return;
    surface.dataset.viewTracked = "true";
    window.zodiacsAnalytics?.track?.("email_capture_viewed", {
      placement: surface.dataset.placement ?? "unknown"
    });
  }
  var captureSurfaces = document.querySelectorAll("[data-email-capture-shell]");
  if ("IntersectionObserver" in window) {
    const captureObserver = new IntersectionObserver((entries, observer) => {
      entries.forEach((entry) => {
        if (!entry.isIntersecting) return;
        trackCaptureView(entry.target);
        observer.unobserve(entry.target);
      });
    }, { threshold: 0.2 });
    captureSurfaces.forEach((surface) => captureObserver.observe(surface));
  } else {
    captureSurfaces.forEach((surface) => {
      if (!surface.hidden) trackCaptureView(surface);
    });
  }
  function preselectCaptureSign(surface, sign) {
    if (!sign) return;
    const radios = Array.from(surface.querySelectorAll('input[name="sign"]'));
    const radio = radios.find((input) => input.value === sign);
    if (!radio) return;
    surface.dataset.personalizedSign = "true";
    radios.forEach((input) => {
      input.checked = input === radio;
      input.defaultChecked = input === radio;
    });
    renderCaptureSign(surface, radio, true);
  }
  function fillSignTemplate(template, signName) {
    return (template ?? "").replace("{sign}", signName);
  }
  function renderCaptureSign(surface, radio, collapse) {
    const title = surface.querySelector("[data-email-title]");
    const summary = surface.querySelector("[data-email-sign-summary]");
    const summaryCopy = surface.querySelector("[data-email-sign-summary-copy]");
    const chooser = surface.querySelector("[data-email-signs]");
    const change = surface.querySelector("[data-email-sign-change]");
    if (!title || !summary || !summaryCopy || !chooser || !change) return;
    const name = radio?.value ? radio.dataset.signName : void 0;
    if (!name) {
      title.textContent = title.dataset.defaultTitle ?? "";
      summary.hidden = true;
      chooser.hidden = false;
      change.setAttribute("aria-expanded", "true");
      return;
    }
    title.textContent = fillSignTemplate(title.dataset.personalTitle, name);
    summaryCopy.textContent = fillSignTemplate(summary.dataset.summaryTemplate, name);
    summary.hidden = false;
    chooser.hidden = collapse;
    change.setAttribute("aria-expanded", String(!collapse));
  }
  function setupSignChooser(surface) {
    if (surface.dataset.signChooserEnhanced === "true") return;
    const chooser = surface.querySelector("[data-email-signs]");
    const summary = surface.querySelector("[data-email-sign-summary]");
    const change = surface.querySelector("[data-email-sign-change]");
    if (!chooser || !summary || !change) return;
    surface.dataset.signChooserEnhanced = "true";
    change.addEventListener("click", () => {
      const generation = captureGeneration(surface);
      const selected = chooser.querySelector('input[name="sign"]:checked');
      const opening = chooser.hidden;
      renderCaptureSign(surface, selected ?? void 0, !opening);
      if (opening) requestAnimationFrame(() => {
        if (generation === captureGeneration(surface) && surface.isConnected && !surface.hidden) selected?.focus();
      });
    });
    chooser.addEventListener("change", (event) => {
      const radio = event.target.closest('input[name="sign"]');
      if (!radio || surface.dataset.personalizedSign !== "true") return;
      const radios = Array.from(chooser.querySelectorAll('input[name="sign"]'));
      radios.forEach((input) => {
        input.defaultChecked = input === radio;
      });
      renderCaptureSign(surface, radio, Boolean(radio.value));
      if (radio.value) change.focus({ preventScroll: true });
    });
    chooser.addEventListener("keydown", (event) => {
      if (event.key !== "Escape" || surface.dataset.personalizedSign !== "true") return;
      const selected = chooser.querySelector('input[name="sign"]:checked');
      if (!selected?.value) return;
      event.preventDefault();
      renderCaptureSign(surface, selected, true);
      change.focus({ preventScroll: true });
    });
  }
  function revealChartCapture(event) {
    const detail = event.detail;
    const mode = detail?.mode;
    if (mode !== "full") return;
    document.querySelectorAll('[data-reveal-on-chart="true"]').forEach((surface) => {
      advanceCapture(surface);
      preselectCaptureSign(surface, detail?.sunSign);
      const managed = surface.dataset.postChartManaged === "true" && document.documentElement.hasAttribute("data-daily-email-lifecycle");
      surface.hidden = managed;
    });
  }
  window.addEventListener("zodiacs:chart-computed", revealChartCapture);
  window.addEventListener("zodiacs:chart-context-cleared", () => {
    document.querySelectorAll('[data-reveal-on-chart="true"]').forEach((surface) => {
      advanceCapture(surface);
      surface.hidden = true;
    });
  });
  captureSurfaces.forEach(setupSignChooser);
  document.querySelectorAll("[data-email-capture]").forEach((form) => {
    if (form.dataset.enhanced === "true") return;
    form.dataset.enhanced = "true";
    form.addEventListener("reset", () => {
      const surface = form.closest("[data-email-capture-shell]");
      const generation = captureGeneration(surface);
      queueMicrotask(() => {
        if (!surface || !surface.isConnected || generation !== captureGeneration(surface) || surface.dataset.personalizedSign !== "true") return;
        const selected = form.querySelector('input[name="sign"]:checked');
        renderCaptureSign(surface, selected ?? void 0, Boolean(selected?.value));
      });
    });
    form.addEventListener("submit", async (event) => {
      event.preventDefault();
      const button = form.querySelector('button[type="submit"]');
      const status = form.querySelector("[data-email-status]");
      if (!button || !status) return;
      const email = form.querySelector('input[name="email"]');
      const selectedSign = form.querySelector('input[name="sign"]:checked');
      const surface = form.closest("[data-email-capture-shell]");
      const generation = captureGeneration(surface);
      const requestIsCurrent = () => form.isConnected && generation === captureGeneration(surface);
      if (!email?.validity.valid) {
        status.textContent = form.querySelector("[data-invalid-email-copy]")?.textContent ?? "";
        email?.reportValidity();
        email?.focus();
        return;
      }
      if (surface?.dataset.dailyCapture === "true" && !selectedSign?.value) {
        status.textContent = form.querySelector("[data-missing-sign-copy]")?.textContent ?? "";
        const chooser = form.querySelector("[data-email-signs]");
        if (chooser) chooser.hidden = false;
        form.querySelector('input[name="sign"]')?.focus();
        return;
      }
      if (!form.reportValidity()) return;
      const idle = button.dataset.label ?? button.textContent ?? "";
      button.disabled = true;
      button.textContent = button.dataset.busyLabel ?? idle;
      status.textContent = "";
      try {
        const response = await fetch(form.action, {
          method: "POST",
          headers: { Accept: "application/json" },
          body: new URLSearchParams(new FormData(form))
        });
        if (!response.ok) throw new Error("subscription unavailable");
        if (requestIsCurrent()) {
          status.textContent = form.querySelector("[data-success-copy]")?.textContent ?? "";
          if (surface?.dataset.dailyCapture === "true" && selectedSign?.value) {
            const radios = Array.from(form.querySelectorAll('input[name="sign"]'));
            radios.forEach((input) => {
              input.defaultChecked = input === selectedSign;
            });
            surface.dataset.personalizedSign = "true";
          }
          form.reset();
          if (surface?.dataset.dailyCapture === "true" && selectedSign?.value) {
            renderCaptureSign(surface, selectedSign, true);
          }
        }
        const placement = form.dataset.placement ?? "unknown";
        window.zodiacsAnalytics?.track?.("email_subscribed", { placement });
      } catch {
        if (requestIsCurrent()) status.textContent = form.querySelector("[data-error-copy]")?.textContent ?? "";
      } finally {
        if (requestIsCurrent()) {
          button.disabled = false;
          button.textContent = idle;
        }
      }
    });
  });
})();
